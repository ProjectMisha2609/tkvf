package main

import (
	"encoding/json"
	"flag"
	"io/ioutil"
	"log"
	"path/filepath"
	"regexp"
)

func main() {
	creatingArgs := parseArgs()
	pathIn := creatingArgs.path
	pathOut := creatingArgs.out
	log.Print("\n======================================\n", "GET PATH FROM ARGS", "\n======================================\n")
	log.Println("Path to Test result - ", pathIn)
	log.Println("Path to created report - ", pathOut)
	var resultsAllure = collectAllureResult(pathIn)
	var resultElma = genElmaReport(resultsAllure)
	writeInFile(pathOut, resultElma)
}

func writeInFile(pathOut string, resultJson []ElmaTestCaseResult) {
	file, err := json.Marshal(resultJson)
	if err != nil {
		panic(err)
	}
	err = ioutil.WriteFile(filepath.Join(pathOut, "elmaReport.json"), file, 0644)
	if err != nil {
		panic(err)
	}
}

func parseArgs() CreateReportArgs {
	pathIn := flag.String("path", "NONE", "Path to test results")
	pathOut := flag.String("out", ".", "Path to test results")
	flag.Parse()
	return CreateReportArgs{
		path: *pathIn,
		out:  *pathOut,
	}
}

func collectAllureResult(path string) *AllureReport {
	list, err := ioutil.ReadDir(path)
	if err != nil {
		log.Println("Not found path", path, err)
	}
	var resultArray = NewAllureReport()
	log.Print("\n======================================\n", "START COLLECT ALLURE RESULTS", "\n======================================\n")
	for _, fileName := range list {
		if fileName.IsDir() {
			log.Println("This is dir - ", fileName.Name())
			continue
		}
		regUuid, err := regexp.Compile("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}-result.json")
		if err != nil {
			log.Println("Trouble with Complie regex: ", err)
		}
		if regUuid.MatchString(fileName.Name()) { //файл с результатом соответсвует регулярному выражению с потфиксом -result
			absolutePath := filepath.Join(path, fileName.Name())
			file, err := ioutil.ReadFile(absolutePath)
			if err != nil {
				log.Fatal("Can not read file", absolutePath, err)
			}
			resultStruct := &AllureTestCaseResult{}
			errorJson := json.Unmarshal(file, resultStruct)
			if errorJson != nil {
				log.Fatal("Can't parse case resut err:", errorJson)
			}
			_, isHaveLink := checkLinkNameIsExist(*resultStruct)
			if isHaveLink {
				resultArray.AddAllureResult(*resultStruct)
			}
		}
	}
	log.Println("Found Allure results Tests with elmaTms Link: ", len(*resultArray))
	return resultArray
}

func genElmaReport(allureResult *AllureReport) []ElmaTestCaseResult {
	var results = make([]ElmaTestCaseResult, 0)
	log.Print("\n======================================\n", "START GENERATE ELMA REPORT", "\n======================================\n")
	for _, allureValue := range *allureResult {
		var linkIndex, isHaveLink = checkLinkNameIsExist(allureValue)
		if isHaveLink {
			var caseId = allureValue.Links[linkIndex].Name
			checkCaseStruct := checkResultContainsInElmaReportYet(results, allureValue, linkIndex)
			if checkCaseStruct.IsEqualsID && //Если айди кейсов равны
				checkCaseStruct.IsEqualsFullName && //Если полное имя кейсов совпадает
				checkCaseStruct.CaseIndex >= 0 && //Если индекс кейса >= 0
				allureValue.Stop >= results[checkCaseStruct.CaseIndex].Stop { //Если время завершение кейсов более новое
				results[checkCaseStruct.CaseIndex].CaseResult = allureValue.Status
				results[checkCaseStruct.CaseIndex].Message = allureValue.StatusDetails.Message
				results[checkCaseStruct.CaseIndex].Stop = allureValue.Stop
				results[checkCaseStruct.CaseIndex].FullName = allureValue.FullName
				results[checkCaseStruct.CaseIndex].Retry += 1
			}
			if len(results) == 0 || (checkCaseStruct.CaseIndex == 0 && checkCaseStruct.IsEqualsID == false && checkCaseStruct.IsEqualsFullName == false) {
				//Если массив пустой или кейса в нем нету то положить его туда
				results = append(results, ElmaTestCaseResult{
					CaseId:     caseId,
					CaseResult: allureValue.Status,
					Message:    allureValue.StatusDetails.Message,
					Stop:       allureValue.Stop,
					FullName:   allureValue.FullName,
					Retry:      1,
				})
			}
		}
	}
	log.Println("Genereate report json contains ", len(results), " test Cases")
	return results
}

func checkResultContainsInElmaReportYet(results []ElmaTestCaseResult, allureCase AllureTestCaseResult, linkIndex int) CheckCaseInElmaReport {
	for i, elementElma := range results {
		if elementElma.CaseId == allureCase.Links[linkIndex].Name && elementElma.FullName == allureCase.FullName {
			return CheckCaseInElmaReport{
				CaseIndex:        i,
				IsEqualsID:       true,
				IsEqualsFullName: true,
			}
		}
		if elementElma.CaseId == allureCase.Links[linkIndex].Name && elementElma.FullName != allureCase.FullName {
			log.Println("Found case have equals caseID but NOT equals FullName \ncase ID: ", allureCase.Links[linkIndex].Name, "\nfullName case 1: ", elementElma.FullName, "\nfullName case 2: ", allureCase.FullName)
			return CheckCaseInElmaReport{
				CaseIndex:        i,
				IsEqualsID:       true,
				IsEqualsFullName: false,
			}
		}
	}
	return CheckCaseInElmaReport{
		CaseIndex:        0,
		IsEqualsID:       false,
		IsEqualsFullName: false,
	}
}

func checkLinkNameIsExist(allureCase AllureTestCaseResult) (int, bool) {
	for i, link := range allureCase.Links {
		if link.Type == "elmaTms" && link.Name != "" {
			return i, true
		}
	}
	log.Println("Case have not link type \"elmaTms\"", allureCase.FullName)
	return 0, false
}

func (arr *AllureReport) AddAllureResult(testCase AllureTestCaseResult) {
	*arr = append(*arr, testCase)
}

func NewAllureReport() *AllureReport {
	var arr AllureReport
	return &arr
}

type (
	CheckCaseInElmaReport struct {
		CaseIndex        int
		IsEqualsID       bool
		IsEqualsFullName bool
	}
	CreateReportArgs struct {
		path string
		out  string
	}
	ElmaTestCaseResult struct {
		CaseId     string `json:"caseId"`
		CaseResult string `json:"caseResult"`
		Message    string `json:"message"`
		FullName   string `json:"fullName"`
		Stop       int64  `json:"stop"`
		Retry      int    `json:"retry"`
	}
	AllureTestCaseResult struct {
		FullName string `json:"fullName"`
		Links    []struct {
			Name string `json:"name"`
			Type string `json:"type"`
		} `json:"links"`
		Status        string `json:"status"`
		StatusDetails struct {
			Message string `json:"message"`
		} `json:"statusDetails"`
		Stop int64 `json:"stop"`
	}
	AllureReport []AllureTestCaseResult
)
