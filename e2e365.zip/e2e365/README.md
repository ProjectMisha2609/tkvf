**Локальный запуск**
  
* Восстановление состояния стенда, если есть бэкап  
`mvn clean -Dtest=OnPremRestorerTest test`  
* Запуск независимых тестов с перезапуском упавших тестов  
`mvn -Dsurefire.rerunFailingTestsCount=2 -Dgroups=express test`  
* Запуск зависимых тестов без перезапуска упавших тестов  
`mvn -Dtest=OrderedNestedTests test`
* Создание и открытие allure отчёта  
`mvn allure:serve`

**Запуск в gitlab ci**
-> пойти в [пайплайны](https://git.elewise.com/elma365/e2e365/-/pipelines)  
-> нажать RunPipeline  
-> Для запуска на существующей площадке в секции variables заполнить переменные  
- `ELMA_STAND_URL` адрес тестового стенда  
  *Примеры*  
  SaaS - `https://company_name.elma365.ru/`  
  OnPrem - `https://192.168.1.1/ или https://test.sale.elewise.local/`
- `ADMIN_LOGIN` почта пользователя для авторизации  
- `ADMIN_PASSWORD` пароль пользователя  
- `USER_LOGIN` логин пользователя не входящего в группу администраторы  
- `USER_PASSWORD` пароль пользователя не входящего в группу администраторы
- `GROUP_TESTS` (опционально), если не указано то запустятся группы express 

Список тегов групп, установленных на тестовые классы:

- `express` - группа для запуска тест плана "Экспресс тест" в эту группу входят все e2e автотесты
- `admin` - группа для запуска тестов из тест класса AdminTests
- `app_actions` - группа для запуска тестов из тест класса AppActionsTests
- `app` - группа для запуска тестов из тест класса ApplicationsTests
- `app_page` - группа для запуска тестов из тест класса AppTypePageTests
- `process` - группа для запуска тестов из тест класса BusinessProcessTests
- `calendar` - группа для запуска тестов из тест класса CalendarTests
- `crm` - группа для запуска тестов из тест класса CrmTests
- `login` - группа для запуска тестов из тест класса LoginTests
- `main_page` - группа для запуска тестов из тест класса MainPageTests
- `message` - группа для запуска тестов из тест класса MessagesTests
- `my_company` - группа для запуска тестов из тест класса MyCompanyTests
- `org_struct` - группа для запуска тестов из тест класса OrgStructureTests
- `sections` - группа для запуска тестов из тест класса SectionTests
- `task` - группа для запуска тестов из тест класса TaskTests
- `install` - запускает установку онпремиса
- `delete` - удаляет онпремис с ВМ
- `install_test` - запускает тестирование онпремиса, сначала установит потом удалит

В общем случае используется для запуска команда `mvn clean test --no-transfer-progress -Dgroups="${GROUP_TESTS}"`  
В переменную можно передать несколько групп через запятую например GROUP_TESTS process,calendar,crm и т.д  

Локальный запуск тестов:  
e2e тесты

- `mvn clean test --no-transfer-progress -Dsurefire.suiteXmlFiles=src/test/resources/e2eng.xml -Dgroups="${GROUP_TESTS}"`  
  On Premise тесты
- `mvn clean test --no-transfer-progress -Dsurefire.suiteXmlFiles=src/test/resources/onpremng.xml -Dgroups="${GROUP_TESTS}"`

**_Если ничего не указать в данной переменной то будут запущенны все кейсы проекта автоматизации_**

**Установка on-Premise**  
-> пойти в [пайплайны](https://git.elewise.com/elma365/e2e365/-/pipelines)  
-> нажать RunPipeline  
-> Для запуска теста установки on-Premise в секции variables заполнить переменные  
`SSH_HOST` IP либо полное доменное имя ВМ   
`SSH_USER` Логин ВМ  
`SSH_PASSWORD` Пароль пользователя ВМ  
`URL_ONPREMISE` Ссылка на версию on-Premise установку которой надо протестировать  
-> нажать RunPipeline

**Запуск по тикету (не проверялось)**  
-> Для запуска по номеру тикета в секции variables заполнить  
`issue` где ключом будет номер тикета, только цифры  
-> Для запуска тестов против определенных веток и сервисов  
`sb` ключ вида _serviceName=branchName,vahter=coolfeature,mailer=develop_  
-> нажать RunPipeline

**Функционал перезапуска упавших тестов реализован через SureFire, но совместим с Junit 5**  
Число перезапусков считается как дополнительное относительно одного основного запуска.  
В отчёте Allure можно увидеть символ круговой стрелки, показывающий, что тест не прошёл с первого раза и был перезапущен.  
Ошибки и скриншоты страниц при падении тестов будут отражены во вкладке history при просмотре перезапускавшегося теста.  

*Пример перезапуска упавших тестов, всего будет не более трёх запусков*  
`mvn test -Dgroups=login -Dsurefire.rerunFailingTestsCount=2`  

**Функционал селективного запуска реализован через Junit @Tag аннотацию**  
Теги могут быть установлены как на тестовый класс, так и на тестовый метод внутри класса  
В случае установки тега на тестовый класс, тестовые методы этого класса будут считаться отмеченными данным тегом  
В тексте ниже отмеченный тегом тестовый класс приравнивается к группе, а тестовый метод - к тесту  

*Пример работы с одной группой:*  
`mvn test -Dgroups=login`  
*Пример работы с несколькими группами и установкой перезапуска упавших тестов:*  
`mvn test -Dgroups=agreement,familiarization,registration -Dsurefire.rerunFailingTestsCount=2`  
*Пример запуска конкретных методов (по тегу автора) из двух конкретных групп (логин и главная):*  
`mvn test -Dgroups=(login|main_page)&Author=Krasilnikov`  
*Пример работы с включением и исключением одновременно:*  
`mvn test -Dgroups=express -DexcludedGroups=login,process,org_struct`  

**Примеры синтаксиса аргументов:**  
*Запуск конкретной группы: `groups={название группы}`*  
*Запуск нескольких конкретных групп: `groups={название группы},{название группы}`*  
*Исключить группу из запуска `excludedGroups={название группы}`*  
*Исключить несколько групп из запуска `excludedGroups={название группы},{название группы}`*  
*Запустить все обладающие тегом методы `groups={тэг теста}`*  
*Запустить обладающий тегом метод, состоящий в конкретной группе `groups={название группы}&{тэг теста}`*  
*Запустить обладающие тегом методы, состоящие в двух конкретных группах `groups=({название группы}|{название группы})&{тэг теста}`*

**К прочтению рекомендуются данная англоязычная статья о работе с тегами Junit 5**  
https://javabydeveloper.com/junit-5-tag-and-filtering-tags-with-examples/  

**Инструменты используемые для разработки автотестов**

1. Java 8 - [Ссылка Java8 bellsoft](https://bell-sw.com/pages/downloads/)
2. Maven - фреймворк для автоматизации сборки проектов на основе описания их структуры в файлах на языке POM, являющемся
   подмножеством XML [Установка мавена](https://linuxize.com/post/how-to-install-apache-maven-on-ubuntu-20-04/).
3. TestNG - среда тестирования для языка программирования Java. Позволяет использовать более мощные и простые функции.
4. Selenide - фреймворк для автоматизированного тестирования веб-приложений на основе Selenium WebDriver.
5. GitLab
6. Browser: в GitLab - image selenium/standalone-chrome:102.0, локально GoogleChrome v102+  
   Так же для локального запуска против контейнера selenium/standalone-chrome:102.0 понадобится Docker

**Конфигурирование тестов**

1. **е2е**   
   создай файл testConfig в папке configStandFiles/, там же лежит файл testConfigExample  
   скопируй его содержимое в созданный testConfig  
   первая строка - полная ссылка до тестовой компании  
   вторая строка - почта пользователя для авторизации  
   третья строка - пароль  
   четвертая строка - почта пользователя не входящего в группу администраторы  
   пятая строка - пароль пользователя не входящего в группу администраторов
2. **Онпремис**  
   создай файл onPremConfig в папке configStandFiles/, там же лежит файл onPremConfigExample  
   первая строка - адрес виртуальной машны на которую будет установлен онпремис  
   вторая строка - имя пользователя ВМки  
   треться строка - пароль пользователя ВМки  
   четвертая строка - URL версии онпремиса который вы собираетесь поставить

**Разработка автотестов**  
Основные правила:

- Подготовительные тестовые данные создавать при помощи ElmaBackend, имена разделов/приложений должны быть уникальными
  для этого в названии использовать рандомную строку
- Для генерации рандомной строки использовать RandomString, этот же класс для UUID
- Название тестового метода должно соответствовать тест кейсу, так же необходимо добавить
  описание `@Test(description = "описание теста")` как правило в описание пишем полное название тест кейса.
- в файле README.md в таблице указкать над каким тестом работаете

Пример исходного кода теста:

```
    @Test(description = "Вход в систему с существующей электронной почтой и верным паролем",
            groups = {Groups.SUPER_ET})
    public void authTest() {
        LoginPage loginPage = new LoginPage();
        loginPage.fillEmail(TestConfig.getLogin());
        loginPage.fillPassword(TestConfig.getPassword());
        loginPage.clickLogin();

        assert new MainPage().isAddSectionButtonExists();
    }
```

Пример исходного кода методов:

```
public class LoginPage extends BasePage {
    /**
    * Поле ввода логина на форме авторизации
    */
    private final By emailCss = By.cssSelector("[name=emailOrLogin]");
    
    /**
    * Ввод логина на форме авторизации
    * @param email почта пользователя
    * @return (void)  
    */
    public void fillEmail(String email) {
        SelenideElement element = $(emailCss).shouldBe(visible, Time.DURATION_20_SEC);
        element.click();
        element.sendKeys(email);
    }
}
```  

- По умолчанию время ожидания стоит 15 сек, как правило этого хвататет для загрузки элемента на страинце, если элемент
  грузится дольше то необходимо явно указать ожидание элемента  
  Пример: `$(emailCss).shouldBe(visible, Time.DURATION_20_SEC)` в данном случае время ожидание выставленно 20 сек.

**САМОСТОЯТЕЛЬНО ТЕСТЫ НЕ ВЛИВАЕМ В ВЕТКУ master!!!**

- Необходимо сделать МР с указанием вашей ветки и основной, и отправить мне на ревью ссылку на него. Предварительно
  запустите Pipeline и дождитесь его результатов (можно не запускать все тесты а только ту группу в которой вы работали)
- Если все ОК и ваши тесты попали в master дальнейшие шаги:

1. Открываем TMS в тиме ищем тест кейс который вы автоматизировали.
2. Нажимаем редактировать
3. Выставлем автомтаизирован "Да"
4. В поле автотесты вписываем <package_name>.<class_name>.<method_name> где:  
   -> package_name - имя папки в ктотрой лежат классы автоетстов  
   -> class_name - имя класса в котором написан ваш тест  
   -> method_name - название тестовго метода  
   *Пример:* e2eTest.SectionTests.addSectionDownloadFromStoreTest

**Работа с Git**  
*Начало работы*

1. Переключиться на ветку master `git checkout master`
2. Обновить репазиторий `git fetch` затем отресетить до самого свежего коммита `get reset --hard origin/master`
3. Создать новую ветку в которой будете работать `get checkout -b <branch_name>`

*Как сделать коммит и запушить его в remote репазиторий*

1. `git add .` или файлы котоыре должны быть добавленны и индекс коммита `git add path/for/your/file`
2. `git commit -m "commit_name"` - делаем коммит
3. `git push` или если ветка еще не отслеживается `git push -u origin <remote_branch_name>`

*Ребейз ветки*

1. Подтянуть изменения `git fetch`, переключиться на мастер (или ветку на которую будете делать
   ребейз) `git checkout <branch_name>`
2. Сделать ресет `git reset --hard origin/<current_branch_name>`
3. Вернуться на свою ветку в которой работаете `git checkout <your_branch_name>`
4. Сделать ребейз `git rebase <target_branch_name>`  
   Если возникли конфликты:   
   -> Решаем конфликты в файлах (git скажет где не смог автоматически сам решить)    
   -> Добавлем изменения в индекс `git add .` или `git add path/for/your/file`  
   -> Продолжаем процесс ребеза `git rebase --continue`  
   И так до тех пор пока не увидим надпись Successful rebase  
   После ребеза когда будете пушить в remote репазиторий необходимо указать флаг `-f` он же `--force`

По окончанию работы над тестом (когда он был влит в ветку master) удаляем старую ветку из remote репазитория
`git push origin --delete <your_branch_name>`

Следите за своими ветками!  
Не должно быть так что она берет начло из одного коммита потом начиналась из другого, дерево репазитория должно быть
понятным, так будет всем удобнее работать. Должно быть примерно так:

```
* - Ветка 1 в которой работаете например вы 
|
* * - Ветка 2, ветка вашего коллеги 
| |
* *
|/ 
* - master
|\
* * - oldBranch, будет удалена
| |
* *
|/
*
|
```  

**СПИСОК ТЕСТОВ**

| Номер | Package  | ClassName            | MethodName                                              | Ссылка на тест в ТМС                                                                                                                                                                                                                        |
|-------|----------|----------------------|---------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1     | e2eTests | AdminTests           | checkLinkToOrgStructureTest                             | [Проверить переход по ссылке Компания - Организационная структура](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/bfb2966e-7295-4b1f-ab39-c4a151457851))                              |
| 2     | e2eTests | AdminTests           | checkLinkToGroupsTest                                   | [Проверить переход по ссылке Компания - Группы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/64d436f8-4c4d-4158-8a8f-d667866e1a72))                                                 |
| 3     | e2eTests | AdminTests           | checkLinkToUsersTest                                    | [Проверить переход по ссылке Компания - Пользователи](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a4fb4ce6-6881-4dd8-91e6-af0f09bb8c44))                                           |
| 4     | e2eTests | AdminTests           | checkLinkToSubstitutionTest                             | [Проверить переход по ссылке Компания - Замещения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e76687d7-d477-4471-a431-c0a0ba3b68f4))                                              |
| 5     | e2eTests | AdminTests           | checkLinkToCompanySettingsTest                          | [Проверить переход по ссылке Настройки системы - Настройки компании](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/da3f0dfa-945e-4b4e-bada-3ddc0e102f93))                            |
| 6     | e2eTests | AdminTests           | checkLinkToNotificationsTest                            | [Проверить переход по ссылке Настройки системы - Оповещения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f861e9b3-0f05-46cf-99a8-2d891821e158))                                    |
| 7     | e2eTests | AdminTests           | checkLinkToTokensTest                                   | [Проверить переход по ссылке Настройки системы - Токены](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/dbbdf935-5741-43ef-9f1d-b267ea95be95))                                        |
| 8     | e2eTests | AdminTests           | checkLinkToFilesTest                                    | [Проверить переход по ссылке Настройки системы - Файлы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b9aa6391-7080-4ef7-9e43-977b7eba5ad4))                                         |
| 9     | e2eTests | AdminTests           | checkLinkToModulesTest                                  | [Проверить переход по ссылке Настройки системы - Интеграции](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/74bb61b2-6eae-4bde-ad7b-a392d977c11d))                                    |
| 10    | e2eTests | AdminTests           | checkLinkToEmailSendSettingsTest                        | [Проверить переход по ссылке Настройки системы - Настройки отправки Email](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f36dcb88-1a2a-482c-87ee-52a0ddcb5d79))                      |
| 11    | e2eTests | AdminTests           | checkLinkToExtraParamsTest                              | [Проверить переход по ссылке Настройки системы - Дополнительные параметры](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/34e62410-539d-4838-9271-2b69559540ad))                      |
| 12    | e2eTests | AdminTests           | checkLinkToPerformingDisciplineTest                     | [Проверить переход по ссылке Настройки системы - Исполнительская дисциплина](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b1ec671f-3c54-49a5-be56-031696d1f1b5))                    |
| 13    | e2eTests | AdminTests           | checkLinkToExportConfigurationTest                      | [Проверить переход по ссылке Настройки системы - Экспорт конфигурации](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4033947c-2b91-4a71-9875-b6c116d87fc8))                          |
| 14    | e2eTests | AdminTests           | checkLinkToIncomingInputCallTest //TODO не актуален off | [Проверить переход по ссылке Настройки CRM - Обработка входящего звонка](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3c390547-72d6-462b-877c-b0d54c09f4b1))                        |
| 15    | e2eTests | AdminTests           | checkLinkToBusinessProcessesTest                        | [Проверить переход по ссылке раздела Бизнес-процессы - Бизнес-процессы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4f586544-7880-4f15-b948-e1e8d5db9337))                         |
| 16    | e2eTests | AdminTests           | checkLinkToProcessesMonitorTest                         | [Проверить переход по ссылке раздела Бизнес-процессы - Монитор процессов](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/60f05f1f-c489-4358-8868-99d3b431e737))                       |
| 17    | e2eTests | AdminTests           | checkLinkToWorkCalendarTest                             | [Проверить переход по ссылке раздела Бизнес-процессы - Рабочий календарь](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5c7caa2e-a76e-4a75-9dc6-f10795b1ac45))                       |
| 18    | e2eTests | AdminTests           | checkLinkToDocumentTemplatesTest                        | [Проверить переход по ссылке раздела Бизнес-процессы - Шаблоны документов](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8cacc7a4-0fb6-4ee6-99e7-e4e4d194ec54))                      |
| 19    | e2eTests | AdminTests           | addNewUserWithOnlyRequiredFieldsTest                    | [Пригласить пользователя: с заполнением только обязательных полей](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/945f7cdc-5f19-42b3-a3a4-3e3958162455))                              | |
| 20    | e2eTests | AppActionsTests      | addBusinessProcessTest                                  | [Проверить добавление бизнес-процесса в приложении](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6d174811-3d82-4b41-b553-d69371fad10d))                                             |
| 21    | e2eTests | AppActionsTests      | deleteApplicationTest                                   | [Проверить удаление Приложения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/24b68d6f-e743-49f2-8e46-67a48a58169c))                                                                 |
| 22    | e2eTests | AppActionsTests      | exportApplicationTest                                   | [Проверить экспорт Приложения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0e515966-bcfe-4c4b-83e8-530c3cf11c7a))                                                                  |
| 23    | e2eTests | AppActionsTests      | applicationImportTest                                   | [Проверить импорт приложения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e6f829ec-b1a0-4b09-803a-4aaa37dce22a))                                                                   |
| 24    | e2eTests | AppActionsTests      | copyApplicationTest                                     | [Проверить копирование Приложения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7df29237-1c14-4640-9eca-74fa9ee09874))                                                              |
| 25    | e2eTests | AppActionsTests      | createGroupTest                                         | [Проверить добавление Группы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e2c93e3d-d125-4f0a-a39d-a63ec7db9bde))                                                                   |
| 26    | e2eTests | AppActionsTests      | createRoleTest                                          | [Проверить добавление Роли](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/11f4c771-c7cb-44f3-8110-ccbd7e0e992d))                                                                     |
| 27    | e2eTests | AppActionsTests      | addButtonCreateTest                                     | [Настройка действий. Добавить кнопку "Создать"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6272cd94-4c20-4dc1-a072-26f21bd18820))                                                 |
| 28    | e2eTests | AppActionsTests      | addButtonRunBusinessProcessTest                         | [Настройка действий. Добавить кнопку запуска процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/02eeb294-1e7a-46ea-bfbd-5dbe61742c24))                                          |
| 29    | e2eTests | AppActionsTests      | createAppTypePageTest                                   | [Создание страницы в разделе](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/31ca68cb-9418-4e20-b29b-e87cac588eed))                                                                   | |
| 30    | e2eTests | ApplicationsTests    | createApplicationElementTest                            | [Создать элемент приложения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/fcc6ed0a-e508-4102-8761-feb746e1242b))                                                                    |
| 31    | e2eTests | ApplicationsTests    | addSimplePropertyOnFormTest                             | [Простой режим. Проверить отображение свойств простого типа на форме](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/630bcd25-660e-4c12-83e2-4387947734c1))                           |
| 32    | e2eTests | ApplicationsTests    | addAppPropertyOnFormTest                                | [Простой режим. Проверить отображение свойств типа "Приложение" на форме](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7208b304-88c7-4e94-90fe-47e3b7c267a2))                       |
| 33    | e2eTests | ApplicationsTests    | addSimplePropertyOnFormAdvancedModeTest                 | [Расширенный режим. Проверить отображение свойства простого типа на форме](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8c8e133d-8747-48e3-b5ef-fc303ae48184))                      |
| 34    | e2eTests | ApplicationsTests    | addAppPropertyOnFormAdvancedModeTest                    | [Расширенный режим. Проверить отображение свойства типа Приложение на форме](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/dd7a48b8-b428-4ba2-8b00-d21f1f7ac41b))                    |
| 35    | e2eTests | ApplicationsTests    | checkAppElementNameByTemplate                           | [Проверить формирование названия элемента по шаблону](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cca3ef0c-2230-4d5b-8fad-d62dbc9f0706))                                           |
| 36    | e2eTests | ApplicationsTests    | dataExportElementsTest                                  | [Проверить экспорт данных](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6d4acd19-8007-4066-9830-f4f0feb5bc8e))                                                                      |
| 37    | e2eTests | ApplicationsTests    | dataImportElementsTest                                  | [Проверить импорт данных](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/24f1c663-3329-4f73-9220-3534e3669399))                                                                       |
| 38    | e2eTests | AppTypePageTests     | createPageFromTemplateTest                              | [Опубликовать шаблон для проверки (системный)](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/040c1064-1d6e-4f63-b7c8-9b4c5504c2a5))                                                  |
| 39    | e2eTests | AppTypePageTests     | addDefaultWidgetOnPageTest                              | [Добавить виджет на странице (Выбрать из списка)](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ca4d4c4f-4b15-45c2-8f56-0172bff47279))                                               |
| 40    | e2eTests | AppTypePageTests     | addTabWidgetPageTest                                    | [Добавить виджет "Вкладки"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0becc319-1711-48f3-970f-e3e65c9e11f7))                                                                     |
| 41    | e2eTests | AppTypePageTests     | addColumnWidgetPageTest                                 | [Добавить виджет "Колонки"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b717eddd-4112-4cf6-98e0-75cd5176b90d))                                                                     |
| 42    | e2eTests | AppTypePageTests     | addPanelWithTitleWidgetPageTest                         | [Добавить виджет "Панель с заголовком"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3c36e0c7-a17a-48ac-85b1-fd65d3d4844f))                                                         |
| 43    | e2eTests | AppTypePageTests     | addCodeWidgetPageTest                                   | [Добавить виджет "Код"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8740c2c4-415f-4c4d-b2ee-f797d3a02158))                                                                         |
| 44    | e2eTests | AppTypePageTests     | addTextWidgetPageTest                                   | [Добавить виджет "Текст"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6addb16e-84ef-474c-a288-93e8431de14e))                                                                       |
| 45    | e2eTests | AppTypePageTests     | addInscriptionWidgetPageTest                            | [Добавить виджет "Надпись"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/075b3920-32a4-42cd-806e-d3f32d6533c4))                                                                     |
| 46    | e2eTests | AppTypePageTests     | addPageHeaderWidgetPageTest                             | [Добавить виджет "Заголовок страницы"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/33d81df1-1795-41b9-95d4-c074a960e026))                                                          |
| 47    | e2eTests | AppTypePageTests     | addPageContentWidgetPageTest                            | [Добавить виджет "Содержимое страницы"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5fccffd3-72fe-474a-a0c3-263e4545248a))                                                         |
| 48    | e2eTests | AppTypePageTests     | addWidgetOnPageCreateTest                               | [Добавить виджет на странице (Создать)](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3ed286c6-0f4d-48d7-9da1-2ad7dd283d18))                                                         |
| 49    | e2eTests | AppTypePageTests     | addSimplePropertyWidgetPageTest                         | [Контекст. Добавить простые свойства](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3b7e4f8a-eafa-4eae-861f-f94c3b37a72e))                                                           |
| 50    | e2eTests | AppTypePageTests     | addTypeAppPropertyWidgetPageTest                        | [Контекст. Добавить свойства типа Приложение](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/685f180c-79c3-4e8c-b241-4d2284b4eb15))                                                   |
| 51    | e2eTests | AppTypePageTests     | publishCreatedWidgetTest                                | [Опубликовать созданный виджет](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/68a83169-0bef-4f2d-a7d0-990ca6f0e4ac))                                                                 |
| 52    | e2eTests | BusinessProcessTests | scriptBPCreateNewFunctionTest                           | [Создать новую функцию](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c32c55de-04d6-4b9d-b45b-6ffff0522d6c))                                                                         |
| 53    | e2eTests | BusinessProcessTests | scriptBPSelectFunctionTest                              | [Выбрать созданную ранее функцию](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a3227c0e-ccb0-40c8-ab69-2f8f1fac5996))                                                               |
| 54    | e2eTests | BusinessProcessTests | asyncStartProcessTest                                   | [Проверить запуск процесса с асинхронным запуском](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/84910fa1-a625-4211-946a-4a0723e9a2c4))                                              |
| 55    | e2eTests | BusinessProcessTests | syncStartProcessTest                                    | [Проверить запуск процесса с синхронным запуском](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a67836b0-8a6f-4864-a1bc-5c2ccff9a96e))                                               |
| 56    | e2eTests | BusinessProcessTests | taskInDifferentZoneTest                                 | [Проверить выполнение задач исполнителями из разных ЗО](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9633381f-c83c-4ab0-aca1-6c4aec10bf9d))                                         |
| 57    | e2eTests | CalendarTests        | createEventTest                                         | [Создать Событие](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/495345ed-10b1-4f0e-9ae7-682596e3c425))                                                                               |
| 58    | e2eTests | CrmTests             | addNewCompanyInCrmSectionTest                           | [Добавить компанию](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/17ba4816-9a54-4826-a7b1-8a2b549edd58))                                                                             |
| 59    | e2eTests | CrmTests             | createDealWithOnlyRequiredFieldsTest                    | [Создать сделку с заполнением только обязательных полей](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2c745177-1228-4340-92e6-29409aabf5f9))                                        |
| 60    | e2eTests | CrmTests             | addContactOnCompanyCardTest                             | [Компания. Добавить контакт](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/89837c24-722f-4659-8dce-a540380a5107))                                                                    |
| 61    | e2eTests | CrmTests             | addDealOnCompanyCardTest                                | [Компания. Добавить сделку](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/dc49e674-6955-4979-a04e-fd35a93f0545))                                                                     |     
| 62    | e2eTests | LoginTests           | authTest                                                | [Вход в систему с существующей электронной почтой и верным паролем](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/951c2ae3-6ac2-45aa-99c2-5577760c7f0e))                             |     
| 63    | e2eTests | MainPageTests        | createTaskTest                                          | [Создать задачу по кнопке из верхнего меню](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8d5c7c21-a8e2-47f2-b20b-4560af2d25ad))                                                     |
| 64    | e2eTests | MainPageTests        | createBusinessProcessTest                               | [Запустить бизнес-процесс по кнопке из верхнего меню](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/98ff7a00-86da-4bfa-834f-7098e204080e))                                           |
| 65    | e2eTests | MainPageTests        | createApplicationElementFromMainPageTest                | [Создать элемент приложения по кнопке из верхнего меню](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/415db3ef-f5ce-4cfc-9e1e-0dbf26f7a169))                                         |
| 66    | e2eTests | MainPageTests        | customizePageTwoColumnsTest                             | [Настроить страницу в две колонки](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/15eb84c0-60fd-4efd-8af6-1ef615e1eb24))                                                              |
| 67    | e2eTests | MainPageTests        | customizePageOneColumnsTest                             | [Настроить страницу в одну колонку](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7f891876-fbeb-4696-a0d5-44722f211540))                                                             |
| 68    | e2eTests | MainPageTests        | addSectionTestFromMainPage                              | [Добавить раздел с главной страницы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/59283b77-d130-4663-a19e-041523630cba))                                                            |
| 69    | e2eTests | MessagesTests        | sendMessageInChannelTest                                | [[Послать сообщение] Послать сообщение в "Канал"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/257517af-3647-4aa3-bc67-b9cc97ea0d69))                                               |
| 70    | e2eTests | MessagesTests        | sendMessageMentionTest                                  | [[Послать сообщение] Послать сообщение "Кому"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0a73648c-35e5-40e0-8fad-122cd970b705))                                                  |
| 71    | e2eTests | MessagesTests        | sendCommentaryTest                                      | [[Работа с сообщениями] Оставить комментарий](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b8ff870f-8037-43d9-b008-db909482e8e5))                                                   |
| 72    | e2eTests | MyCompanyTests       | employeesAlphabeticalOrderTest                          | [Проверить корректность отображения пользователей на вкладке "Сотрудники"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/77699877-94d9-4d62-ac1e-f20886045b85))                      |
| 73    | e2eTests | OrgStructureTests    | addNewPositionInOrgStructureTest                        | [Добавить новую должность](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b5012be0-7d9a-418b-91e2-76daa35a143b))                                                                      |
| 74    | e2eTests | OrgStructureTests    | addNewGroupInOrgStructureTest                           | [Добавить новую группу сотрудников](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/af08c1cb-31c5-4871-a870-7b4e6963cdc6))                                                             |
| 75    | e2eTests | OrgStructureTests    | addNewDepartmentInOrgStructureTest                      | [Добавить новый отдел](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/62068bfc-1e4a-44a1-a714-629677c7618e))                                                                          |
| 76    | e2eTests | OrgStructureTests    | saveOrgStructureTest                                    | [Проверить сохранение орг структуры](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ae48cd93-07b5-44e4-8a3d-f919bb030e6c))                                                            |
| 77    | e2eTests | SectionTests         | addSectionFromLeftToolbarTest                           | [Создать раздел](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/73da0c1b-d2be-44e1-8d9d-8cd8155c5fbe))                                                                                |
| 78    | e2eTests | SectionTests         | addSectionDownloadFromStoreTest                         | [Скачать раздел (Выбрать готовый Раздел из каталога)](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/85cae424-2aa8-476f-9183-eaf1a55a663c))                                           |
| 79    | e2eTests | SectionTests         | addBusinessProcessTest                                  | [Проверить добавление бизнес-процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c759cc68-2b8e-4239-8645-311533f630f2))                                                          |
| 80    | e2eTests | SectionTests         | addUserGroupTest                                        | [Проверить добавление Группы/Роли](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4ccadd60-1cff-4098-8a91-0507d1e44dc3))                                                              |
| 81    | e2eTests | SectionTests         | addDocumentTemplateTest                                 | [Проверить добавление шаблона документа](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/db229427-cdc8-4ed6-bb45-e630ec838362))                                                        |
| 82    | e2eTests | SectionTests         | editSectionTest                                         | [Настройки Раздела. Редактировать раздел](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d20bcdad-0a18-444c-ab56-ef448ec022d3))                                                       |
| 83    | e2eTests | SectionTests         | addCounterTest                                          | [Проверить добавление нумератора](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3aa19eaa-ae23-4797-b14e-3979857f6005))                                                               |
| 84    | e2eTests | TaskTests            | taskDoneButtonTest                                      | [Проверить работу кнопки "Сделано"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b218679f-3b32-450d-b647-c15e637756ce))                                                             |
| 85    | e2eTests | TaskTests            | taskReassignTest                                        | [Список действий. Переназначить](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/93e8d5fa-acc1-4edb-b5bd-b1d622c298e3))                                                                |
| 86    | e2eTests | TaskTests            | checkTaskSearchByAuthorTest                             | [Проверить поиск по полю "Автор"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c08decea-e942-4da3-bc79-4f60baeedba9))                                                               |
| 87    | e2eTests | TaskTests            | checkTaskSearchByNameTest                               | [Проверить поиск по Названию](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/95a46b1c-0029-4d91-b353-6f27f8df80b6))                                                                   |
| 88    | e2eTests | CrmTests             | addSalesFunnelTest                                      | [Добавить новую Воронку продаж](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/370e5e6a-516d-403d-b642-e9248ada5c1e))                                                                 |
| 89    | e2eTests | BusinessProcessTests | checkProcessInfoTest                                    | [Проверить отображение информации о процессе на карточке процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/00c3ab65-64ba-4990-93f6-ad15a2180913))                              |
| 90    | e2eTests | BusinessProcessTests | checkFinishedProcessInfoTest                            | [Проверить отображение завершенных экземпляров процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/137c55dc-4169-4efc-814f-86bf4aeb2df8))                                        |
| 91    | e2eTests | BusinessProcessTests | sendMessageFromProcessInstanceCardTest                  | [Оставить сообщение в ленте на виджете на карточке экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/209c51b4-2292-4a8e-aa89-e984cc42fa58))                         |
| 92    | e2eTests | BusinessProcessTests | checkRunningProcessInfoTest                             | [Проверить отображение текущих экземпляров процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/35f29172-e62d-43d2-a666-8a9c6d63dc95))                                            |
| 93    | e2eTests | BusinessProcessTests | interruptProcessTest                                    | [Прервать процесс с карточки экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/51ef4188-a82f-4b18-811a-2177c78c710e))                                               |
| 94    | e2eTests | BusinessProcessTests | checkInterruptedProcessInfoTest                         | [Проверить отображение прерванных процессов](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/29b4ba9e-6004-4c6b-afa8-1fb5f1df6c9c))                                                    |
| 95    | e2eTests | BusinessProcessTests | sendMessageWithAttachmentFromProcessInstanceCardTest    | [Оставить сообщение с вложением в ленте на виджете на карточке экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2c5524c5-aea1-4921-95f9-842ac1ea4207))             |
| 96    | e2eTests | BusinessProcessTests | checkProcessInfoByExecutorTest                          | [Проверить отображение информации по исполнителям на карточке процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/36bc4faf-fa86-4751-a272-f83b5161fc35))                         |
| 97    | e2eTests | BusinessProcessTests | skipTimerFromProcessInstanceCardTest                    | [Выполнить таймер принудительно с карточки экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/1a44d1d6-b820-45e6-a778-8b1e7fdd5d1b))                                 |
| 98    | e2eTests | BusinessProcessTests | checkAllProcessButtonTest                               | [Проверить работу кнопки Все процессы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8c82ab3a-7062-4e86-bb3b-5a004221a345))                                                          |
| 99    | e2eTests | BusinessProcessTests | checkPropertiesOnProcessInstanceCardTest                | [Проверить отображение свойств процесса на виджете на карточке экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/890aec9e-9032-4b01-a268-60cb9b8745a3))             |
| 100   | e2eTests | BusinessProcessTests | checkContextChangeOnProcessInstanceCardTest             | [Проверить изменение контекста на карточке экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c842a0d1-8967-4c57-bbd9-cfa2f1a4d620))                                 |
| 101   | e2eTests | BusinessProcessTests | checkUpdateVersionOnProcessInstanceCardTest             | [Проверить обновление версии на карточке экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9fec33a5-286c-4700-879c-a0824174e892))                                   |
| 102   | e2eTests | BusinessProcessTests | checkProcessMapTabOnProcessInstanceCardTest             | [Проверить корректность отображения информации на вкладке Карта карточки экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ba243572-fb2b-4e6a-8299-eab692ca8d23))   | 
| 103   | e2eTests | BusinessProcessTests | rerunTaskWithErrorInProcessInstanceCardTest             | [Возобновить выполнение экземпляра процесса при ошибке](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ef184a99-21cc-496d-8941-9f242ab2de89))                                         |
| 104   | e2eTests | BusinessProcessTests | skipTaskWithErrorInProcessInstanceCardTest              | [Пропустить шаг на карточке экземпляра процесса при ошибке](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/07103377-7391-4119-a22b-7cbc7f452140))                                     |
| 105   | e2eTests | BusinessProcessTests | checkHistoryTabOnProcessInstanceCardTest                | [Проверить корректность отображения информации на вкладке История карточки экземпляра процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f44bca7d-49d9-48b7-9e0f-986abba5e8f8)) | 
| 106   | e2eTests | BusinessProcessTests | putTimerOnProcessSchemeTest                             | [Вынести таймер на схему бизнес-процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d266096a-fe74-41e9-b7f6-4eb6892727fe))                                                       |
| 107   | e2eTests | BusinessProcessTests | checkTimerWithContextVariableTest                       | [Проверить работу таймера с ограничением по переменной](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/abaf134e-2cb7-4bb0-938d-17844caa9262))                                         |
| 108   | e2eTests | BusinessProcessTests | checkTimerWithActualTimeTest                            | [Проверить работу таймера с ограничением точное время](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/144bb642-f20d-4554-85db-6ad0097c2c09))                                          |
| 109   | e2eTests | BusinessProcessTests | checkTimerExcludingWorkCalendarTest                     | [Проверить выполнение таймера без учета рабочего календаря](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/03454f91-788d-4c51-a648-69d2dd57082b))                                     |
| 110   | e2eTests | BusinessProcessTests | checkTimerAccordingWorkCalendarTest                     | [Проверить выполнение таймера с учетом рабочего календаря](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/993c6c7a-7de4-4b0d-87f1-0c6b0ce8a69f))                                      |
| 111   | e2eTests | BusinessProcessTests | addContextTypeStringTest                                | [Добавить контекст типа Строка](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4a7fbe60-4890-428f-9b3f-00d376093656))                                                                 |
| 112   | e2eTests | BusinessProcessTests | addContextTypeStringAsTextTest                          | [Добавить поле типа Строка в формате Текст](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c79d9db7-9a19-42b3-a62b-84c0c049b315))                                                     |
| 113   | e2eTests | BusinessProcessTests | addContextTypeIntegerTest                               | [Добавить контекст типа Целое число](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6ede39d6-de49-480a-9226-a77b630788b7))                                                            |
| 114   | e2eTests | BusinessProcessTests | addContextTypeDoubleTest                                | [Добавить контекст типа Дробное число](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/96f3b8d6-0579-4f28-8e4f-8c04eeb5d47a))                                                          |
| 115   | e2eTests | BusinessProcessTests | addContextTypeBooleanSwitchTest                         | [Добавить контекст типа Выбор \да/нет\ - в виде переключателя](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/da87303d-7113-4997-af6e-c473869192d8))                                  |
| 116   | e2eTests | BusinessProcessTests | addContextTypeBooleanCheckboxTest                       | [Добавить контекст типа Выбор \да/нет\ - в виде флажка](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d7147993-5219-4210-85b4-9d13369fb356))                                         |
| 117   | e2eTests | BusinessProcessTests | addContextTypeDateTimeTest                              | [Добавить контекст типа Дата/время в виде Дата/время](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/63455cdf-fd3c-41dc-96f6-f0b301c3c2a3))                                           |
| 118   | e2eTests | BusinessProcessTests | addContextTypeDateTest                                  | [Добавить контекст типа Дата/время в виде Дата](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/29819e02-4745-42fb-abac-b3e4ab0096d6))                                                 |
| 119   | e2eTests | BusinessProcessTests | addContextTypeTimeTest                                  | [Добавить контекст типа Дата/время в виде Время](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/caf15804-e3c4-47bd-bc64-407744539c12))                                                |
| 120   | e2eTests | BusinessProcessTests | addContextTypeCategoryTest                              | [Добавить контекст типа Категория - одиночная](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4d4a47f8-4018-4002-a519-28897af80df2))                                                  |
| 121   | e2eTests | BusinessProcessTests | addContextTypeCategoryMultipleTest                      | [Добавить контекст типа Категория - множественная](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/77510922-8f36-4716-a158-5cd71c516e34))                                              |
| 122   | e2eTests | BusinessProcessTests | addContextTypeMoneyTest                                 | [Добавить контекст типа Деньги](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2ab496b0-83cb-4b7e-8581-47522e36e61b))                                                                 |
| 123   | e2eTests | BusinessProcessTests | addContextTypePhoneTest                                 | [Добавить контекст типа Номер телефона](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2b633a71-b164-4fcd-8626-c44d739ef1d9))                                                         |
| 124   | e2eTests | BusinessProcessTests | addContextTypeEmailTest                                 | [Добавить контекст типа Электронная почта](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ac74eae7-531d-40f6-9ec2-f71a2ee88e21))                                                      |
| 125   | e2eTests | BusinessProcessTests | addContextTypeImageSingleTest                           | [Добавить контекст типа Изображение - одно](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/bd2161d5-1f07-4195-bcd3-07e1e988900d))                                                     |
| 126   | e2eTests | BusinessProcessTests | addContextTypeImageMultipleTest                         | [Добавить контекст типа Изображение - несколько](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/93fb590f-acba-4667-a4a3-fac353631e9b))                                                |
| 127   | e2eTests | BusinessProcessTests | addContextTypeFileSingleTest                            | [Добавить контекст типа Файлы - один](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4023df1a-7884-44da-84ac-4331ab18de9e))                                                           |
| 128   | e2eTests | BusinessProcessTests | addContextTypeFileMultipleTest                          | [Добавить контекст типа Файлы - несколько](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5efa7d72-6c34-489c-87c9-6ac3468dabe6))                                                      |
| 129   | e2eTests | BusinessProcessTests | addContextTypeFullNameTest                              | [Добавить контекст типа Ф.И.О.](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f7b61fc2-802f-4570-9e4e-386bda87b2a2))                                                                 |
| 130   | e2eTests | BusinessProcessTests | addContextTypeLinkTest                                  | [Добавить контекст типа Ссылка](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3de03390-a9b4-4b42-b9db-e9f03a05a0f5))                                                                 |
| 131   | e2eTests | BusinessProcessTests | addContextTypeTableTest                                 | [Добавить контекст типа Таблица с вариантом отображения Таблица](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/227f8682-e362-45a6-aa49-82b1b4e29d6a))                                |
| 132   | e2eTests | BusinessProcessTests | addContextTypeUserSingleTest                            | [Добавить контекст типа Пользователи - один пользователь](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/14fa8781-0e12-4aed-994f-4334eba8d732))                                       |
| 133   | e2eTests | BusinessProcessTests | addContextTypeUserMultipleTest                          | [Добавить контекст типа Пользователь - Несколько пользователей](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/15720161-f611-49a0-9135-398af53adfde))                                 |
| 134   | e2eTests | BusinessProcessTests | addContextTypeApplicationTest                           | [Добавить контекст типа Приложение](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/94a2a9af-b7b7-4d17-9e99-8c9006a5d353))                                                             |
| 135   | e2eTests | BusinessProcessTests | addContextTypeStringDefaultValueTest                    | [Проверить заполнение свойства по умолчанию](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c0e494d2-e587-4f43-9220-7df8abd9aec6))                                                    |
| 136   | e2eTests | BusinessProcessTests | addContextTypeStringFormulaTest                         | [Проверить работу настройки \Заполняется по формуле\ ](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c1325450-9a32-4548-9925-58fb9dc47ce1))                                          |
| 137   | e2eTests | BusinessProcessTests | addContextTypeStringWithTooltipTest                     | [Проверить отображение подсказки к свойству](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cfe12974-cd8f-4bb7-a506-9647099680d6))                                                    |
| 138   | e2eTests | BusinessProcessTests | addContextTypeDateTimeNowTest                           | [Добавить контекст типа Дата/время с установкой текущего времени](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3da1ddaf-9205-4fa5-868a-3f1c8647dcdd))                               |
| 139   | e2eTests | BusinessProcessTests | addContextTypeDateTimeStartOfDayTest                    | [Добавить контекст типа Дата/время с установкой опционального времени - начало дня](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/bc8fb821-4944-4416-b5d4-dd14c8ac3b89))             |
| 140   | e2eTests | BusinessProcessTests | addContextTypeDateTimeEndOfDayTest                      | [Добавить контекст типа Дата/время с установкой опционального времени - конец дня](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/22a69428-2f1c-4562-abc2-f50c0da9d751))              |
| 141   | e2eTests | BusinessProcessTests | addContextTypeUserShowBlockedTest                       | [Добавить контекст типа Пользователи с настройкой \Показывать блокированных\ ](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/fd399ad3-497d-4c56-8728-ab1fcd945c8b))                  |
| 142   | e2eTests | BusinessProcessTests | addContextTypeImageFragmentTest                         | [Добавить контекст типа Изображение с настройкой \Выбирать фрагмент изображения при загрузке\ ](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e2fdf98b-56dd-4eb7-ac79-0b8cd20ff219)) |
| 143   | e2eTests | BusinessProcessTests | saveDataTypeAppInProcessContextTableTest                | [Сохранение данных внутри таблицы в процессе с колонками "Типа Приложение"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/21161032-89df-4908-91e2-139a9463a946))                     |
| 144   | e2eTests | BusinessProcessTests | saveDataTypeSimpleInProcessContextTableTest             | [Сохранение данных внутри таблицы в процессе с колонками "Простого типа"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e1ae9426-696a-4947-ae40-70b375d0d832))                       |
| 145   | e2eTests | BusinessProcessTests | columnTypeFormulaWithSimplePropertyTest                 | [Проверить работу формул в колонках таблиц на формах процесса](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3514a760-b1ca-4ab1-b101-52c0173accdc))                                  |                
| 146   | e2eTests | BusinessProcessTests | columnTypeFormulaWithAttachedPropertyTest               | [Проверить работу формул в колонках таблицы с вложенными свойтсвами](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/eb011506-1430-4d5d-b1e7-5f1431ceb924))                            |      
| 147   | e2eTests | CrmTests             | createTaskTest                                          | [Создать задачу](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f4321e38-16a1-4c86-93b6-c114b4cb4b18))                                                                                |
| 148   | e2eTests | CrmTests             | checkEditTest                                           | [Проверить редактирование](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b3a8109f-47c9-41f4-8dc1-02f723d035fe))                                                                      |
| 149   | e2eTests | AdminTests           | checkLinkToNomenclatureSettingsTest                     | [Проверить переход по ссылке Настройки Номенкулатуры](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4e4d9cae-1031-468c-a49e-86bd20eff337))                                           |                                                                                                                                                                                                                                      |      
| 150   | e2eTests | AdminTests           | checkLinkToSettingsServiceTest                          | [Проверить переход по ссылке Почта - Настройка сервисов](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/596ef365-cdbe-4d33-8c8a-8f31d2a75ac1))                                        |
| 151   | e2eTests | AdminTests           | checkLinkToSettingsConnectionsTest                      | [Проверить переход по ссылке Почта - Настройка связей](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c7949fee-9c0c-4e2c-813c-c7ff7aa5b995))                                          |
| 152   | e2eTests | AdminTests           | checkLinkToSettingsLinesTest                            | [Проверить переход по ссылке ChatDesk - Линии](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5233026d-9f6b-4897-8ea9-4588a9fedf7e))                                                  |
| 153   | e2eTests | SectionTests         | numeratorChangeTest                                     | [Изменение нумератора в приложении](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3cc3d3f2-bb81-44b4-8373-8cfe153b1fda))                                                             |      
| 154   | e2eTests | AppTypePageTests     | deleteWidgetTest                                        | [Удалить виджет со страницы](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e319dda4-7953-4165-894c-fe6f6f1a8e08))                                                                    |
| 155   | e2eTests | AppTypePageTests     | openWidgetSettingsTest                                  | [Открыть настройки виджета](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e56d0ded-6c74-4e7b-ac85-05e36c940d7c))                                                                     |
| 156   | e2eTests | AppActionsTests      | createStandartApplicationTest                           | [Создание приложения с типом \\Стандартное\\](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/485e9c57-8099-4b4d-a21c-1aa23e218683))                                                   |
| 157   | e2eTests | AppActionsTests      | createLinkInSectionTest                                 | [Создание ссылки в разделе](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/577cc987-f4af-4773-bb35-f2e4f929893c))                                                                     |
| 158   | e2eTests | AppActionsTests      | createEventInSection                                    | ["Создание приложения с типом \\Событие\\"](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/606aadc8-46de-4ea7-a92e-2cce028c6b4a))                                                     |
| 159   | e2eTests | AppActionsTests      | createDocumentInSectionTest                             | [Создание приложения с типом \\Документ\\](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cdcb6c28-d124-4261-9f4a-649a0815802a))                                                      |
| 160   | e2eTests | SectionTests         | deleteSectionTest                                       | [Проверить удаление раздела](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/86d309f9-a833-4d6d-9369-48e4179b99f3))                                                                    |
| 161   | e2eTests | SectionTests         | copySectionTest                                         | [Проверить копирование Раздела](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/994bd126-3d5f-4ae1-a359-b0131c95e5f9))                                                                 |
| 162   | e2eTests | SectionTests         | sectionVisionSettingsTest                               | [Проверить настройки видимости](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2a8b1f94-0119-428c-a37b-2754d3aba83b))                                                                 |
| 163   | e2eTests | SectionTests         | exportSectionTest                                       | [Проверить экспорт Раздела](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ff559eec-d979-4cdc-a484-ca2690b4e704))                                                                     |
| 164   | e2eTests | CrmTests             | sendMessageInDealCardTest                               | [Написать сообщение в ленту](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/02d8ebb0-5572-4c2b-bea7-3171ef3b9c2f))                                                                    |
| 165   | e2eTests | CrmTests             | createMeetingInDealCardTest                             | [Создать встречу](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0e5fa000-5cd4-4c46-bb5a-f1d20e1cca24))                                                                               |
| 166   | e2eTests | CrmTests             | createTaskInDealCardTest                                | [Создать задачу](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5d5a191f-47f4-41cd-9a9f-d2b4b5822d37))                                                                                |
| 167   | e2eTests | CrmTests             | changeLetterDateTest                                    | [Письмо. Перенести](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/142d9a67-680b-4287-9708-25d88527cf39))                                                                             |
| 168   | e2eTests | CrmTests             | meetingDoneInDealCardTest                               | [Встреча. Сделано](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/190524ed-a935-4996-a06c-921c91d0dad1))                                                                              |
| 169   | e2eTests | CrmTests             | webinarDoneInDealCardTest                               | [Вебинар. Сделано](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/1d7ee197-4f59-4799-b7e7-34d54a244e53))                                                                              |
| 170   | e2eTests | CrmTests             | addContactInDealCardTest                                | [Добавить контакт](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/263d0b4f-228a-45d9-95dc-0bad54cfc5c9))                                                                              |
| 171   | e2eTests | CrmTests             | statusChangeInDealCardTest                              | [Проверить смену статуса Сделки](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/26db2e66-1e87-471f-9c1d-a0eae69d626e))                                                                |
| 172   | e2eTests | CrmTests             | changeCallDateTest                                      | [Звонок. Перенести](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4ade53e8-01f9-4330-ab7c-01cc0baca281))                                                                             |
| 173   | e2eTests | CrmTests             | checkCallHistoryTest                                    | [Проверить историю звонков в Календаре](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5dd0566b-11b4-4cc7-abfc-24b39039fd8b))                                                         |
| 174   | e2eTests | CrmTests             | completeTaskInDealCardTest                              | [Выполнить задачу](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/638b94cb-c870-4d26-8e36-ecb2ab3b78e2))                                                                              |
| 175   | e2eTests | CrmTests             | makeCallDateTest                                        | [Создать звонок](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6df991ca-bd09-44e6-8fbc-072cf9c8d607))                                                                                |
| 176   | e2eTests | CrmTests             | letterDoneTest                                          | [Письмо. Сделано](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7186d23e-c6d5-41a1-a719-e22063527713))                                                                               |
| 177   | e2eTests | CrmTests             | closeDealCallTest                                       | [Звонок. Закрыть сделку](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/82dd9c50-2ae4-4b8c-9a24-ce97c9aaceb0))                                                                        |
| 178   | e2eTests | CrmTests             | changeWebinarTimeInDealCardTest                         | [Вебинар. Перенести](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9fcdd24d-d2e3-45ad-b036-ff46e61f23f4))                                                                            |
| 189   | e2eTests | CrmTests             | closeCallTaskTest                                       | [Звонок. Недозвон. Закрыть задачу](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a11d68a3-8f96-4890-a125-bfb3b55733a4))                                                              |
| 180   | e2eTests | CrmTests             | checkLettersHistoryTest                                 | [Проверить историю писем в Календаре](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a9e80d22-15ad-488a-942b-eb4edddce099))                                                           |
| 181   | e2eTests | CrmTests             | callStatusesTaskTest                                    | [Звонок. Недозвон](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cd136637-9365-4f26-9bd0-4284f9919ea0))                                                                              |
| 182   | e2eTests | CrmTests             | callDoneTest                                            | [Звонок. Сделано](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d620de0c-9eed-4dda-a03e-e0a58940f9e5))                                                                               |
| 183   | e2eTests | CrmTests             | changeMeetingDateTest                                   | [Встреча. Перенести](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d7b16da8-687b-481f-a659-e1d55d3b8618))                                                                            |
| 184   | e2eTests | CrmTests             | checkMeetingHistoryTest                                 | [Проверить историю встреч в Календаре](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f83c1d65-3ee0-40ad-bc3b-6359c3912657))                                                          |
| 185   | e2eTests | SectionTests         | createElementWithApiTest                                | [Проверить запрос Создать элемент](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5696fd13-d490-4fa0-82a1-1e255aa5acd6))                                                              |
| 186   | e2eTests | SectionTests         | getElementWithApiTest                                   | [Проверить запрос Получить элемент](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/caa97a1f-5d33-49a0-80b5-2d470d8d3463))                                                             |
| 187   | e2eTests | SectionTests         | changeElementWithApiTest                                | [Проверить запрос Изменить элемент](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6a75a86b-05cf-4b5b-a436-a9137afbd63b))                                                             |
| 188   | e2eTests | ApplicationsTests    | changeStatusTest                                        | [Проверить смену статуса на указанный в операции для приложения](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e556469a-882f-491c-b5b7-b9be4e934345))                                |
| 189   | e2eTests | SectionTests         | changeElementStatusWithApiTest                          | [Проверить запрос Изменить статус](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9d0cc470-d067-4ae5-8b4b-a411438c8e21))                                                              |
| 190   | e2eTests | SectionTests         | getElementListWithApiTest                               | [Проверить запрос на получение Списка элементов](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d77acb99-85c9-4fb6-90b8-e81181f130df))                                                |
| 191   | e2eTests | ApplicationsTests    | addDateTimeContextSettingStartDayTest                   | [Добавить контекст типа Дата/время с установкой опционального времени - начало дня](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/02e8b159-6eed-44bd-b0ce-5a85e8af1aef))             |
| 192   | e2eTests | ApplicationsTests    | addDateTimeContextSettingEndDayTest                     | [Добавить контекст типа Дата/время с установкой опционального времени - конец дня](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3b9d5458-529d-455a-a788-e332061d8c62))              |
| 193   | e2eTests | ApplicationsTests    | addDateTimeContextSettingDateTest                       | [Добавить контекст типа Дата/время в виде Дата](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/25e068f4-fcc0-4a9e-a010-de25f3013503))                                                 |
| 194   | e2eTests | ApplicationsTests    | addDateTimeContextSettingTimeTest                       | [Добавить контекст типа Дата/время в виде Время](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8027a827-4530-41e5-b995-48a3f7237d52))                                                |
| 195   | e2eTests | ApplicationsTests    | addYesNoContextChangingParametersTest                   | [Добавить контекст типа Выбор \да/нет\ - с изменением значений](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c3ec9ee4-7a7a-4d6e-affa-08d739d1ea4c))                                 |
| 196   | e2eTests | ApplicationsTests    | checkPropertyTooltipDisplayTest                         | [Проверить отображение подсказки к свойству](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8c5a9200-8f9c-4073-a580-7b832b769140))                                                    |
| 197   | e2eTests | ApplicationsTests    | checkDefaultPropertyCompletionTest                      | [Проверить заполнение свойства по умолчанию](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ad8ee208-9cc4-4304-b12f-f294f1306be3))                                                    |
| 198   | e2eTests | ApplicationsTests    | deleteContextTest                                       | [Удалить контекст](https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/aae83d06-99ea-42dd-9cc7-fff9d1a3551c))                                                                              |