package pages.elmaPages;

import com.codeborne.selenide.*;
import com.codeborne.selenide.conditions.CssClass;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.util.Locale;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

/**
 * Страница редактирования форм приложений и бизнес - процессов.
 *
 * @link /_designer/interfaces/{путь к редактируемой форме}
 */
@Singleton
public class InterfaceDesignerPage extends BasePage {
    @Override
    public void open(String... route) {
        String baseUrl = config.standUrl;
        String fullUrl = String.format(baseUrl + String.join("/", route)).toLowerCase(Locale.ROOT);
        Selenide.open(fullUrl);
        checkAlert();
    }

    private final By tabListCss = By.cssSelector("ul[role='tablist']");
    private final By addTabPlusButtonCss = By.cssSelector("a[id='add-tab']");
    private final By widgetNamesCss = By.cssSelector("elma-groupbox span");
    private final By titleWidgetsCss = By.cssSelector("elma-label");
    private final By tabSetNamesCss = By.cssSelector("elma-tabset>ul>li>a");
    private final By navItemNamesCss = By.cssSelector("elma-content-navigation div[class*='content-navigation__title']");
    private final By deleteTabButtons = By.cssSelector("elma-tabset i[title='Удалить']");
    private final By tabSettingsButtonCss = By.cssSelector("elma-tabset i[title='Настроить']");
    private final By deleteNavItemButtons = By.cssSelector("elma-widget-template-item-tools button[title='Удалить']");
    private final By openedTabAddWidgetButtonCss = By.cssSelector("elma-form div[class='tab-content'] button[class*='add-widget-button']");
    private final By sidePanelWidgetDraggableXpath = By.xpath("//li[text()[contains(., 'Виджет боковой панели')]]");
    private final By menuWithFormDraggableXpath = By.xpath("//li[text()[contains(., 'Меню с формой')]]");
    private final By ApproveListDraggableXpath = By.xpath("//li[text()[contains(., ' Листы согласования')]]");
    private final By FamiliarizationListDraggableXpath = By.xpath("//li[text()[contains(., ' Листы ознакомления')]]");
    private final By titleWidgetDraggableXpath = By.xpath("//li[text()[contains(., 'Надпись')]]");
    private final By tabsDraggableXpath = By.xpath("//li[text()[contains(., 'Вкладки')]]");
    private final By mainItemsContainerCss = By.cssSelector("elma-form elma-modal-body");
    private final By sidePanelWidgetCss = By.cssSelector("elma-sidebar-widget");
    private final By menuWithTabWidgetContainerCss = By.cssSelector("elma-content-navigation app-row-layout div[class*='zone-items-container']");
    private final By widgetTemplateToolsDeleteButtonCss = By.cssSelector("elma-widget-template-item-tools>button[elmabutton='danger']");
    private final By sidePanelCss = By.cssSelector("div[class*='complex-popup__info-wrapper']");
    private final By widgetTemplateToolsCss = By.cssSelector("elma-widget-template-item-tools");
    private final By visibleDeletionAcceptButtonCss = By.xpath("//div[contains(@class,'popover_is-visible')]//button[text()[contains(., 'Подтвердить удаление')]]");
    private final By saveInToolbarXpath = By.xpath("//button[text()[contains(., 'Сохранить')]]");
    private final By publishInToolbarXpath = By.xpath("//button[text()[contains(., 'Опубликовать')]]");
    private final By confirmPublishCss = By.cssSelector("div[role='dialog'] div.btn-group button.btn-primary");
    private final By navItemsCss = By.cssSelector("elma-content-navigation div");
    private final By widgetsCss = By.cssSelector("elma-groupbox");
    private final By draggableWidgetsOnRightPanel = By.cssSelector("elma-widget-sidebar-widgets li[class*='widget-draggable-item']");
    private final By togglerArrowButtonCss = By.cssSelector("elma-groupbox button.toggler");
    private final By widgetItemContainersCss = By.cssSelector("elma-groupbox .zone-items-container");
    private final By panelWithHeaderBodyElements = By.cssSelector("elma-groupbox div[class='groupbox-body']");
    private final By taskInstanceStartDateCss = By.cssSelector("app-task-instance-start-date");
    private final By imgFileCss = By.cssSelector("elma-file img[src]");
    private final By viewFileCss = By.cssSelector("elma-file");
    private final By buttonYesInApplicationElement = By.cssSelector("[aria-label='Да']");
    private final By textInModalWindow = By.cssSelector("[class*='modal-body']>elma-label");
    private final By headerInModalWindow = By.cssSelector("[class*='maintitle']");
    private final By tableHeadItemsCss = By.cssSelector("thead th span");
    private final By tableHeadFloatNumberCss = By.cssSelector("thead elma-type-float");
    private final By tableHeadFloatNumbersCss = By.cssSelector("tbody elma-type-float");
    private final By finderButtonXpath = By.xpath("//button[contains(text(), 'Поиск')]");
    private final By finderInputCss = By.cssSelector("app-appview-report-table input");
    private final By appNamesInTableBodyCss = By.cssSelector("app-appview-list-field elma-type-string span");
    private final By tableWidgetCss = By.cssSelector("app-appview-widget-report-table");
    private final By parameterStringValueCss = By.cssSelector("elma-type-string span");
    private final By standardFormElementCss = By.cssSelector("app-dynamic-form");
    private final By sidePanelTasksWidgetDropzoneXpath = By.xpath("//elma-sidebar-widget//div[contains(text(), 'Связанные задачи')]");
    private final By taskNameCss = By.cssSelector("span[class*='maintitle']");
    private final By yesNoButtonsCss = By.cssSelector("p-selectbutton div");
    final private By appPageWrapperCss = By.cssSelector("app-page-wrapper");
    final private By appPageWrapperTagLineCss = By.cssSelector("app-page-wrapper app-row-layout");
    final private By appPageWrapperColumnCss = By.cssSelector("app-page-wrapper elma-column");

    public void checkTaskNameVisible(String taskName) {
        $$(taskNameCss).findBy(text(taskName)).shouldBe(visible);
    }

    public void dragSidePanelWidgetToSidePanel() {
        //через метод dragAndDrop не работает, решаю экшеном
        actions().clickAndHold($(sidePanelWidgetDraggableXpath))
                .moveToElement($(sidePanelCss))
                .release()
                .build()
                .perform();
    }

    public void checkWidgetTemplateToolsExists() {
        // добавленный на боковую панель через dragAndDrop виджет всегда обладает открытым меню настроек.
        $(widgetTemplateToolsCss).shouldBe(visible);
    }

    public void dragAndDropTitleWidgetToSidePanelWidget() {
        actions().clickAndHold($(titleWidgetDraggableXpath))
                // пришлось чинить, раньше sidePanelWidgetCss наводился на заголовок
                .moveToElement($(sidePanelTasksWidgetDropzoneXpath))
                .moveToElement($(sidePanelTasksWidgetDropzoneXpath))
                .release()
                .build()
                .perform();
    }

    public void dragAndDropTitleWidgetToMenuWithForm() {
        actions().clickAndHold($(titleWidgetDraggableXpath))
                .moveToElement($(menuWithTabWidgetContainerCss))
                /* при использовании drag-and-drop меняются размеры элементов,
                 в результате конечную точку нужно определять дважды:
                 до перемещения и после смены разметки страницы в результате перемещения */
                .moveToElement($(menuWithTabWidgetContainerCss))
                .release()
                .build()
                .perform();
    }

    public void removeSidePanelWidget() {
        $(sidePanelWidgetCss).shouldBe(visible).click();
        $(widgetTemplateToolsCss).shouldBe(visible);
        $(widgetTemplateToolsDeleteButtonCss).shouldBe(visible).click();
        $(visibleDeletionAcceptButtonCss).shouldBe(visible).click();
    }

    public boolean isSidePanelWidgetExists() {
        return $(sidePanelWidgetCss).exists();
    }

    public void checkNoMoreSidePanelWidgets() {
        $(sidePanelWidgetCss).shouldNotBe(exist);
    }

    public void addTabByDragAndDrop() {
        actions().clickAndHold($(tabsDraggableXpath))
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void addMenuWithFormByDragAndDrop() {
        actions().clickAndHold($(menuWithFormDraggableXpath))
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void addTabByPlusButton() {
        $(addTabPlusButtonCss).click();
    }

    public void checkTabVisible(String tabName) {
        $$(tabListCss).findBy(text(tabName)).shouldBe(visible);
    }

    public void clickAddWidgetOnOpenedTab() {
        $(openedTabAddWidgetButtonCss).click();
    }

    public void checkWidgetExists(String widgetName) {
        $$(widgetNamesCss).findBy(text(widgetName)).shouldBe(visible);
    }

    public void checkTitleWidgetVisible(String widgetName) {
        $$(titleWidgetsCss).findBy(text(widgetName)).shouldBe(visible);
    }

    public void removeAllTabs() {
        $$(tabSetNamesCss).first().shouldBe(visible).click();
        $(widgetTemplateToolsDeleteButtonCss).shouldBe(visible).click();
        $(visibleDeletionAcceptButtonCss).shouldBe(visible).click();
    }

    public void removeTabByName(String tabName) {
        $$(tabSetNamesCss).findBy(text(tabName)).shouldBe(visible).click();
        $$(deleteTabButtons).find(visible).click();
        $(visibleDeletionAcceptButtonCss).shouldBe(visible).click();
    }

    public void removeNavItemByName(String widgetName) {
        $$(navItemNamesCss).findBy(text(widgetName)).shouldBe(visible).click();
        $$(deleteNavItemButtons).find(visible).click();
        $(visibleDeletionAcceptButtonCss).shouldBe(visible).click();
    }

    public void checkNoMoreTabs() {
        $(tabSetNamesCss).shouldNot(exist);
    }

    public void checkNoMoreNavItems() {
        $(navItemNamesCss).shouldNot(exist);
    }

    public void checkTabNotExists(String tabName) {
        $$(tabSetNamesCss).findBy(text(tabName)).shouldNot(exist);
    }

    public void openDefaultTabSettings() {
        $$(tabSetNamesCss).findBy(text("Вкладка")).shouldBe(visible).click();
        $(tabSettingsButtonCss).shouldBe(visible).click();
    }

    public void clickSaveToolbarButton() {
        // TODO: разобраться с наслоением кликабельных и не кликабельных кнопок.
        $(saveInToolbarXpath).shouldBe(enabled);
        actions().moveToElement($(saveInToolbarXpath)).click().perform();
    }

    public void clickPublishToolbarButton() {
        $(publishInToolbarXpath).shouldBe(enabled);
        actions().moveToElement($(publishInToolbarXpath)).click().perform();
    }

    public void confirmPublishing() {
        $(confirmPublishCss).shouldBe(visible).click();
    }

    public void saveAndPublish() {
        clickSaveToolbarButton();
        clickPublishToolbarButton();
        confirmPublishing();
    }

    public void checkNavItemNameVisible(String widgetName) {
        $$(navItemsCss).findBy(text(widgetName)).shouldBe(visible);
    }

    public void checkNavItemExists() {
        $$(navItemsCss).shouldBe(CollectionCondition.sizeGreaterThan(0));
    }

    public int getSidePanelWidgetsCount() {
        $$(sidePanelWidgetCss).last().should(exist);
        return $$(sidePanelWidgetCss).size();
    }

    public void checkSidePanelWidgetsCount(int count) {
        $$(sidePanelWidgetCss).shouldBe(CollectionCondition.size(count));
    }

    public void addWidgetWithExactNameByDragAndDropToMainForm(String widgetName) {
        actions().clickAndHold($$(draggableWidgetsOnRightPanel).findBy(exactText(widgetName)))
                .moveToElement($(mainItemsContainerCss))
                .moveToElement($(mainItemsContainerCss))
                .release()
                .build()
                .perform();
    }

    public void checkPanelWithHeaderVisible(String panelName) {
        $$(widgetNamesCss).findBy(text(panelName)).shouldBe(visible);
    }

    public void checkPanelWithHeaderIsSimplyViewed() {
        /* findBy(cssClass("@style-simple") не удаётся использовать.
        Селенид ругается и отмечает как ошибку неправильное название класса, но класс называется именно так.
        Приходится делать костыли и объявлять класс заранее, затем передавая его в метод поиска */
        CssClass simpleClass = new CssClass("@style-simple");
        $$(widgetsCss).findBy(simpleClass).shouldBe(visible);
    }

    public void checkPanelWithHeaderIsDefaultViewed() {
        // Если многое на сайте завязано на такие классы стилей - можно их перенести в BasePage.
        CssClass defaultClass = new CssClass("@style-default");
        $$(widgetsCss).findBy(defaultClass).shouldBe(visible);
    }

    public void removePanelWithHeaderByName(String panelName) {
        $$(widgetNamesCss).findBy(text(panelName)).shouldBe(visible).click();
        $$(deleteNavItemButtons).find(visible).click();
        $(visibleDeletionAcceptButtonCss).shouldBe(visible).click();
    }

    public void removeTable() {
        $(tableWidgetCss).shouldBe(visible).click();
        $$(deleteNavItemButtons).find(visible).click();
        $(visibleDeletionAcceptButtonCss).shouldBe(visible).click();
    }

    public void checkNoMorePanelWithHeaders() {
        $(widgetNamesCss).shouldNotBe(exist);
    }

    public void checkNoFoldButtonOnPanelWithHeader() {
        $(togglerArrowButtonCss).shouldNot(visible);
    }

    public void checkFoldButtonOnPanelWithHeader() {
        $(togglerArrowButtonCss).shouldBe(visible).click();
        $(togglerArrowButtonCss).shouldBe(visible).click();
    }

    public void dragAndDropTitleWidgetToPanelWithHeader() {
        actions().clickAndHold($(titleWidgetDraggableXpath))
                .moveToElement($(widgetItemContainersCss))
                /* при использовании drag-and-drop меняются размеры элементов,
                 в результате конечную точку нужно определять дважды:
                 до перемещения и после смены разметки страницы в результате перемещения */
                .moveToElement($(widgetItemContainersCss))
                .release()
                .build()
                .perform();
    }

    public void checkPanelWithHeaderIsFolded() {
        $$(panelWithHeaderBodyElements).first().shouldHave(attribute("hidden"));
    }

    public void checkPanelWithHeaderIsNotFolded() {
        $$(panelWithHeaderBodyElements).first().shouldNotHave(attribute("hidden"));
    }

    public void checkAlignmentLine(String typeAlignmentLine) {
        String alignment = "";
        switch (typeAlignmentLine) {
            case "По правому краю":
                alignment = "right";
                break;
            case "По левому краю":
                alignment = "left";
                break;
            case "По центру":
                alignment = "center";
                break;
            case "По ширине":
                alignment = "justify";
                break;
            case "Распределить":
                alignment = "evenly";
                break;
        }
        $(By.cssSelector("app-row-layout[data-elements-align='" + alignment + "']")).shouldBe(exist);
    }

    public void checkTableHeadItemVisible(String name) {
        $$(tableHeadItemsCss).findBy(text(name)).shouldBe(visible);
    }

    public void checkTableNotExists() {
        $(tableHeadItemsCss).shouldNot(exist);
    }

    public void checkIndexTableElementsAggregated() {
        ElementsCollection tableBodyInts = $$(tableHeadFloatNumbersCss);
        tableBodyInts.last().shouldBe(visible);
        int valuesToAggregate = 0;
        for (SelenideElement e : tableBodyInts) {
            valuesToAggregate += Integer.parseInt(e.getText());
        }
        $(tableHeadFloatNumberCss).shouldBe(visible)
                .shouldHave(text(String.valueOf(valuesToAggregate)));
    }

    public void checkFinderVisible() {
        $(finderButtonXpath).shouldBe(visible);
    }

    public void fillFinderQuery(String elementName) {
        $(finderInputCss).shouldBe(visible).sendKeys(elementName);
    }

    public void clickFinderButton() {
        $(finderButtonXpath).shouldBe(visible).click();
    }

    public void checkFindResultExists(String elementNameSecond) {
        $(appNamesInTableBodyCss).shouldBe(visible).shouldHave(text(elementNameSecond));
    }

    public void checkStringParameterValue(String s) {
        $(parameterStringValueCss).shouldBe(visible).shouldHave(text(s));
    }

    public void checkUploadPNGOnForm() {
        try {
            $(imgFileCss).shouldBe(visible);
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            Selenide.refresh();
            $(imgFileCss).shouldBe(visible);
        }

    }

    public void checkViewFileWidgetOnForm() {
        $(viewFileCss).shouldBe(exist);
    }

    public void checkViewFileWidgetIsNotExistsOnForm() {
        $(viewFileCss).shouldNotBe(exist);
    }

    public String getDateStart() {
        return $(taskInstanceStartDateCss).getText();
    }

    public void addApprovalListWidgetByDragAndDrop() {
        actions().clickAndHold($(ApproveListDraggableXpath))
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void addFamiliarizationListWidgetByDragAndDrop() {
        actions().clickAndHold($(FamiliarizationListDraggableXpath))
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void addUserWidgetByDragAndDrop(String widgetName) {
        actions().clickAndHold($(By.xpath("//li[text()[contains(., '" + widgetName + "')]]")))
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void dragWidgetAndDropSidePanelToJoinTaskWidget(String nameWidget) {
        actions().clickAndHold($(By.xpath("//li[text()[contains(., '" + nameWidget + "')]]")))
                .moveToElement($$(sidePanelWidgetCss).findBy(text("Связанные задачи")))
                .moveToElement($$(sidePanelWidgetCss).findBy(text("Связанные задачи")))
                .release()
                .build()
                .perform();
    }

    public void clickButtonYesInApplicationElement() {
        $(buttonYesInApplicationElement).shouldBe(visible).click();
    }

    public void checkButtonYesInApplicationElement() {
        $(buttonYesInApplicationElement).shouldHave(visible);
    }

    public void checkTextInModalWindow(String textWidget) {
        $(textInModalWindow).shouldHave(text(textWidget));
    }

    public void checkHeaderTextInModalWindow(String textWidget) {
        $(headerInModalWindow).shouldBe(exist).shouldHave(text(textWidget));
    }

    public void checkStandardFormElementExistsOnForm() {
        $(standardFormElementCss).shouldNotBe(exist);
    }

    public void selectProcessStartCondition(String condition) {
        $$(yesNoButtonsCss).findBy(Condition.attribute("aria-label", condition))
                .shouldBe(visible).click();
    }

    public void checkExistsWidgetOnToolBar(String widgetName) {
        $$(sidePanelCss).findBy(text(widgetName)).shouldBe(visible);
    }

    public void checkAppElementExistsOnForm(String appName) {
        $$(standardFormElementCss).findBy(text(appName)).shouldBe(exist);
    }

    public void checkAppElementNotExistsOnForm(String appName) {
        $$(standardFormElementCss).findBy(text(appName)).shouldNotBe(exist);
    }

    public void checkExistWidgetOnWrapper(String widgetName) {
        $$(appPageWrapperCss).findBy(text(widgetName)).shouldBe(exist);
    }

    public void checkNotExistWidgetOnWrapper(String widgetName) {
        $$(appPageWrapperCss).findBy(text(widgetName)).shouldNot(exist);
    }

    public void checkExistLineOnWrapper() {
        $(appPageWrapperTagLineCss).shouldBe(exist);
    }

    public void checkNotExistLineOnWrapper() {
        $(appPageWrapperTagLineCss).shouldNot(exist);
    }

    public void checkExistColumnOnWrapper() {
        $(appPageWrapperColumnCss).shouldBe(exist);
    }

    public void checkNotExistColumnOnWrapper() {
        $(appPageWrapperColumnCss).shouldNot(exist);
    }
}
