package pages.elmaPages;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import infrastructure.elmaBackend.ElmaBackend;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class ApiPage extends BasePage {
    @Inject
    protected ElmaBackend elmaBackend;

    private final By methodsListCss = By.cssSelector("elma-tabset:nth-child(2) > ul li");
    private final By actionsListCss = By.cssSelector("app-api-path-handler elma-tabset ul li");
    private final By textareaCss = By.cssSelector("elma-tab[class*='active'] textarea");
    private final By elmaAnswerCss = By.cssSelector("elma-tab:last-child[class*='active'] pre");
    private final By sendRequestButtonCss = By.cssSelector("elma-tab:last-child[class*='active'] button");
    private final By idInputCss = By.cssSelector("elma-tab:last-child[class*='active'] input[name]");
    private final By responseResultCss = By.cssSelector("app-api-path-handler-test span");

    /**
     * Выбор апи метода для элемента
     *
     * @param action название вкладки (получить,создать,изменить...)
     */
    public void chooseApiMethod(String action) {
        $$(methodsListCss).findBy(text(action)).shouldBe(visible).click();
    }

    /**
     * Выбор действий после открытия метода
     *
     * @param action название вкладки (json пакет, проверить)
     */
    public void chooseApiAction(String action) {
        $$(actionsListCss).findBy(text(action)).shouldBe(visible).click();
    }

    /**
     * Удаляет дефолтный запрос создания элемента и заменяет его на свой уже заполненный
     *
     * @param name имя элемента приложения
     */
    public void enterCreateElementJson(String name) {
        String json = String.format("""
                {
                  "context": {
                      "__name": "%s",
                      "__directory": "00000000-0000-0000-0000-000000000000",
                      "__externalProcessMeta": "undefined"
                  },
                  "withEventForceCreate": true
                }""", name);
        $(textareaCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, json);
    }

    /**
     * Удаляет дефолтный запрос смены статуса и заменяет его на свой уже заполненный
     *
     * @param statusCode код статуса на который меняем
     */
    public void enterChangeElementStatusJson(String statusCode) {
        String json = String.format("""
                {
                  "status": {
                    "code": "%s"
                  }
                }""", statusCode);
        $(textareaCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, json);
    }

    /**
     * Удаляет дефолтный запрос списка элементов и заменяет его на свой уже заполненный
     *
     * @param elementName имя элемента который ищем
     * @param status      статус этого элемента
     */
    public void getElementListJson(String elementName, String status) {
        String createdBy = elmaBackend.getUserIdByEmail(config.adminLogin);
        String json = String.format("""
                {
                  "active": true,
                  "filter": {
                    "tf": {
                      "__name": "%s",
                      "__index": {
                        "min": 1,
                        "max": 100
                      },
                      "__createdBy": "%s",
                      "__updatedAt": {
                        "min": "2018-09-01",
                        "max": "2044-01-01"
                      }
                    }
                  },
                  "from": 0,
                  "size": 10,
                  "ascending": false,
                  "statusCode": [
                   "%s"
                  ]
                }""", elementName, createdBy, status);
        $(textareaCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, json);
    }

    /**
     * Удаляет дефолтный запрос id Элемента и заменяет на предсозданный
     *
     * @param id id элемента приложения
     */
    public void enterGetElementId(String id) {
        $(idInputCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, id);
    }

    /**
     * Жмет кнопку Отправить
     */
    public void pressSendRequestButton() {
        $(sendRequestButtonCss).shouldBe(visible).click();
    }

    /**
     * Проверяет тело ответа, чтобы там было переданные значения переменной
     * Также должен быть код ответа - 200
     *
     * @param name ожидаемое значение в поле __name в ответе
     */
    public void checkAnswerContain(String name) {
        String response = $$(elmaAnswerCss).last().shouldBe(visible).getText();
        JsonObject responseJson = JsonParser.parseString(response).getAsJsonObject().getAsJsonObject("item");
        String nameFromResponse = responseJson.get("__name").toString().replace("\"", "");
        $$(responseResultCss).findBy(text("Результат:"))
                .$("a").shouldBe(visible).shouldHave(text("200"));
        Assertions.assertEquals(nameFromResponse, name);
    }

    /**
     * Проверяет тело ответа, чтобы там было переданные значения переменных
     * Также должен быть код ответа - 200
     *
     * @param name ожидаемое значение в поле __name в ответе
     * @param id   ожидаемое значение в поле __id в ответе
     */
    public void checkAnswerContain(String name, String id) {
        String response = $$(elmaAnswerCss).last().shouldBe(visible).getText();
        JsonObject responseJson = JsonParser.parseString(response).getAsJsonObject().getAsJsonObject("item");
        String nameFromResponse = responseJson.get("__name").toString().replace("\"", "");
        String idFromResponse = responseJson.get("__id").toString().replace("\"", "");
        $$(responseResultCss).findBy(text("Результат:"))
                .$("a").shouldBe(visible).shouldHave(text("200"));
        Assertions.assertEquals(nameFromResponse, name);
        Assertions.assertEquals(idFromResponse, id);
    }

    /**
     * Проверяет тело ответа, чтобы там было переданные значения переменных
     * Также должен быть код ответа - 200
     *
     * @param name       ожидаемое значение в поле __name в ответе
     * @param id         ожидаемое значение в поле __id в ответе
     * @param idPosition ожидаемое значение в поле status в ответе(в ответе указывается порядковый номер статуса а не он сам)
     */
    public void checkAnswerContain(String name, String id, int idPosition) {
        String response = $$(elmaAnswerCss).last().shouldBe(visible).getText();
        JsonObject responseJson = JsonParser.parseString(response).getAsJsonObject().getAsJsonObject("item");
        String nameFromResponse = responseJson.get("__name").toString().replace("\"", "");
        String idFromResponse = responseJson.get("__id").toString().replace("\"", "");
        String statusFromResponse = responseJson.get("__status").getAsJsonObject().get("status").toString().replace("\"", "");
        $$(responseResultCss).findBy(text("Результат:"))
                .$("a").shouldBe(visible).shouldHave(text("200"));
        Assertions.assertEquals(nameFromResponse, name);
        Assertions.assertEquals(idFromResponse, id);
        Assertions.assertEquals(statusFromResponse, Integer.toString(idPosition));
    }

    /**
     * Проверяет первый элемент возвращенного массива, чтобы там было переданные значения переменных
     * Также должен быть код ответа - 200
     *
     * @param name       ожидаемое значение в поле __name в ответе
     * @param id         ожидаемое значение в поле __id в ответе
     * @param idPosition ожидаемое значение в поле status в ответе(в ответе указывается порядковый номер статуса, а не он сам)
     */
    public void checkAnswerContainInArray(String name, String id, int idPosition) {
        String response = $$(elmaAnswerCss).last().shouldBe(visible).getText();
        String createdBy = elmaBackend.getUserIdByEmail(config.adminLogin);
        JsonArray responseJson = JsonParser.parseString(response).getAsJsonObject()
                .getAsJsonObject("result").getAsJsonArray("result");
        JsonObject target = responseJson.get(0).getAsJsonObject();
        String nameFromResponse = target.get("__name").toString().replace("\"", "");
        String idFromResponse = target.get("__id").toString().replace("\"", "");
        String createdByFromResponse = target.get("__createdBy").toString().replace("\"", "");
        String statusFromResponse = target.get("__status").getAsJsonObject().get("status").toString().replace("\"", "");
        $$(responseResultCss).findBy(text("Результат:"))
                .$("a").shouldBe(visible).shouldHave(text("200"));
        Assertions.assertEquals(nameFromResponse, name);
        Assertions.assertEquals(idFromResponse, id);
        Assertions.assertEquals(createdByFromResponse, createdBy);
        Assertions.assertEquals(statusFromResponse, Integer.toString(idPosition));
    }
}
