package pages.elmaPages;

import com.codeborne.selenide.Selenide;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import pages.BasePages.BasePage;

import java.util.Locale;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class CompanyCardPage extends BasePage {
    private final String elementNameCss = "app-dynamic-form-row input[id='__name']";
    private final String addContactCss = "app-dynamic-form-row:nth-child(7) button[class*=add-element]";
    private final String addDealCss = "app-dynamic-form-row:nth-child(8) button[class*=add-element]";
    private final String contactOnCardCss = "app-dynamic-form-row:nth-child(7) app-collection-readonly-link:first-child";
    private final String dealOnCardCss = "app-dynamic-form-row:nth-child(8) app-collection-readonly-link:first-child";

    public void clickAddContact() {
        $(addContactCss).shouldBe(visible).click();
    }

    public void clickAddDeal() {
        $(addDealCss).shouldBe(visible).click();
    }

    public void fillName(String name) {
        $(elementNameCss).shouldBe(visible).sendKeys(name);
    }

    public void checkContactName(String text) {
        $(contactOnCardCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkDealName(String text) {
        $(dealOnCardCss).shouldBe(visible).shouldHave(text(text));
    }

    public void open(String companyId) {
        String urlCompanyCardElement = "_clients/_companies(p:item/_clients/_companies/" + companyId + ")";
        // при открытии карточки по ссылке не грузится остальной контент сайта под нею.
        String baseUrl = config.standUrl;
        String fullUrl = String.format(baseUrl + String.join("/", urlCompanyCardElement)).toLowerCase(Locale.ROOT);
        if (!CustomDriver.getCurrentUrl().equals(fullUrl) | fullUrl.equals(baseUrl)) {
            Selenide.open(fullUrl);
        }
        checkAlert();
    }
}
