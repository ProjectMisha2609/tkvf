package pages.elmaPages;

import com.codeborne.selenide.Condition;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Selenide.$;

/**
 * Страница просмотр 'Администрирование / Файлы'
 */
@Singleton
public class FilePageInAdminSectionPage extends BasePage {
    private final By uncheckedCheckboxCss = By.cssSelector("[class='p-checkbox-icon']");
    private final By saveButtonCss = By.cssSelector("[class*='primary']");


    public void clickCheckmark() {
        if ($(uncheckedCheckboxCss).exists())
            $(uncheckedCheckboxCss).parent().shouldBe(Condition.visible).click();
    }

    public void clickButtonSave() {
        $(saveButtonCss).shouldBe(Condition.visible).click();
    }
}