package pages.elmaPages;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.Actions.ConfigPageActions;
import pages.BasePages.BasePage;
import pages.elmaModals.ImportModal;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.WebDriverConditions.url;
import static java.lang.String.format;
import static java.time.format.DateTimeFormatter.ofPattern;

@Singleton
public class SectionPage extends BasePage implements ConfigPageActions {
    @Inject
    protected ElmaBackend elmaBackend;

    /**
     * Метод открытия элемента приложения
     *
     * @param sectionName секция, содержащая приложение
     * @param appName     имя приложения
     * @param elementName имя элемента
     */
    public void openAppElement(String sectionName, String appName, String elementName) {
        String baseUrl = config.standUrl;
        String elementId = elmaBackend.getElementIdByName(sectionName, appName, elementName);
        String fullUrl = baseUrl + "/" + sectionName.toLowerCase(Locale.ROOT) + "/" + appName.toLowerCase(Locale.ROOT) +
                "(p:item/" + sectionName.toLowerCase(Locale.ROOT) + "/" + appName.toLowerCase(Locale.ROOT) + "/" + elementId + ")";
        if (!CustomDriver.getCurrentUrl().equals(fullUrl) | fullUrl.equals(baseUrl)) {
            Selenide.open(fullUrl);
        }
        checkAlert();
    }

    /**
     * Открыть входящую задачу по ID
     *
     * @param taskID айди задачи
     */
    public void openTask(String taskID) {
        String baseUrl = config.standUrl;
        String fullUrl = String.format("%1$s/tasks/income(p:task/%2$s)", baseUrl, taskID);
        if (!CustomDriver.getCurrentUrl().equals(fullUrl) | fullUrl.equals(baseUrl)) {
            Selenide.open(fullUrl);
        }
        checkAlert();
    }

    private final String toastId = "[id=toast-container] [class*=toast-title]";
    private final String sideNavigationAppNameId = "[data-test=sideNavigationAppNameS]";
    private final String diagrammerContainerCssId = "[class=diagrammer-container]";
    private final By headerPageTemplateCss = By.cssSelector("div.page-header__title elma-label");
    private final By widgetStartPageCss = By.cssSelector("elma-main-page-default-widget");
    private final String counterNameCss = "span>a[class*=ng-star-inserted]";
    private final By tabWidgetOnPageCss = By.cssSelector("app-custom-page elma-tabset");
    private final String contextSimplePageCss = "app-custom-page elma-form-row span.labelName";
    private final By columnWidgetOnPageCss = By.cssSelector("app-custom-page elma-row elma-column");
    private final By panelWithHeaderWidgetOnPageCss = By.cssSelector("app-custom-page elma-groupbox span");
    private final By codeWidgetOnPageCss = By.cssSelector("app-custom-page div");
    private final By textWidgetOnPageCss = By.cssSelector("app-custom-page div[data-widget='[Текст]']");
    private final String inscriptionTextOnPageCss = "app-custom-page elma-label";
    private final String pageHeaderOnPageCss = "app-custom-page app-page-header";
    private final String pageContentOnPageCss = "app-custom-page app-page-content";
    private final By customPageCss = By.cssSelector("app-custom-page");
    private final String nameContainerSwitchCss = "app-name-config div.radioswitch__group";
    private final String switchUseNameAppCss = "p-radiobutton label";
    private final String patternNameFieldCss = "label.radioswitch__plate input[title='Шаблон']";
    private final String savePatternNameCss = "app-page-content div.btn-group button.btn-primary";
    private final String elementAppHeaderCss = "div.tile-view div.tile-item:first-child app-appview-card-header span";
    private final String appInLeftToolbarCss = "app-navigation-namespace [class*='side-nav__item'] [data-test='sideNavigationAppNameS']";
    private final String templateDocInSectionCss = "app-namespace-doctemplate [class*='childerenNodes'] elma-type-string span";
    private final String appSideBarCss = "[class*='side-nav__scope'] div[class*='side-nav__item']";
    private final String addWidgetBtnCss = "button[title='Добавить виджет']";
    private final String sectionTitleAndNameCss = "app-navigation-submenu-title";
    private final String groupCss = "div.childerenNodes elma-type-string span";
    private final By settingsActionCss = By.cssSelector("button[title*='Настройка действий']");
    private final String permissionCreateCss = "tbody td:nth-child(3) elma-checkbox";
    private final By permissionAllAccess = By.cssSelector("tbody td:nth-child(10) elma-checkbox");
    private final By permissionProcessManagement = By.cssSelector("tbody td:nth-child(7) elma-checkbox");
    private final By permissionUpdate = By.xpath("//table//input[contains(@value,'update')]/../..");
    private final By permissionDelete = By.xpath("//table//input[contains(@value,'delete')]/../..");
    private final String saveAccessCss = "div.control[class*='btn-group'] button[elmabutton='primary']";
    private final String accessContainerCss = "div.content-body";
    private final String accessRadiobuttonCss = "p-radiobutton label";
    private final String messageSaveAccessCss = "div[aria-label='Изменения успешно сохранены']";
    private final By actionButtonNotSettingsCss = By.cssSelector("app-appview-process-buttons elma-buttons div.fluid-nav-scope div.fluid-nav-item");
    private final String trashIconCss = "[class*='visible'] div.delete button[elmabutton='danger']";
    private final String trashLinkCss = "[class*='visible'] div.delete button[elmabutton='link']";
    private final String actionContainerNotSettingsStatusCss = "app-appview-process-buttons div[class*='fluid-nav-scope']";
    private final String actionButtonInNotSettingStatusCss = "div[class*='fluid-nav-item']:last-child button";
    private final String buttonOnProcessForm = "[class*='visible'] elma-popover-footer button[class*='primary']";
    private final String buttonOnDangerForm = "[class*='visible'] elma-popover-footer button[class*='danger']";
    private final String searchByTasksCss = "[placeholder='Поиск по задачам']";
    private final String buttonSearchByTasksCss = "[class*='search-item__name']";
    private final String containerSearchResultsCss = "p-table";
    private final String containerTasksCss = "tbody";
    private final String buttonSearchByTasksParametersCss = "[title='Поиск по параметрам']";
    private final String containerSearchByTasksParametersCss = "div[class*='visible'][class*='popover-outer'] [class*='popover-body']";
    private final String searchFieldCss = "[class*='search-group']";
    private final String extendSearchCss = "[title='Расширенный поиск']";
    private final String mainButtonSearchByParametersCss = "[class*='footer'] button";
    private final String nameElementCss = "[class*='fc-event-title']";
    private final String containerEventCss = "full-calendar";
    private final String containerCreateEventModalCss = "[class*='complex-popup__main modal']";
    private final String modalTitleCreateEventCss = "[class*='modal-title']";
    private final String tasksSidebarMenuCss = "div[class='side-nav__scope']";
    private final String tasksSidebarMenuOptionCss = "div[class*='side-nav__item']";
    private final String allTasksCss = "div[aria-label='Все']";
    private final By searchTaskOnPage = By.cssSelector("app-appview-list-table button[class*='task-name__title']");
    private final By pageContentCss = By.cssSelector("app-page-content");
    private final By modalFooterPrimaryBtnCss = By.cssSelector("div[class*='modal-footer'] button[class*='btn-primary']");
    private final By categoryOnAddProcessPage = By.cssSelector("app-bptemplate-admin-page-tree-category div.d-flex.category");
    private final By addProcessId = By.cssSelector("[data-test=addProcessB]");
    private final By notificationAuthorCss = By.cssSelector("app-object-message span[class*='user-name']");
    private final By signButtonXpath = By.xpath("//app-sign-app//button");
    private final By nameTaskCss = By.cssSelector("[class*='cell___name']");
    private final By dateStartTaskCss = By.cssSelector("[class*='cell___createdAt'] [class*='date']");
    private final By dateFinishTaskCss = By.cssSelector("[class*='cell_dueDate'] [class*='date']");
    private final By containerTableTasksElementCss = By.cssSelector("p-table[class*='p-element']");
    private final By emptyMessageCss = By.cssSelector("[class*='emptymessage']");
    private final By inputComment = By.cssSelector("textarea[name='comment']");
    private final By inputCommentFamiliarize = By.cssSelector("elma-form textarea");
    private final By plusFileField = By.cssSelector("div[class='drop-area-wrapper']");
    private final By buttonPrimaryCss = By.cssSelector("button[elmabutton='primary']");
    private final By buttonDangerCss = By.cssSelector("button[elmabutton='danger']");
    private final By menuHorizontal = By.xpath("//*[contains(text(), 'menu_horizontal')]");
    private final By buttonSelectFiles = By.xpath("//*[text()[contains(.,'Выбрать из Раздела \"Файлы\"')]]");
    private final By buttonMyFileCss = By.cssSelector("[class*='demo elma-modal-window'] [class*='disk-list__item']:nth-child(3) [class*='directory__name']");
    private final String buttonNamePhotoOrFolder = "//*[contains(@class,'demo elma-modal-window')]//div[text()[contains(.,'%s')]]";

    /**
     * селекторы для запуска бизнес-процесса: кнопка +Процесс, процессы в модальном окне, кнопка подтверждения запуска,
     * раскрывающиеся меню древа процессов, кнопка закрытия стадии процесса
     */
    private final By plusProcessButtonXpath = By.xpath("//button[@data-test='createVacancyB'][text()[contains(., 'Процесс')]]");
    private final By processesCss = By.cssSelector("app-bpm-public  a");
    private final By processStartConfirmationButton = By.cssSelector("button[data-test='createVacancyB'][type='submit']");
    private final By processAccordionsCss = By.cssSelector("app-bpm-tree button");
    private final By goToNextStageButtonXpath = By.xpath("//button[@data-test='createVacancyB'][text()[contains(., '->')]]");
    private final By agreeButtonCss = By.cssSelector("button[data-test='createVacancyB'][type='button']");
    private final By inscriptionOfPerformedOperation = By.cssSelector("div[class*='list-status @approved']");
    private final By registrationDocButtonRightSideOfWindow = By.cssSelector("button[class*='first full']");
    private final By registrationButtonRightSideOfWindow = By.xpath("//button[@elmabutton='default'][text()[contains(., 'Зарегистрировать документ')]]");
    private final By plusCreateButton = By.cssSelector("[class='hide-mobile']");
    private final By expandMenuCss = By.cssSelector("[class='p-dropdown-trigger']");
    private final By inputDateCss = By.cssSelector("input[placeholder='дд.мм.гггг']");
    private final By inputTimeCss = By.cssSelector("input[placeholder='h:мм']");
    private final By accessRight = By.cssSelector("section button[title='Права доступа']");
    private final By blockAdditionalRights = By.xpath("//app-permissions//h3[contains(text(), 'Дополнительные права')]/ ..//div[contains(@class,'permission-group')]/span");

    /**
     * Разворачиваемая папка в разделах
     */
    private final By folderLink = By.cssSelector(".btn-link.folder-link");
    /**
     * Название процесса на форме процессной задачи
     */
    private final By processNameInModalTask = By.cssSelector("[class*='modal'] header[class='modal-header'] span[class*='subtitle']");
    /**
     * Элемент приложения при отображении плиткой
     */
    private final By elementInTileCss = By.cssSelector("div[class*='md tile-item']");
    private final By numeratorNextNumberChangeCss = By.cssSelector("elma-form-control button");
    private final By numeratorSetNextNumberChangeCss = By.cssSelector("input[min='1']");
    private final By patternTextStringCss = By.cssSelector("input[name='name']");
    private final By dialogWindowCss = By.cssSelector("p-dialog div[class*='p-element']");
    private final By closeDialogWindowCss = By.cssSelector("p-header span[class='elma-icons']");
    private final By dialogWindowButtonCss = By.cssSelector("div[role='dialog'] [class*='footer'] button");
    private final By leftSideNavigationItemCss = By.cssSelector("app-navigation-main-item span");
    private final By newSectionCreationInputsCss = By.cssSelector("p-dialog elma-form input");
    private final By dialogRemoveGroupCss = By.cssSelector("elma-autocomplete button[class*='remove']");
    private final By expandSearchResultCss = By.cssSelector("span[class*='expand'] i");
    private final By expandSearchSelectAdminGroupCss = By.cssSelector("p-treenode div[aria-label='Администраторы']");
    private final By sectionNameId = By.cssSelector("[data-test=sectionNameTb]");
    private final By buttonChooseSendApproveXpath = By.xpath("//button[contains(text(),'send_approve') or contains(text(),'send_doc')]");
    private final By buttonSendApproveXpath = By.xpath("//span[contains(text(),'На согласование')]");
    private final By buttonSendFamiliarizationXpath = By.xpath("//span[contains(text(),'На ознакомление')]");
    /**
     * Статус в карочке приложения
     */
    private final By appStatusCss = By.cssSelector("app-appview-view-status span");
    private final By changeStatusButtonCss = By.cssSelector(".status-item .targets-toggle");
    private final By listStatusCss = By.cssSelector("app-appview-view-status .status-item");
    private final By kanbanElementCss = By.cssSelector("[class*='ngx-dnd-item'] a span");
    private final By lastKanbanStatusCss = By.cssSelector("app-page-content app-appview-list-board-list:last-child");
    /**
     * Блок содержащий карточки приложения
     */
    private final By blockCardApp = By.cssSelector("[class*='tile-view']");
    private final By checkBoxCss = By.cssSelector("elma-checkbox");
    private final By elmaFormRowCss = By.cssSelector("elma-form-row");
    private final By multiSelectLabelCss = By.cssSelector(".p-multiselect-label");
    private final By multiSelectItemsCss = By.cssSelector("p-multiselectitem");
    private final By elmaModalBody = By.cssSelector("elma-modal-body");
    private final By taskInTaskBlock = By.cssSelector("app-system-linked-task .task-title");

    /**
     * Локаторы связанные с 'Иерархический справочник'
     */
    private final By pencilButtonXpath = By.xpath("//*[contains(text(),'app_pencil')]");
    private final By addFolderButtonCss = By.cssSelector("[class='add-folder-link']");
    private final By inputNewFolder = By.cssSelector("[class='new-folder'] [class*='ng-pristine']");
    private final By systemCheckbox = By.xpath("//*[contains(text(),'system_checkbox')]");
    private final By plusAppButton = By.xpath("//button[@data-test='createVacancyB'][text()[contains(., 'Приложение')]]");
    private final By inputNameApp = By.cssSelector("[class*='modal-body'] input[id='__name']");
    private final By saveButton = By.xpath("//button[@data-test='createVacancyB'][text()[contains(., 'Сохранить')]]");
    private final String addAppName = "//div[@class='tile-view']//span[text()[contains(., '%s')]]";
    private final String folderCss = "[title='%s']";
    private final By lastFolderCss = By.cssSelector("[class*='cdk-drop-list']>div>div>:last-child [class='folder-name']");
    private final By addButtonInAccessRights = By.cssSelector("[class='buttons']>[class*='default']");
    private final By listOfActionsWithFolder = By.cssSelector("[class='popover-content'] [class*='menu-group__option']");
    private final By elementButtonInModalWindow = By.cssSelector("[class*='elma-modal'] [class*='primary']");
    private final By elementToAssignAccessRights = By.cssSelector("[class*='p-radiobutton-label']");
    private final By inputFieldInBlockGroup = By.cssSelector("app-group-select input[placeholder='Начните вводить текст для поиска элемента']");
    private final By inputField = By.cssSelector("input[placeholder='Начните вводить текст для поиска элемента']");
    private final By systemGroups = By.cssSelector("[class*='default elma-icons']");
    private final By openListOrgStructure = By.cssSelector("[class*='selectbox-arrow']");
    private final By listOrgStructure = By.cssSelector("[class*='selectbox-dropdown'] span");
    private final By listGroup = By.cssSelector("[class='elma-tree-label']");
    private final By listUserByEmail = By.cssSelector("[class*='cell_email']");
    private final By checkBoxAllUsers = By.cssSelector("tr>td:nth-child(2) [class*='p-element']");
    private final By inputRenameFolder = By.cssSelector("[class='folder-name'] [class*='ng-pristine']");
    private final By checkmarkButton = By.xpath("//button[contains(text(),'check')]");
    private final String folderToMoveTo = "[class*='elma-modal'] [title='%s']";
    private final By saveHierarchicalDirectorySettings = By.cssSelector("[class*='control btn-group']>[class*='primary']");
    private final By checkBoxHierarchicalDirectorySettings = By.cssSelector("span[class*='p-checkbox-icon']");
    private final By modalBodyExtendSearchCss = By.cssSelector("[class*='modal-body'] [title='Расширенный поиск']");
    private final By itemsFromDirectoryCss = By.cssSelector(".doc-nav__name");
    private final By titleItemAppCss = By.cssSelector("div.md.tile-item div.title span");
    private final By navigationDirectoryCss = By.cssSelector("app-navigation-directory");
    private final By childNavigationFilterCss = By.cssSelector(".doc-nav-child app-navigation-filter");
    private final By navigationFilterCss = By.cssSelector("app-navigation-filter");
    private final By loadTaskListXpath = By.xpath("//*[contains(@class,'emptymessage') or contains(@class,'task-name__template')]");
    private final By emptyMessageListXpath = By.xpath("//*[contains(@class,'emptymessage')]");
    private final By registerButtonOnPopoverCss = By.cssSelector("elma-popover-footer button.btn-primary");
    private final By addNewAppOrPageButtonCss = By.cssSelector("[data-test=\"sidebarAddAppB\"]");
    private final By appSettingButton = By.xpath("//*[contains(@class,'sidebar-controls')]/button/i[contains(text(),'tool_wrench')]/..");
    private final By appNameInListBasket = By.cssSelector("elma-tab[role='tabpanel'] span");

    /**
     * Имена и фамилии пользователей, принявших согласуемую сущность
     */
    private final By approversFirstAndLastNames = By.xpath("//elma-sidebar-widget//app-docflow-list-respondents//li//i[text()='approved']/..//app-user-name//span");
    /**
     * Имена и фамилии пользователей, участвовавших в согласовании
     */
    private final By participantFirstAndLastNames = By.xpath("//elma-sidebar-widget//app-docflow-list-respondents//li//i[contains(text(),'')]/..//app-user-name//span");
    private final By messageTitleCss = By.cssSelector(".message__title");
    private final By messageBodyThreadCss = By.cssSelector(".message__body_thread");

    public void checkToastAppeared() {
        $(toastId).shouldBe(visible);
    }

    public void checkCreatedAppAvailable(String text) {
        $(sideNavigationAppNameId).shouldBe(visible).shouldHave(text(text));
    }

    public void checkCreatedAppsAvailable(String text) {
        $$(sideNavigationAppNameId).findBy(text(text)).shouldBe(visible);
    }

    public void checkNameMenuSeparator(String nameSeparator) {
        $(By.xpath("//a[contains(@class,'side-nav__separator')]//span[contains(.,'" + nameSeparator + "')]"))
                .shouldBe(visible);
    }

    public void checkDiagrammerExists() {
        $(diagrammerContainerCssId).shouldBe(visible);
    }

    public void checkPageTemplatePublished(String text) {
        $(headerPageTemplateCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkDefaultPageWidgetPublished() {
        $(widgetStartPageCss).shouldBe(visible);
    }

    public void checkCounterNameExists(String text) {
        $(counterNameCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkTabWidgetAddedOnAppTypePage() {
        $(tabWidgetOnPageCss).shouldBe(visible);
    }

    public void checkColumnWidgetAddedOnAppTypePage() {
        $(customPageCss).shouldBe(visible);
        $(columnWidgetOnPageCss).should(exist);
    }

    public void checkTextPanelWithHeaderWidgetOnAppTypePage(String text) {
        $(panelWithHeaderWidgetOnPageCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkTextCodeWidgetOnAppTypePage(String text) {
        $(codeWidgetOnPageCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkTextFromTextWidgetOnAppTypePage(String text) {
        $(textWidgetOnPageCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkTextFromInscriptionWidgetOnAppTypePage(String text) {
        $$(inscriptionTextOnPageCss).findBy(text(text)).shouldBe(visible);
    }

    public void checkPageHeaderWidgetAddedOnAppTypePage() {
        $(pageHeaderOnPageCss).shouldBe(visible);
    }

    public void checkPageContentWidgetAddedOnApTypePage() {
        $(customPageCss).shouldBe(visible);
        $(pageContentOnPageCss).should(exist);
    }

    public void checkNameContextWidgetOnAppTypePage(String text) {
        $(contextSimplePageCss).shouldBe(visible).shouldHave(text(text));
    }

    public void clickElementNameByTemplate() {
        $(nameContainerSwitchCss)
                .$$(switchUseNameAppCss)
                .findBy(exactText("Формирование по шаблону"))
                .shouldBe(visible)
                .click();
    }

    public void fillPatternElementName(String namePattern) {
        $(patternNameFieldCss).shouldBe(visible).sendKeys(namePattern + " {$__index}");
    }

    public void clickSavaSettingsName() {
        $(savePatternNameCss).shouldBe(visible).click();
    }

    public void checkHeaderTitleCard(String text) {
        $(elementAppHeaderCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkAppDeleted() {
        SelenideElement element = $(appInLeftToolbarCss).shouldBe(disappear);
        element.should(not(exist));
    }

    public void clickTask(String taskName) {
//        try {
        $(pageContentCss).shouldBe(visible);
        $$(searchTaskOnPage).findBy(text(taskName)).shouldBe(visible).click();
//        } catch (ElementNotFound ignore) {
//            refreshPage();
//            clickAllTasks();
//            $(pageContentCss).shouldBe(visible);
//            $$(searchTaskOnPage).findBy(text(taskName)).shouldBe(visible).click();
//        }
    }

    public void clickTask(String processInstanceName, String taskName) {
//        try {
        $(pageContentCss).shouldBe(visible);
        SelenideElement task = $$("app-task-name").filter(text(processInstanceName))
                .findBy(text(taskName)).scrollTo().shouldBe(visible);
        //если сразу заходить бывает кнопка выполнения задания не появляется на форме
        CustomDriver.waitMills(1500);
        task.click();
//        } catch (ElementNotFound ignore) {
//            refreshPage();
//            clickAllTasks();
//            $(pageContentCss).shouldBe(visible);
//            $$("app-task-name").filter(text(processInstanceName))
//                    .findBy(text(taskName)).shouldBe(visible).click();
//        }
    }

    public void checkNameTemplateDoc(String text) {
        if ($(templateDocInSectionCss).is(not(visible)))
            $(folderLink).click();
        $(templateDocInSectionCss).shouldBe(visible).shouldHave(text(text));
    }

    public void checkAppCopiedInTargetSection(String... route) {
        String currentUrl = CustomDriver.getCurrentUrl();
        String targetUrl = String.format(config.standUrl + String.join("/", route)).toLowerCase(Locale.ROOT);
        $$(appSideBarCss).findBy(text(route[1])).shouldBe(visible);
        Assertions.assertEquals(currentUrl, targetUrl, "Текущий url не соответствует переданному");
    }

    public void clickCreateNewWidget() {
        $(addWidgetBtnCss).shouldBe(visible).click();
    }

    public void checkNewSectionSettingsApplied(String sectionName, String sectionDescription) {
        $(sectionTitleAndNameCss).shouldBe(visible).shouldHave(text(sectionName))
                .shouldHave(attribute("title", sectionDescription));
    }

    public void checkGroupOrRoleName(String text) {
        if ($(groupCss).is(not(visible)))
            $(folderLink).click();
        $(groupCss).shouldBe(visible).shouldHave(text(text));
    }

    public void clickLimitAccess(String buttonName) {
        $(accessContainerCss).$$(accessRadiobuttonCss)
                .findBy(text(buttonName)).shouldBe(visible).click();
    }

    @Deprecated // сделан метод установки чекбокса по его строке и колонке
    public void clickAccessCreateCheckbox() {
        $(permissionCreateCss).shouldBe(visible).click();
    }

    @Deprecated // сделан метод установки чекбокса по его строке и колонке
    public void clickAllAccessCheckbox() {
        $(permissionAllAccess).shouldBe(visible).click();
    }

    @Deprecated // сделан метод установки чекбокса по его строке и колонке
    public void clickProcessManagementCheckbox() {
        $(permissionProcessManagement).shouldBe(visible).click();
    }

    @Deprecated // сделан метод установки чекбокса по его строке и колонке
    public void clickUpdateCheckbox() {
        $(permissionUpdate).shouldBe(visible).click();
    }

    @Deprecated // сделан метод установки чекбокса по его строке и колонке
    public void clickDeleteCheckbox() {
        $(permissionDelete).shouldBe(visible).click();
    }

    @Deprecated // сделан глобальный метод для страниц настроек приложений и секций
    public void clickSaveAccess() {
        $(saveAccessCss).shouldBe(visible).click();
        $(messageSaveAccessCss).shouldBe(visible);
    }

    public void checkPermissionOnButtonCreate() {
//        try {
        $(settingsActionCss).shouldBe(visible);
        $(actionButtonNotSettingsCss).should(disappear, Duration.ofSeconds(10));
//        } catch (ElementShould e) {
//            refreshPage();
//            $(settingsActionCss).shouldBe(visible);
//            $(actionButtonNotSettingsCss).should(disappear);
//        }
    }

    public void clickDeleteButtonActionButton() {
        $(trashIconCss).shouldBe(visible).click();
        $(trashLinkCss).shouldBe(visible).click();
        //надо дать время на удаление
        CustomDriver.waitMills(2000);
    }

    public void checkButtonDeleted(String buttonName) {
        CustomDriver.waitMills(2000);
        $(settingsActionCss).shouldBe(visible);
        $(actionContainerNotSettingsStatusCss).$$(actionButtonInNotSettingStatusCss).findBy(text(buttonName)).shouldNot(exist);
    }

    public void clickButtonOnProcessForm() {
        $(buttonOnProcessForm).shouldBe(visible).click();
    }

    public void isProcessRun(String processName) {
        $(processNameInModalTask).shouldBe(visible).shouldHave(text(processName));
    }

    public void fillNameTaskBySearch(String taskName) {
        $(searchByTasksCss).shouldBe(visible).sendKeys(taskName);
    }

    public void clickSearchInTasks() {
        $(buttonSearchByTasksCss).shouldBe(visible).click();
    }

    @Deprecated // написан новый метод проверки имени задачи вместе с именем процесса
    public void checkTaskNameExists(String text) {
        $(containerSearchResultsCss).shouldBe(visible)
                .$$(containerTasksCss).findBy(text(text)).shouldBe(visible).shouldHave(text(text));
    }

    /**
     * Проверить, что за указанное время приходит задача с указанным именем от определённого процесса
     *
     * @param taskName    - имя задачи
     * @param processName - имя процесса
     * @param millis      - время ожидания в миллисекундах
     */
    public void checkTaskWithNameAppearFromProcess(String taskName, String processName, long millis) {
        $(By.xpath("//span[contains(text(),'" + processName
                + "')]/../button[contains(text(),'" + taskName + "')]"))
                .should(exist, Duration.ofMillis(millis)).scrollTo().shouldBe(visible);
    }

    /**
     * Проверить, что видна задача с указанным именем от определённого процесса
     *
     * @param taskName    - имя задачи
     * @param processName - имя процесса
     */
    public void checkTaskWithNameAppearFromProcess(String taskName, String processName) {
        $(By.xpath("//span[contains(text(),'" + processName
                + "')]/../button[contains(text(),'" + taskName + "')]"))
                .should(exist).scrollTo().shouldBe(visible);
    }

    public void clickSearchInParametersTasks() {
        $(buttonSearchByTasksParametersCss).shouldBe(visible).click();
    }

    public void clickSystemFields(String text) {
        $(containerSearchByTasksParametersCss).shouldBe(visible)
                .$$(searchFieldCss).findBy(text(text)).shouldBe(visible).click();
    }

    public void clickExtendSearch() {
        $(extendSearchCss).shouldBe(visible).hover();
        $(extendSearchCss).shouldBe(visible).click();
    }

    public void clickSearchByParameters() {
        $(containerSearchByTasksParametersCss).$(mainButtonSearchByParametersCss).shouldBe(visible).click();
    }

    public void clickOnEvent(String text) {
        $(containerEventCss).shouldBe(visible)
                .$$(nameElementCss).findBy(text(text)).shouldBe(visible).click();
    }

    public void checkElementNameExists(String text) {
        $(containerCreateEventModalCss).shouldBe(visible)
                .$$(modalTitleCreateEventCss).findBy(text(text)).shouldBe(visible).shouldHave(text(text));
    }

    public void clickTaskType(String taskType) {
        $(tasksSidebarMenuCss).shouldBe(visible)
                .$$(tasksSidebarMenuOptionCss).findBy(text(taskType)).shouldBe(visible).click();
    }

    public void clickAllTasks() {
        $(allTasksCss).shouldBe(visible).click();
    }

    public void changeTitleTemplate() {
        $$(switchUseNameAppCss).findBy(text("Формирование по шаблону")).shouldBe(visible).click();
        $(patternTextStringCss).shouldBe(visible).sendKeys("{$__index}");
        $(savePatternNameCss).shouldBe(visible).click();
        //без задержки он закроет окно сразу и не успеет сохранить
        CustomDriver.waitMills(1500);
    }

    public void checkAppElementExist(String elementName) {
        $$(elementInTileCss).findBy(text(elementName)).shouldBe(visible);
    }

    public void checkAppElementNotExist(String elementName) {
        $$(titleItemAppCss).findBy(exactText(" " + elementName)).shouldNotBe(exist);
    }

    public void changeNumeratorNextNumber(String nextNumber) {
        $(numeratorNextNumberChangeCss).shouldBe(visible).click();
        $(numeratorSetNextNumberChangeCss).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, nextNumber);
        $$(modalFooterPrimaryBtnCss).last().shouldBe(visible).click();
        $(modalFooterPrimaryBtnCss).shouldBe(visible).click();
        //без задержки он закроет окно сразу и не успеет сохранить
        CustomDriver.waitMills(1500);
    }

    public void checkBPCreationWindowAppear() {
        $(dialogWindowCss).shouldBe(visible);
        $(closeDialogWindowCss).shouldBe(visible).click();
        $(dialogWindowCss).shouldBe(disappear);
        $(dialogWindowCss).should(not(exist));
    }

    public void checkAppCreated(String appNameEntered) {
        $$(tasksSidebarMenuOptionCss).last().shouldBe(visible).shouldHave(text(appNameEntered));
    }

    public void checkLinkAppear(String linkName, String linkIcon, String link) {
        $("a[title='" + linkName + "']").shouldBe(visible).shouldHave(text(linkName));
        $("a[title='" + linkName + "'] i").shouldBe(visible).shouldHave(text(linkIcon));
        $("a[title='" + linkName + "']").shouldHave(href(link));
    }

    public void checkSectionDeleted(String sectionName) {
        webdriver().shouldHave(url(config.standUrl));
        //проверка, что боковая панель прогрузилась
        $$(leftSideNavigationItemCss).findBy(text("Задачи")).shouldBe(visible);
        $$(leftSideNavigationItemCss).findBy(text(sectionName)).shouldNot(exist);
    }

    public void closeDialogWindow() {
        $(dialogWindowCss).shouldBe(visible);
        $(closeDialogWindowCss).shouldBe(visible).click();
        $(dialogWindowCss).shouldBe(disappear);
    }

    public void goInCopiedSection() {
        //надо дать время
        $$(dialogWindowButtonCss).findBy(text("Перейти в Раздел")).shouldBe(visible);
        CustomDriver.waitMills(2000);
        new ImportModal().dialogWindowPressButton("Перейти в Раздел");
    }

    public void enterNameAndLink(String newSectionName, String newSectionLink) {
        $$(newSectionCreationInputsCss).first().shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, newSectionName);
        $$(newSectionCreationInputsCss).last().shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, newSectionLink.toLowerCase(Locale.ROOT));
    }

    public void checkSectionCopied(String newSectionName, String newSectionLink) {
        webdriver().shouldHave(url(config.standUrl + newSectionLink.toLowerCase(Locale.ROOT)));
        $$(sectionTitleAndNameCss).findBy(text(newSectionName)).shouldBe(visible);
        $(sectionTitleAndNameCss).shouldBe(visible).shouldHave(text(newSectionName));
    }

    public void dialogChangeGroupToAdmin() {
        $(dialogWindowCss).shouldBe(visible);
        $(dialogRemoveGroupCss).shouldBe(visible).click();
        $(extendSearchCss).shouldBe(visible).click();
        $(expandSearchResultCss).shouldBe(visible).click();
        $(expandSearchSelectAdminGroupCss).shouldBe(visible).click();
    }

    public void checkSectionNotVisible(String sectionName) {
        //проверка, что боковая панель прогрузилась
        $$(leftSideNavigationItemCss).findBy(text("Задачи")).shouldBe(visible);
        $$(leftSideNavigationItemCss).findBy(text(sectionName)).shouldNot(exist);
    }

    public void checkAppElementStatus(String text) {
        $(appStatusCss).shouldBe(visible).shouldHave(text(text));
    }

    public void clickChangeStatusButtonAndSelectNewStatus(String statusName) {
        $(changeStatusButtonCss).shouldBe(visible).click();
        $$(listStatusCss).findBy(text(statusName)).shouldBe(visible).click();
    }

    public void openElementStatusLast(String elementName) {
        $(lastKanbanStatusCss).shouldBe(visible)
                .$$(kanbanElementCss).findBy(text(elementName)).shouldBe(visible).hover().click();
    }

    /**
     * При добавлении процесса использовать этот метод иначе зависает браузер
     */
    public void clickAddProcess() {
        $(pageContentCss).shouldBe(visible).$(categoryOnAddProcessPage).shouldBe(visible);
        $(addProcessId).shouldBe(visible).click();
    }

    /**
     * Кликает по элементу приложения
     */
    public void clickOnCardApp(String cardName) {
        $$(blockCardApp).findBy(text(cardName)).shouldBe(visible);
        $(elementAppHeaderCss).click();
    }

    /**
     * Метод для запуска процесса компании по его названию.
     * Так как раскрывающееся дерево процессов может быть и открыто, и закрыто, есть перехват ошибки.
     *
     * @param name - название процесса
     */
    public void startCompanyProcessWithName(String name) {
        startSectionProcessWithName("Процессы компании", name);
    }

    /**
     * Метод для запуска процесса из секции по названию секции и процесса.
     * Так как раскрывающееся дерево процессов может быть и открыто, и закрыто, есть перехват ошибки.
     *
     * @param sectionName - название секции с процессом
     * @param name        - название процесса
     */
    public void startSectionProcessWithName(String sectionName, String name) {
        $(plusProcessButtonXpath).shouldBe(visible).click();
        try {
            $$(processesCss).findBy(partialText(name))
                    .should(exist, Duration.ofSeconds(3)).scrollTo()
                    .shouldBe(visible, Duration.ofSeconds(3)).click();
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            $$(processAccordionsCss).findBy(text(sectionName)).shouldBe(visible).click();
            $$(processesCss).findBy(partialText(name)).scrollTo().shouldBe(visible).click();
        }
    }

    public void clickNextStageOrExit() {
        $(goToNextStageButtonXpath).shouldBe(visible).click();
    }

    public void clickButtonSetApprove() {
        $(buttonChooseSendApproveXpath).click();
        $(buttonSendApproveXpath).click();
    }

    public void clickButtonSetFamiliarization() {
        $(buttonChooseSendApproveXpath).click();
        $(buttonSendFamiliarizationXpath).click();
    }

    @Deprecated // не использует часть сигнатуры, нужно или допилить, или удалить.
    public void startCompanyProcessWithNameAndSetFile(String id, String variableName) {
        $(plusProcessButtonXpath).shouldBe(visible).click();
        try {
            $$(processesCss).findBy(partialText(id))
                    .should(exist, Duration.ofSeconds(3)).scrollTo()
                    .shouldBe(visible, Duration.ofSeconds(3)).click();
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            $$(processAccordionsCss).findBy(text("Процессы компании")).shouldBe(visible).click();
            $$(processesCss).findBy(partialText(id)).scrollTo().shouldBe(visible).click();
        }
    }

    @Deprecated // дубликат метода startCompanyProcessWithName
    public void startCompanyProcess(String id) {
        $(plusProcessButtonXpath).shouldBe(visible).click();
        try {
            $$(processesCss).findBy(partialText(id))
                    .should(exist, Duration.ofSeconds(3)).scrollTo()
                    .shouldBe(visible, Duration.ofSeconds(3)).click();
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            $$(processAccordionsCss).findBy(text("Процессы компании")).shouldBe(visible).click();
            $$(processesCss).findBy(partialText(id)).scrollTo().shouldBe(visible).click();
        }
    }

    public void processStartConfirmation() {
        $(processStartConfirmationButton).shouldBe(visible).click();
    }

    public void clickCheckBox(String labelCheckBox) {
        $$(checkBoxCss).findBy(text(labelCheckBox)).shouldBe(visible).click();
    }

    public void clickMultiSelectLabel(String rowName) {
        $$(elmaFormRowCss).findBy(text(rowName)).$(multiSelectLabelCss).click();
    }

    public void clickMultiSelectItem(String itemName) {
        $$(multiSelectItemsCss).findBy(text(itemName)).scrollTo()
                .shouldBe(visible).click();
    }

    public void elementNotHaveStandardForm() {
        $(elmaModalBody).shouldBe(visible).$$(elmaFormRowCss).should(CollectionCondition.size(0));
    }

    public void checkNotificationWithAuthorVisible(String name) {
        $(notificationAuthorCss).shouldBe(visible).shouldHave(text(name));
    }

    public void clickPencilButton() {
        $(pencilButtonXpath).shouldBe(visible).click();
    }

    public void clickAddFolderButton() {
        $(addFolderButtonCss).shouldBe(visible).click();
    }

    public void inputNewFolder(String nameFolder) {
        $(inputNewFolder).shouldBe(visible).sendKeys(nameFolder);
        $(systemCheckbox).shouldBe(visible).click();
    }

    public void clickNameFolder(String nameFolder) {
        $(String.format(folderCss, nameFolder)).shouldBe(visible).click();
    }

    public void clickPlusAppButton() {
        $(plusAppButton).shouldBe(visible).click();
    }

    public void clickSaveButton() {
        $(saveButton).shouldBe(visible).click();
    }

    public void clickTaskInTaskBlock() {
        $(taskInTaskBlock).shouldBe(visible).click();
    }

    public void inputNameApp(String nameApp) {
        $(inputNameApp).shouldBe(visible).sendKeys(nameApp);
    }

    public void checkAddedApp(String nameApp) {
        $(By.xpath(String.format(addAppName, nameApp))).shouldHave(visible, exist);
    }

    public void moveFolderDown(String nameFolderOne) {
        SelenideElement folder = $((String.format(folderCss, nameFolderOne))).shouldBe(visible);
        int height = folder.getRect().getHeight();
        actions().clickAndHold(folder)
                // TODO: для того, что бы "взять" папку её нужно не только кликнуть, но и сдвинуть. Баг веба.
                .moveByOffset(0, height)
                .moveByOffset(0, -height)
                .moveByOffset(0, height)
                .release().perform();
    }

    public void isFolderInLastPosition(String nameFolder) {
        $(lastFolderCss).shouldHave(text(nameFolder));
    }

    public void checkAppNotVisible(String nameFolder) {
        $((String.format(folderCss, nameFolder))).shouldNot(visible);
    }

    public void checkAppVisible(String nameFolder) {
        $((String.format(folderCss, nameFolder))).shouldBe(visible);
    }

    public void clickButtonSettingByFolder(String nameFolder) {
        $((String.format("[title='%s'] button", nameFolder))).shouldBe(visible).click();
    }

    public void selectSettingFolder(String settingsName) {
        $$(listOfActionsWithFolder).shouldBe(CollectionCondition.sizeGreaterThan(0))
                .findBy(text(settingsName)).shouldBe(visible).hover().click();
    }

    public void clickButtonAddInAccessRights() {
        $(addButtonInAccessRights).shouldBe(visible).click();
    }

    public void clickButtonSelect() {
        $$(elementButtonInModalWindow).findBy(text("Выбрать")).shouldBe(visible).click();
    }

    public void clickButtonSave() {
        $$(elementButtonInModalWindow).findBy(text("Сохранить")).shouldBe(visible).click();
    }

    public void addUserRights(String userEmail) {
        $$(modalBodyExtendSearchCss).last().shouldBe(visible).click();
        $$(listUserByEmail).findBy(text(userEmail)).shouldBe(visible).click();
    }

    public void addUserRightsViaInputField(String userName) {
        $$(inputField).last().shouldBe(visible).sendKeys(userName);
        $(By.xpath(format("//app-user//app-user-name[contains(.,'%s')]", userName))).shouldBe(visible).click();
    }

    public void addRightToGroup(String groupName) {
        $$(elementToAssignAccessRights).findBy(text("Группа")).click();
        $(modalBodyExtendSearchCss).shouldBe(visible).click();
        $(systemGroups).shouldBe(visible).click();
        $$(listGroup).findBy(text(groupName)).shouldBe(visible).click();
    }

    public void addRightToGroupViaInputField(String groupName) {
        $$(elementToAssignAccessRights).findBy(text("Группа")).click();
        $(inputFieldInBlockGroup).shouldBe(visible).sendKeys(groupName);
        $(format("app-group-name span[title='%s']", groupName)).shouldBe(visible).click();
    }

    public void addRightToOrgStructure(String positionName) {
        $$(elementToAssignAccessRights).findBy(text("Элемент оргструктуры")).click();
        $(openListOrgStructure).shouldBe(visible).click();
        $$(listOrgStructure).findBy(text(positionName)).shouldBe(visible).click();
    }

    public void clickTurnOffCheckbox() {
        $("[class*='checkbox__v']").shouldBe(visible).click();
        $$(elementButtonInModalWindow).findBy(text("Да")).shouldBe(visible).click();
        //Отметить чекбокс “Просмотр/Загрузка” у группы “Все пользователи”
        clickCheckBoxAllUsers();
    }

    public void clickDeleteModalWindow() {
        $(elementButtonInModalWindow).shouldBe(visible).click();
    }

    public void clickCheckBoxAllUsers() {
        $(checkBoxAllUsers).shouldBe(visible).click();
    }

    public void selectWhichFolderToMoveTo(String nameFolder) {
        $((String.format(folderToMoveTo, nameFolder))).shouldBe(visible).click();
    }

    public void clickButtonMove() {
        $(elementButtonInModalWindow).shouldBe(visible).click();
    }

    public void checkFolderTwo(String nameFolder, String nameFolderTwo) {
        $(String.format(folderCss, nameFolderTwo)).shouldBe(visible).click();
        $(String.format(folderCss, nameFolder)).shouldBe(visible);
    }

    public void inputRenameFolder(String nameFolder) {
        $(inputRenameFolder).shouldBe(visible).clear();
        $(inputRenameFolder).shouldBe(visible).sendKeys(nameFolder);
        $(checkmarkButton).shouldBe(visible).click();
    }

    public void clickCheckboxHierarchy() {
        $(checkBoxHierarchicalDirectorySettings).parent().shouldBe(visible).click();
        $(saveHierarchicalDirectorySettings).shouldBe(visible).click();
    }

    public void isAllFolderAndPencilVisible() {
        $(pencilButtonXpath).shouldBe(visible);
        $(String.format(folderCss, "Все записи")).shouldBe(visible);
    }

    public void startCompanyProcessFromMainPage(String id) {
        $$(processAccordionsCss).findBy(text("Процессы компании")).shouldBe(visible).click();
        $$(processesCss).findBy(partialText(id)).scrollTo().shouldBe(visible).click();
    }

    public void selectItemFromRootDirectory(String filterName) {
        $$(itemsFromDirectoryCss).findBy(text(filterName)).shouldBe(visible).click();
    }

    public void checkItemFromCurrentFolderExists(String directory, String filterName) {
        if (!$$(navigationDirectoryCss).findBy(text(directory)).$("span").is(cssClass("toogle"))) {
            $$(navigationDirectoryCss).findBy(text(directory)).shouldBe(visible).click();
        }
        $$(navigationDirectoryCss).filterBy(text(directory)).findBy(text(filterName)).shouldBe(visible, exist);
    }

    public void checkItemFromRootDirectoryExists(String filterName) {
        $$(navigationFilterCss).findBy(text(filterName)).shouldBe(visible, exist);
        $$(childNavigationFilterCss).findBy(text(filterName)).shouldNotBe(exist);
    }

    public void checkSignButtonVisible() {
        $(signButtonXpath).shouldBe(visible);
    }

    public void checkDifferentDateStartAndFinishDate(String taskName, int differenceOfDays) {
        String dateStart = $$(nameTaskCss).findBy(text(taskName)).parent().$(dateStartTaskCss).shouldBe(visible).text();
        DateTimeFormatter dateTimeFormatter = ofPattern("dd MMMM yyyy 'г.,' H:mm").withLocale(Locale.forLanguageTag("ru"));
        LocalDateTime docDate = LocalDateTime.parse(dateStart, dateTimeFormatter);
        $$(nameTaskCss).findBy(text(taskName)).parent().$(dateFinishTaskCss).shouldBe(visible)
                .shouldHave(text(docDate.plusDays(differenceOfDays).format(dateTimeFormatter)));
    }

    public void checkDateFinishTask(String taskName, LocalDate dateFinish) {
        $$(nameTaskCss).findBy(text(taskName)).parent().$(dateFinishTaskCss).shouldBe(visible)
                .shouldHave(text(dateFinish.format(ofPattern("dd MMMM yyyy").withLocale(Locale.forLanguageTag("ru"))) + " г., 0:00"));
    }

    public void checkNameTaskPattern(String userName) {
        $$(nameTaskCss).findBy(text(userName))
                .shouldBe(visible);
    }

    public void checkVisibleTaskInCalendar(String nameTask) {
        $(String.format("[class*='fc-daygrid-event']>[title='%s']", nameTask)).shouldBe(visible);
    }

    public void clickTaskByName(String taskName) {
        $(By.xpath(String.format("//button[contains(text(),'%s')]", taskName)))
                .shouldBe(visible).click();
    }

    public void checkTaskNameNotExists(String text) {
        if ($(containerTableTasksElementCss).exists()) {
            $$(containerTasksCss).findBy(text(text)).shouldNot(visible);
        } else $(emptyMessageCss).shouldBe(visible);
    }

    @Deprecated // Задачу лучше отлавливать по совпадению названия и процесса
    public boolean isTaskBindToCurrentUser(String taskName) {
        try {
            return $(By.xpath(String.format("//button[contains(text(),'%s')]", taskName))).shouldBe(visible, Duration.ofSeconds(5)).is(visible);
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            return false;
        }
    }

    public boolean isTaskBindToCurrentUser(String taskName, String processName) {
        try {
            return $(By.xpath("//span[contains(text(),'" + processName
                    + "')]/../button[contains(text(),'" + taskName + "')]"))
                    .should(exist).scrollTo().shouldBe(visible, Duration.ofSeconds(5)).is(visible);
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            return false;
        }
    }

    public void checkNextStageNameEquals(String name) {
        $(goToNextStageButtonXpath).shouldBe(visible).shouldHave(text(name));
    }

    public void checkAlertMessageExists(String text) {
        $(By.xpath("//app-message-body//*[contains(text(), '" + text + "')]")).shouldBe(visible);
    }

    public void checkTaskOnListNotExists(String text) {
        if ($(containerSearchResultsCss).exists()) {
            $(containerSearchResultsCss).shouldBe(visible)
                    .$$(containerTasksCss).findBy(text(text)).shouldNotBe(exist);
        }
    }

    public void checkLoadTaskListPage() {
        $(loadTaskListXpath).shouldBe(exist);
    }

    public void clickAddAppOrPageButton() {
        $(addNewAppOrPageButtonCss).shouldBe(visible).click();
    }

    public void clickAppSettingButton() {
        $(appSettingButton).shouldBe(visible).click();
    }

    public void checkAppNameInListBasket(String name) {
        $$(appNameInListBasket).findBy(text(name)).shouldHave(text(name));
    }

    @Deprecated
    // Странный дубликат, не проверяющий раскрытие папки. Работает с секциями, а не с процессами компании. Выпилить.
    public void startCompanyProcess(String sectionName, String id) {
        $(plusProcessButtonXpath).shouldBe(visible).click();
        $$(processAccordionsCss).findBy(text(sectionName)).shouldBe(visible).click();
        $$(processesCss).findBy(text(id))
                .should(exist, Duration.ofSeconds(3)).scrollTo()
                .shouldBe(visible, Duration.ofSeconds(3)).click();

    }

    public void clickExpandAdvancedSearch() {
        $$(extendSearchCss).findBy(visible).click();
    }

    public void selectAppInModalWindow(String appName) {
        $$(containerTasksCss).findBy(text(appName)).shouldBe(visible).click();
    }

    public void agreeWithoutComment() {
        SelenideElement agreeButton = $$(agreeButtonCss).findBy(text("Согласовать"));
        agreeButton.shouldBe(visible).click();
        $(buttonOnProcessForm).shouldBe(visible).click();
        // ждём что исчезнет кнопка (закроется форма, с которой попали в согласование)
        agreeButton.should(disappear);
    }

    public void agreeWithComment(String comment) {
        SelenideElement agreeButton = $$(agreeButtonCss).findBy(text("Согласовать"));
        agreeButton.shouldBe(visible).click();
        $(inputComment).shouldBe(visible).sendKeys(comment);
        $(buttonOnProcessForm).shouldBe(visible).click();
        // ждём что исчезнет кнопка (закроется форма, с которой попали в согласование)
        agreeButton.should(disappear);
    }

    public void inputComment(String comment) {
        $$(inputComment).findBy(visible).shouldBe(visible).sendKeys(comment);
    }

    public void familiarizationWithComment(String comment) {
        SelenideElement agreeButton = $$(agreeButtonCss).findBy(text("Ознакомиться"));
        agreeButton.shouldBe(visible).click();
        $(inputCommentFamiliarize).shouldBe(visible).sendKeys(comment);
        $(buttonOnProcessForm).shouldBe(visible).click();
        // ждём что исчезнет кнопка (закроется форма, с которой попали в согласование)
        agreeButton.should(disappear);
    }

    public void refuseWithComment(String text) {
        SelenideElement refuseButton = $$(agreeButtonCss).findBy(text("Отказать"));
        refuseButton.shouldBe(visible).click();
        $(inputComment).shouldBe(visible).sendKeys(text);
        $(buttonOnDangerForm).shouldBe(visible).click();
        // ждём что исчезнет кнопка (закроется форма, с которой попали в согласование)
        refuseButton.should(disappear);
    }

    public void clickFamiliarizationButton(String buttonName) {
        $$(agreeButtonCss).findBy(text(buttonName)).click();
        $(buttonOnProcessForm).shouldBe(visible).click();
    }

    public void clickFamiliarizationButtonAndInputComment() {
        $$(buttonPrimaryCss).findBy(text("Ознакомиться")).click();
        $(buttonOnProcessForm).shouldBe(visible).click();
    }

    public void clickAgreeButtonAndInputComment(String text) {
        $$(buttonPrimaryCss).findBy(text("Согласовать")).click();
        $(inputComment).shouldBe(visible).sendKeys(text);
        $(buttonOnProcessForm).shouldBe(visible).click();
        CustomDriver.waitMills(2000);
    }

    public void clickRefuseButtonAndInputComment(String text) {
        $$(buttonDangerCss).findBy(text("Отказать")).click();
        $(inputComment).shouldBe(visible).sendKeys(text);
        $(buttonOnDangerForm).shouldBe(visible).click();
        CustomDriver.waitMills(2000);
        $(buttonOnDangerForm).should(disappear);
    }

    public void checkInscriptionAgreed(String inscription) {
        $(inscriptionOfPerformedOperation).shouldHave(text(inscription), visible);
    }

    public void selectFileFromSection(String nameFolder, String nameFile) {
        $(plusFileField).shouldBe(exist).hover();
        $(menuHorizontal).shouldBe(visible).click();
        $(buttonSelectFiles).shouldBe(visible).click();
        $(buttonMyFileCss).shouldBe(visible).click();
        $(By.xpath(format(buttonNamePhotoOrFolder, nameFolder))).shouldBe(visible).click();
        $(By.xpath(format(buttonNamePhotoOrFolder, nameFile))).shouldBe(visible).click();
    }

    public void clickButtonPlusCreate() {
        $(plusCreateButton).shouldBe(visible).click();
    }

    public void clickRegistrationButtonRightSideOfWindow() {
        $(registrationButtonRightSideOfWindow).shouldBe(visible).click();
    }

    public void expandMenuOfSelected(String typeName) {
        $$(expandMenuCss).findBy(visible).click();
        $(String.format("li[aria-label*='%s']", typeName)).shouldBe(visible).click();
    }

    public void clickRegistrationDocButtonRightSideOfWindow() {
        $(registrationDocButtonRightSideOfWindow).shouldBe(visible).click();
    }

    public void clickRegistrationButtonBottomOfWindow() {
        $$(agreeButtonCss).findBy(text("Зарегистрировать")).click();
    }

    public void expandMenuAndCheckContents(String contents) {
        $$(expandMenuCss).findBy(visible).click();
        $(String.format("li[aria-label*='%s']", contents)).shouldHave(text(contents), visible);
    }

    public void expandMenuAndRegister(String contents) {
        $$(expandMenuCss).findBy(visible).click();
        $(String.format("li[aria-label*='%s']", contents)).shouldHave(text(contents), visible).click();
        $(registerButtonOnPopoverCss).shouldBe(visible).click();
        $(registerButtonOnPopoverCss).should(disappear);
        $(goToNextStageButtonXpath).should(disappear);
    }

    public void inputDateInModalWindow(String date, String time) {
        $$(inputDateCss).findBy(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a")
                        + Keys.DELETE, date, Keys.TAB);
        $$(inputTimeCss).findBy(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a")
                        + Keys.DELETE, time, Keys.TAB);
    }

    /**
     * Проверить, что список согласовавших содержит только переданных пользователей
     *
     * @param logins - перечисление пользователей.
     */
    public void checkAgreementListApproverUsers(String... logins) {
        for (String user : logins) {
            $$(approversFirstAndLastNames)
                    .findBy(text(elmaBackend.getUserSurnameAndNameByEmail(user)))
                    .shouldBe(visible);
        }
        $$(approversFirstAndLastNames).shouldHave(CollectionCondition.size(logins.length));
    }

    /**
     * Проверить, что список участвовавших в согласовании содержит только переданных пользователей
     *
     * @param logins - перечисление пользователей.
     */
    public void checkAgreementListParticipantUsers(String... logins) {
        for (String user : logins) {
            $$(participantFirstAndLastNames)
                    .findBy(text(elmaBackend.getUserSurnameAndNameByEmail(user)))
                    .shouldBe(visible);
        }
        $$(participantFirstAndLastNames).shouldHave(CollectionCondition.size(logins.length));
    }

    public void checkTextInConfirmationPopupAndConfirm(String text) {
        $(By.xpath("//app-task-exit-confirmation//p[contains(text(),'" +
                text + "')]/ancestor::app-task-exit-confirmation//button[@type='submit']"))
                .shouldBe(visible).click();
    }

    public void checkRequiredFieldAlertAppearInFormRow(String rowName) {
        $(By.xpath("//elma-form-label/span[contains(text(),'" + rowName
                + "')]/ancestor::elma-form-row[1]//elma-form-errors//div[contains(text(),'Обязательное поле')]")).shouldBe(visible);
    }

    public void clickAccessRightButton() {
        $(accessRight).shouldBe(visible).click();
    }

    public void checkInBlockAdditionalRightsAddRight(String accessRight) {
        $$(blockAdditionalRights).findBy(text(accessRight)).shouldHave(text(accessRight));
    }

    /**
     * Проверяет что "Проверка раздела" прошла успешно
     */
    public void checkListStepOneCheckSectionAllSuccess() {
        int countList = $$(By.xpath("//ul[contains(@class,'log-list')]/li")).shouldBe(CollectionCondition.sizeGreaterThan(1)).size();
        $$(By.xpath("//ul[contains(@class,'log-list')]/li[contains(@class,'success')]"))
                .shouldBe(CollectionCondition.sizeGreaterThanOrEqual(countList), Duration.ofSeconds(3));
    }

    public void checkNotificationMessageTitle(String title) {
        $$(messageTitleCss).findBy(text(title)).shouldBe(visible);
    }

    public void checkNotificationMessageBodyThread(String title) {
        $$(messageBodyThreadCss).findBy(text(title)).shouldBe(visible);
    }

    public void checkRemoveButtonByUser(String userName) {
        $(By.xpath("//span[contains(text(),'" + userName + "')]/ancestor::div[contains(@class,'chips-wrapper')]//button[contains(@class,'button-remove')]"))
                .shouldBe(visible);
    }

    public void checkListGroupVisible(String groupName) {
        $$(listGroup).findBy(text(groupName)).shouldBe(visible);
    }

    public void checkListUserVisible(String userEmail) {
        $$(listUserByEmail).findBy(text(userEmail)).shouldBe(visible);
    }

    public void checkListUserNotVisible(String userEmail) {
        $$(listUserByEmail).findBy(text(userEmail)).shouldNot(visible);
    }
}