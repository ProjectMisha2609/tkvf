package pages.elmaPages;


import jakarta.inject.Singleton;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class BusinessProcessDebugPage {
    private final By messageBodyCss = By.cssSelector(".message__body");
    private final By rowFormCss = By.cssSelector("app-dynamic-form-row");
    private final By highlightElementsCss = By.cssSelector("[id='highlight-elements'] rect");
    private final By containerTitleCss = By.cssSelector(".monitor-container .title");
    public final By itemsTableCss = By.cssSelector(".table td a");
    private final By headerTabsCss = By.cssSelector("app-bpm-debug-header-tabs li");
    private final By actionsOnDiagramCss = By.cssSelector("app-diagram-bpmn .action-component");

    public void checkTapeMessage(String message) {
        $$(messageBodyCss).findBy(text(message)).shouldBe(visible);
    }

    public void checkContextExists(String variableName, String text) {
        $$(rowFormCss).findBy(text(variableName)).shouldHave(text(text));
    }

    public String getCreateTimeFromHistory(String taskName, String userName) {
        return $(By.xpath("//tr[contains(.,'" + taskName + "')]//app-user-name[contains(.,'" + userName + "')]/../../following::td[1]")).getText();
    }

    public void checkViewMapSimpleProcessAtStartDebug() {
        $(highlightElementsCss).shouldBe(visible);
        $$(highlightElementsCss).get(0).should(attribute("stroke", "#0003ff"), attribute("stroke-dasharray", "3 1")).shouldBe(visible);
        $$(highlightElementsCss).get(1).should(attribute("stroke", "#0003ff"), attribute("stroke-dasharray", "none")).shouldBe(exist);
        $$(highlightElementsCss).get(2).should(attribute("stroke", "#14b500"), attribute("stroke-dasharray", "none")).shouldBe(visible);
    }

    public void checkMainsFormsExists(String... formNames) {
        for (String formName : formNames) {
            $$(containerTitleCss).findBy(text(formName)).shouldBe(visible);
        }
    }

    public void clickTaskOnHistoryForm(String taskName) {
        $$(itemsTableCss).findBy(text(taskName)).shouldBe(visible).hover().click();
    }

    public void clickHeaderTabs(String name) {
        $$(headerTabsCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void checkHistoryRecordExists(String taskName, String userName) {
        $(By.xpath("//tr[contains(.,'" + taskName + "')]//app-user-name[contains(.,'" + userName + "')]")).shouldBe(visible);
    }

    public void checkActionComponentOnDiagramExists(String taskName) {
        $$(actionsOnDiagramCss).findBy(text(taskName)).shouldBe(visible);
    }
}
