package pages.elmaPages;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.Actions.ConstructorPageActions;
import pages.BasePages.BasePage;
import pages.elmaModals.CreateBpModal;

import java.time.Duration;
import java.util.Locale;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

@Singleton
public class BusinessProcessPage extends BasePage implements ConstructorPageActions {

    /**
     * Метод открытия страницы, переопределён по причине отсутствия левого тулбара,
     * ожидание инициализации которого есть в BasePage.
     *
     * @param route путь до ресурса
     */
    @Override
    public void open(String... route) {
        String baseUrl = config.standUrl;
        String fullUrl = String.format(baseUrl + String.join("/", route)).toLowerCase(Locale.ROOT);
        Selenide.open(fullUrl);
        super.checkAlert();
    }

    private final By workAreaContentCss = By.cssSelector("#content g[data-drag-container='true']"); //[class='action-component'] text[alignment-baseline='middle']
    private final By cursorCss = By.cssSelector("app-monaco textarea.monaco-mouse-cursor-text");
    private final By publishBusinessProcess = By.cssSelector("app-button[name='diagram.header-actions@publish']");
    private final By confirmPublishCss = By.cssSelector("div[role='dialog'] div.btn-group button.btn-primary");
    private final By messageAboutPublishCss = By.cssSelector("div[aria-label='Процесс опубликован']");
    private final By messageAboutCheckCss = By.cssSelector("div[aria-label='Процесс составлен верно']");
    private final By checkInToolbarCss = By.cssSelector("app-button[name='diagram.header-actions@validate']");
    private final By debugInToolbarCss = By.cssSelector("app-button[name='diagram.header-actions@debug']");
    private final By initComponentCss = By.cssSelector("[id*='content'] g[data-drag-source='#group-selection'][class*='event-component']");
    private final By finishArrowCss = By.cssSelector("#quick-actions [data-drag-container='true']>:last-child");
    private final By arrowCss = By.cssSelector("use[x='1'][y='1']");
    private final By addZoneResponsibilityCss = By.cssSelector("[class*='plus']");
    private final By modalSelectZoneCss = By.cssSelector("div[role='dialog']");
    private final By blockZoneResponsibilityCss = By.cssSelector("[class*='radioswitch__group'] label");
    private final By orgStructureElementCss = By.cssSelector("[aria-label='Элемент оргструктуры']");
    private final By orgStructurePositionElementCss = By.cssSelector("div[class='os-item']:first-child");
    private final By buttonSaveZoneCss = By.cssSelector("[class*='modal-footer'] [type='submit']");
    private final By draggableItem = By.cssSelector(".item.draggable-item");
    private final By lineNumbersCss = By.cssSelector("div.line-numbers");
    private final By zoneResponsibilityHeader = By.cssSelector(".dropzone-area [data-drag-source=\"#group-selection\"] .lane-header-text");
    private final By firstContextVariableCss = By.cssSelector("ngx-dnd-item:first-child button[elmabutton='link']");
    private final By bottomPanelAlertXpath = By.xpath("//app-bpm-validation-panel//span");
    private final By contextVariableNameCss = By.cssSelector("ngx-dnd-item span");
    private final By deleteButtonCss = By.cssSelector("button[elmabutton='danger']");
    private final By confirmDeletionButtonCss = By.cssSelector("div[class*='popover-body'] button");
    private final By debugTabsCss = By.cssSelector("app-bpm-debug-header-tabs a");
    /**
     * Кнопка добавления со знаком +
     */
    private final By buttonAdd = By.cssSelector(".btn.btn-default .add-icon");
    /**
     * Отображаемое имя контекстной переменной в таблице "Контекстные переменные"
     */
    private final By contextDisplayName = By.cssSelector("ngx-dnd-item.ngx-dnd-item .name");
    /**
     * Имя свойства контекстной переменной в таблице "Контекстные переменные"
     */
    private final By contextPropertyName = By.cssSelector("ngx-dnd-item.ngx-dnd-item .code");
    /**
     * Тип контекстной переменной в таблице "Контекстные переменные"
     */
    private final By contextType = By.cssSelector("ngx-dnd-item.ngx-dnd-item .type");
    private final By businessProcessNameInputCss = By.cssSelector("app-create-template input[name='name']");
    private final By listFormsCss = By.cssSelector("td a");
    private final By startBlockCss = By.cssSelector("circle[r='15']");
    private final By finalBlockCss = By.cssSelector("g[id='content'] circle[r='14']");
    private final By buttonAddVariableXpath = By.xpath("//button[contains(text(),'Создать новую переменную')]");
    private final By waitChangeStatusCss = By.cssSelector("g[id='content'] circle[r='16']");
    private final By dropdownCss = By.cssSelector("div.p-dropdown");
    private final By listDropdownCss = By.cssSelector("li[role='option']");
    private final By headerListZoneCss = By.xpath("//a[contains(text(),'Зоны')]/..");
    private final By sidebarActivitiesCss = By.cssSelector(".sidebar ul li");
    private final By headerZoneOnSchemeCss = By.cssSelector("g.header");
    private final By endProcessElementCss = By.cssSelector("[id='group-selection']");
    private final By surfaceInfoCss = By.cssSelector(".sn-title__inner");
    private final By actionButtonsCss = By.cssSelector("g.action use");
    private final By textAreaCss = By.cssSelector("textarea[name='instruction']");
    private final By settingsTabCss = By.cssSelector("app-general-settings elma-tabset li a");
    private final By showAllFieldsSelectorXpath = By.xpath("//elma-form-row//span[contains(text(),'все поля')]/../..//elma-checkbox");
    private final By templateInputXpath = By.xpath("//elma-form-label//span[contains(text(), 'Шаблон')]/../..//input");
    private final By templateSelectorCss = By.cssSelector("app-template-selector");
    private final By templateSelectorCreateButtonCss = By.cssSelector("app-template-selector button");
    private final By templatesInDropdownCss = By.cssSelector("p-dropdownitem span");

    private final By buttonMenuHorizontalForFileFieldCss = By.cssSelector("elma-type-file button");
    private final By buttonAddAppCss = By.cssSelector(".button-add-element");


    public void simpleDragAndDrop(String blockName, String zoneCss) {
        CustomDriver.getAction().dragAndDrop($$(draggableItem).findBy(text(blockName)).shouldBe(visible),
                $(zoneCss)).build().perform();
    }

    public void simpleDragAndDropBelowBlock(String blockName, String belowBlockName) {
        SelenideElement folder = $$(workAreaContentCss).findBy(text(belowBlockName)).shouldBe(visible);
        int height = folder.getRect().getHeight();
        actions().clickAndHold($$(draggableItem).findBy(text(blockName)))
                .moveToElement($(workAreaContentCss), 0, height + 300)
                .release()
                .build()
                .perform();
    }

    public void moveArrow(String startElement, String finishElement) {
        if (startElement.equals(""))
            $(initComponentCss).click();
        else
            $$(workAreaContentCss).findBy(text(startElement)).shouldBe(visible).click();
        SelenideElement block;
        if (finishElement.equals(""))
            block = $(initComponentCss);
        else
            block = $$(workAreaContentCss).findBy(text(finishElement)).shouldBe(visible);
        CustomDriver.getAction().dragAndDrop($(arrowCss).shouldBe(visible), block).build().perform();
    }

    public void moveArrowFinish(String startElement) {
        if (startElement.equals(""))
            $(initComponentCss).click();
        else
            $$(workAreaContentCss).findBy(text(startElement)).click();
        CustomDriver.getAction().dragAndDropBy($(finishArrowCss), -50, 80).build().perform();
    }

    public void addZoneResponsibility() {
        $(addZoneResponsibilityCss).shouldBe(visible).click();
        $(modalSelectZoneCss).$$(blockZoneResponsibilityCss)
                .findBy(text("Статическая")).click();
        $(modalSelectZoneCss).$(orgStructureElementCss).click();
        $(modalSelectZoneCss).$(orgStructurePositionElementCss).click();
        $(modalSelectZoneCss).$(buttonSaveZoneCss).click();
    }

    public void clickSettingsBlock(String blockName) {
        if (blockName.equals("")) $(initComponentCss).doubleClick();
        else $$(workAreaContentCss).findBy(text(blockName)).shouldBe(visible).doubleClick();
        //TODO Ждем 2 секунды после открытия модалки чтобы успели проггрузиться JSы
        CustomDriver.waitMills(2000);
    }

    public void clickStartBlock() {
        $(startBlockCss).shouldBe(visible).doubleClick();
    }

    public void clickWaitChangeStatusBlock() {
        $(waitChangeStatusCss).shouldBe(visible).doubleClick();
    }

    /**
     * Открыть настройки зоны ответственности.
     *
     * @param zoneName Название зоны ответственности
     */
    public void clickSettingsZoneResponsibility(String zoneName) {
        $$(zoneResponsibilityHeader).findBy(text(zoneName)).shouldBe(visible).doubleClick();
        CustomDriver.waitMills(2000);
    }

    /**
     * Раскрыть папку с элементами BPMN в правой части экрана.
     *
     * @param folderName Название папки
     */
    public void openFolder(String folderName) {
        $$(".folder").findBy(text(folderName)).click();
    }

    /**
     * Проверить наличие на схеме процесса элемента с указанным названием.
     *
     * @param elementName Название элемента
     */
    public void checkElementByName(String elementName) {
        $$(workAreaContentCss).findBy(text(elementName)).shouldBe(visible);
    }

    /**
     * Клик по кнопке добавления (На вкладках: Контекст / Форма)
     */
    public void clickAddButton() {
        $(buttonAdd).click();
    }

    public void checkPropertyInContextTable(String propertyName, String type) {
        $$(contextDisplayName).findBy(text(propertyName)).shouldBe(visible);
        $$(contextPropertyName).findBy(text(propertyName)).shouldBe(visible);
        $$(contextType).findBy(text(type)).shouldBe(visible);
    }

    public void fillSimpleScript(String simpleScript) {
        $$(lineNumbersCss).findBy(text("7")).shouldBe(visible).click();
        $(cursorCss).shouldBe(visible).sendKeys(simpleScript);
    }

    public void clickPublish() {
        $(publishBusinessProcess).shouldBe(visible).click();
        $(confirmPublishCss).shouldBe(visible, Duration.ofSeconds(60)).click();
        $(messageAboutPublishCss).shouldBe(visible, Duration.ofSeconds(60));
    }

    public void clickFirstContextVariable() {
        $(firstContextVariableCss).shouldBe(visible).click();
    }

    /**
     * Открыть вкладку с видом элементов (Стандартные элементы/ Системные элементы/ Интеграции).
     *
     * @param activity Название вкладки
     */
    public void chooseSidebarActivity(String activity) {
        $("sidebar-activities label[title='" + activity + "']").shouldBe(visible).click();
    }

    /**
     * Заполнение названия БП при нажатии кнопки + Процесс
     *
     * @param name имя БП
     */
    public void createBusinessProcess(String name) {
        $(businessProcessNameInputCss).shouldBe(visible).sendKeys(name);
        new CreateBpModal().dialogWindowPressButton("Создать");
    }

    public void clickForm(String nameForm) {
        $$(listFormsCss).findBy(text(nameForm)).shouldBe(visible).click();
    }

    public void clickLogicGateway(String name) {
        $(By.xpath(String.format("//*[contains(text(), '%s')]/../../../*/*[@class='not-printable']/..", name)))
                .shouldBe(visible).doubleClick();
    }

    public void clickLeftArrowFromGateway() {
        // todo: подумать как можно сделать стрелку уникальной и как на неё нажимать.
        SelenideElement arrow = $(By.cssSelector("#transition>path[d*='M104']")).shouldBe(visible);
        // пока что сделал центр стрелки кнопки кликабельным закрутив её, а распознаю по точке начала.
        arrow.doubleClick();
    }

    public void checkCantPublish(String alertMessage) {
        $(publishBusinessProcess).shouldBe(visible).click();
        $$(bottomPanelAlertXpath).findBy(text(alertMessage)).shouldBe(visible);
    }

    public void deleteContextVariable(String name) {
        $$(contextVariableNameCss).findBy(text(name)).shouldBe(visible).click();
        $(deleteButtonCss).shouldBe(visible).click();
        $(confirmDeletionButtonCss).shouldBe(visible).click();
    }


    public void addZoneResponsibilityButtonPlus() {
        $(addZoneResponsibilityCss).shouldBe(visible).click();

    }

    public void setDynamicZone() {
        $$(blockZoneResponsibilityCss).findBy(text("Динамическая зона")).click();
    }

    public void setStaticZone() {
        $$(blockZoneResponsibilityCss).findBy(text("Статическая зона")).click();
    }

    public void setVariableDynamicZone(String nameVariable) {
        $(dropdownCss).shouldBe(visible).click();
        $$(listDropdownCss).findBy(text(nameVariable)).click();
    }

    public void clickCreateNewVariableFromZone() {
        $(buttonAddVariableXpath).click();
    }

    public void dragAndDropZoneOnScheme(String direction) {
        if ("group".equals($(headerListZoneCss).getAttribute("class"))) {
            $(headerListZoneCss).click();
        }
        actions().clickAndHold($$(draggableItem).findBy(text(direction)))
                .moveToElement($(headerZoneOnSchemeCss))
                .moveByOffset(250, 300)
                .release()
                .build()
                .perform();
    }

    public void dragAndDropScriptBlockOnScheme(String direction) {
        actions().clickAndHold($$(draggableItem).findBy(text(direction)))
                .moveToElement($$(workAreaContentCss).last())
                .moveByOffset(0, 100)
                .release()
                .build()
                .perform();
    }

    public void openSettingZone(String zoneName) {
        $$(headerZoneOnSchemeCss).findBy(text(zoneName)).doubleClick();
    }

    public void checkEmptyFieldVariableZone() {
        $(dropdownCss).shouldBe(visible).shouldBe(empty);
    }

    public void checkSurfaceMessage(String infoText) {
        $(surfaceInfoCss).shouldBe(visible);
        $$(surfaceInfoCss).findBy(text(infoText)).should(exist);
    }

    public void checkAddTwoDynamicZone(String zoneName) {
        $$(workAreaContentCss).filterBy(text(zoneName)).shouldBe(CollectionCondition.sizeGreaterThan(1));
    }

    public void chooseStartBlock() {
        $(startBlockCss).shouldBe(visible).click();
    }

    public void isFinalBlockVisibleInWorkArea() {
        $(finalBlockCss).shouldBe(visible);
    }

    public void checkIconRemoveExists() {
        $$(actionButtonsCss).findBy(href("#icon-remove")).shouldBe(exist);
    }

    public void checkIconRemoveNotExists() {
        $$(actionButtonsCss).findBy(href("#icon-remove")).shouldNotBe(exist);
    }

    public void setTextInstruction(String textInstruction) {
        $(textAreaCss).shouldBe(visible).sendKeys(textInstruction);
    }

    public void checkContextStringOnStartEventExists(String contextName) {
        $(By.cssSelector("input[id ='" + contextName.toLowerCase() + "']")).shouldBe(exist);
    }

    public void checkErrorMessageExists(String alertMessage) {
        $$(bottomPanelAlertXpath).findBy(text(alertMessage)).shouldBe(visible);
    }

    public void clickCheck() {
        $(checkInToolbarCss).shouldBe(visible).click();
    }

    public void checkSuccessfulCheckMessage() {
        $(messageAboutCheckCss).shouldBe(visible, Duration.ofSeconds(60));
    }

    public void clickDebug() {
        $(debugInToolbarCss).shouldBe(visible).click();
    }

    public void checkDebugTabVisible(String tabName) {
        $$(debugTabsCss).findBy(text(tabName)).shouldBe(visible);
    }

    public void clickBlockExists(String blockName) {
        $$(workAreaContentCss).findBy(text(blockName)).shouldBe(visible);
    }

    public void checkIsBusinessProcessPage() {
        $$(workAreaContentCss).findBy(visible).should(exist);
    }

    public void selectSettingsTab(String name) {
        $$(settingsTabCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void setProcessFormField(String field) {
        $(showAllFieldsSelectorXpath).shouldBe(visible).click();
        $(By.xpath("//ngx-dnd-item//div[contains(text(),'" + field + "')]/..//i")).shouldBe(visible).click();
    }

    public void setNameTemplate(String template) {
        $(templateInputXpath).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, template);
    }

    public void clickCreateProcessInstanceForm() {
        $(templateSelectorCss).shouldBe(visible).click();
        $(templateSelectorCreateButtonCss).shouldBe(visible).click();
    }

    public void selectProcessInstanceForm(String name) {
        $(templateSelectorCss).shouldBe(visible).click();
        $(templateSelectorCss).shouldBe(visible).click();
        $$(templatesInDropdownCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void clickButtonMenuHorizontal() {
        $(buttonMenuHorizontalForFileFieldCss).shouldBe(visible).click();
    }

    public void clickButtonDeleteUserFromAssignRightList(String userName) {
        $(By.xpath("//tr[contains(.,'" + userName + "')] //a")).shouldBe(visible).click();
    }

    public void clickButtonAddNewAppOnStartForm() {
        $(buttonAddAppCss).shouldBe(visible).click();
    }
}