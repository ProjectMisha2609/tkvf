package pages.elmaPages;

import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Страница Замещения
 */
@Singleton
public class SubstitutionPage extends BasePage {
    private final By currentSubstitutionCss = By.cssSelector("a[href='/admin/substitution/current']");
    private final By comingSubstitutionCss = By.cssSelector("a[href='/admin/substitution/coming']");
    private final By substitutionCss = By.cssSelector("tr[class*='p-selectable-row']>td[class*='name']");
    private final By editButtonCss = By.cssSelector("div[class*='modal-footer']>button[class*='primary']");
    private final By modalDeleteButtonCss = By.cssSelector("div[class*='modal-footer']>button[class*='danger']");
    private final By deleteButtonCss = By.cssSelector("div[class*='popover-content']>button[class*='danger']");
    private final By changeEndDateCss = By.cssSelector("[class*='elma-form-row']:last-child input[class*='p-inputtext p-component']");
    private final By changeStartDateCss = By.cssSelector("[class*='elma-form-row']:nth-child(4) input[class*='p-inputtext p-component']");
    private final By typeInformation = By.cssSelector("[class*='radioswitch__group']>:nth-child(1)");
    private final By editTypeInfo = By.cssSelector("[class*='elma-form-row']:nth-child(1) [class*='elma-form-control text-base']");
    private final By editStartData = By.cssSelector("[class*='elma-form-row']:nth-child(4) [class*='elma-form-control text-base']");
    private final By editFinishData = By.cssSelector("[class*='elma-form-row']:nth-child(5) [class*='elma-form-control text-base']");
    private final By buttonCreateSubstitutionCss = By.cssSelector("[class*='page-header']>[class *='btn btn-primary']");
    private final By typeAssignTasks = By.cssSelector("[class*='radioswitch__group']>:nth-child(2)");
    private final By typeFullTransfer = By.cssSelector("[class*='radioswitch__group']>:nth-child(3)");
    private final By buttonSearchMissing = By.cssSelector("[class*='elma-form-row']:nth-child(2) [title*='Расширенный поиск']");
    private final By buttonSearchSubstitute = By.cssSelector("[class*='elma-form-row']:nth-child(3) [title*='Расширенный поиск']");
    private final By emailUsersCss = By.cssSelector("[class *='cell_email'] span span");
    private final By inputStartDateCss = By.cssSelector("[class*='elma-form-row']:nth-child(4) input[class*='p-inputtext p-component']");
    private final By inputEndDateCss = By.cssSelector("[class*='elma-form-row']:nth-child(5) input[class*='p-inputtext p-component']");
    private final By listSubstitutionDisplay = By.cssSelector("[class*='p-element p-datatable-tbody']>tr");
    private final By startDateCss = By.cssSelector("[class*='p-element p-datatable-tbody'] [class*='cell_begin']");
    private final By buttonSetting = By.cssSelector("[class*='page-header']>[elmabutton='link']");
    private final By inputAdvanceNotification = By.cssSelector("input[inputmode*='decimal']");

    public void clickCurrentSubstitution() {
        $(currentSubstitutionCss).shouldBe(visible).click();
    }

    public void clickComingSubstitution() {
        $(comingSubstitutionCss).shouldBe(visible).click();
    }

    public void clickSubstitution() {
        $(substitutionCss).shouldBe(visible).click();
    }

    public void clickEditButton() {
        $(editButtonCss).shouldBe(visible).click();
    }

    public void clickDeleteButton() {
        $(modalDeleteButtonCss).shouldBe(visible).click();
        $(deleteButtonCss).shouldBe(visible).click();
    }

    public void inputChangeEndDateCss(String endData) {
        $(changeEndDateCss)
                .shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a")
                        + Keys.DELETE, endData);
    }

    public void inputChangeStartDateCss(String startData) {
        $(changeStartDateCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, startData);
    }

    public void chooseTypeInformation() {
        $(typeInformation).shouldBe(visible).click();
    }

    public void checkEditType(String text) {
        $(editTypeInfo).shouldHave(text(text));
    }

    public void checkEditStartData(String text) {
        $(editStartData).shouldHave(text(text));
    }

    public void checkEditFinishData(String text) {
        $(editFinishData).shouldHave(text(text));
    }

    public void clickCreateSubstitution() {
        $(buttonCreateSubstitutionCss).shouldBe(visible).click();
        //Не успевает прогрузить полностью модальное окно
        CustomDriver.waitMills(1000);
    }

    public void chooseTypeAssignTasks() {
        $(typeAssignTasks).shouldBe(visible).click();
    }

    public void chooseTypeFullTransfer() {
        $(typeFullTransfer).shouldBe(visible).click();
    }

    public void clickButtonSearchMissing() {
        $(buttonSearchMissing).shouldBe(visible).click();
    }

    public void clickButtonSearchSubstitute() {
        $(buttonSearchSubstitute).shouldBe(visible).click();
    }

    public void chooseUserByEmail(String email) {
        $$(emailUsersCss).findBy(text(email)).shouldBe(visible).click();
    }


    public void inputEndDateCss(String endData) {
        $(inputEndDateCss)
                .shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a")
                        + Keys.DELETE, endData);
    }

    public void inputStartDateCss(String startData) {
        $(inputStartDateCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, startData);
    }

    public void checkListSubstitutionDisplay() {
        $(listSubstitutionDisplay).shouldHave(exist);
    }

    public void checkStartDate(String startDate) {
        $(startDateCss).shouldHave(text(startDate));
    }

    public void clickSettingButton() {
        $(buttonSetting).shouldBe(visible).click();
    }

    public void inputAdvanceNotification(String day) {
        $(inputAdvanceNotification).shouldBe(visible).clear();
        $(inputAdvanceNotification).sendKeys(day);
    }
}