package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

/**
 * Страница 'Рабочий календарь'
 */
@Singleton
public class WorkCalendarPage extends BasePage {
    private final By buttonDeleteCss = By.cssSelector("[class*='delete-wrapper']>button");
    private final By buttonSaveCss = By.cssSelector("[class*='save-button-wrapper']>button");
    private final By inputFriday = By.cssSelector("li:nth-child(5) [class *='p-checkbox-box']");
    private final By beginWorkDay = By.cssSelector("[class*='shedule__row']:first-child [class*='datepicker']:first-child [class*='dropdown-label']");
    private final By finishWorkDay = By.cssSelector("[class*='shedule__row']:first-child [class*='datepicker']:last-child [class*='dropdown-label']");
    private final By beginLunchBreakTime = By.cssSelector("[class*='shedule__row']:last-child [class*='datepicker']:first-child [class*='dropdown-label']");
    private final By finishLunchBreakTime = By.cssSelector("[class*='shedule__row']:last-child [class*='datepicker']:last-child [class*='dropdown-label']");
    private final By buttonExceptionCss = By.cssSelector("[elmabutton*='default']");
    private final By dateException = By.cssSelector("[class*='date-wrapper'] [type='text']");
    private final By timeException = By.cssSelector("[class*='table'] [class*='row']>div:first-child elma-time [class*='dropdown-label']");
    private final By timeFromException = By.cssSelector("[class*='table'] [class*='row']>div:last-child elma-time [class*='dropdown-label']");
    private final By checkBoxWeekend = By.cssSelector("[class*='table'] [class*='p-checkbox-box']");

    public void clickButtonDelete() {
        $(buttonDeleteCss).shouldBe(visible).click();
    }

    public void clickButtonSave() {
        $(buttonSaveCss).shouldBe(visible).click();
    }

    public void clickInputFriday() {
        $(inputFriday).shouldBe(visible).click();
    }

    public void inputBeginOfWorkDay(String time) {
        $(beginWorkDay).shouldBe(visible).clear();
        $(beginWorkDay).sendKeys(time);
    }

    public void inputFinishOfWorkDay(String time) {
        $(finishWorkDay).shouldBe(visible).clear();
        $(finishWorkDay).sendKeys(time);
    }

    public void inputBeginOfLunchBreakTime(String time) {
        $(beginLunchBreakTime).shouldBe(visible).clear();
        $(beginLunchBreakTime).sendKeys(time);
    }

    public void inputFinishOfLunchBreakTime(String time) {
        $(finishLunchBreakTime).shouldBe(visible).clear();
        $(finishLunchBreakTime).sendKeys(time);
    }

    public void clickButtonException() {
        $(buttonExceptionCss).shouldBe(visible).click();
    }

    public void clickCheckBoxWeekend() {
        $(checkBoxWeekend).shouldBe(visible).click();
    }

    public void inputDateException(String time) {
        $(dateException)
                .shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a")
                        + Keys.DELETE, time);
    }

    public void inputTimeFromException(String time) {
        $(timeException).shouldBe(visible).clear();
        $(timeException).sendKeys(time);
    }

    public void inputTimeToException(String time) {
        $(timeFromException).shouldBe(visible).clear();
        $(timeFromException).sendKeys(time);
    }
}
