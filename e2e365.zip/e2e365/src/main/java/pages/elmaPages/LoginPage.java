package pages.elmaPages;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;
import java.util.Locale;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class LoginPage extends BasePage {
    private final By emailCss = By.cssSelector("[name*=Login]");
    private final By passwordCss = By.cssSelector("[name=password]");
    private final By loginCss = By.cssSelector("[type=submit]");

    @Override
    public void open(String... route) {
        CustomDriver.clearAllCookie();
        Selenide.open(String.format(config.standUrl + String.join("/", route)).toLowerCase(Locale.ROOT));
    }

    public void fillEmail(String email) {
        SelenideElement element = $(emailCss).shouldBe(visible, Duration.ofSeconds(30));
        element.click();
        element.sendKeys(email);
    }

    public void fillPassword(String password) {
        SelenideElement element = $(passwordCss).shouldBe(visible, Duration.ofSeconds(30));
        element.click();
        element.sendKeys(password);
    }

    public void clickLogin() {
        $(loginCss).shouldBe(visible).click();
    }

    public void isEmailVisible() {
        $(emailCss).shouldBe(visible);
    }
}
