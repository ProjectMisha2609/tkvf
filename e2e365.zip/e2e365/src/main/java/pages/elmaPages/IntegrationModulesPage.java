package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.Actions.ConfigPageActions;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.exist;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class IntegrationModulesPage extends BasePage implements ConfigPageActions {

    /**
     * @param name - название карточки интеграции, которую нужно нажать.
     */
    public void clickIntegrationCard(String name) {
        $(By.xpath("//app-integration-card//div[contains(.,'" + name + "') and contains(@class, '__info')]"))
                .should(exist).scrollTo().shouldBe(visible).click();
    }
}
