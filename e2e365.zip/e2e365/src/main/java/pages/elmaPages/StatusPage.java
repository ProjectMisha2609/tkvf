package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.util.Locale;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.*;
import static com.codeborne.selenide.WebDriverConditions.url;

@Singleton
public class StatusPage extends BasePage {
    private final By checkBoxCss = By.cssSelector("p-checkbox label");
    private final By statusInputCss = By.cssSelector("div[class='statuses-add'] input");
    private final By addStatusCss = By.cssSelector("div[class='statuses_list'] button");
    private final By bottomButtonsCss = By.cssSelector("app-page-content div[class*='control'] button");

    /**
     * Нажимает на чекбокс для включения статусов
     */
    public void clickAddStatusField() {
        $$(checkBoxCss).findBy(text("Добавить поле \"Статус\"")).shouldBe(visible).click();
    }

    /**
     * Создает новый статус
     */
    public void createNewStatus(String statusName) {
        $(statusInputCss).shouldBe(visible).sendKeys(statusName);
        $$(addStatusCss).findBy(text("Добавить")).shouldBe(visible).click();
    }

    /**
     * Жмет кнопку Сохранить
     *
     * @param section имя секции
     * @param app     имя приложения
     */
    public void clickSaveStatuses(String section, String app) {
        $$(bottomButtonsCss).findBy(text("Сохранить")).shouldBe(visible).click();
        //если у введенного url нет слеша на конце то добавляет
        String url = config.standUrl;
        if (!url.endsWith("/"))
            url = url + "/";
        //проверяет что страница закончила все свои дела и сделала редирект
        webdriver().shouldHave(url(url + section.toLowerCase(Locale.ROOT) + "/" + app.toLowerCase(Locale.ROOT)));
    }
}
