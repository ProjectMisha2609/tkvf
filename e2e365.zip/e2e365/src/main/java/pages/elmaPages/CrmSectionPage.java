package pages.elmaPages;

import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendCrm;
import infrastructure.helpers.RandomString;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.Actions.ConfigPageActions;
import pages.BasePages.BasePage;
import pages.elmaModals.CreateAppElementModal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.util.*;

import static com.codeborne.selenide.CollectionCondition.sizeGreaterThan;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;

@Singleton
public class CrmSectionPage extends BasePage implements ConfigPageActions {
    @Inject
    protected BackendCrm backendCrm;

    private final By companyNameElementCss = By.cssSelector("tr[tabindex='0']:first-child a elma-type-string span");
    private final By funnelAddCss = By.cssSelector("button[title='Добавить воронку']");
    private final By inputNewFunnelNameCss = By.cssSelector("app-application-funnel-list input");
    private final By leadsMenuCss = By.cssSelector("app-application-funnel-list");
    private final By leadsElementCss = By.cssSelector("div.item.ng-star-inserted");
    private final By funnelHeaderCss = By.cssSelector("elma-breadcrumbs nav span");
    //список компаний
    private final By searchResultsCss = By.cssSelector("tbody tr");
    //кнопка + задача в карточке компании
    private final By newTaskCss = By.cssSelector("div[class*='new-task-row'] button");
    private final By newTaskNameCss = By.cssSelector("div[class*='new-task-row'] input[placeholder='Новая задача']");
    private final By extendedSearchButtonCss = By.cssSelector("section button[title='Расширенный поиск']");
    private final By calendarCss = By.cssSelector("p-calendar button");
    private final By todayDateCss = By.cssSelector("[class*='p-datepicker-buttonbar'] button:first-child");
    private final By saveTaskCss = By.cssSelector("button[class*='task-submit-button']");
    //кнопка недозвон, для понимания что задача создалась
    private final By noncallCss = By.cssSelector("button[class*='non-call']");
    private final By taskNameCss = By.cssSelector("button[class*='task-title']");
    //------тут начинаются ксс полей для заполнения строк в редактировании компании
    private final By phoneInputCss = By.cssSelector("elma-type-phone input");
    private final By emailInputCss = By.cssSelector("elma-type-email input");
    private final By webInputCss = By.cssSelector("app-dynamic-form-row input[id*='_website']");
    private final By addressInputCss = By.cssSelector("app-dynamic-form-row input[id*='_address']");
    private final By innInputCss = By.cssSelector("app-dynamic-form-row input[id*='_inn']");
    private final By kppInputCss = By.cssSelector("app-dynamic-form-row input[id*='_kpp']");
    private final By juridicalNameInputCss = By.cssSelector("app-dynamic-form-row input[id*='_legalName']");
    private final By ogrnInputCss = By.cssSelector("app-dynamic-form-row input[id*='_ogrn']");
    private final By juridicalAddressInputCss = By.cssSelector("app-dynamic-form-row input[id*='_legalAddress']");
    private final By mailAddressInputCss = By.cssSelector("app-dynamic-form-row input[id*='_correspondenceAddress']");
    private final By bankInputCss = By.cssSelector("app-dynamic-form-row input[id*='_bank']");
    private final By bikInputCss = By.cssSelector("app-dynamic-form-row input[id*='_bik']");
    private final By checkingAccountInputCss = By.cssSelector("app-dynamic-form-row input[id*='_operatingAccount']");
    private final By correspondentAccountInputCss = By.cssSelector("app-dynamic-form-row input[id*='_correspondentAccount']");
    private final By firstnameInputCss = By.cssSelector("elma-type-fullname input[class*='full-name-firstname']");
    private final By middleNameInputCss = By.cssSelector("elma-type-fullname input[class*='full-name-middlename']");
    private final By lastnameInputCss = By.cssSelector("elma-type-fullname input[class*='full-name-lastname']");
    //------тут начинаются ксс полей для проверки строк после редактировании компании
    private final By phoneCheckCss = By.cssSelector("app-dynamic-form-row elma-phone-item a");
    private final By webCheckCss = By.cssSelector("app-dynamic-form-row elma-type-link a");
    private final By linkCheckCss = By.cssSelector("app-dynamic-form-row app-collection-readonly-link a");
    private final By stringCheckCss = By.cssSelector("app-dynamic-form-row elma-type-string");
    private final By fullNameCheckCss = By.cssSelector("app-dynamic-form-row elma-type-fullname");
    private final By emailCheckCss = By.cssSelector("app-dynamic-form-row elma-email-item");
    //------
    private final By sectionCss = By.cssSelector("section");
    private final By nameInModalCss = By.cssSelector("elma-modal-body input[id*='__name']");
    private final By addElementCss = By.cssSelector("button[class*='add-element']");
    private final By companyChangeNotificationCss = By.cssSelector("elma-top-center-error div[aria-label='Компания успешно изменен']");
    private final By dealCardElementCss = By.cssSelector("app-appview-list-board-list elma-type-string");
    private final By messageFieldCss = By.cssSelector("elma-html-editor p");
    private final By sendMessageButtonCss = By.cssSelector("div[class*='editor-buttons'] button[class*='btn-send']");
    private final By messageBodyCss = By.cssSelector("app-message-body");
    private final By newTaskButtonCss = By.cssSelector("app-crm-linked-tasks-task-form button");
    private final By selectTaskTypeCss = By.cssSelector("app-crm-linked-tasks-task-form p-dropdown");
    private final By taskTypeElementCss = By.cssSelector("p-dropdownitem li");
    private final By extendedSearchCss = By.cssSelector("app-crm-linked-tasks-task-form button[title='Расширенный поиск']");
    private final By extendedSearchResultsCss = By.cssSelector(".search-results tr");
    private final By messageTitleInFeedCss = By.cssSelector("div[class*='message__title']");
    private final By taskNameFieldCss = By.cssSelector("app-crm-linked-tasks-task-name-input input");
    private final By taskLinkCss = By.cssSelector("app-linked-task button");
    private final By calendarInDealCardCss = By.cssSelector("app-crm-linked-tasks-task-form p-calendar button");
    private final By letterDateCss = By.cssSelector("div[class='task-date']");
    private final By taskButtonsCss = By.cssSelector("div[class='actions-row'] button");
    private final By tomorrowDateInCalendarCss = By.cssSelector("td[class*='p-datepicker-today'] ~ td");
    private final By confirmWindowButtonsCss = By.cssSelector("div[class='comment-dialog'] button");
    private final By confirmRescheduleWindowButtonsCss = By.cssSelector("app-confirm-plan-dates button");
    private final By confirmWindowTextareaCss = By.cssSelector("div[class='comment-dialog'] textarea");
    /**
     * Кнопка + в карточке сделки для добавления контакта
     */
    private final By addContactInDealCss = By.cssSelector("app-collection-readonly-list button");
    /**
     * Ссылка на контакт в карточке сделки, справа
     */
    private final By contactLinkInDealCss = By.cssSelector("app-collection-readonly-list-sub-item a");
    /**
     * Кнопка для изменения смены статуса в карточке сделки, справа
     */
    private final By statusChangeInDealButtonCss = By.cssSelector("app-appview-view-status button");
    /**
     * Статус в листе возможных статусов в карточке сделки, справа
     */
    private final By statusListItemInDealCss = By.cssSelector("app-appview-view-status div[class*='status-item']");
    /**
     * Статус в листе возможных статусов в карточке сделки, справа
     */
    private final By currentStatusInDealCss = By.cssSelector("div[class*='status-item current'] span");
    /**
     * При задаче позвонить кнопка недозвон, варианты причин
     */
    private final By callResultCss = By.cssSelector("div[class='popover-outer visible'] elma-popover-menu-option span");
    /**
     * Любое событие в календаре
     */
    private final By calendarEventCss = By.cssSelector("td div[class*='fc-event-title']");
    /**
     * Зеленая табличка сверху о выполненном действии
     */
    private final By topCenterConfirmCss = By.cssSelector("elma-top-center-error div[class*='col-9']");
    private final By buttonBuildingCss = By.xpath("//elma-form //button[contains(text(),'Построить')]");
    private final By dropDownItemCss = By.cssSelector("li.p-dropdown-item");
    private final By closeTaskCss = By.cssSelector("button.task-closed");
    private final By loadListDealsXpath = By.xpath("//*[contains(@class,'emptymessage') or contains(@class,'p-datatable-wrapper')]");
    private final By buttonLinkCss = By.cssSelector(".buttons-container button.btn-link");
    private final By taskTitleCss = By.cssSelector("elma-form .task-title");
    private final By pageHeaderButtons = By.xpath("//div[contains(@class, 'page-header__buttons')]//button");
    private final By itemEditInputCss = By.cssSelector(".item.edit input");
    private final By buttonDangerCss = By.cssSelector(".visible [class*='btn-danger']");
    private final By buttonEndSettingCss = By.cssSelector(".btn[title='Завершить настройку']");
    private final By listBoardHeaderClickableCss = By.cssSelector("app-appview-list-board-header .clickable");
    private final By listBoardHeaderTitleCss = By.cssSelector("app-appview-list-board-header .title");
    private final By waitReport = By.xpath("//elma-groupbox//div[contains(text(),'Подождите, идёт построение отчёта')]");

    public void checkCompanyCreated(String nameCompany) {
        $("elma-top-center-error div[aria-label='Компания успешно создан']").shouldBe(visible);
        open("_clients/_companies");
        $(companyNameElementCss).shouldBe(visible).shouldHave(text(nameCompany));
    }

    /**
     * Открыть карточку доски kanban по названию.
     */
    public void openCard(String cardName) {
        $$(dealCardElementCss).findBy(text(cardName)).shouldBe(visible).click();
    }

    /**
     * Открыть карточку сделки из указанной колонки
     *
     * @param cardName           - название карты
     * @param sourceColumnNumber - номер колонки (1 - Новые, 2 - Обработка, 3 - Квалифицирован)
     */
    public void openCard(String cardName, int sourceColumnNumber) {
        $$("app-appview-list-board-list:nth-child(" + sourceColumnNumber + ") elma-type-string")
                .findBy(text(cardName)).shouldBe(visible).click();
    }

    /**
     * Проверить, что карточка есть на kanban.
     *
     * @param dealOrLeadName     - название карточки
     * @param sourceColumnNumber - номер колонки (1 - Новые, 2 - Обработка, 3 - Квалифицирован)
     */
    public void checkCardVisible(String dealOrLeadName, int sourceColumnNumber) {
        $$("app-appview-list-board-list:nth-child(" + sourceColumnNumber + ") div[class*='ngx-dnd-item']").findBy(text(dealOrLeadName)).shouldBe(visible);
    }

    /**
     * Проверить, что карточка отсутствует на kanban.
     *
     * @param dealOrLeadName     - название карточки
     * @param sourceColumnNumber - номер колонки (1 - Новые, 2 - Обработка, 3 - Квалифицирован)
     */
    public void checkCardNotVisible(String dealOrLeadName, int sourceColumnNumber) {
        // todo: нужно ожидание для начала проверки, иначе может проверить слишком рано.
        $$("app-appview-list-board-list:nth-child(" + sourceColumnNumber + ") div[class*='ngx-dnd-item']").findBy(text(dealOrLeadName)).shouldNotBe(visible);
    }

    /**
     * Проверить, что карточка есть в вертикальном списке (при просмотре колонки) по названию карточки.
     */
    public void checkListFieldVisible(String dealOrLeadName) {
        $(By.xpath("//app-appview-list-field//span[contains(text(),'" + dealOrLeadName + "')]")).should(exist)
                .scrollTo().shouldBe(visible);
    }

    public void addNewFunnel(String funnelName) {
        $(funnelAddCss).shouldBe(visible).click();
        SelenideElement element = $(inputNewFunnelNameCss).shouldBe(visible);
        element.sendKeys(funnelName);
        element.pressEnter();
    }

    public void checkPageContainsNewFunnel(String funnelName) {
        $(leadsMenuCss).$$(leadsElementCss).findBy(text(funnelName)).shouldBe(exist).click();
        $$(funnelHeaderCss).findBy(text(funnelName)).shouldBe(visible);
    }

    public void openCompany(String companyName) {
        $$(searchResultsCss).findBy(text(companyName)).shouldBe(visible).click();
    }

    public void fillTask(String taskName) {
        $(newTaskCss).shouldBe(visible).click();
        $(newTaskNameCss).shouldBe(visible).sendKeys(taskName);
        $(extendedSearchButtonCss).shouldBe(visible).click();
        $$(searchResultsCss).findBy(text(config.adminLogin)).shouldBe(visible).click();
        $$(calendarCss).first().shouldBe(visible).click();
        $(todayDateCss).shouldBe(visible).click();
        $$(calendarCss).last().shouldBe(visible).click();
        $(todayDateCss).shouldBe(visible).click();
        $(saveTaskCss).shouldBe(visible).click();
        $(noncallCss).shouldBe(visible);
    }

    public void fillRedactFields(Map<String, String> dataForCompany) {
        $$(sectionCss).last().$$(addElementCss).get(3).shouldBe(visible).click();
        $$(nameInModalCss).last().shouldBe(visible).sendKeys(dataForCompany.get("industryName"));
        // todo: действия другой страницы в методе
        CreateAppElementModal createApplicationElementModal = new CreateAppElementModal();
        createApplicationElementModal.clickModalFooterButton("Сохранить");
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        $$(sectionCss).last().$$(addElementCss).get(4).shouldBe(visible).click();
        $$(nameInModalCss).last().shouldBe(visible).sendKeys(dataForCompany.get("segmentName"));
        createApplicationElementModal.clickModalFooterButton("Сохранить");
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        $$(extendedSearchButtonCss).get(0).shouldBe(visible).click();
        $$(searchResultsCss).findBy(text(dataForCompany.get("contactName"))).shouldBe(visible).click();
        $$(extendedSearchButtonCss).get(1).shouldBe(visible).click();
        $$(searchResultsCss).findBy(text(dataForCompany.get("dealName"))).shouldBe(visible).click();
        $$(extendedSearchButtonCss).get(2).shouldBe(visible).click();
        $$(searchResultsCss).findBy(text(dataForCompany.get("leadName"))).shouldBe(visible).click();
        CustomDriver.waitMills(500);  // todo: костыль с ожиданием
        $(phoneInputCss).shouldBe(visible).sendKeys(dataForCompany.get("phoneNumber"));
        $(emailInputCss).shouldBe(visible).sendKeys(dataForCompany.get("email"));
        $(webInputCss).shouldBe(visible).sendKeys(dataForCompany.get("web"));
        $(addressInputCss).shouldBe(visible).sendKeys(dataForCompany.get("address"));
        $(innInputCss).shouldBe(visible).sendKeys(dataForCompany.get("inn"));
        $(kppInputCss).shouldBe(visible).sendKeys(dataForCompany.get("kpp"));
        $(juridicalNameInputCss).shouldBe(visible).sendKeys(dataForCompany.get("juridicalName"));
        $(ogrnInputCss).shouldBe(visible).sendKeys(dataForCompany.get("ogrn"));
        $(juridicalAddressInputCss).shouldBe(visible).sendKeys(dataForCompany.get("juridicalAddress"));
        $(mailAddressInputCss).shouldBe(visible).sendKeys(dataForCompany.get("mailAddress"));
        $(bankInputCss).shouldBe(visible).sendKeys(dataForCompany.get("bank"));
        $(bikInputCss).shouldBe(visible).sendKeys(dataForCompany.get("bik"));
        $(checkingAccountInputCss).shouldBe(visible).sendKeys(dataForCompany.get("checkingAccount"));
        $(correspondentAccountInputCss).shouldBe(visible).sendKeys(dataForCompany.get("correspondentAccount"));
        $(firstnameInputCss).shouldBe(visible).sendKeys(dataForCompany.get("firstName"));
        $(middleNameInputCss).shouldBe(visible).sendKeys(dataForCompany.get("middleName"));
        $(lastnameInputCss).shouldBe(visible).sendKeys(dataForCompany.get("lastName"));
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        createApplicationElementModal.clickModalFooterButton("Сохранить");
        $(companyChangeNotificationCss).shouldBe(visible);
    }

    public Map<String, String> generateData() {
        Map<String, String> dataForCompany = new HashMap<>();
        dataForCompany.put("companyName", "createTaskCompany" + RandomString.get(8));
        dataForCompany.put("contactName", "checkEditContact" + RandomString.get(6));
        dataForCompany.put("dealName", "checkEditDeal" + RandomString.get(6));
        dataForCompany.put("leadName", "checkEditLead" + RandomString.get(6));
        dataForCompany.put("industryName", "checkEditIndustry" + RandomString.get(6));
        dataForCompany.put("segmentName", "checkEditSegment" + RandomString.get(6));
        dataForCompany.put("phoneNumber", RandomString.getNum(12));
        dataForCompany.put("email", RandomString.get(6) + "@" + RandomString.get(4) + "." + "gf");
        dataForCompany.put("web", RandomString.get(8));
        dataForCompany.put("address", RandomString.get(8));
        dataForCompany.put("inn", RandomString.getNum(8));
        dataForCompany.put("kpp", RandomString.getNum(8));
        dataForCompany.put("juridicalName", RandomString.get(8));
        dataForCompany.put("ogrn", RandomString.getNum(8));
        dataForCompany.put("juridicalAddress", RandomString.get(8));
        dataForCompany.put("mailAddress", RandomString.get(8));
        dataForCompany.put("bank", RandomString.get(8));
        dataForCompany.put("bik", RandomString.getNum(8));
        dataForCompany.put("checkingAccount", RandomString.getNum(8));
        dataForCompany.put("correspondentAccount", RandomString.getNum(8));
        dataForCompany.put("firstName", RandomString.get(8));
        dataForCompany.put("lastName", RandomString.get(8));
        dataForCompany.put("middleName", RandomString.get(8));
        backendCrm.createCompany(dataForCompany.get("companyName"), RandomString.getUUID());
        backendCrm.createContact(dataForCompany.get("contactName"));
        backendCrm.createDeal(dataForCompany.get("dealName"));
        backendCrm.createLead(dataForCompany.get("leadName"));
        return dataForCompany;
    }

    public void checkCompanyDataCorrect(Map<String, String> dataForCompany) {
        String fullName = dataForCompany.get("lastName") + " "
                + dataForCompany.get("firstName") + " " + dataForCompany.get("middleName");
        $$(fullNameCheckCss).findBy(text(fullName)).shouldBe(visible);

        $(phoneCheckCss).shouldBe(visible).shouldHave(text(dataForCompany.get("phoneNumber")));
        $(webCheckCss).shouldBe(visible).shouldHave(text(dataForCompany.get("web")));
        $(emailCheckCss).shouldBe(visible).shouldHave(text(dataForCompany.get("email")));

        $$(stringCheckCss).findBy(text(dataForCompany.get("address"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("inn"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("kpp"))).shouldBe(visible);
        $$(linkCheckCss).findBy(text(dataForCompany.get("contactName"))).shouldBe(visible);
        $$(linkCheckCss).findBy(text(dataForCompany.get("dealName"))).shouldBe(visible);
        $$(linkCheckCss).findBy(text(dataForCompany.get("leadName"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("juridicalName"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("ogrn"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("mailAddress"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("bank"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("bik"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("checkingAccount"))).shouldBe(visible);
        $$(stringCheckCss).findBy(text(dataForCompany.get("correspondentAccount"))).shouldBe(visible);
        $$(linkCheckCss).findBy(text(dataForCompany.get("industryName"))).shouldBe(visible);
        $$(linkCheckCss).findBy(text(dataForCompany.get("segmentName"))).shouldBe(visible);
    }

    public void sendMessageInFeed(String feedMessage) {
        $(messageFieldCss).shouldBe(visible).sendKeys(feedMessage);
        $(sendMessageButtonCss).shouldBe(visible).click();
    }

    public void checkMessageSent(String feedMessage) {
        $$(messageBodyCss).findBy(text(feedMessage)).shouldBe(visible);
    }

    public void pressNewTaskButton(String taskType) {
        $$(newTaskButtonCss).last().shouldBe(visible).click();
        $(selectTaskTypeCss).shouldBe(visible).click();
        $$(taskTypeElementCss).findBy(text(taskType)).click();
    }

    public void clickNewTaskButton() {
        $$(newTaskButtonCss).last().shouldBe(visible).click();
    }

    public void enterTaskName(String taskName) {
        $(taskNameFieldCss).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, taskName);
    }

    public void selectAdminInSearch() {
        for (SelenideElement element : $$(extendedSearchCss)) {
            element.shouldBe(visible).click();
            $$(extendedSearchResultsCss).findBy(text(config.adminLogin)).shouldBe(visible).click();
        }
    }

    public void fillCalendarData() {
        for (SelenideElement element : $$(calendarInDealCardCss)) {
            element.shouldBe(visible).click();
            $(todayDateCss).shouldBe(visible).click();
        }
    }

    public void saveTask() {
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        $(saveTaskCss).shouldBe(visible, enabled).click();
        // TODO: БАГ Без перезагрузки страницы не отображается приложение вызовов
        refreshPage();
        $(taskLinkCss).shouldBe(visible);
    }

    public String getTaskCreationDate() {
        $(taskLinkCss).shouldBe(visible);
        String fullDate = $(letterDateCss).shouldBe(visible).getText();
        return fullDate.split(" ")[0];
    }

    public void checkTaskTimeChanged(String creationDate) {
        //режем сообщение в ленте для получения даты на которую переносим
        $$(messageTitleInFeedCss).findBy(text("изменена")).shouldBe(visible);
        String messageInFeed = $(messageBodyCss).shouldBe(visible).getText();
        // todo: попробовать переделать в проверку Selenide shouldHave(text())
        String actualNewDate = messageInFeed.split(": ")[1].split(" ")[0];
        Date date = null;
        // todo: поднять вопрос разработки вспомогательного класса для обработки дат
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
        try {
            date = format.parse(creationDate);
        } catch (ParseException e) {
            //ignored
        }
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        String dateFormat = format.format(calendar.getTime());
        Assertions.assertEquals(actualNewDate, dateFormat);
    }

    public void clickTaskButton(String button) {
        $(taskButtonsCss).shouldBe(visible);
        CustomDriver.waitMills(1500); // todo: костыль с ожиданием
        $$(taskButtonsCss).findBy(text(button)).shouldBe(visible).click();
    }

    public void setTomorrowDateInCalendar() {
        $$(calendarCss).last().shouldBe(visible).click();
        $(tomorrowDateInCalendarCss).shouldBe(visible).click();
    }

    public void clickAddContactInDealCard() {
        $(addContactInDealCss).shouldBe(visible).click();
    }

    public void confirmWindowClickButton(String button) {
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        $$(confirmWindowButtonsCss).findBy(text(button)).shouldBe(visible).click();
    }

    public void confirmWindowClickButton(String button, String commentary) {
        $(confirmWindowTextareaCss).shouldBe(visible).sendKeys(commentary);
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        $$(confirmWindowButtonsCss).findBy(text(button)).shouldBe(visible).click();
    }

    public void confirmChangeLetterTime() {
        $$(confirmRescheduleWindowButtonsCss).findBy(text("Изменить")).shouldBe(visible).click();
        CustomDriver.waitMills(500); // todo: костыль с ожиданием
        $(taskLinkCss).shouldBe(visible).click();
    }

    public void changeStatusInDealCard(String status) {
        $(statusChangeInDealButtonCss).shouldBe(visible).click();
        $$(statusListItemInDealCss).findBy(text(status)).shouldBe(visible).click();
    }

    public void chooseCallResult(String reason) {
        $$(callResultCss).findBy(text(reason)).shouldBe(visible).click();
        $$(messageBodyCss).findBy(text(reason)).shouldBe(visible);
    }

    public void isCallTaskClosed() {
        $$(messageTitleInFeedCss).findBy(text("Не удалось дозвониться")).shouldBe(visible);
        $$(messageBodyCss).findBy(text("Закрыть задачу")).shouldBe(visible);
    }

    public void isControlTaskCompleted() {
        $(topCenterConfirmCss).shouldBe(visible);
    }

    public boolean isDealCallClosed(String taskName) {
        $$(messageTitleInFeedCss).findBy(text("Сделка \"" + taskName + "\" закрыта.")).shouldBe(visible);
        return $(currentStatusInDealCss).shouldBe(visible).getText().equals("Закрыта неуспешно");
    }

    public void isDealCallAborted(String taskName) {
        $(currentStatusInDealCss).shouldBe(visible).shouldHave(text("Закрыта неуспешно"));
        String message = "Процесс " + taskName + " был прерван";
        $(messageTitleInFeedCss).shouldBe(visible).shouldHave(text(message));
    }

    public void isNewTaskInFeedAppeared(String taskName) {
        $$(messageTitleInFeedCss).findBy(text("Задача \"" + taskName + "\" ")).shouldBe(visible);
    }

    public void isNewTaskCreated(String taskName) {
        $$(taskLinkCss).findBy(text(taskName)).shouldBe(visible);
    }

    public void isTaskInDealCardDone(String taskName, String commentary) {
        $$(messageTitleInFeedCss).findBy(text(taskName + " - сделано")).shouldBe(visible);
        $$(messageBodyCss).findBy(text(commentary)).shouldBe(visible);
    }

    public void isContactAdded(String contactName) {
        $$(contactLinkInDealCss).findBy(text(contactName)).shouldBe(visible);
    }

    public void checkStatusChanged(String status) {
        $(currentStatusInDealCss).shouldBe(visible).shouldHave(exactText(status));
        $(messageTitleInFeedCss).shouldBe(visible).shouldHave(text(status));
    }

    public void checkHistoryAppearedInFeed(String taskName, String text) {
        $$(calendarEventCss).findBy(text(taskName)).shouldBe(visible).hover().click();
        $$(messageBodyCss).findBy(text(text)).shouldBe(visible);
    }

    public void isLetterHaveHistory(String taskName) {
        $$(calendarEventCss).findBy(text(taskName)).shouldBe(visible).hover().click();
        $$(messageTitleInFeedCss).findBy(text(taskName + " - сделано.")).shouldBe(visible);
    }

    public void isStatusAppearedInFeed(String callResult) {
        $$(messageBodyCss).findBy(text(callResult)).shouldBe(visible);
    }

    public void clickButtonBuilding() {
        $(buttonBuildingCss).shouldBe(visible).click();
        CustomDriver.waitMills(500); //TODO Ожидание обновления данных в таблице
    }

    public void changeStatusByFirstColumnValue(String firstColumnValue, String status) {
        $(By.xpath("//td/button[contains(text(),'" + firstColumnValue + "')]/ancestor::tr[1]//elma-icon-label-option/span")).shouldBe(visible).click();
        $(By.xpath("//ul//li[contains(@aria-label,'" + status + "')]")).shouldBe(visible).click();
    }

    public void changeStatusByValueOfFieldName(String fieldName, String status) {
        $(By.xpath("//elma-form-label[contains(.,'" + fieldName + "')]/ancestor::elma-form-row//app-select-item-status[1]")).shouldBe(visible).click();
        $(By.xpath("//ul//li[contains(@aria-label,'" + status + "')]")).shouldBe(visible).click();
    }

    public void checkTextInRightBlock(String blockName, String text) {
        $(By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-sidebar-widget[1]//" +
                "span[contains(., '" + text + "')]")).shouldBe(visible);
    }

    public void clickTextInRightBlock(String blockName, String text) {
        $(By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-sidebar-widget[1]//" +
                "*[contains(text(), '" + text + "')]")).shouldBe(visible).click();
    }

    /**
     * Перетаскивает лид из указанной колонки в указанную колонку
     *
     * @param leadName                - название лид
     * @param sourceColumnNumber      - номер колонки в которой находится лид (1 - Новые, 2 - Обработка, 3 - Квалифицирован)
     * @param destinationColumnNumber - номер колонки куда нужно перетащить (1 - Новые, 2 - Обработка, 3 - Квалифицирован)
     */
    public void dragLeadAndDropBetweenColumns(String leadName, int sourceColumnNumber, int destinationColumnNumber) {
        String leadPath = "app-appview-list-board-list:nth-child(" + sourceColumnNumber + ") elma-type-string";
        CustomDriver.getAction().dragAndDrop(
                $$(leadPath).findBy(text(leadName)).shouldBe(visible),
                $("app-appview-list-board-list:nth-child(" + destinationColumnNumber + ")").shouldBe(visible)).build().perform();
    }

    public void clickButton(String buttonName) {
        $(By.xpath("//elma-form//button[contains(text(),'" + buttonName + "')]")).shouldBe(visible).click();
    }

    public void setThresholdsForResultsOfDuplicates(String thresholdsName, int percent) {
        $(By.xpath("//td[contains(text(),'" + thresholdsName + "')]/ancestor::tr[1]//input")).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, String.valueOf(percent));
    }

    /**
     * Проверить что блок имеет указанный цвет
     *
     * @param blockName - название блока
     * @param value     - значение (true - желтого цвета, false- красного цвета)
     */
    public void checkCorrectBlockColor(String blockName, boolean value) {
        By blockPath = By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-sidebar-widget[1]//div[contains(@class,'high-relation')]");
        if (value) $(blockPath).shouldNot(exist);
        else $(blockPath).shouldBe(exist);
    }

    public void checkDisplayedOnCardCrossedOut(String leadName) {
        $(By.xpath("//span[contains(text(),'" + leadName + "') and contains(@class,'task-closed')]"))
                .shouldBe(visible);
    }

    public void inputSearchByNameAndClickEnter(String nameFile) {
        $("app-header-part input[placeholder='Поиск по полю Название']").shouldBe(visible).sendKeys(nameFile, Keys.ENTER);
    }

    /**
     * Нажать кнопку "Запустить поиск" по названию приложения
     *
     * @param appName - название приложение (Например : Приложение "Лиды", Приложение "Сделки")
     */
    public void clickStartSearchByAppName(String appName) {
        $(By.xpath("//span[contains(.,'" + appName + "')]/ancestor::elma-groupbox[1]//button[contains(.,'Запустить поиск')]"))
                .shouldBe(visible).click();
    }

    public int getCountDealsFromDynamicTable(String columnName, String rowName) {
        // таблица симметричная так что для поиска хватит одного селектора.
        $(By.xpath("//span[contains(text(),'" + columnName + "')]/parent::div/preceding-sibling::div")).shouldBe(visible);

        int countColumn = $$(By.xpath("//span[contains(text(),'" + columnName + "')]/parent::div/preceding-sibling::div")).size() + 1;
        int countRow = $$(By.xpath("//span[contains(text(),'" + rowName + "')]/parent::div/preceding-sibling::div")).size() + 1;

        return Integer.parseInt($(By.xpath("//div[contains(@class, 'deals-table__row')][" + countRow + "]/div[" + countColumn + "]")).getText());
    }

    public void clickCellDealsFromDynamicTable(String columnName, String rowName) {
        // таблица симметричная так что для поиска хватит одного селектора.
        $(By.xpath("//span[contains(text(),'" + columnName + "')]/parent::div/preceding-sibling::div")).shouldBe(visible);

        int countColumn = $$(By.xpath("//span[contains(text(),'" + columnName + "')]/parent::div/preceding-sibling::div")).size() + 1;
        int countRow = $$(By.xpath("//span[contains(text(),'" + rowName + "')]/parent::div/preceding-sibling::div")).size() + 1;

        $(By.xpath("//div[contains(@class, 'deals-table__row')][" + countRow + "]/div[" + countColumn + "]//button")).shouldBe(visible).click();
    }

    public void clickAllDealsFromDynamicTable() {
        $(By.cssSelector("button[title='Все сделки в отчете']")).shouldBe(visible).click();
    }

    public void clickAllPositiveDealsFromDynamicTable() {
        $(By.cssSelector("button[title='Сделки с положительной динамикой']")).shouldBe(visible).click();
    }

    public void clickAllNegativeDealsFromDynamicTable() {
        $(By.cssSelector("button[title='Сделки с отрицательной динамикой']")).shouldBe(visible).click();
    }

    public void setNumberTelephoneWithPosition(String rowName, String typePhone, String number, int position) {
        String dropdownXpath = String.format("//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//elma-type-phone//div[%s] //div[contains(@class,'element-container__phone')]//p-dropdown", rowName, position);
        $(By.xpath(dropdownXpath)).shouldBe(visible).click();
        $$(dropDownItemCss).findBy(text(typePhone)).scrollTo().shouldBe(visible).click();

        String locator = String.format("//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//elma-type-phone//div[%s] //div[contains(@class,'element-container__phone')]//input[not(@readonly)]", rowName, position);
        $(By.xpath(locator)).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, number, Keys.TAB);

    }

    public void checkCellTextTableContactExists(String contractName, String cellText) {
        $(By.xpath(String.format("//td//span[contains(text(), '%s')]/ancestor::tr[1]/td[contains(.,'%s')]", contractName, cellText))).shouldBe(visible);
    }

    public void fillTaskFromContact(String taskName) {
        $(newTaskCss).shouldBe(visible).click();
        $(newTaskNameCss).shouldBe(visible).sendKeys(taskName);
        $(extendedSearchButtonCss).shouldBe(visible).click();
        $$(searchResultsCss).findBy(text(config.adminLogin)).shouldBe(visible).click();
        $(calendarCss).shouldBe(visible).click();
        $(todayDateCss).shouldBe(visible).click();
        $(saveTaskCss).shouldBe(visible).click();
    }

    public void checkCloseTaskInContact(String taskName) {
        $$(closeTaskCss).findBy(text(taskName)).shouldBe(visible);
    }

    public void checkLoadDealsList() {
        $(loadListDealsXpath).shouldBe(visible);
    }

    public void clickExpandFunnelButton() {
        if ($(buttonLinkCss).exists())
            $(buttonLinkCss).click();
    }

    public void clickTaskOnCalendar(String taskName) {
        $$(calendarEventCss).findBy(text(taskName)).shouldBe(visible).hover().click();
    }

    public void checkTaskOnCardDealExists(String title) {
        $$(taskTitleCss).findBy(text(title)).shouldBe(visible);
    }

    public void clickDeleteFunnelDeal(String funnelName) {
        $$(itemEditInputCss).findBy(value(funnelName)).parent().$(".btn-delete").shouldBe(visible).click();
        $(buttonDangerCss).shouldBe(visible).click();
    }

    public void changeFunnelName(String oldFunnelName, String newFunnelName) {
        SelenideElement element = $$(itemEditInputCss).findBy(value(oldFunnelName)).shouldBe(visible);
        element.sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, newFunnelName, Keys.ENTER);
        $(buttonEndSettingCss).shouldBe(visible).click();
    }

    public void checkFunnelDealNotExists(String funnelName) {
        $(leadsMenuCss).$$(leadsElementCss).findBy(text(funnelName)).shouldNot(exist);
    }

    public void checkFunnelDealExists(String funnelName) {
        $(leadsMenuCss).$$(leadsElementCss).findBy(text(funnelName)).shouldBe(exist);
    }

    public void clickColumnNameTableDeals(String name) {
        $$(listBoardHeaderClickableCss).findBy(text(name)).scrollTo().shouldBe(visible).click();
    }

    public void checkColumnNameTableDeals(String name) {
        $$(listBoardHeaderTitleCss).findBy(text(name)).scrollTo().shouldBe(visible);
    }

    public void setCheckBoxOnItemInDealsTable(String name, boolean condition) {
        String selectorString = "//td//span[contains(text(),'%s')]//ancestor::tr[1]/td[1]//div[@aria-checked='%s']";
        By selector = By.xpath(String.format(selectorString, name, !condition));
        if ($(selector).exists())
            $(selector).click();
        selector = By.xpath(String.format(selectorString, name, condition));
        $(selector).shouldBe(visible);
    }

    public void clickPageHeaderButtons(String name) {
        $$(pageHeaderButtons).findBy(text(name)).shouldBe(visible).click();
    }

    public void checkCellTextTableContactNotExists(String contractName, String cellText) {
        $(By.xpath(String.format("//td//span[contains(text(), '%s')]/ancestor::tr[1]/td[contains(.,'%s')]", contractName, cellText))).shouldNot(exist);
    }

    public void checkDealByBlockName(String blockName, String dealName) {
        $(By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-groupbox" +
                "//div[contains(@class,'groupbox-body')]//div[contains(@title,'" + dealName + "')]"))
                .shouldBe(visible);
    }

    public void checkDealByBlockNameNotVisible(String blockName, String text) {
        $(By.xpath("//span[contains(text(), '" + blockName + "')]" +
                "/ancestor::elma-groupbox//div[contains(@class,'groupbox-body')]//div[contains(text(),'" + text + "')]"))
                .shouldNotBe(visible);
    }

    public void checkDealByBlockNameVisible(String blockName, String text) {
        $(By.xpath("//span[contains(text(), '" + blockName + "')]" +
                "/ancestor::elma-groupbox//div[contains(@class,'groupbox-body')]//div[contains(.,'" + text + "')]"))
                .shouldBe(visible);
    }

    public void checkThatStatusNotPercent(String blockName, String status, String percent) {
        int countColumn = $$(By.xpath("//span[contains(text(), '" + blockName + "')]" +
                "/ancestor::elma-groupbox[1]//div[contains(@title,'" + status + "')]" +
                "//parent::div/preceding-sibling::div[@title]")).shouldBe(sizeGreaterThan(-1)).size();
        $$(By.xpath("//span[contains(text(),'" + blockName + "')]/" +
                "ancestor::elma-groupbox//div[contains(@class,'chart-container-label')]")).get(countColumn).shouldNotBe(exactText(percent));
    }

    public void checkThatStatusPercent(String blockName, String status, String percent) {
        int countColumn = $$(By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-groupbox" +
                "//div[contains(@title,'" + status + "')]//parent::div" +
                "/preceding-sibling::div[contains(@class,'chart-title')]")).shouldBe(sizeGreaterThan(-1)).size();
        $$(By.xpath("//span[contains(text(),'" + blockName + "')]/" +
                "ancestor::elma-groupbox//div[contains(@class,'chart-container-label')]")).get(countColumn).shouldBe(exactText(percent));
    }

    public void checkThatPercentEmployee(String blockName, String status, String count) {
        int countColumn = $$(By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-groupbox" +
                "//div[contains(@title,'" + status + "')]//parent::div" +
                "/preceding-sibling::div[contains(@class,'chart-title')]")).shouldBe(sizeGreaterThan(-1)).size() + 1;
        $(By.xpath("//span[contains(text(),'" + blockName + "')]/ancestor::elma-groupbox" +
                "//div[contains(@class,'chart-container')]/div[" + countColumn + "]")).shouldBe(exactText(count));
    }

    public void checkThatPercentNotEmployee(String blockName, String status, String count) {
        int countColumn = $$(By.xpath("//span[contains(text(), '" + blockName + "')]/ancestor::elma-groupbox" +
                "//div[contains(@title,'" + status + "')]//parent::div" +
                "/preceding-sibling::div[contains(@class,'chart-title')]")).shouldBe(sizeGreaterThan(-1)).size() + 1;
        $(By.xpath("//span[contains(text(),'" + blockName + "')]/ancestor::elma-groupbox" +
                "//div[contains(@class,'chart-container')]/div[" + countColumn + "]")).shouldNot(exactText(count));
    }

    public void checkDashboardGridVisible(String labelName, String number) {
        $(By.xpath("//div[contains(@class,'grid-border')]//div[contains(text(),'" + labelName + "')]/parent::div/div[1]"))
                .shouldBe(exactText(number));
    }

    public void checkCRMActivityVisible(String block, String itemLabel, String count) {
        $(By.xpath("//span[contains(text(), '" + block + "')]/ancestor::elma-groupbox[1]" +
                "//div[contains(@class,'legend-item')]//div[contains(text(),'" + itemLabel + "')]" +
                "/parent::div/div[contains(@class,'item-value')]")).shouldBe(visible).shouldBe(text(count));
    }

    public void checkCRMActivityNotVisible(String block, String itemLabel, String count) {
        $(By.xpath("//span[contains(text(), '" + block + "')]/ancestor::elma-groupbox[1]" +
                "//div[contains(@class,'legend-item')]//div[contains(text(),'" + itemLabel + "')]" +
                "/parent::div/div[contains(@class,'item-value')]")).shouldBe(visible).shouldNot(text(count));
    }


    public int getCountInCRMActivity(String block, String itemLabel) {
        return Integer.parseInt($(By.xpath("//span[contains(text(), '" + block + "')]/ancestor::elma-groupbox[1]" +
                "//div[contains(@class,'legend-item')]//div[contains(text(),'" + itemLabel + "')]" +
                "/parent::div/div[contains(@class,'item-value')]")).shouldBe(visible).text());
    }

    public void checkDashboardGridNotVisible(String labelName, String number) {
        $(By.xpath("//div[contains(@class,'grid-border')]//div[contains(text(),'" + labelName + "')]/parent::div/div[1]"))
                .shouldNotBe(exactText(number));
    }

    public void disappearWaitReportBuilt() {
        try {
            $(waitReport).should(exist);
            $(waitReport).should(disappear, Duration.ofSeconds(30));
        } catch (com.codeborne.selenide.ex.ElementNotFound ignore) {
        }
    }

    public void inputDateStart(LocalDate startDate) {
        $("input[placeholder*='Начало']").shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE,
                        startDate.format(FORMATTER_DD_MM_YYYY));
    }
}