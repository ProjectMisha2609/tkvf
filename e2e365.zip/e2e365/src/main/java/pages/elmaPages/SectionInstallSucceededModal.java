package pages.elmaPages;

import infrastructure.utils.Loggers;
import jakarta.inject.Singleton;
import pages.BasePages.BasePage;

import java.time.Duration;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SectionInstallSucceededModal extends BasePage {
    private final String moveToSectionId = "[data-test=moveToSectionB]";

    public void clickMoveToSection() {
        try {
            $(moveToSectionId).shouldBe(visible, Duration.ofSeconds(30)).click();
        } catch (Exception e) {
            Loggers.CONSOLE.info("-----------------------------------\n" +
                    "exception from SectionInstallSucceededModal.clickMoveToSection()\n" +
                    "-----------------------------------\n");
            e.printStackTrace();
        }
    }
}
