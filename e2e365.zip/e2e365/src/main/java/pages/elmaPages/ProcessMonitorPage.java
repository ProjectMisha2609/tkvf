package pages.elmaPages;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import infrastructure.elmaBackend.ElmaBackend;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;

import static com.codeborne.selenide.CollectionCondition.size;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class ProcessMonitorPage extends BasePage {
    @Inject
    protected ElmaBackend elmaBackend;
    /**
     * Элемент или каталог на странице монитора процессов
     */
    private final By monitorTreeElement = By.cssSelector(".item-outer .btn-link");
    /**
     * Заголовок на странице информации о процессе
     */
    private final By monitorInfoTitle = By.cssSelector(".content-header__title");
    /**
     * Строка в секции "Информация о процессе"
     */
    private final By processInfoRow = By.cssSelector(".process-info .process-info__row");
    /**
     * Столбец строки в панели "Информация о процессе"
     */
    private final By processInfoCol = By.cssSelector(".process-info__col");
    /**
     * Ссылка с именем пользователя в секции "Информация о процессе"
     */
    private final By userNameLink = By.cssSelector(".user-name");
    /**
     * Текст поповера пользователя
     */
    private final By userPopover = By.cssSelector(".popover-content .text-content");
    /**
     * Строка в панели "По статусам и исполнителям"
     */
    private final By instanceCountersRow = By.cssSelector(".instance-counters .table__row");
    /**
     * Строка результирующей таблицы в секции "По статусам и исполнителям"
     */
    private final By instanceResultRow = By.cssSelector(".p-datatable-wrapper .p-selectable-row");
    /**
     * Столбец строки результирующей таблицы в секции "По статусам и исполнителям"
     */
    private final By instanceResultCol = By.cssSelector(".p-datatable-wrapper .p-selectable-row td");
    /**
     * Кнопка-ссылка на странице
     */
    private final By buttonLink = By.cssSelector(".btn.btn-link");
    /**
     * Кнопка "Ве процессы"
     */
    private final By buttonReset = By.cssSelector(".button-reset .btn");
    /**
     * Сообщение о пустой результирующей таблице "Список элементов пуст"
     */
    private final By gridEmptyMessage = By.cssSelector("elma-grid .emptymessage");
    /**
     * Уведомление в нижней правой части экрана
     */
    private final By notificationBottomRight = By.cssSelector(".simple-notification-wrapper.bottom.right");
    private final By historyProcessCss = By.cssSelector("app-monitor-name-template button");
    private final By tabListCss = By.cssSelector("[role='tablist'] [role='tab']");
    private final By performerUser = By.cssSelector(".cell___tasks .user-name");
    private final By headerCss = By.cssSelector("[class*='__head']");

    public void selectProcess(String processName) {
        $$(monitorTreeElement).findBy(text(processName)).scrollTo().hover().click();
    }

    /**
     * Проверить текст уведомления в нижней правой части экрана.
     *
     * @param notificationText Текст уведомления
     * @return (Boolean) Наличие указанного текста
     */
    public void checkNotificationBottomRight(String notificationText) {
        $(notificationBottomRight).shouldBe(visible).shouldHave(text(notificationText));
    }

    /**
     * Проверка соответствия заголовка названию процесса.
     *
     * @param processName Название процесса в заголовке
     */
    public void checkProcessNameInTitle(String processName) {
        $(monitorInfoTitle).shouldHave(text(processName));
    }

    /**
     * Проверка информации по процессу.
     * Проверяет отображение номера версии процесса, даты и автора создания/публикации процесса.
     */
    public void checkProcessInfoPanel() {
        String date = "\\d{1,2}.{5,}\\d{4}.{3},.\\d{1,2}:\\d{2}";
        String adminName = elmaBackend.getUserSurnameAndNameByEmail(config.adminLogin);
        $$(processInfoRow).findBy(text("Номер версии")).shouldBe(visible)
                .$$(processInfoCol).last()
                .shouldHave(text("1(Карта)"));
        $$(processInfoRow).findBy(text("Создан")).shouldBe(visible)
                .$$(processInfoCol).last()
                .shouldHave(matchText(date)).$(userNameLink).shouldHave(text(adminName));
        $$(processInfoRow).findBy(text("Опубликован")).shouldBe(visible)
                .$$(processInfoCol).last()
                .shouldHave(matchText(date)).$(userNameLink).shouldHave(text(adminName));
    }

    /**
     * Открыть карту процесса.
     */
    public void openProcessMap() {
        $$(buttonLink).findBy(text("Карта")).shouldBe(visible, Duration.ofSeconds(10)).hover().click();
    }

    /**
     * Проверяет количество экземпляров процесса для указанного состояния и сортировку по этому состоянию
     * в результирующей таблице.
     *
     * @param condition Название состояния ("Текущий" / "Завершен" / "Прерван")
     * @param count     Количество экземпляров процесса
     */
    public void selectConditionInInstanceCountersPanel(String condition, Integer count) {
        $$(instanceCountersRow).findBy(text(condition))
                .$(buttonLink).shouldHave(exactText(count.toString())).click();
        if (count > 0)
            $$(instanceResultRow).shouldHave(size(count)).last().scrollTo().shouldBe(visible);
        else
            $(gridEmptyMessage).shouldBe(visible);
    }

    /**
     * Открывает экземпляр процесса из результирующей таблицы.
     */
    public void openProcessInstanceInInstanceResultTable() {
        SelenideElement element = $$(instanceResultRow).first();
        element.$("td[class*='cell___name']").shouldBe(visible).click();
    }

    /**
     * Проверяет, что экземпляры процесса в результирующей таблице имеют одинакового исполнителя.
     *
     * @param name Фамилия и имя исполнителя
     */
    public void checkOnlyOneExecutorInInstanceResultTable(String name) {
        ElementsCollection collection = $$(instanceResultRow);
        for (SelenideElement row : collection) {
            row.$$(instanceResultCol).filter(text(name)).shouldHave(CollectionCondition.size(1));
        }
    }

    /**
     * Проверяет, что экземпляры процесса в результирующей таблице имеют даты создания и завершения.
     *
     * @return (Boolean) Наличие даты создания и завершения в каждой строке таблицы
     */
    public void checkHaveStartEndDateInInstanceResultTable() {
        String datePattern = "\\d{1,2}.{5,}\\d{4}.{3},.\\d{1,2}:\\d{2}";
        ElementsCollection rows = $$(instanceResultRow);
        rows.last().shouldBe(visible);
        By updateDateCellCss = By.cssSelector("td[class*='cell___updatedAt']");
        By createDateCellCss = By.cssSelector("td[class*='cell___createdAt']");
        for (int i = 0; i < rows.size(); i++) {
            $$(updateDateCellCss).get(i).shouldHave(matchText(datePattern));
            $$(createDateCellCss).get(i).shouldHave(matchText(datePattern));
        }
    }

    /**
     * Проверяет количество строк в результирующей таблице.
     *
     * @param size Ожидаемое количество строк
     */
    public void checkSizeOfResultTable(int size) {
        $$(instanceResultRow).shouldHave(size(size));
    }

    /**
     * Нажать кнопку "Все процессы".
     * Приводит к сбросу сортировок для результирующей таблицы.
     */
    public void clickAllProcessButton() {
        $(buttonReset).click();
    }

    public void openHistory() {
        $(historyProcessCss).shouldBe(visible).click();
    }

    public void checkTabList(String tabName) {
        $$(tabListCss).findBy(text(tabName)).should(exist);
    }

    /**
     * Открыть первую задачу в мониторе процессов по email пользователя или его имени и фамилии.
     *
     * @param emailUser - email пользователя
     * @return email пользователя если удалось открыть по нему/имя и фамилия пользователя,
     * если не удалось открыть по email.
     */
    public String clickByNumberInstancesProcess(String emailUser) {
        try {
            $$(instanceCountersRow).findBy(text(emailUser)).$(buttonLink).shouldBe(visible).click();
            return emailUser;
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            String userName = elmaBackend.getUserSurnameAndNameByEmail(emailUser);
            $$(instanceCountersRow).findBy(text(userName)).$(buttonLink).shouldBe(visible).click();
            return userName;
        }
    }

    public void checkPerformerSelectedUser(String emailUser) {
        $(performerUser).shouldHave(text(emailUser));
    }

    public void checkHeaderPage(String headerName) {
        $$(headerCss).findBy(text(headerName)).shouldHave(visible, exist);
    }

    public void openProcessInstance(String name) {
        $(By.xpath("//app-monitor-name-template//button[contains(text(),'" + name + "')]"))
                .shouldBe(visible).click();
    }
}
