package pages.elmaPages;

import com.codeborne.selenide.conditions.CssClass;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.Actions.ConfigPageActions;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

@Singleton
public class LinesPage extends BasePage implements ConfigPageActions {
    private final By bindContactButtonXpath = By.xpath("//button[contains(@title, 'Связать')]");
    private final By bindContactSearchInputXpath = By.xpath("//input[contains(@placeholder, 'поиска элемента')]");
    private final By contactDropboxItemXpath = By.xpath("//div[contains(@class, 'p-autocomplete-panel')]");
    private final By savedContactsXpath = By.xpath("//app-application-session-binding//span");
    private final By crmContactXpath = By.xpath("//app-session-client-card//a");
    private final By sessionQueueXpath = By.xpath("//a[contains(@title, 'очереди')]");
    private final By chatInputXpath = By.xpath("//app-html-editor//elma-html-editor");
    private final By closeChatXpath = By.xpath("//app-chat-header//button");
    private final By messagesTextXpath = By.xpath("//app-chat-message//span");
    private final By confirmCloseChatXpath = By.xpath("//elma-confirm//button[contains(@class,'primary')]");
    private final By lineNameInMessageProcessingChartXpath = By.xpath("//div[contains(text(), 'Обработанные обращения')]/..//span[contains(@class,'label-text')]");
    private final By answerSpeedCellsXpath = By.xpath("//span[contains(text(),'первого ответа')]/../../../../../../..//span");
    private final By answersByBotCellsXpath = By.xpath("//span[contains(text(),'Доля ответов бота')]/../../../../../../..//span");
    private final By operatorNameInAnswerSpeedChartXpath = By.xpath("//div[contains(text(), 'Скорость ответа')]/..//span");
    private final By operatorNameInWaitTimeChartXpath = By.xpath("//div[contains(text(), 'Время ожидания')]/..//span");
    private final By operatorNameInSessionTimeChartXpath = By.xpath("//div[contains(text(), 'Длительность сессии')]/..//span");
    private final By knowledgeBaseXpath = By.xpath("//button[contains(@title,'Шаблоны ответов')]");
    private final By answerTemplateXpath = By.xpath("//app-knowledge-base//span[contains(text(),'Шаблоны')]");
    private final By articleXpath = By.xpath("//app-knowledge-base//span[contains(text(),'Статьи')]");
    private final By templateItemsXpath = By.xpath("//app-knowledge-base//span");
    private final By renameSessionPencilButtonXpath = By.xpath("//button[contains(@class, 'session-name-button')]");
    private final By sessionNameXpath = By.xpath("//app-chat-header//span[contains(@class, 'title')]");
    private final By unassignedSessionsCounterXpath = By.xpath("//app-channels-requests-indicator//a[contains(@title, 'нераспределенных')]//span");
    private final By queueSessionsCounterXpath = By.xpath("//app-channels-requests-indicator//a[contains(@title, 'очереди')]//span");
    private final By lineSessionsCounterXpath = By.xpath("//app-navigation-main-item/a[contains(.,'Линии')]//span[contains(@class, 'badge')]");
    private final By operatorsGroupCss = By.cssSelector("app-chatdesk-operator-group span");
    private final By assignButtonCss = By.cssSelector("div[class*='popover-body'] button[class*='primary']");
    private final By groupPopupCss = By.cssSelector("app-group-name span");
    private final By groupFinderCss = By.cssSelector("app-group-select input");
    private final By changeOperatorGroupButtonCss = By.cssSelector("app-chatdesk-operator-group button");
    private final By changeOperatorButtonCss = By.cssSelector("app-set-operator button");
    private final By operatorFinderCss = By.cssSelector("app-user-select input");
    private final By operatorPopupCss = By.cssSelector("ul app-user-name");
    private final By operatorsNamesCss = By.cssSelector("span[class*='operator']");
    private final By operatorFinderButtonCss = By.cssSelector("app-user-select button[title*='поиск']");
    private final By operatorMailCss = By.cssSelector("app-appview-list-table span");
    private final By groupFinderButtonCss = By.cssSelector("app-group-select button[title*='поиск']");
    private final By companyGroupsXpath = By.xpath("//span[contains(text(),'Группы компании')]");
    private final By collapsedGroupCss = By.cssSelector("elma-tree span[class*='collapsed']");
    private final By groupNamesXpath = By.xpath("//p-treenode//span[contains(@class, 'elma-tree-label')]");
    private final By lineAdministrationTabsCss = By.cssSelector("a[role*='tab']");
    private final By companyProcessFolderOpener = By.xpath("//button[contains(.,'Процессы компании')]/../../../div[contains(@class,'opened-indicator')]/i");
    private final By processItemsInTreeCss = By.cssSelector("app-bptemplate-admin-page-tree-template button");
    private final By popoverOptionsXpath = By.xpath("//elma-popover-menu-option//span");
    private final By fieldSelectorButtonXpath = By.xpath("//button[contains(text(),'Выберите поле')]");
    private final By addFieldButtonXpath = By.xpath("//button[contains(text(),'+ Поле')]");
    private final By setParametersButtonXpath = By.xpath("//button[contains(text(),'Настроить')]");
    private final By modalWindowSaveButtonXpath = By.xpath("//elma-modal-window//button[text()='Сохранить']");
    private final By saveButtonProcessXpath = By.xpath("//elma-tab//app-chatdesk-events-settings//button[text()='Сохранить']");
    private final By sessionAppBindLink = By.xpath("//app-application-session-binding//span");

    public void bindContact(String contactName) {
        $(bindContactButtonXpath).shouldBe(visible).click();
        $(bindContactSearchInputXpath).shouldBe(visible).sendKeys(contactName);
        $(contactDropboxItemXpath).shouldBe(visible).click();
    }

    public void checkContactBound(String contactName) {
        $$(savedContactsXpath).findBy(text(contactName)).shouldBe(visible);
    }

    public void checkCrmContactBound(String contactName) {
        $$(crmContactXpath).findBy(text(contactName)).shouldBe(visible);
        $(bindContactButtonXpath).shouldNotBe(visible);
    }

    public void openSessionFromQueue() {
        $(sessionQueueXpath).shouldBe(visible).click();
    }

    public void closeSession() {
        $(closeChatXpath).shouldBe(visible).click();
        $(confirmCloseChatXpath).shouldBe(visible).click();
    }

    public void sendAnswer(String answer) {
        $(chatInputXpath).shouldBe(visible).click();
        $$(chatInputXpath).findBy(new CssClass("@focus"))
                .shouldBe(visible);
        actions().sendKeys(answer + "Answer" + Keys.ENTER).perform();
        $$(messagesTextXpath).findBy(text(answer + "Answer")).shouldBe(visible);
    }

    public void checkMessageProcessingReport(String name) {
        $$(lineNameInMessageProcessingChartXpath).findBy(text(name)).scrollTo().shouldBe(visible);
    }

    public void checkEfficiencyReport(String name) {
        $$(answerSpeedCellsXpath).findBy(text(name)).scrollTo().shouldBe(visible);
        $$(answerSpeedCellsXpath).findBy(text("сек")).scrollTo().shouldBe(visible);
        $$(answersByBotCellsXpath).findBy(text(name)).scrollTo().shouldBe(visible);
        $$(answersByBotCellsXpath).findBy(text("0")).scrollTo().shouldBe(visible);
    }

    public void checkOperatorsReport(String name) {
        $$(operatorNameInAnswerSpeedChartXpath).findBy(text(name)).scrollTo().shouldBe(visible);
        $$(operatorNameInWaitTimeChartXpath).findBy(text(name)).scrollTo().shouldBe(visible);
        $$(operatorNameInSessionTimeChartXpath).findBy(text(name)).scrollTo().shouldBe(visible);
    }

    public void sendAnswerTemplate(String name) {
        $(knowledgeBaseXpath).shouldBe(visible).click();
        $(answerTemplateXpath).shouldBe(visible).click();
        $$(templateItemsXpath).findBy(text(name)).shouldBe(visible).click();
        $(chatInputXpath).shouldBe(visible).click();
        $$(chatInputXpath).findBy(new CssClass("@focus"))
                .shouldBe(visible);
        actions().sendKeys(Keys.ENTER).perform();
    }

    public void sendArticle(String article) {
        $(knowledgeBaseXpath).shouldBe(visible).click();
        $(articleXpath).shouldBe(visible).click();
        $$(templateItemsXpath).findBy(text(article)).shouldBe(visible).click();
        $(chatInputXpath).shouldBe(visible).click();
        $$(chatInputXpath).findBy(new CssClass("@focus"))
                .shouldBe(visible);
        actions().sendKeys(Keys.ENTER).perform();
    }

    public void checkMessageContentExists(String content) {
        $$(messagesTextXpath).findBy(text(content)).shouldBe(visible);
    }

    public void renameSessionAndCheckNewName(String sessionName) {
        $(renameSessionPencilButtonXpath).shouldBe(visible).click();
        $(renameSessionPencilButtonXpath).should(disappear);
        actions().sendKeys(sessionName, Keys.ENTER).perform();
        $(sessionNameXpath).shouldBe(visible).shouldHave(text(sessionName));
    }

    public void checkUnassignedSessionsCountEquals(String count) {
        $(unassignedSessionsCounterXpath).shouldBe(visible).shouldHave(text(count));
    }

    public void checkQueueSessionsCountEquals(String count) {
        $(queueSessionsCounterXpath).shouldBe(visible).shouldHave(text(count));
    }

    public void checkLineSessionsCountEquals(String count) {
        $(lineSessionsCounterXpath).shouldBe(visible).shouldHave(text(count));
    }

    public void assignSessionToUser(String operator) {
        $(changeOperatorButtonCss).shouldBe(visible).click();
        $(operatorFinderCss).shouldBe(visible).sendKeys(operator);
        $$(operatorPopupCss).findBy(text(operator)).shouldBe(visible).click();
        $$(assignButtonCss).findBy(visible).click();
    }

    public void assignSessionToUserByFindButton(String operator) {
        $(changeOperatorButtonCss).shouldBe(visible).click();
        $(operatorFinderButtonCss).shouldBe(visible).click();
        $$(operatorMailCss).findBy(text(operator)).shouldBe(visible).click();
        $$(assignButtonCss).findBy(visible).click();
    }


    public void assignSessionToUsersGroup(String group) {
        $(changeOperatorGroupButtonCss).shouldBe(visible).click();
        $(groupFinderCss).shouldBe(visible).sendKeys(group);
        $$(groupPopupCss).findBy(text(group)).shouldBe(visible).click();
        $$(assignButtonCss).findBy(visible).click();
    }

    public void assignSessionToUsersGroupByFindButton(String group) {
        $(changeOperatorGroupButtonCss).shouldBe(visible).click();
        $(groupFinderButtonCss).shouldBe(visible).click();
        $(companyGroupsXpath).shouldBe(visible);
        if ($(collapsedGroupCss).is(visible)) $(collapsedGroupCss).click();
        $$(groupNamesXpath).findBy(text(group)).shouldBe(visible).click();
        $$(assignButtonCss).findBy(visible).click();
    }

    public void checkGroupAssigned(String group) {
        $$(operatorsGroupCss).findBy(text(group)).shouldBe(visible);
    }

    public void checkOperatorAssigned(String operator) {
        $$(operatorsNamesCss).findBy(text(operator)).shouldBe(visible);
    }

    public void chooseAdministrationTab(String tabName) {
        $$(lineAdministrationTabsCss).findBy(text(tabName)).shouldBe(visible).click();
    }

    public void clickAddProcessOnTrigger(String trigger) {
        $(By.xpath(String.format(
                "//td[contains(text(),'%s')]/..//button", trigger)))
                .shouldBe(visible).click();
    }


    public void saveEventChanges() {
        $(saveButtonProcessXpath).shouldBe(visible).click();
    }

    public void setProcessVariableToLineId(String variableName) {
        $(setParametersButtonXpath).shouldBe(visible).click();
        $(addFieldButtonXpath).shouldBe(visible).click();
        $(fieldSelectorButtonXpath).shouldBe(visible).click();
        $$(popoverOptionsXpath).findBy(text(variableName)).shouldBe(visible).click();
        $(fieldSelectorButtonXpath).shouldBe(visible).click();
        $$(popoverOptionsXpath).findBy(text("Линия")).shouldBe(visible).click();
        $$(popoverOptionsXpath).findBy(text("Идентификатор")).shouldBe(visible).click();
        $(modalWindowSaveButtonXpath).shouldBe(visible).click();

    }

    public void selectFromCompanyProcesses(String processName) {
        // Пришлось сделать экземпляр метода выбора процесса, т.к. селекторы другие.
        if ($(companyProcessFolderOpener).shouldBe(visible).is(text("arrow_right"))) {
            // Если стрелка сворачивания папки смотрит вправо (папка закрыта) - нажать.
            $(companyProcessFolderOpener).click();
        }
        $$(processItemsInTreeCss).findBy(text(processName)).scrollTo().shouldBe(visible).click();
    }

    public void checkSessionAppBind(String appName) {
        $(sessionAppBindLink).shouldBe(visible).shouldHave(text(appName));
    }

    public void setPriority(String priority) {

    }

    public void openRuleEllipsisSettingsByName(String ruleName) {
        $(By.xpath("//div[contains(@class,'rule-announcement') and contains(.,'" + ruleName + "')]" +
                "//ancestor::app-draggable-routing-rule[1]//button[contains(text(),'ellipsis_v')]")).shouldBe(visible).click();
    }

    public void deleteRuleByName(String ruleName) {
        openRuleEllipsisSettingsByName(ruleName);
        selectPopoverOptionByName("Удалить");
        dialogWindowPressButton("Удалить");
        $(By.xpath("//div[contains(@class,'rule-announcement') and contains(.,'"
                + ruleName + "')]")).shouldNotBe(visible);
    }

    public void copyRuleByName(String ruleName) {
        openRuleEllipsisSettingsByName(ruleName);
        selectPopoverOptionByName("Создать копию");
        dialogWindowPressButton("Сохранить");
        checkRuleWithNameExists("(копия) " + ruleName);
    }

    public void checkRuleWithNameExists(String ruleName) {
        $(By.xpath("//div[contains(@class,'rule-announcement') and contains(.,'"
                + ruleName + "')]")).shouldBe(visible);
    }
}