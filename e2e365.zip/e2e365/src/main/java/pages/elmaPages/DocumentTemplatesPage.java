package pages.elmaPages;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class DocumentTemplatesPage extends BasePage {
    private final By expandArrowCss = By.cssSelector("elma-treetable span span");
    private final By createdTemplatesCss = By.cssSelector("elma-treetable div[class*='childerenNodes'] elma-type-string span");
    private final By trashIconCss = By.cssSelector("button[elmabutton='danger']");
    private final By sectionNameInDocTemplatesCss = By.cssSelector("elma-treetable div[id*='id_global'] div:first-child span elma-field-value");
    private final By pageHeaderButtons = By.xpath("//div[contains(@class, 'page-header__buttons')]");
    private final By templatesArrowUp = By.xpath(".//i[text()='arrow_up']/..");
    private final By templatesArrowDown = By.xpath(".//i[text()='arrow_down']/..");

    /**
     * Нажать по имени на элемент в вкладке шаблона документов
     *
     * @param name имя элемента на который нажимать
     */
    public void pressSection(String name) {
        $$(expandArrowCss).findBy(text(name)).shouldBe(visible).click();
    }

    /**
     * Нажать на иконку удаления шаблона
     */
    public void pressTrashIcon() {
        $(trashIconCss).shouldBe(visible).click();
    }

    /**
     * Проверяет, что элемент, который появляется после разворачивания содержимого раздела, существует
     *
     * @param templateName имя элемента который должен существовать
     */
    public void checkSectionContentExists(String templateName) {
        $$(createdTemplatesCss).findBy(text(templateName)).should(exist);
    }

    /**
     * Проверяет, что элемент, который появляется после разворачивания содержимого раздела, не существует
     *
     * @param templateName имя элемента который не должен существовать
     */
    public void checkSectionContentNotExists(String templateName) {
        $$(createdTemplatesCss).findBy(text(templateName)).shouldNot(exist);
    }

    /**
     * Проверяет, что существует разворачиваемый раздел
     *
     * @param sectionName имя раздела
     */
    public void checkSectionExists(String sectionName) {
        $(expandArrowCss).shouldBe(visible);
        $$(sectionNameInDocTemplatesCss).findBy(text(sectionName)).should(exist);
    }

    public void clickTurnAllTemplates() {
        SelenideElement element = $(pageHeaderButtons).shouldBe(visible);
        if (element.$(templatesArrowDown).is(not(visible))) {
            element.$(templatesArrowUp).shouldBe(visible).click();
        }
    }

    public void clickExpandAllTemplates() {
        SelenideElement element = $(pageHeaderButtons).shouldBe(visible);
        if (element.$(templatesArrowUp).is(not(visible))) {
            element.$(templatesArrowDown).shouldBe(visible).click();
        }
    }

}
