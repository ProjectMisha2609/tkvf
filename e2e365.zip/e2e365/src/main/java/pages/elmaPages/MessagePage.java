package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class MessagePage extends BasePage {
    private final String wheelCss = "button[class*='btn btn-primary btn-style-icon']";
    private final String settingOptionCss = "div[class*='popover-outer visible'] elma-popover-menu-option";
    private final String channelNameModalCss = "input[class*='form-control']";
    private final String messageHeaderModalCss = "input[placeholder='Заголовок...']";
    private final String messageTextModalCss = "div[data-placeholder='Сообщение...']";
    private final String firstMessageHeaderCss = "div.message__title a";
    private final String firstMessageTextCss = "app-read-more div";
    private final String firstUserInList = "ul[id='quill-mention-list'] div:first-child";
    private final String firstMessageMentionCss = "div[class*=message__body] a[class*='mention']";
    private final String commentaryAreaCss = "div[class*='ql-editor']";
    private final String firstCommentaryCss = "div[class='message__body_container'] p";
    private final String searchBoxUsersControlModalCss = "input[role='searchbox']";
    private final String mentionUserUsersControlModalCss = "div[class*='user-card__info-padding-sm'] app-user-name:first-child";
    private final String saveButtonUsersControlModalCss = "div[class='btn-group'] button[elmabutton='primary']";
    private final By messagesCss = By.cssSelector(".message__inner");
    private final By readAllMessagesButtonXpath = By.xpath("//app-read-all//button");
    private final By confirmReadAllMessagesButtonXpath = By.xpath("//div[contains(@class,'popover-content')]//button[contains(text(),'Да')]");
    private final By newMessagesTitleCss = By.cssSelector("[class*='message__inner @new'] [class*='message__title']");
    private final By newMessagesTextCss = By.cssSelector("[class*='message__inner @new'] [class*='message__conten']");

    public void chooseSettingsOption(String option) {
        $(wheelCss).shouldBe(visible).click();
        $$(settingOptionCss).findBy(text(option)).shouldBe(visible).click();
    }

    public void enterChannelNameModal(String channelName) {
        $(channelNameModalCss).shouldBe(visible).sendKeys(channelName);
    }

    public void writeMessageHeader(String messageHeader) {
        $(messageHeaderModalCss).shouldBe(visible).sendKeys(messageHeader);
    }

    public void writeMessageText(String messageText) {
        $(messageTextModalCss).shouldBe(visible).sendKeys(messageText);
    }

    public void clickAddMentionUserInUsersControlModal(String mentionUser) {
        $(searchBoxUsersControlModalCss).shouldBe(visible).sendKeys(mentionUser);
        $(mentionUserUsersControlModalCss).shouldBe(visible).click();
        $(saveButtonUsersControlModalCss).shouldBe(visible).click();
    }

    public void clickFirstUserInSendMessage() {
        $(firstUserInList).shouldBe(visible).click();
    }

    public void sendCommentary(String commentaryText) {
        $(commentaryAreaCss).shouldBe(visible).sendKeys(commentaryText + "\n");
    }

    public void checkMentionExist(String mentionUser) {
        $(firstMessageMentionCss).shouldBe(visible);
        $(firstMessageMentionCss).shouldBe(visible).shouldHave(text(mentionUser));
    }

    public void checkCommentaryExistAndEqual(String commentaryText) {
        $(firstCommentaryCss).shouldBe(visible);
        $(firstCommentaryCss).shouldBe(visible).shouldHave(text(commentaryText));
    }

    @Deprecated // устаревший метод, который проверяет наличие элементов сообщения по отдельности.
    public void checkHeaderAndTextEqual(String messageHeader, String messageText) {
        $(firstMessageHeaderCss).shouldBe(visible).shouldHave(text(messageHeader));
        $(firstMessageTextCss).shouldBe(visible).shouldHave(text(messageText));
    }

    public void checkMessageHeaderAndTextEqual(String messageTitle, String messageText) {
        $$(newMessagesTitleCss).findBy(text(messageTitle)).shouldBe(visible);
        $$(newMessagesTextCss).findBy(text(messageText)).shouldBe(visible)
                //нужно нажать чтобы это сообщение не было новым
                .click();
    }

    public void checkExistsMessage(String targetTitle) {
        $$(messagesCss).findBy(text(targetTitle)).should(exist).scrollTo().shouldBe(visible).click();
    }

    public void checkExistsMessage(String targetTitle, String targetText) {
        $$(messagesCss).findBy(text(targetTitle)).should(exist).scrollTo().shouldBe(visible);
        $$(messagesCss).findBy(text(targetText)).should(exist).shouldBe(visible).click();
    }

    public void readAllMessages() {
        try {
            $(readAllMessagesButtonXpath).shouldBe(visible).click();
            $(confirmReadAllMessagesButtonXpath).shouldBe(visible).click();
        } catch (com.codeborne.selenide.ex.ElementNotFound ignore) {
        }
    }

    public void checkNotExistsMessage(String targetTitle) {
        $$(messagesCss).findBy(text(targetTitle)).shouldNot(exist);
    }
}