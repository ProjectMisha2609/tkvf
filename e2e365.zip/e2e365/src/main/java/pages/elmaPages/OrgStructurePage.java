package pages.elmaPages;

import com.codeborne.selenide.Selenide;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.util.Locale;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.openqa.selenium.Keys.DELETE;

@Singleton
public class OrgStructurePage extends BasePage {
    private final By inputElementNameCss = By.cssSelector("[class*='textarea-input']");
    private final By saveButtonCss = By.cssSelector("[class*='actions__item actions__item--save']");
    private final By nameElementsCss = By.cssSelector("[class*='tree-container']>g>:nth-child(1)");
    private final By saveMessageCss = By.cssSelector("div[aria-label='Организационная структура сохранена']");
    private final By titleOrgStructureCss = By.cssSelector("[class*=pull-left][class*=title]");
    private final By directorElementCss = By.xpath("//elma-orgstruct//*[@class='outter']");
    private final By addUser = By.xpath("//elma-orgstruct//*[@class='outter']//*[text()='user_plus_2']");
    private final By addGroup = By.xpath("//elma-orgstruct//*[@class='outter']//*[text()='users_plus_2']");
    private final By addDepartment = By.xpath("//elma-orgstruct//*[@class='outter']//*[text()='door_plus']");
    private final By editButton = By.xpath("//elma-orgstruct//*[@class='outter']//*[text()='pencil_2']");
    private final By deleteButton = By.xpath("//elma-orgstruct//*[@class='outter']//*[text()='close']");
    private final By deleteButtonModalWindow = By.cssSelector("[class*='btn-danger']");
    private final By buttonMoveClickable = By.cssSelector("[class='connector blue']");
    private final By collapseArrowUp = By.cssSelector("[class='elma-icons green']");
    private final By firstPosition = By.cssSelector("[class*='tree']:first-child [class='desc'] text:last-child");
    private final String nameOfOrgStructure = "//*[contains(@class, 'desc')] //*[contains(text(), '%s')]";
    private final By buttonReturnCss = By.cssSelector("[class='button']>circle");

    public void open() {
        Selenide.open(String.format(config.standUrl + "/admin" + "/orgstruct").toLowerCase(Locale.ROOT));
        CustomDriver.alertAccept();
    }

    public void clickAddPosition() {
        $(directorElementCss).hover();
        $(addUser)
                .shouldBe(visible)
                .hover()
                .click();
    }

    public void clickAddGroup() {
        $(directorElementCss).hover();
        $(addGroup)
                .shouldBe(visible)
                .hover()
                .click();
    }

    public void clickAddDepartment() {
        $(directorElementCss).hover();
        $(addDepartment)
                .shouldBe(visible)
                .hover()
                .click();
    }

    public void fillName(String name) {
        $(inputElementNameCss).shouldBe(visible).sendKeys(name);
    }

    public void clickSaveButton() {
        $(saveButtonCss).shouldBe(visible).click();
        $(saveMessageCss).shouldBe(visible);
    }

    public void checkElementNameExists(String text) {
        $(nameElementsCss).shouldBe(visible).shouldHave(text(text));
    }

    public String getPageHeaderText() {
        return $(titleOrgStructureCss).shouldBe(visible).getText();
    }

    public void checkPageHeaderContainsText(String text) {
        $(titleOrgStructureCss).shouldBe(visible).shouldHave(text(text));
    }

    public void clickButtonCollapseArrowUp(String nameOrgStructure) {
        CustomDriver.getAction().moveToElement($(By.xpath(String.format(nameOfOrgStructure, nameOrgStructure)))
                        .shouldBe(visible))
                .moveToElement($(collapseArrowUp)).click()
                .build().perform();
    }

    public void clickDepartment(String nameDepartment) {
        CustomDriver.getAction().moveToElement($(By.xpath(String.format(nameOfOrgStructure, nameDepartment)))
                .shouldBe(visible)).click().perform();
    }

    public void clickButtonReturn() {
        CustomDriver.getAction().moveToElement($(buttonReturnCss).shouldBe(visible)).click().perform();
    }

    public void checkDepartment(String nameDepartment) {
        $(By.xpath(String.format(nameOfOrgStructure, nameDepartment))).shouldHave(exist, visible);
    }

    public void clickDeleteButtonPosition(String positionName) {
        CustomDriver.getAction()
                .moveToElement($(By.xpath(String.format(nameOfOrgStructure, positionName))).shouldBe(visible).hover())
                .moveToElement($$(deleteButton).findBy(visible)).click()
                .build()
                .perform();
    }

    public void clickDeleteButtonModalWindow() {
        $(deleteButtonModalWindow).shouldBe(visible).click();
    }

    public void checkAbsenceOfPosition(String positionName) {
        $(By.xpath(String.format(nameOfOrgStructure, positionName))).shouldNotHave(exist, visible);
    }

    public void checkExistPosition(String positionName) {
        $(By.xpath(String.format(nameOfOrgStructure, positionName))).shouldHave(exist, visible);
    }

    public void repositionName(String positionName, String newPositionName) {
        CustomDriver.getAction()
                .moveToElement($(By.xpath(String.format(nameOfOrgStructure, positionName))).shouldBe(visible)).doubleClick()
                .sendKeys(DELETE, newPositionName)
                .moveToElement($(collapseArrowUp)).click()
                .build()
                .perform();
    }

    public void checkButtonReturn() {
        $(buttonReturnCss).shouldHave(visible, exist);
    }

    public void movePosition(String positionName) {
        CustomDriver.getAction()
                .moveToElement($(By.xpath(String.format(nameOfOrgStructure, positionName))).hover())
                .moveToElement(
                        $$(buttonMoveClickable).findBy(visible)).click()
                .build()
                .perform();
    }

    public void addPosition(String positionName) {
        CustomDriver.getAction()
                .moveToElement($(By.xpath(String.format(nameOfOrgStructure, positionName))).shouldBe(visible).hover())
                .moveToElement($$(addUser).findBy(visible)).click()
                .build()
                .perform();
    }

    public void checkFirstPosition(String expectedPositionName) {
        $(firstPosition).shouldHave(text(expectedPositionName));
    }

    public void repositionNameWithButtonEdit(String positionName, String newPositionName) {
        CustomDriver.getAction()
                .moveToElement($(By.xpath(String.format(nameOfOrgStructure, positionName)))
                        .shouldBe(visible).hover())
                .moveToElement($$(editButton).findBy(visible)).click()
                .sendKeys(DELETE, newPositionName)
                .build()
                .perform();
    }
}