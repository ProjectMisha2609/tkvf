package pages.elmaPages;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import infrastructure.utils.Constants;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import java.io.File;
import java.time.LocalDate;
import java.util.Locale;
import java.util.Objects;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static java.time.format.DateTimeFormatter.ofPattern;

@Singleton
public class ProjectPage extends BasePage {
    private final String locatorBlock = "//elma-column//span[contains(text(),'%s')]/ancestor::elma-column[1]";
    private final By mainPanelButtonCss = By.cssSelector(".gantt-button-panel button");
    private final By gridDataRowCss = By.cssSelector(".gantt_grid_data .gantt_row");

    public void clickButtonNameOnBlockOfProject(String blockName, String buttonName) {
        $$(By.xpath(String.format(locatorBlock, blockName) + "//button")).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void clickButtonAddTaskInProjectPlan() {
        $(".gantt_grid_head_cell span.plus-button").shouldBe(visible).click();
    }

    public void clickButtonOfMainPanel(String buttonName) {
        $$(mainPanelButtonCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void checkTextOnDiagramGantExists(String taskName) {
        $$(gridDataRowCss).findBy(text(taskName)).shouldBe(visible);
    }

    public void uploadingMPP(String filePath) {
        $("[data-test='uploadFileI']>input").sendKeys(new File("").getAbsoluteFile() + filePath);

        CustomDriver.waitMills(3000);
    }

    public void clickButtonZoomAllVersionPlan() {
        $(".main-panel button.input-group-search").shouldBe(visible).click();
    }

    public void openContextByTask(String taskName) {
        $$(gridDataRowCss).findBy(text(taskName)).shouldBe(visible).contextClick();
    }

    public void checkDateTask(String rowName, LocalDate time) {
        $$(By.xpath("//elma-form-row//span[contains(text(), '" + rowName + "')]" +
                "/ancestor::elma-form-row[1]//elma-type-datetime"))
                .findBy(text(time.format(ofPattern("dd MMMM yyyy").withLocale(Locale.forLanguageTag("ru"))) + " г.")).shouldBe(visible);
    }

    public void checkColorMileStone(int r, int g, int b) {
        SelenideElement element = $(By.cssSelector(".gantt_task_content"));
        this.checkElementBackgroundColor(element, r, g, b);
    }

    public void editTaskInDiagramGant(String taskName, String oldValue, String newValue) {
        $(By.xpath("//div[contains(text(),'" + taskName + "')]/ancestor::*[contains(@class,'gantt_row_task')]//*[contains(text(),'" + oldValue + "')]"))
                .shouldBe(visible).click();
        $(By.xpath("//div[contains(@class,'gantt_grid_editor_placeholder')]//input")).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a"), Keys.BACK_SPACE, newValue, Keys.ENTER);
    }

    public void checkDownLoadMPP(String name) {
        boolean isExists = false;
        for (String s : Objects.requireNonNull(new File(Configuration.downloadsFolder).list())) {
            if (s.contains(name)) {
                isExists = true;
                break;
            }
        }
        if (!isExists) {
            for (String s : Objects.requireNonNull(new File(Constants.PATH_TO_DEFAULT_DIR).list())) {
                if (s.contains(name)) {
                    isExists = true;
                    break;
                }
            }
        }

        Assertions.assertTrue(isExists, "Файл не выгрузился");
    }
}