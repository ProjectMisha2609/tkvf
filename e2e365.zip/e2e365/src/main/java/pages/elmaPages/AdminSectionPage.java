package pages.elmaPages;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import java.time.Duration;
import java.util.Locale;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

@Singleton
public class AdminSectionPage extends BasePage {

    /**
     * Открыть роль по ID
     *
     * @param roleID - id Роли
     */
    public void openRole(String roleID) {
        String baseUrl = config.standUrl;
        String fullUrl = String.format("%1$s/admin/groups(p:group/%2$s)", baseUrl, roleID);
        if (!CustomDriver.getCurrentUrl().equals(fullUrl) | fullUrl.equals(baseUrl)) {
            Selenide.open(fullUrl);
        }
        checkAlert();
    }

    private final By inviteSuccessfullyCreatedToastCss = By.cssSelector("div[aria-label='Приглашение успешно создано']");
    private final By linkOrgStructurePageCss = By.cssSelector("[class*=orgstructure]");
    private final By linkGroupsPageCss = By.cssSelector("[class*=groups]");
    private final By linkUsersPageCss = By.cssSelector("[class*=users]");
    private final By linkSubstitutionPageCss = By.cssSelector("[routerlink='../substitution']");
    private final By linkCompanySettingsPageXpath = By.xpath("//a[contains(text(),'Настройки компании')]");
    private final By linkSecuritySettingsPageCss = By.cssSelector("[class*=security]");
    private final By linkNotificationsPageCss = By.cssSelector("[class*=notifications]");
    private final By linkTokensPageCss = By.cssSelector("[class*=tokens]");
    private final By linkFilesPageCss = By.cssSelector("[routerlink='../disk']");
    private final By linkModulesPageCss = By.cssSelector("[routerlink='../extensions']");
    private final By linkEmailSendSettingsPageCss = By.cssSelector("[routerlink='../mail']");
    private final By linkExtraParamsPageCss = By.cssSelector("[routerlink='../params']");
    private final By linkPerformingDisciplinePageCss = By.cssSelector("[routerlink='../discipline']");
    private final By linkExportConfigurationModalCss = By.cssSelector("[href='/admin/main(p:export/configuration)']");
    private final By linkIncomingInputCallPageCss = By.cssSelector("[routerlink='../crm/input-call']");
    private final By linkBusinessProcessesPageCss = By.cssSelector("[routerlink='../process']");
    private final By linkProcessesMonitorPageCss = By.cssSelector("[routerlink='../monitor']");
    private final By linkErrorMonitorPageCss = By.cssSelector("[routerlink='../errormonitor']");
    private final By linkWorkCalendarPageCss = By.cssSelector("[routerlink='../worktimer']");
    private final By linkDocumentTemplatesPageCss = By.cssSelector("[routerlink='../doctemplates']");
    private final By linkInterfacesPageCss = By.cssSelector("[routerlink='../interfaces']");
    private final By linkNomenclatureSettingsPageCss = By.cssSelector("[routerlink='../../_designer/nom']");
    private final By serviceSettingsCss = By.cssSelector("[routerlink='../postman/services']");
    private final By connectionsSettingsCss = By.cssSelector("[routerlink='../postman/links']");
    private final By linesSettingsCss = By.cssSelector("[routerlink='../chatdesk/lines']");
    private final By createParameterButton = By.xpath("//button[contains(., 'Параметр')]");
    private final By companyParameterDropdownButtonXpath = By.xpath("//span[@elmabutton][contains(., ' Дополнительные параметры компании')]");
    private final By parameterDropdownButtons = By.xpath("//span[@elmabutton]");
    private final By openParameterButtonsXpath = By.xpath("//button[@elmabutton='link']//span");
    private final By parameterValuesXpath = By.xpath("//elma-type-string//span");
    private final By saveButtonXpath = By.xpath("//i[@class='elma-icons save-button']");
    private final By companyParameterEllipsisButton = By.xpath("//span[contains(text(), 'Дополнительные параметры компании')]/../../../../..//button[contains(text(), 'menu_horizontal')]");
    private final By plusParameterPopupButton = By.xpath("//div[contains(@class, 'popover_is-visible')]//span[contains(text(), 'Добавить параметр')]");
    private final By processNameInputXpath = By.xpath("//elma-form-row//span[contains(text(),'Название')]/../..//input");
    private final By processCodeInputXpath = By.xpath("//elma-form-row//span[contains(text(),'Код')]/../..//input");
    private final By createProcessButtonXpath = By.xpath("//app-page-header//button[contains(text(), 'Процесс')]");
    private final By confirmMoveProcessButtonXpath = By.xpath("//app-move-template//button[contains(text(),'Переместить')]");
    private final By confirmCopyProcessButtonXpath = By.xpath("//app-copy-template//button[contains(text(),'Скопировать')]");
    private final By renameProcessOptionInDropdownXpath = By.xpath("//div[contains(@class,'popover-outer visible')]//elma-popover-menu-option//span[contains(text(),'Переименовать')]");
    private final By copyProcessOptionInDropdownXpath = By.xpath("//div[contains(@class,'popover-outer visible')]//elma-popover-menu-option//span[contains(text(),'Создать копию')]");
    private final By moveProcessOptionInDropdownXpath = By.xpath("//div[contains(@class,'popover-outer visible')]//elma-popover-menu-option//span[contains(text(),'Переместить')]");
    private final By categoryInputXpath = By.xpath("//app-move-template//input");
    private final By collapsedFolderXpath = By.xpath("//elma-tree//span[contains(@class, 'collapsed')]");
    private final By parentCategoryInputXpath = By.xpath("//elma-form-row//span[contains(text(),'Родительская')]/../..//input");
    private final By collapsedCompanyProcessesFolderXpath = By.xpath("//button[contains(text(),'Процессы компании')]/../../../div[contains(@class,'opened-indicator')]");
    private final By companyProcessesFolderXpath = By.xpath("//button[contains(text(),'Процессы компании')]");
    private final By confirmCreateProcessButtonXpath = By.xpath("//app-create-template//button[contains(text(),'Создать')]");
    private final By errorMonitorHeaderCss = By.cssSelector("div[class='content-header__title']");

    public void checkUserAdded() {
        $(inviteSuccessfullyCreatedToastCss).shouldBe(visible);
    }

    public void clickLinkOrgStructure() {
        $(linkOrgStructurePageCss).shouldBe(visible).click();
    }

    public void clickLinkGroups() {
        $(linkGroupsPageCss).shouldBe(visible).click();
    }

    public void clickLinkUsers() {
        $(linkUsersPageCss).shouldBe(visible).click();
    }

    public void clickSubstitutionUsers() {
        $(linkSubstitutionPageCss).shouldBe(visible).click();
    }

    public void clickCompanySettings() {
        $(linkCompanySettingsPageXpath).shouldBe(visible).click();
    }

    public void clickSecuritySettings() {
        $(linkSecuritySettingsPageCss).shouldBe(visible).click();
    }

    public void clickNotifications() {
        $(linkNotificationsPageCss).shouldBe(visible).click();
    }

    public void clickTokens() {
        $(linkTokensPageCss).shouldBe(visible).click();
    }

    public void clickFiles() {
        $(linkFilesPageCss).shouldBe(visible).click();
    }

    public void clickModules() {
        $(linkModulesPageCss).shouldBe(visible).click();
    }

    public void clickEmailSendSettings() {
        $(linkEmailSendSettingsPageCss).shouldBe(visible).click();
    }

    public void clickExtraParams() {
        $(linkExtraParamsPageCss).shouldBe(visible).click();
    }

    public void clickPerformingDiscipline() {
        $(linkPerformingDisciplinePageCss).shouldBe(visible).click();
    }

    public void clickExportConfiguration() {
        $(linkExportConfigurationModalCss).shouldBe(visible).click();
    }

    public void clickIncomingInputCall() {
        $(linkIncomingInputCallPageCss).shouldBe(visible).click();
    }

    public void clickBusinessProcesses() {
        $(linkBusinessProcessesPageCss).shouldBe(visible).click();
    }

    public void clickProcessesMonitor() {
        $(linkProcessesMonitorPageCss).shouldBe(visible).click();
    }

    public void clickErrorMonitor() {
        $(linkErrorMonitorPageCss).shouldBe(visible).click();
    }

    public void clickWorkCalendar() {
        $(linkWorkCalendarPageCss).shouldBe(visible).click();
    }

    public void clickDocumentTemplates() {
        $(linkDocumentTemplatesPageCss).shouldBe(visible).click();
    }

    public void clickInterfaces() {
        $(linkInterfacesPageCss).shouldBe(visible).click();
    }

    public void clickNomenclatureSettings() {
        $(linkNomenclatureSettingsPageCss).shouldBe(visible).click();
    }

    public void clickServiceSettings() {
        $(serviceSettingsCss).shouldBe(visible).click();
    }

    public void clickConnectionsSettings() {
        $(connectionsSettingsCss).shouldBe(visible).click();
    }

    public void clickLinesSettings() {
        $(linesSettingsCss).shouldBe(visible).click();
    }

    public void clickCreateParameterButton() {
        $(createParameterButton).shouldBe(visible).click();
    }

    public void checkCompanyParameterExists(String parameterName) {
        SelenideElement target = $$(openParameterButtonsXpath).findBy(text(parameterName));
        if (target.isDisplayed()) {
            target.shouldBe(visible);
        } else {
            $(companyParameterDropdownButtonXpath).click();
            target.shouldBe(visible);
        }
    }

    public void checkSectionParameterExists(String parameterName) {
        SelenideElement target = $$(openParameterButtonsXpath).findBy(text(parameterName));
        if (target.isDisplayed()) {
            target.shouldBe(visible);
        } else {
            $(parameterDropdownButtons).click();
            target.shouldBe(visible);
        }
    }

    public void checkCompanyParameterNotExists(String parameterName) {
        $$(openParameterButtonsXpath).findBy(text(parameterName)).shouldNot(exist);
        $(companyParameterDropdownButtonXpath).click();
        $$(openParameterButtonsXpath).findBy(text(parameterName)).shouldNot(exist);
    }

    public void checkCompanyParameterValueExists(String parameterValue) {
        SelenideElement target = $$(parameterValuesXpath).findBy(text(parameterValue));
        try {
            target.shouldBe(visible, Duration.ofSeconds(5));
            // проверяем видимость, если элемент не виден - раскрываем раздел.
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            $(companyParameterDropdownButtonXpath).click();
            target.shouldBe(visible);
        }
    }

    public void openCompanyParameterByName(String parameterName) {
        SelenideElement target = $$(openParameterButtonsXpath).findBy(text(parameterName));
        if (target.isDisplayed()) {
            target.shouldBe(visible).click();
        } else {
            $(companyParameterDropdownButtonXpath).click();
            target.shouldBe(visible).click();
        }
    }

    public void editCompanyParameterValueByName(String parameterName, String value) {
        SelenideElement target = $$(openParameterButtonsXpath).findBy(text(parameterName));
        By targetPencil = By.xpath(String.format("//button[@elmabutton='link']//span[contains(.,'%s')]/../../../..//button[@title = 'Изменить']", parameterName));
        if (target.isDisplayed()) {
            target.shouldBe(visible).hover();
            $(targetPencil).click();
            $(By.xpath("//input")).sendKeys(value);
            $(saveButtonXpath).click();
        } else {
            $(companyParameterDropdownButtonXpath).click();
            target.shouldBe(visible).hover();
            $(targetPencil).click();
            $(By.xpath("//input")).sendKeys(value);
            $(saveButtonXpath).click();
        }
    }

    public void checkCompanyParameterTitle(String parameterName, String parameterHint) {
        SelenideElement target = $$(openParameterButtonsXpath).findBy(text(parameterName));
        if (target.isDisplayed()) {
            target.shouldHave(attribute("title", parameterHint));
        } else {
            $(companyParameterDropdownButtonXpath).click();
            target.shouldHave(attribute("title", parameterHint));
        }
    }

    public void createCompanyParameterByEllipsisButton() {
        $(companyParameterEllipsisButton).shouldBe(visible).click();
        $(plusParameterPopupButton).shouldBe(visible).click();
    }

    public void createSectionParameterByEllipsisButton(String sectionName) {
        By sectionParameterEllipsisButton = By.xpath("//span[contains(text(), '" +
                sectionName + "')]/../../../../..//button[contains(text(), 'menu_horizontal')]");
        $(sectionParameterEllipsisButton).shouldBe(visible).click();
        $(plusParameterPopupButton).shouldBe(visible).click();
    }

    public void editSectionParameterValueByName(String sectionName, String parameterName, String value) {
        SelenideElement target = $$(openParameterButtonsXpath).findBy(text(parameterName));
        By targetPencil = By.xpath(String.format("//button[@elmabutton='link']//span[contains(.,'%s')]/../../../..//button[@title = 'Изменить']", parameterName));
        if (target.isDisplayed()) {
            target.shouldBe(visible).hover();
            $(targetPencil).click();
            $(By.xpath("//input")).sendKeys(value);
            $(saveButtonXpath).click();
        } else {
            $(By.xpath(String.format("//span[@elmabutton][contains(., '%s')]", sectionName))).click();
            target.shouldBe(visible).hover();
            $(targetPencil).click();
            $(By.xpath("//input")).sendKeys(value);
            $(saveButtonXpath).click();
        }
    }

    public void checkSectionParameterValueExists(String sectionName, String parameterValue) {
        SelenideElement target = $$(parameterValuesXpath).findBy(text(parameterValue));
        try {
            target.shouldBe(visible, Duration.ofSeconds(5));
            // проверяем видимость, если элемент не виден - раскрываем раздел.
        } catch (com.codeborne.selenide.ex.ElementNotFound e) {
            $(By.xpath(String.format("//span[@elmabutton][contains(., '%s')]", sectionName))).click();
            target.shouldBe(visible);
        }
    }

    public void addBusinessProcess(String processName, String category) {
        $(createProcessButtonXpath).shouldBe(visible).click();
        $(processNameInputXpath).shouldBe(visible).sendKeys(processName);
        $(parentCategoryInputXpath).click();
        $(By.xpath(String.format("//span[contains(text(),'%s') and contains(@class,'elma-tree-label')]", category)))
                .shouldBe(visible).click();
        $(confirmCreateProcessButtonXpath).shouldBe(visible).click();
    }

    public void openCompanyProcesses() {
        if (!$(collapsedCompanyProcessesFolderXpath).shouldBe(visible).is(cssClass("opened"))) {
            $(companyProcessesFolderXpath).shouldBe(visible).click();
        }
    }

    public void openFolderWithProcesses(String name) {
        if (!$(By.xpath(String.format("//button[contains(text(),'%s')]/../../../div[contains(@class,'opened-indicator')]", name)))
                .shouldBe(visible).is(cssClass("opened"))) {
            $(By.xpath(String.format("//button[contains(text(),'%s')]", name))).shouldBe(visible).click();
        }
    }

    public void copyProcess(String processName, String processNameNew, String category) {
        $(By.xpath(String.format("//app-bptemplate-admin-page-tree-template//a[contains(text(),'%s')]/../../..//button", processName)))
                .should(exist).scrollTo().shouldBe(visible).click();
        $(copyProcessOptionInDropdownXpath)
                .shouldBe(visible).click();
        $(processNameInputXpath).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, processNameNew);
        $(processCodeInputXpath).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, processNameNew.toLowerCase(Locale.ROOT));
        if (!category.equals("Процессы компании")) {
            $(parentCategoryInputXpath).click();
            $(By.xpath(String.format("//span[contains(text(),'%s') and contains(@class,'elma-tree-label')]", category)))
                    .shouldBe(visible).click();
        }
        $(confirmCopyProcessButtonXpath).shouldBe(visible).click();
    }

    public void checkProcessExists(String processName) {
        $(By.xpath(String.format("//app-bptemplate-admin-page-tree-template//a[contains(text(),'%s')]", processName)))
                .should(exist).scrollTo().shouldBe(visible);
    }

    public void renameProcess(String processName, String processNameNew) {
        $(By.xpath(String.format("//app-bptemplate-admin-page-tree-template//a[contains(text(),'%s')]/../../..//button", processName)))
                .should(exist).scrollTo().shouldBe(visible).click();
        $(renameProcessOptionInDropdownXpath)
                .shouldBe(visible).click();
        actions().sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, processNameNew + Keys.ENTER).perform();
        checkProcessExists(processNameNew);
    }

    public void moveProcess(String processName, String category) {
        $(By.xpath(String.format("//app-bptemplate-admin-page-tree-template//a[contains(text(),'%s')]/../../..//button", processName)))
                .should(exist).scrollTo().shouldBe(visible).click();
        $(moveProcessOptionInDropdownXpath).shouldBe(visible).click();
        if (!category.equals("Процессы компании")) {
            $(categoryInputXpath).click();
            $(collapsedFolderXpath).shouldBe(visible).click();
            $(By.xpath(String.format("//span[contains(text(),'%s') and contains(@class,'elma-tree-label')]", category)))
                    .shouldBe(visible).click();
        }
        $(confirmMoveProcessButtonXpath).shouldBe(visible).click();
    }

    public void checkProcessIsInFolder(String processName, String folderName) {
        By processLocator = By.xpath(String.format("//app-bptemplate-admin-page-tree-category//button[contains(text(),'%s')]/../../../..//a[contains(text(),'%s')]", folderName, processName));
        $(processLocator).shouldBe(visible);
    }

    public void isPageErrorMonitor() {
        $(errorMonitorHeaderCss)
                .shouldBe(visible)
                .shouldHave(text("Монитор ошибок"));
        Assertions.assertTrue(CustomDriver.getCurrentUrl().contains("/admin/errormonitor"));
    }
}
