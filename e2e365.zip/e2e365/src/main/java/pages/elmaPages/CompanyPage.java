package pages.elmaPages;

import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.util.ArrayList;
import java.util.Collections;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class CompanyPage extends BasePage {
    private final String userContainerCss = "div[class*='group-row']:first-child div[class='group-for-letter']";
    private final String userCss = "span[class*='user-name']";
    private final By informationSubstitutionUser = By.cssSelector("[class*='info']>[class*='substitution']");
    private final By usersPageCss = By.cssSelector("[title='Cотрудники']");

    public void checkEmployeeListSorted() {
        ArrayList<String> initialEmployeeList = (ArrayList<String>) $(userContainerCss)
                .shouldBe(visible).$$(userCss).texts();
        ArrayList<String> AlphabeticalSortedEmployeeList = (ArrayList<String>) $(userContainerCss)
                .shouldBe(visible).$$(userCss).texts();
        Collections.sort(AlphabeticalSortedEmployeeList);
        Assertions.assertIterableEquals(initialEmployeeList, AlphabeticalSortedEmployeeList);
    }

    public void checkSubstitutionUser(String text) {
        $(informationSubstitutionUser).shouldHave(text(text));
    }

    public void clickUsersPage() {
        $(usersPageCss).shouldBe(visible).click();
    }
}
