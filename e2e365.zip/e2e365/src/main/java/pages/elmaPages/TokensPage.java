package pages.elmaPages;

import com.codeborne.selenide.CollectionCondition;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static org.openqa.selenium.By.cssSelector;

@Singleton
public class TokensPage extends BasePage {
    private final By buttonTokenCss = cssSelector("button[class *='btn btn-primary'] *[class ='elma-icons']");
    private final By buttonAdvancedSearchCss = cssSelector("[title ='Расширенный поиск']");
    private final By selectUserCss = cssSelector("[class='quick-list-container'] [class*='cell_email ng-star-inserted']");
    private final By inputTitleCss = cssSelector("[class*='ng-pristine ng-invalid']");
    private final By buttonCreateCss = cssSelector("[class*='modal-footer'] [class ='btn btn-primary']");
    private final By deleteTokenButtonCss = cssSelector("button[class ='delete btn btn-default btn-style-icon elma-icons']");
    private final By buttonOkCss = cssSelector("[class ='modal-footer'] button[class ='btn btn-primary']");
    private final By tokenNamesCss = By.cssSelector("td[class*='cell___name']>span");

    public void clickButtonToken() {
        $(buttonTokenCss).shouldBe(visible).click();
    }

    public void clickButtonAdvancedSearch() {
        $(buttonAdvancedSearchCss).shouldBe(visible).click();
    }

    public void clickSelectUser() {
        $(selectUserCss).shouldBe(visible).click();
    }

    public void inputName(String title) {
        $(inputTitleCss).shouldBe(visible).sendKeys(title);
    }

    public void clickButtonCreate() {
        $(buttonCreateCss).shouldBe(visible).click();
    }

    public void clickButtonDeleteToken() {
        CustomDriver.getAction().moveToElement($(deleteTokenButtonCss)).click().build().perform();
    }

    public void clickButtonOk() {
        $(buttonOkCss).shouldBe(visible).click();
    }

    public void isTokenNameExists(String text) {
        $$(tokenNamesCss).findBy(text(text)).shouldBe(exist);
    }

    public void isTokenNamesListHaveSameSize(int size) {
        $$(tokenNamesCss).shouldBe(CollectionCondition.size(size));
    }

    public void isTokenNamesListHaveSizeGreaterThan(int size) {
        $$(tokenNamesCss).shouldBe(CollectionCondition.sizeGreaterThan(size));
    }

    public int getTokensCount() {
        return $$(tokenNamesCss).size();
    }
}