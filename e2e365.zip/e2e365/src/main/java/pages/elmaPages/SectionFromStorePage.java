package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.exist;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SectionFromStorePage extends BasePage {
    private final By createVacancyId = By.cssSelector("[data-test=createVacancyB]");

    public boolean isCreateVacancyButtonExists() {
        return $(createVacancyId).shouldBe(visible).is(exist);
    }
}
