package pages.elmaPages;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.LocalDate;
import java.util.Locale;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static java.time.format.DateTimeFormatter.ofPattern;

/**
 * раздел "Номенклатура дел"
 */
@Singleton
public class NomenclaturePage extends BasePage {
    private final By treeTableItemsCss = By.cssSelector("elma-treetable .item-outer");
    private final By buttonCss = By.cssSelector("button");
    private final By counterNameCss = By.cssSelector("[class*=ng-pristine][class*=ng-invalid]");
    private final By dropdownMenuItemsCss = By.cssSelector("div.visible span[class*='ctx-menu__text']");
    private final By controlButtonsCss = By.cssSelector(".control.btn-group button");
    private final By buttonCreateAppCss = By.cssSelector("[data-test='createVacancyB']");
    private final By buttonExpandRegDocumentCss = By.cssSelector(".reg-title.btn.btn-link");
    private final By dropdownLabelCss = By.cssSelector(".p-dropdown-label");
    private final By dropdownItemCss = By.cssSelector(".p-dropdown-item");
    private final By viewRegistrationCss = By.cssSelector("app-appview-view-registration-ui-el");
    private final By navigationDirectoryCss = By.cssSelector(".side-nav__item .doc-nav__header");
    private final By breadCrumbTrailsCss = By.cssSelector(".breadcrumb-item");
    private final By radioButtonXpath = By.xpath("//p-radiobutton");
    private final By buttonSettingDossierXpath = By.xpath("//app-page-header//span[text()='tools']");
    private final By headerTitleCss = By.cssSelector(".page-header__title");
    private final By fieldValueCss = By.cssSelector("elma-field-value");
    private final By registrationManualInputCss = By.cssSelector("app-appview-view-registration-manual input");
    private final By treeNodeContentCss = By.cssSelector(".p-treenode-content");
    private final By rowTableCss = By.cssSelector("tbody tr");
    private final By buttonEditNumberRegCss = By.cssSelector(".show-edit-icon.btn.btn-link");
    private final By registrationNumInputCss = By.cssSelector("app-appview-view-registration input");
    private final By deleteButtonModalWindowCss = By.cssSelector("[class*='btn-danger']");
    private final By buttonAppViewRegistrationCss = By.cssSelector("app-appview-view-registration button");
    private final By innerButtonSaveCss = By.cssSelector(".content-body__inner .btn-primary");
    private final By multiSelectLabelCss = By.cssSelector(".p-multiselect-label");
    private final By checkCreateElementButtonCss = By.cssSelector("button[data-test=\"createVacancyB\"]");
    private final By loadAppListXpath = By.xpath("//*[contains(@class,'empty-folder') or contains(@class,'tile-click')]");
    private final By reserveMessageXpath = By.xpath("//div[contains(text(),'Номер зарезервирован')]");
    private final By viewDateRegistrationCss = By.cssSelector(".reg-date");


    public void clickThreeDotsButton(String nomenclatureName) {
        $$(treeTableItemsCss).findBy(text(nomenclatureName)).scrollTo()
                .shouldBe(visible).$(buttonCss).click();
    }

    public void clickItemMenu(String itemName) {
        $$(dropdownMenuItemsCss).findBy(text(itemName)).shouldBe(visible).click();
    }

    public void fillName(String name) {
        SelenideElement element = $(counterNameCss).shouldBe(visible);
        element.click();
        element.sendKeys(name);
    }

    public void clickControlButton(String buttonName) {
        $$(controlButtonsCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void createAppPressButton() {
        $(buttonCreateAppCss).shouldBe(visible).click();
    }

    public void checkDocumentNotRegistered() {
        $$(buttonAppViewRegistrationCss).findBy(text("Зарегистрировать документ")).shouldBe(visible);
    }

    public void runRegDocument(String dossierName) {
        $$(buttonAppViewRegistrationCss).findBy(text("Зарегистрировать документ")).shouldBe(visible).click();
        $$(dropdownLabelCss).findBy(text("Выберите дело")).shouldBe(visible).click();
        $$(dropdownItemCss).findBy(text(dossierName)).shouldBe(visible).click();
        $$(buttonAppViewRegistrationCss).findBy(text("Регистрировать документ")).shouldBe(visible).click();
    }

    public void checkRegistrationNumberReserved(String dossierName) {
        $$(buttonAppViewRegistrationCss).findBy(text("Зарегистрировать документ")).shouldBe(visible).click();
        $$(dropdownLabelCss).findBy(text("Выберите дело")).shouldBe(visible).click();
        $$(dropdownItemCss).findBy(text(dossierName)).shouldBe(visible).click();
        $(reserveMessageXpath).shouldBe(visible);
    }

    public void checkRegistrationNumberNotReserved(String dossierName) {
        $$(buttonAppViewRegistrationCss).findBy(text("Зарегистрировать документ")).shouldBe(visible).click();
        $$(dropdownLabelCss).findBy(text("Выберите дело")).shouldBe(visible).click();
        $$(dropdownItemCss).findBy(text(dossierName)).shouldBe(visible).click();
        $$(buttonAppViewRegistrationCss).findBy(text("Резервировать")).shouldBe(visible);
    }

    public void runRegDocumentManualNumberForRegDocument(String dossierName, String number) {
        $$(buttonAppViewRegistrationCss).findBy(text("Зарегистрировать документ")).shouldBe(visible).click();
        $$(dropdownLabelCss).findBy(text("Выберите дело")).shouldBe(visible).click();
        $$(dropdownItemCss).findBy(text(dossierName)).shouldBe(visible).click();
        $$(buttonAppViewRegistrationCss).findBy(text("Не задан")).shouldBe(visible).click();
        $(registrationManualInputCss).shouldBe(visible).sendKeys(number);
        $$(buttonAppViewRegistrationCss).findBy(text("Сохранить")).shouldBe(visible).click();
    }

    public void runRegDocumentWithReserveNumber(String dossierName) {
        $$(buttonAppViewRegistrationCss).findBy(text("Зарегистрировать документ")).shouldBe(visible).click();
        $$(dropdownLabelCss).findBy(text("Выберите дело")).shouldBe(visible).click();
        $$(dropdownItemCss).findBy(text(dossierName)).shouldBe(visible).click();
        $$(buttonAppViewRegistrationCss).findBy(text("Резервировать")).shouldBe(visible).click();
    }

    public void clickButtonExpandRegDocument() {
        $(buttonExpandRegDocumentCss).shouldBe(visible).click();
    }

    public void checkRegDocument(String dossierName) {
        $$(viewRegistrationCss).findBy(text(dossierName)).shouldBe(visible);
    }

    public void clickNomenclatureSection(String nomSectionName) {
        $$(navigationDirectoryCss).findBy(text(nomSectionName)).shouldBe(visible).click();
    }

    public void checkNomenclatureSectionExists(String nomSectionName) {
        $$(navigationDirectoryCss).findBy(text(nomSectionName)).shouldBe(visible);
    }

    public void checkBreadCrumbTrailsExists(String pathName) {
        $$(breadCrumbTrailsCss).findBy(text(pathName)).shouldBe(visible);
    }

    public void checkNomenclatureOnSettingListExists(String nomenclatureName) {
        $$(treeTableItemsCss).findBy(text(nomenclatureName)).shouldBe(visible);
    }

    public void checkExpandIconExists(String itemRowName) {
        $(By.xpath("//elma-treetable//*[contains(@class,'item-outer') and contains(.,'" + itemRowName + "')]//i[contains(@class,'expand-icon')]")).shouldBe(visible);
    }

    public void chooseRowRadioButton(String rowName) {
        $$(radioButtonXpath).findBy(text(rowName)).shouldBe(visible).click();
    }

    public void chooseItemTreeWrapper(String itemName, String... path) {
        $$(treeNodeContentCss).findBy(text(path[0])).shouldBe(exist);
        for (String rowPath : path) {
            if ($$(treeNodeContentCss).findBy(text(rowPath)).$(".expand-status").is(cssClass("collapsed"))) {
                $$(treeNodeContentCss).findBy(text(rowPath)).scrollTo().shouldBe(visible).$("i").click();
            }
        }
        $$(treeNodeContentCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    public void clickButtonSettingDossier() {
        $(buttonSettingDossierXpath).shouldBe(visible).click();
    }

    public void checkNameInHeaderExists(String name) {
        $(headerTitleCss).$$("li").findBy(text(name)).shouldBe(visible);
    }

    public void clickItemOnAdministrationList(String name) {
        $$(fieldValueCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void checkNumerationRegDocument(String number) {
        $$(buttonExpandRegDocumentCss).findBy(text(number)).shouldBe(visible);
    }

    public void checkRegAppInChancellery(String elementName, String DossierName) {
        $$(rowTableCss).filterBy(text(DossierName)).findBy(text(elementName)).shouldBe(visible);
    }

    public void clickButtonEditNumberRegDocument() {
        $(buttonEditNumberRegCss).shouldBe(visible).click();
    }

    public void setNumberReg(String number) {
        $(registrationNumInputCss).shouldBe(visible).clear();
        $(registrationNumInputCss).shouldBe(visible).sendKeys(number);
        $$(buttonCss).findBy(text("Сохранить")).shouldBe(visible).click();
    }

    public void checkReserveNumerationRegDocument(String number) {
        $$(By.cssSelector(".reg-sub-title")).findBy(text("Номер зарезервирован")).shouldBe(visible);
        $$(By.cssSelector(".reg-name")).findBy(text(number)).shouldBe(visible);
    }

    public void clickButton(String buttonName) {
        $$(buttonCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void clickDeleteButtonModalWindow() {
        $(deleteButtonModalWindowCss).shouldBe(visible).click();
    }

    public void checkItemOnAdministrationListExists(String itemName) {
        $$(fieldValueCss).findBy(text(itemName)).shouldBe(visible);
    }

    public void checkItemOnAdministrationListNotExists(String itemName) {
        $$(fieldValueCss).findBy(text(itemName)).shouldNotBe(exist);
    }

    public void checkItemOnAdministrationListDisappear(String itemName) {
        $$(fieldValueCss).findBy(text(itemName)).should(appear).should(disappear);
    }

    public void setConditionCheckBox(String name, boolean condition) {
        By checkBoxNameXpath = By.xpath("//p-checkbox[contains(.,'" + name + "')]//div[contains(@class,'p-checkbox-box')]");
        SelenideElement element = $(checkBoxNameXpath).shouldBe(visible);
        if ($(checkBoxNameXpath).is(Condition.cssClass("p-highlight")) != condition)
            element.click();
    }

    public void checkButtonSaveExists() {
        $(innerButtonSaveCss).shouldBe(visible);
    }

    public void checkSelectDossierReg(String DossierName) {
        $$(multiSelectLabelCss).findBy(text(DossierName)).shouldBe(visible);
    }

    public void checkArrowRightExists(String placeName) {
        $(By.xpath("//i[contains(@class, 'collapse-node')]/../../../div//span[contains(text(),'" + placeName + "')]")).shouldBe(visible);
    }

    public void checkCreateElementButtonAndAppListExists() {
        $(checkCreateElementButtonCss).shouldBe(visible);
        $(loadAppListXpath).shouldBe(visible);
    }

    public void checkDateRegDocument(LocalDate localDate) {
        $$(viewDateRegistrationCss).findBy(text(localDate.format(ofPattern("dd MMMM yyyy").withLocale(Locale.forLanguageTag("ru"))) + " г.")).shouldBe(visible);
    }
}
