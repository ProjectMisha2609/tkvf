package pages.elmaPages;

import com.codeborne.selenide.Selenide;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.util.Locale;

import static com.codeborne.selenide.Condition.exist;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.actions;

/**
 * Администрирование/интерфейсы.
 * В папке "Интерфейсы компании" выбрать созданный виджет на редакриторание, либо создать новый, через кнопку "+Создать"
 */
@Singleton
public class UserWidgetPage extends BasePage {
    public void open(String nameUserWidget) {
        String urlUserWidget = "admin/interfaces/widget/global/" + nameUserWidget;
        String baseUrl = config.standUrl;
        String fullUrl = String.format(baseUrl + String.join("/", urlUserWidget)).toLowerCase(Locale.ROOT);
        if (!CustomDriver.getCurrentUrl().equals(fullUrl) | fullUrl.equals(baseUrl)) {
            Selenide.open(fullUrl);
        }
        checkAlert();
    }

    private final By tabsDraggableXpath = By.xpath("//li[text()[contains(., 'Вкладки')]]");
    private final By inscriptionDraggableXpath = By.xpath("//li[text()[contains(., 'Надпись')]]");
    private final By buttonAddWidgetCss = By.cssSelector("button.add-widget-button");
    private final By mainItemsContainerCss = By.cssSelector(".zone-items-container");

    public void addTabByDragAndDrop() {
        actions().clickAndHold($(tabsDraggableXpath))
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void addInscriptionByDragAndDrop() {
        actions().clickAndHold($(inscriptionDraggableXpath).shouldBe(exist).scrollTo())
                .moveToElement($(mainItemsContainerCss)).release().build().perform();
    }

    public void clickAddWidget() {
        $(buttonAddWidgetCss).shouldBe(visible).click();
    }
}
