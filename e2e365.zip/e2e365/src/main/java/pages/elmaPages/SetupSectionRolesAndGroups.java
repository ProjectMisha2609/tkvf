package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;
import java.util.NoSuchElementException;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SetupSectionRolesAndGroups extends BasePage {
    private final By installSectionId = By.cssSelector("[data-test=installSectionB]");
    private final By appExchangeProgressId = By.cssSelector("[data-test=appExchangeProgress]");

    public void clickInstallIfPresented() {
        try {
            $(installSectionId).shouldBe(visible).click();
            $(appExchangeProgressId).should(disappear, Duration.ofSeconds(30));
        } catch (NoSuchElementException ignored) {
        }
    }
}
