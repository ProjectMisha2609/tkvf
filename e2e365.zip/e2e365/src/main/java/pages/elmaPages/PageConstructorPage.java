package pages.elmaPages;

import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static java.lang.String.format;

@Singleton
public class PageConstructorPage extends BasePage {
    private final By publishBtnCss = By.cssSelector("div.toolbar div.pull-left.actions button.publish-widget");
    private final By messageCss = By.cssSelector("div[aria-label='Виджет опубликован']");
    private final By workAreaCss = By.cssSelector("div[class*='zone-items-container']");
    private final By saveToolbarCss = By.cssSelector("div.toolbar button.need-save");
    private final By topToolbarCss = By.cssSelector("div.pull-right ul.tabs li");
    private final By addContextCss = By.cssSelector("elma-context-fields-editor div.header button");
    private final By propertiesCss = By.cssSelector("elma-widget-sidebar label[title='Свойства']");
    private final By containerWidgetsToolbarCss = By.cssSelector("elma-widget-sidebar-widgets li[class*='widget-draggable-item'][data-draggable='true']");
    private final By containerContextToolbarCss = By.cssSelector("elma-widget-sidebar-fields elma-field-tile");
    private final By confirmPublishCss = By.cssSelector("div[role='dialog'] div.btn-group button.btn-primary");
    private final By workAreaFormCss = By.cssSelector("section.complex-popup");
    private final By workAreaContentCss = By.cssSelector("app-page-content div[class*='zone-items-container']");
    private final By inputTextCss = By.cssSelector("input[id = 'text']");
    private final By inputValueCss = By.cssSelector("input[id = 'value']");
    private final By buttonDeleteCss = By.cssSelector("button[title='Удалить']");
    private final By buttonAddColumnCss = By.cssSelector("button[title=\"+ Колонка\"]");
    private final By buttonStartJoinWithFieldCss = By.cssSelector("button[title='Установить связь с полем']");
    private final By buttonJoinWithFieldCss = By.cssSelector("button.value-button");
    private final By openContextFieldCss = By.cssSelector("div[aria-label='Контекст']");
    private final By chooseContextCss = By.cssSelector(".elma-tree-label.selectable");
    private final By buttonDangerCss = By.cssSelector("button.btn.btn-danger");
    private final By elmaBadgeCss = By.cssSelector("elma-badge");
    private final By buttonAddWidgetCss = By.cssSelector("button.add-widget-button");
    private final By elmaFormRowCss = By.cssSelector("elma-form-row");
    private final By appRowLayoutCss = By.cssSelector("app-row-layout");
    private final By elmaRowColumnsCss = By.cssSelector("elma-row");
    private final By elmaOneColumnCss = By.cssSelector("elma-column");
    private final By appPageWrapperColumnCss = By.cssSelector("app-page-wrapper elma-column");
    private final By widgetsCss = By.cssSelector("elma-widget-sidebar label[title='Виджеты']");
    private final By workAreaModalMainCss = By.cssSelector("div[class*='modal__main']");
    private final By buttonIconElementBindXpath = By.xpath("//elma-form-label/span[contains(text(),'Показать окно')]/../..//button[contains(text(),'system_link')]");
    private final By buttonIconElementBindHeaderCss = By.cssSelector("[class*='elma-form-row']:nth-child(1) [title*='Установить связь с полем']");
    private final By buttonNotInstalledCss = By.xpath("//*[contains(text(),'Не установлено')]");
    private final String listVariablesInShowWindowFieldCss = "//*[contains(@class,'p-treenode-content')]//span[contains(text(), '%s')]";
    private final By addWidgetInWidgetCss = By.cssSelector("[class*='modal-content zone-items-container'] [class*='modal-content zone-items-container'] [class*='add-widget-button']");
    private final By listWidgetsCss = By.cssSelector("[class*='widget-item__title']");
    private final By buttonDeleteWidget = By.cssSelector("[title='Удалить']");
    private final By buttonConfirmDeleteWidget = By.cssSelector("[class='popover-content'] [elmabutton*='danger']");
    private final By applicationElementCss = By.cssSelector("[aria-label='Элемент Приложения'] [class*='elma-icons md-18']");
    private final By indexer = By.xpath("//span[contains(text(), 'Идентификатор')]");
    private final By inputTextInHeader = By.cssSelector("[class*='multiline-container']>input[id*='title']");
    private final By lineContextCss = By.cssSelector(".lines-content");
    private final By sidePanelCss = By.cssSelector("div[class*='complex-popup__info-wrapper']");
    private final By switchButtonClientServerCss = By.cssSelector(".switch-buttons .p-button[aria-pressed=\"true\"]");
    private final By buttonCreateCss = By.cssSelector("app-gagarin");
    private final By uploaderFileCss = By.cssSelector("app-file-uploader-with-preview");
    private final By elmaChartCss = By.cssSelector("elma-chart");
    private final By viewFileCss = By.cssSelector("elma-file");
    private final By lineNumbersCss = By.cssSelector("div.line-numbers");
    private final By cursorCss = By.cssSelector("app-monaco textarea.monaco-mouse-cursor-text");
    private final By standardFormElementCss = By.cssSelector("app-dynamic-form");
    private final By itemsContextCss = By.cssSelector("elma-context-fields-editor button.item-line-inner");

    public void clickPublishAndCheckPublish() {
        // todo: в исходном boolean методе было объединено две зоны ответственности, надо делить.
        $(publishBtnCss).shouldBe(visible).click();
        if ($(confirmPublishCss).is(exist))
            $(confirmPublishCss).shouldBe(visible).click();
        $(messageCss).shouldBe(visible, Duration.ofSeconds(60));
    }

    public void clickSaveInToolbar() {
        $(saveToolbarCss).shouldBe(visible).click();
    }

    public void selectMainTab(String tabName) {
        $$(topToolbarCss).findBy(text(tabName)).shouldBe(visible).click();// tabName).click();
    }

    public void clickContextAdd() {
        $(addContextCss).shouldBe(visible).click();
    }

    public void clickProperties() {
        $(propertiesCss).shouldBe(visible).click();
    }

    public void dragContextAndDropArea(String contextName) {
        CustomDriver.getAction().dragAndDrop($$(containerContextToolbarCss)
                        .findBy(text(contextName))
                        .shouldBe(visible),
                $(workAreaCss).shouldBe(visible)).build().perform();
    }

    public void dragWidgetAndDropArea(String widgetName) {
        CustomDriver.getAction().dragAndDrop($$(containerWidgetsToolbarCss)
                        .findBy(text(widgetName))
                        .shouldBe(visible),
                $(workAreaCss).shouldBe(visible)).build().perform();
    }

    public void dragWidgetAndDropForm(String widgetName) {
        CustomDriver.getAction().dragAndDrop($$(containerWidgetsToolbarCss)
                        .findBy(text(widgetName))
                        .shouldBe(visible),
                $(workAreaFormCss).shouldBe(visible)).build().perform();
    }

    public void dragWidgetAndDropPageContent(String widgetName) {
        CustomDriver.getAction().dragAndDrop($$(containerWidgetsToolbarCss)
                        .findBy(text(widgetName))
                        .shouldBe(visible),
                $(workAreaContentCss).shouldBe(visible)).build().perform();
    }

    public void fillCardOfCounter(String counterName) {
        $(inputTextCss)
                .shouldBe(visible)
                .sendKeys(counterName);
        $(inputValueCss)
                .shouldBe(visible)
                .sendKeys("1");
    }

    public void fillCardOfButton(String buttonName) {
        $$(elmaFormRowCss).findBy(text("Надпись / подсказка")).$("input").sendKeys(buttonName);
    }

    public void fillCardOfCounterWithRelation() {
        $(inputValueCss)
                .shouldBe(visible)
                .sendKeys("1");
        $$(buttonStartJoinWithFieldCss).filter(visible).get(1).click();
        $$(buttonJoinWithFieldCss).findBy(text("<Не установлено> ")).click();
        // поиск в менюшке нужной строки и раскрытие списка с выбором нужного пункта. Поиск на 1 уровень
        $$(openContextFieldCss).findBy(text("Контекст")).$("i").click();
        $$(chooseContextCss).findBy(text("Название")).click();
    }

    public void findAndDeleteCounter(String counterName) {
        $$(elmaBadgeCss).findBy(text(counterName)).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void findAndDeleteHtml(String counterName) {
        $$(".template-renderer").findBy(text(counterName)).shouldBe(visible).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void findAndDeleteLine() {
        $(appRowLayoutCss).shouldBe(visible).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void findAndDeleteOneColumn() {
        $(elmaOneColumnCss).shouldBe(visible).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void addWidgetToCounter(String counterName) {
        $$(elmaBadgeCss).filterBy(text(counterName)).get(0).$(buttonAddWidgetCss).click();
    }

    public void addWidgetToLine() {
        $$(appRowLayoutCss).get(0).$(buttonAddWidgetCss).click();
    }

    public void clickPlusOnColumn() {
        $(elmaRowColumnsCss).shouldBe(visible).click();
        $(buttonAddColumnCss).click();
    }

    public int getCountColumnOnWrapper() {
        return $$(appPageWrapperColumnCss).size();
    }

    public void findAndDeleteGraph() {
        $(elmaChartCss).shouldBe(visible).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void findAndDeleteButtonCreate(String buttonName) {
        $$(buttonCreateCss).findBy(text(buttonName)).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void findAndDeleteUploaderFile(String name) {
        $$(uploaderFileCss).findBy(text(name)).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void findAndDeleteViewFile(String name) {
        $$(viewFileCss).findBy(text(name)).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void addWidgetToColumn() {
        $(buttonAddWidgetCss).shouldBe(visible).click();
    }

    public void checkContainsTextInScript(String textScript) {
        $$(lineContextCss).findBy(text(textScript)).shouldBe(exist);
    }

    public void checkSwitchButtonClientServer(String nameButton) {
        $$(switchButtonClientServerCss).findBy(text(nameButton)).shouldBe(exist);
    }

    public void dragContextAndDropModalMainArea(String contextName) {
        CustomDriver.getAction().dragAndDrop($$(containerContextToolbarCss)
                        .findBy(text(contextName))
                        .shouldBe(visible),
                $(workAreaModalMainCss).shouldBe(visible)).build().perform();
    }

    public void dragWidgetAndDropModalMainArea(String widgetName) {
        CustomDriver.getAction().dragAndDrop($$(containerWidgetsToolbarCss)
                        .findBy(text(widgetName))
                        .shouldBe(visible),
                $(workAreaModalMainCss).shouldBe(visible)).build().perform();
    }

    public void clickWidgets() {
        $(widgetsCss).shouldBe(visible).click();
    }

    public void clickButtonIconElementBind() {
        $(buttonIconElementBindXpath).shouldBe(visible).click();
    }

    public void clickButtonIconElementBindHeader() {
        $(buttonIconElementBindHeaderCss).shouldBe(visible).click();
    }

    public void clickButtonNotInstalledAndSelectIndexer() {
        $(buttonNotInstalledCss).shouldBe(visible).click();
        $(applicationElementCss).shouldBe(visible, exist).click();
        $(indexer).shouldBe(visible).click();
    }

    public void inputTextInHeader(String text) {
        $(inputTextInHeader).shouldBe(visible).sendKeys(text);
    }

    public void clickButtonNotInstalledAndSelectValue(String contextName) {
        $(buttonNotInstalledCss).shouldBe(visible).click();
        $$(By.xpath(format(listVariablesInShowWindowFieldCss, contextName))).findBy(text(contextName)).shouldBe(visible).click();
    }

    public void clickAddWidgetInWidget() {
        $(addWidgetInWidgetCss).click();
    }

    public void selectWidget(String nameWidget) {
        $$(listWidgetsCss).findBy(text(nameWidget)).shouldBe(visible).click();
    }

    public void inputTextInTextField(String textWidget) {
        $(inputTextCss).shouldBe(visible).sendKeys(textWidget);
    }

    public void clickButtonDeleteModalWindow() {
        $(buttonDeleteWidget).shouldBe(visible).click();
        $(buttonConfirmDeleteWidget).shouldBe(visible).click();
    }

    public void writeScript(String script, String lineNum) {
        $$(lineNumbersCss).findBy(text(lineNum)).shouldBe(visible).click();
        $(cursorCss).shouldBe(visible).sendKeys(script);
    }

    public void findAndDeleteStandardFormElement(String name) {
        $$(standardFormElementCss).findBy(text(name)).click();
        $(buttonDeleteCss).click();
        $$(buttonDangerCss).findBy(text("Подтвердить удаление")).shouldBe(visible).click();
    }

    public void clickVisibleSaveButton() {
        // TODO: При редактировании формы экземпляра процесса кнопки "сохранить" накладываются,
        //  в результате чего нажимается кнопка сохранения процесса. Было решено сделать workaround-метод.
        // Element <button role="button" class="need-save">...</button> is not clickable at point (109, 54).
        // Other element would receive the click: <button _ngcontent-otk-c991="" type="button" class="need-save">...</button>
        $$(saveToolbarCss).last().shouldBe(visible).click();
    }

    public void openSettingItemContext(String contextName) {
        $$(itemsContextCss).findBy(text(contextName)).shouldBe(visible).click();
    }
}