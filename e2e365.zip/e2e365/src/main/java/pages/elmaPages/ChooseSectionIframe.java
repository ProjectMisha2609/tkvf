package pages.elmaPages;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class ChooseSectionIframe extends BasePage {
    private final By hrSolutionCss = By.cssSelector("a[href*='component'] h4");
    private final By installSectionCss = By.cssSelector("section.container div[class*='bottom'] a[href]");

    public void chooseSectionIframe() {
        CustomDriver.switchToFrame("store");
    }

    public void clickSolutionByName(String nameSolution) {
        ElementsCollection collection = $$(hrSolutionCss)
                .shouldBe(CollectionCondition.sizeGreaterThan(1));
        for (SelenideElement element : collection) {
            if (element.getText().contains(nameSolution)) {
                element.scrollTo()
                        .hover()
                        .click();
                return;
            }
        }
        throw new AssertionError(String.format("Not Found", nameSolution));
    }

    public void clickInstallSection() {
        $(installSectionCss).shouldBe(visible).click();
    }

    public void closeSectionIframe() {
        CustomDriver.switchToDefaultContent();
    }
}
