package pages.elmaPages;

import com.codeborne.selenide.CollectionCondition;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.Actions.DocumentActions;
import pages.BasePages.BasePage;

import java.io.File;
import java.io.FileNotFoundException;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static infrastructure.utils.Constants.TimeWait.SECONDS_1;
import static infrastructure.utils.Constants.TimeWait.SECONDS_40;
import static infrastructure.utils.Loggers.CONSOLE;

/**
 * Страница просмотр 'Файлы'
 */
@Singleton
public class FilePage extends BasePage implements DocumentActions {
    private final By buttonMyFile = By.xpath("//*[text()[contains(.,'Мои файлы')]]");
    private final By buttonsMenuFileXpath = By.xpath("//button[@data-test='createVacancyB']");
    private final By directoryCss = By.cssSelector(".directory__name");
    private final By noteEmptyFolderCss = By.cssSelector(".empty-folder");
    private final By menuHorizontal = By.xpath("//*[contains(text(), 'menu_horizontal')]");
    private final By menuVertical = By.xpath("//*[contains(text(), 'menu_vertical')]");
    private final By menuSystemInfo = By.xpath("//*[contains(text(), 'system_info')]");
    private final By listMyFile = By.cssSelector("[class*='list-item']");
    private final By emailUserCss = By.cssSelector("[class*='cell_email']");
    private final By addButtonCss = By.cssSelector("[class='buttons']>[class*='default']");
    private final By advancedSearchButton = By.cssSelector("[class*='modal-body'] [title='Расширенный поиск']");
    private final By elementButtonInModalWindow = By.cssSelector("[class*='elma-modal'] [class*='primary']");
    private final By plusFileButton = By.cssSelector("[class*='fluid-nav'] [class*='primary']");
    private final By inputNameFile = By.cssSelector("input[class*='pristine ng-invalid']");
    private final By createButtonXpath = By.xpath("//a[contains(text(), 'Создать')]");
    private final By systemCloseButtonXpath = By.xpath("//button[contains(text(), 'system_close')]");
    private final By listTypeFile = By.cssSelector("[class='popover-body']>[class='ctx-menu'] [class*='menu__text']");
    private final By moveToolbarButton = By.xpath("//button[(contains(text(),'folder_type_move'))]");
    private final By listFolders = By.cssSelector("a[class='doc-nav__link'] span[class*='doc-nav__name']");
    private final By moveButtonCss = By.cssSelector("div[class='modal-footer']>button[class*='move']");
    private final By favoriteToolbarButton = By.xpath("//button[(contains(text(),'category_favorite'))]");
    private final By deleteToolbarButton = By.xpath("//button[(contains(text(),'app_trash'))]");
    private final By deleteButtonCss = By.cssSelector("button[elmabutton='danger']");
    private final By buttonCompanyFile = By.xpath("//*[text()[contains(.,'Файлы компании')]]");
    private final By fieldApprovalSheets = By.xpath("//*[contains(text(), 'Листы согласования')]");
    private final By inputSearchByNameFile = By.cssSelector("app-header-part input[placeholder='Поиск по имени файла']");
    private final By checkboxSearchInThisFolder = By.cssSelector("app-header-part p-checkbox div[class*='p-checkbox-box']");
    private final By fileHomeLabel = By.cssSelector("app-disk-search nav a[class*='home-label']");
    private final By listFileAfterSearch = By.cssSelector("app-disk-search app-page-content ul");
    private final By linkDocumentCss = By.cssSelector("li.upload-list__item a");
    private final By downloadButtonInHeaderXpath = By.xpath("//a[contains(text(),'download_sign')]");

    public void clickButtonMyFile() {
        $(buttonMyFile).shouldBe(visible).click();
    }

    public void uploadingPhotos(String filePath) {
        $("[id = 'fileInputForm']>input").sendKeys(new File("").getAbsoluteFile() + filePath);
        CustomDriver.waitMills(3000);
    }

    public void clickMenuHorizontal(String name) {
        $$(listMyFile).findBy(text(name)).hover();
        $$(menuHorizontal).findBy(visible).click();
    }

    public void selectFromMenuHorizontal(String nameMenuItem) {
        $$(By.xpath(String.format("//*[contains(text(), '%s')]", nameMenuItem)))
                .findBy(visible).click();
    }

    public void giveUserRightViewFile(String emailUser) {
        $(addButtonCss).shouldBe(visible).click();
        $(advancedSearchButton).shouldBe(visible).click();
        $$(emailUserCss).findBy(text(emailUser)).shouldBe(visible).click();
    }

    public void clickButtonSave() {
        $$(elementButtonInModalWindow).findBy(text("Сохранить")).shouldBe(visible).click();
    }

    public void clickButtonSelect() {
        $$(elementButtonInModalWindow).findBy(text("Выбрать")).shouldBe(visible).click();
    }

    public void checkMenuVertical() {
        $(menuVertical).shouldBe(visible);
    }

    public void clickByFolderOrPhoto(String nameFolderOrPhoto) {
        $$(listMyFile).findBy(text(nameFolderOrPhoto)).click();
    }

    public void clickMenuSystemInfo() {
        // кнопка может быть активной, но инф не высвечивается
        // нажимать на кнопку Инфо пока не высветиться информация 'Листы согласования'
        int i = 0;
        while (!$(fieldApprovalSheets).is(visible) && i < 5) {
            $(menuSystemInfo).shouldBe(visible).click();
            CustomDriver.waitMills(SECONDS_1);
            i++;
        }
    }

    public void clickMenuSystemInfo(String blockName) {
        // кнопка может быть активной, но инф не высвечивается
        // нажимать на кнопку Инфо пока не высветиться информация
        int i = 0;
        while (!$(By.xpath(String.format("//*[contains(text(), '%s')]", blockName))).is(visible) && i < 5) {
            $(menuSystemInfo).shouldBe(visible).click();
            CustomDriver.waitMills(SECONDS_1);
            i++;
        }
    }

    public void clickCheckBoxByPhoto(String namePhoto) {
        String checkboxPhotos = "//div[(contains(text(),'%s'))]/ancestor::app-disk-file//elma-checkbox";
        $(By.xpath(String.format(checkboxPhotos, namePhoto))).hover().click();
    }

    public void clickButtonMoveAndSelectFolderPhoto(String nameFolder) {
        $(moveToolbarButton).shouldBe(visible).click();
        $$(listFolders).findBy(text(nameFolder)).click();
        $(moveButtonCss).shouldBe(visible).click();
    }

    public void clickButtonFavoritesPhoto() {
        $(favoriteToolbarButton).shouldBe(visible).click();
    }

    public void clickButtonDeletePhoto() {
        $(deleteToolbarButton).shouldBe(visible).click();
        $$(deleteButtonCss).findBy(visible).click();
    }

    public void clickButtonPlusFile() {
        $(plusFileButton).shouldBe(visible).click();
    }

    public boolean isFileNotExists(String fileName) {
        $$(buttonsMenuFileXpath).findBy(text("Папка")).shouldBe(visible);
        return $$(noteEmptyFolderCss).findBy(text("Папка пуста. Добавить")).exists() || !$$(directoryCss).findBy(text(fileName)).exists();
    }

    public void checkFileNotExists(String fileName) {
        $$(buttonsMenuFileXpath).findBy(text("Папка")).shouldBe(visible);
        $$(directoryCss).filterBy(text(fileName))
                .shouldBe(CollectionCondition.empty);
    }

    public void selectFile(String nameFile) {
        $(By.xpath("//*[text()[contains(.,'" + nameFile + "')]]")).shouldBe(visible).click();
    }

    public void clickButtonAddFolder() {
        $$(buttonsMenuFileXpath).findBy(text("Папка")).shouldBe(visible).click();
    }

    public void selectTypeFile(String typeFile) {
        $$(listTypeFile).findBy(text(typeFile)).shouldBe(visible).click();
    }

    public void inputNameFile(String nameFile) {
        $(inputNameFile).shouldBe(visible).sendKeys(nameFile);
    }

    public void clickButtonCreate() {
        $(createButtonXpath).shouldBe(visible).click();
    }

    public void clickButtonSystemClose() {
        $(systemCloseButtonXpath).shouldBe(visible).click();
    }

    public void checkFileVisible(String nameFile) {
        $$(listMyFile).findBy(text(nameFile)).shouldBe(visible);
    }

    public void checkTypeFileVisible(String typeFile) {
        $$(listTypeFile).findBy(text(typeFile)).shouldBe(visible);
    }

    public void clickButtonCompanyFiles() {
        $(buttonCompanyFile).shouldBe(visible).click();
    }

    public void checkIssuingRightsToFile(String userName, boolean condition, String... rights) {
        for (String right : rights) {
            $(By.xpath("//tr[contains(.,'" + userName + "')] //*[@value='" + right + "' and @aria-checked='" + condition + "']/../..")).shouldBe(visible);
        }
    }

    public void inputSearchByNameFileAndClickEnter(String nameFile) {
        $(inputSearchByNameFile).shouldBe(visible).sendKeys(nameFile, Keys.ENTER);
    }

    public void checkboxSearchInThisFolder() {
        $(checkboxSearchInThisFolder).shouldBe(visible).click();
    }

    public void checkFileNotExistInSearchResults(String nameFile) {
        $(fileHomeLabel).shouldBe(visible);
        $$(listFileAfterSearch).filterBy(text(nameFile))
                .shouldBe(CollectionCondition.empty);
    }

    public void checkFileExistInSearchResults(String nameFile) {
        $(fileHomeLabel).shouldBe(visible);
        $$(listFileAfterSearch).findBy(text(nameFile)).shouldBe(exist);
    }

    public void clickLinkDocument(String docName) {
        $$(linkDocumentCss).findBy(text(docName)).shouldBe(visible).click();
    }

    public File downloadGenerationFile() {
        try {
            $(downloadButtonInHeaderXpath).shouldBe(visible);
            return $(downloadButtonInHeaderXpath).shouldBe(visible).download(SECONDS_40);
        } catch (FileNotFoundException e) {
            CONSOLE.error(e.getMessage(), e);
            Assertions.fail(e.getMessage());
            return null;
        }
    }
}