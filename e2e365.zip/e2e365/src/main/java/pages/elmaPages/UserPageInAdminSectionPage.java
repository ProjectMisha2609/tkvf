package pages.elmaPages;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static java.lang.String.format;
import static org.openqa.selenium.By.xpath;
import static org.openqa.selenium.Keys.BACK_SPACE;

/**
 * Перейти в раздел Администрирование - Пользователи
 */
@Singleton
public class UserPageInAdminSectionPage extends BasePage {
    private final By buttonFilterStatusCss = By.cssSelector("[name = '__status.status']");
    private final By statusBlockCss = By.cssSelector("[aria-label *= 'Заблокирован']");
    private final By buttonSearchCss = By.cssSelector("[class = 'footer']>[elmabutton='primary']");
    private final By buttonUnblock = xpath("//*[text()[contains(.,'Разблокировать')]]");
    private final By buttonOkCss = By.cssSelector("[class*='p-dialog-content'] [class*='btn btn-primary']");
    private final By emailUsersCss = By.cssSelector("td[class*='cell_email']>span");
    private final By buttonBlockCss = xpath("//*[text()[contains(.,'Блокировать')]]");
    private final By buttonEditCss = By.cssSelector("[class*='modal-footer']>[class*='btn btn-primary']");
    private final By lastNameCss = By.cssSelector("input[placeholder *= 'Фамилия']");
    private final By firstNameCss = By.cssSelector("input[placeholder *= 'Имя']");
    private final By middleNameCss = By.cssSelector("input[placeholder *= 'Отчество']");
    private final By workPhoneCss = By.cssSelector("[class*='tel'][data-intl-tel-input-id*='0']");
    private final By mobilePhoneCss = By.cssSelector("[class*='tel'][data-intl-tel-input-id*='1']");
    private final By dataBirthdayCss = By.cssSelector("elma-form-row:nth-child(5) input[class*='p-inputtext p-component']");
    private final By employmentDateCss = By.cssSelector("elma-form-row:nth-child(6) input[class*='p-inputtext p-component']");
    private final By positionCss = By.cssSelector("[class*='children-node'] span:last-child");
    private final By inputGroupCss = By.cssSelector("input[role = 'searchbox']");
    private final By chooseTimeZoneCss = By.cssSelector("elma-form-row:nth-child(7) [class='p-dropdown-trigger']");
    private final By buttonSavePhotoCss = By.cssSelector("[class='modal-footer']>[class*='primary']");
    private final By buttonSaveCss = By.cssSelector("[class*='modal-footer'] [type*='submit']");

    private final By editedFIOCss = By.cssSelector("[class*='elma-form-row']:nth-child(1) [class*='appview-field__value']");
    private final By editedEmailCss = By.cssSelector("[class*='elma-form-row']:nth-child(2) [class*='appview-field__value']");
    private final By editedMobilePhoneCss = By.cssSelector("[class*='elma-form-row']:nth-child(3) a");
    private final By editedWorkPhoneCss = By.cssSelector("[class*='elma-form-row']:nth-child(4) a");
    private final By editedBirthdayCss = By.cssSelector("[class*='elma-form-row']:nth-child(5) [class*='appview-field__value']");
    private final By editedDateEmploymentCss = By.cssSelector("[class*='elma-form-row']:nth-child(6) [class*='appview-field__value']");
    private final By editedTimeZoneCss = By.cssSelector("[class*='elma-form-row']:nth-child(7) [class*='appview-field__value']");
    private final By editedPositionCss = By.cssSelector("[class*='elma-form-row']:nth-child(9) [class*='appview-field__value']>span");
    private final By editedGroupsCss = By.cssSelector("[class*='elma-form-row']:nth-child(10) [class*='appview-field__value']>span");

    public void clickButtonFilterStatus() {
        $(buttonFilterStatusCss).shouldBe(visible).click();
    }

    public void clickButtonStatusBlock() {
        $(statusBlockCss).shouldBe(visible).click();
    }

    public void clickButtonSearch() {
        $(buttonSearchCss).shouldBe(visible).click();
    }

    public void clickButtonUnblockAndOk() {
        $(buttonUnblock).shouldBe(visible).click();
        $(buttonOkCss).shouldBe(visible).click();
    }

    public void cLickUserProfile(String email) {
        $$(emailUsersCss).findBy(text(email)).shouldBe(exist).click();
    }

    public void clickButtonBlockAndOk() {
        $(buttonBlockCss).shouldBe(visible).click();
        $(buttonOkCss).shouldBe(visible).click();
    }

    public void clickEditButton() {
        $(buttonEditCss).shouldBe(visible).click();
    }

    public void inputLastName(String lastName) {
        $(lastNameCss).shouldBe(visible).clear();
        $(lastNameCss).sendKeys(lastName);
    }

    public void inputFirstName(String firstName) {
        $(firstNameCss).shouldBe(visible).clear();
        $(firstNameCss).sendKeys(firstName);
    }

    public void inputMiddleName(String middleName) {
        $(middleNameCss).shouldBe(visible).clear();
        $(middleNameCss).sendKeys(middleName);
    }


    public void inputWorkPhone(String phoneNumber) {
        $(workPhoneCss).shouldBe(visible).clear();
        $(workPhoneCss).shouldBe(visible).sendKeys(phoneNumber);
    }

    public void inputMobilePhone(String phoneNumber) {
        $(mobilePhoneCss).shouldBe(visible).clear();
        $(mobilePhoneCss).shouldBe(visible).sendKeys(phoneNumber);
    }


    public void inputDataBirthday(String data) {
        $(dataBirthdayCss).shouldBe(visible).sendKeys(BACK_SPACE);
        $(middleNameCss).shouldBe(visible).click();
        $(dataBirthdayCss).sendKeys(data);
    }

    public void inputEmploymentDate(String data) {
        $(employmentDateCss).shouldBe(visible).sendKeys(BACK_SPACE);
        $(middleNameCss).shouldBe(visible).click();
        $(employmentDateCss).sendKeys(data);
    }

    public void choosePosition() {
        $(positionCss).shouldBe(visible).click();
    }

    public void chooseGroup(String group) {
        $(inputGroupCss).shouldBe(visible).sendKeys(group);
        $(format("[title='%s']", group)).shouldBe(visible).click();
    }


    public void uploadingPhotos(String filePath) {
        $("[data-test='uploadFileI']>input").sendKeys(new File("").getAbsoluteFile() + filePath);
        $(buttonSavePhotoCss).click();
        CustomDriver.waitMills(3000);
    }

    public void changePhoto(String filePath) {
        ElementsCollection avatarDeletionButtons = $$(By.xpath("//elma-image-view/../button"));
        avatarDeletionButtons.last().shouldBe(visible);
        for (SelenideElement e : avatarDeletionButtons) {
            e.click();
        }
        $("[data-test='uploadFileI']>input").sendKeys(new File("").getAbsoluteFile() + filePath);
        $(buttonSavePhotoCss).click();
        $(By.xpath("//elma-image-view/../button")).shouldBe(visible);
    }

    public void clickButtonSave() {
        $(buttonSaveCss).click();
    }

    public boolean checkEditFIO(String fio) {
        return $(editedFIOCss).shouldHave(text(fio)).getText().contains(fio);
    }

    public boolean checkEditEmail(String email) {
        return $(editedEmailCss).shouldHave(text(email)).getText().contains(email);
    }

    public boolean checkEditWorkPhone(String mobilePhone) {
        return $(editedMobilePhoneCss).shouldHave(text(mobilePhone)).getText().contains(mobilePhone);
    }

    public boolean checkEditMobilePhone(String workPhone) {
        return $(editedWorkPhoneCss).shouldHave(text(workPhone)).getText().contains(workPhone);
    }

    public boolean checkEditBirthday(String birthday) {
        return $(editedBirthdayCss).shouldHave(text(birthday)).getText().contains(birthday);
    }

    public boolean checkEditDateEmployment(String dateEmployment) {
        return $(editedDateEmploymentCss).shouldHave(text(dateEmployment)).getText().contains(dateEmployment);
    }

    public boolean checkEditTimeZone(String timeZone) {
        return $(editedTimeZoneCss).shouldHave(text(timeZone)).getText().contains(timeZone);
    }

    public boolean checkEditPosition(String position) {
        return $(editedPositionCss).shouldHave(text(position)).getText().contains(position);
    }

    public boolean checkEditGroups(String group) {
        return $$(editedGroupsCss).findBy(text(group)).exists();
    }

    public boolean isImg(String nameFile) {
        return $(format("[alt*='%s']", nameFile)).shouldBe(visible).exists();
    }

    public void chooseTimeZone(String timeZone) {
        $(chooseTimeZoneCss).shouldBe(visible).click();
        $(xpath(format("//li//*[text()[contains(.,'%s')]]", timeZone))).shouldBe(visible).click();
    }
}