package pages.elmaPages;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Методы для настроек и работы с контрактами
 */
@Singleton
public class ContractPage extends BasePage {
    private final By saveSettingsButtonsCss = By.cssSelector("button.save-settings");
    private final By headerButtonsCss = By.cssSelector("[class*='header'] button");
    private final By footerButtonsCss = By.cssSelector("[config-footer] button");
    private final By contractSourceSelectorButtonCss = By.cssSelector("app-contract-source-selector button");
    private final By appBindingCss = By.cssSelector("app-binding");
    private final By dropDownViewListXpath = By.xpath("//p-dropdown//i[contains(text(),'view_')]");
    private final By dropDownStreamViewListXpath = By.xpath("//p-dropdownitem//i[contains(text(),'view_stream')]");
    private final By dropDownModuleViewListXpath = By.xpath("//p-dropdownitem//i[contains(text(),'view_module')]");
    private final By settingTableContractButtonCss = By.cssSelector("app-page-header button[title=\"Настройка действий и списка\"]");
    private final By menuOptionCss = By.cssSelector("elma-popover-menu-option");
    private final By columnTableCss = By.cssSelector(".p-datatable-wrapper .field-name");
    private final By appContractApplicationOptionsSettingsCss = By.cssSelector("app-contract-application-options-settings");

    public void clickSaveSettingButton() {
        $(saveSettingsButtonsCss).shouldBe(visible).click();
    }

    public void clickHeaderButton(String name) {
        $$(headerButtonsCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void clickFooterButton(String name) {
        $$(footerButtonsCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void clickSourceSelectorButton() {
        $(contractSourceSelectorButtonCss).shouldBe(visible).click();
    }

    public void selectSourceApp(String sectionName, String applicationName) {
        By checkAppXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]//span[contains(@class, 'collapsed') or contains(@class,'expanded')]"
                , sectionName));
        $(checkAppXpath).shouldBe(visible);

        By expandButtonXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]//span[contains(@class, 'collapsed')]"
                , sectionName));
        if ($(expandButtonXpath).is(exist)) {
            $(expandButtonXpath).click();
        }
        By applicationToClickXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]/../..//span[text()='%s']"
                , sectionName, applicationName));
        $(applicationToClickXpath).click();
    }

    public void checkAppBindingOnListExists(String contractName) {
        $$(appBindingCss).findBy(text(contractName)).shouldBe(visible);
    }

    public void setViewStreamOnList() {
        $(dropDownViewListXpath).shouldBe(visible).click();
        $(dropDownStreamViewListXpath).shouldBe(visible).click();
    }

    public void setViewModuleOnList() {
        $(dropDownViewListXpath).shouldBe(visible).click();
        $(dropDownModuleViewListXpath).shouldBe(visible).click();
    }

    public void clickSettingTableContractButton(String name) {
        $(settingTableContractButtonCss).shouldBe(visible).click();
        $$(menuOptionCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void addPropertyForTable(String propertyName) {
        if ($$(By.cssSelector(".pull-field span")).findBy(text(propertyName)).is(exist))
            $(By.xpath("//span[contains(@class,'field-name') and contains(text(),'" + propertyName + "')]/../button[contains(text(),'plus')]")).shouldBe(visible).click();
    }

    public void checkColumnTableExists(String columnName) {
        $$(columnTableCss).findBy(text(columnName)).shouldBe(visible);
    }


    public void chooseParameterRadioButton(String rowName, String buttonName) {
        $$(By.xpath("//app-app-update-settings//elma-form-row[contains(.,'" + rowName + "')]//p-radiobutton")).findBy(text(buttonName)).shouldBe(visible).click();
    }

    @Deprecated // инпут формы заполняется методом базовой страницы по имени строки формы.
    public void setParameterSingleInput(String rowName, String inputText) {
        $(By.xpath("//app-dynamic-form//elma-form-row[contains(.,'" + rowName + "')]//input")).shouldBe(visible).sendKeys(inputText);
    }

    public void checkSourceAppExists(String sectionName, String applicationName) {
        By checkXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]//span[contains(@class, 'collapsed') or contains(@class,'expanded')]"
                , sectionName));
        $(checkXpath).shouldBe(visible);

        By expandButtonXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]//span[contains(@class, 'collapsed')]"
                , sectionName));
        if ($(expandButtonXpath).is(exist)) {
            $(expandButtonXpath).click();
        }
        By applicationToClickXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]/../..//span[text()='%s']"
                , sectionName, applicationName));
        $(applicationToClickXpath).shouldBe(visible);
    }

    public void checkTextAboutNotAppSource() {
        $(appContractApplicationOptionsSettingsCss).shouldHave(text("Нет источников для контракта"));
    }

}
