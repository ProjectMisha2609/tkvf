package pages.elmaPages;

import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class MainPage extends BasePage {
    private final By createSectionId = By.cssSelector("[title='Добавить Раздел']");
    private final By fastCreateSectionId = By.cssSelector("[data-test='createSectionB']");
    private final By uploadSectionButton = By.cssSelector("div[class*='modal-body'] a[elmabutton*='link']");
    private final By leftToolbarCss = By.cssSelector("div[class*='navigation-pagination_content']");
    private final By downloadSectionId = By.cssSelector("[data-test=mainPageDownloadSectionB]");
    private final By createCss = By.cssSelector("app-gagarin [class*=size-lg]");
    private final By createMenuOptionsContainerCss = By.cssSelector("[class*=popover-content]:not(.hide)");
    private final By createMenuSingleOptionCss = By.cssSelector("[class*=ctx-menu__text]");
    private final By toastId = By.cssSelector("[id=toast-container] [class*=toast-title]");
    private final By popoverAppContainerCss = By.cssSelector("body div.visible ~ div");
    private final By pageSettingsCss = By.cssSelector("[class*=custom-page-options]");
    private final By sectionSettingsOptionsBodyCss = By.cssSelector("[class*=popover_left]>[class*=popover-content]");
    private final By sectionSettingsSingleOptionCss = By.cssSelector("[class*=ctx-menu__text]");
    private final By twoPageClassCss = By.cssSelector("[class*='@two-cols']");
    private final By currentUserNameCss = By.cssSelector("div[class*='user__name_wrapper']");
    private final By logoutXpath = By.xpath("//span[text()='Выйти']");
    private final By logoutConfirmation = By.xpath("//elma-confirm//button[text()='ОК']");
    private final By addUsersButton = By.xpath("//i[contains(text(),'user_plus')]");
    private final By inviteSuccessfullyCreatedToastCss = By.cssSelector("div[aria-label='Приглашение успешно создано']");
    private final By appPageWrapperCss = By.cssSelector("app-page-wrapper");
    private final By appPageWrapperTagLineCss = By.cssSelector("app-page-wrapper app-row-layout");
    private final By appPageWrapperColumnCss = By.cssSelector("app-page-wrapper elma-column");
    private final By userWidgetCss = By.cssSelector("[class*='user-widget']");
    private final By settingsButton = By.xpath("//span[contains(text(),'Настройки')]");
    private final By buttonCreateOnPage = By.cssSelector("app-page-wrapper app-gagarin button");
    private final By selectUserCss = By.cssSelector("[class='quick-list-container'] [class*='cell_email ng-star-inserted']");
    private final By ButtonsOnAppContentCss = By.cssSelector(".app-content button");
    private final By rowsTabXpath = By.xpath("//tr");
    private final By headerButtonsXpath = By.xpath("//*[@class='header-buttons']/*");
    private final By selectNameCss = By.cssSelector("[class='quick-list-container'] [class*='cell___name ng-star-inserted']");
    private final By elmaFormButtonsXpath = By.xpath("//elma-form//button");
    private final By elmaFormLinkXpath = By.xpath("//elma-form//a");


    public void isUserAdded() {
        $(inviteSuccessfullyCreatedToastCss).shouldBe(visible);
    }

    public void clickCreateSection() {
        $(createSectionId).shouldBe(visible).click();
        $(fastCreateSectionId).shouldBe(visible).click();
    }

    public void clickUploadSection() {
        $(createSectionId).shouldBe(visible).click();
        $(uploadSectionButton).shouldBe(visible).click();
    }

    public void clickDownloadExistingSection() {
        $(downloadSectionId).shouldBe(visible).click();
    }

    public void selectFromCreateMenu(String optionText) {
        $(createCss).shouldBe(visible).click();
        $(createMenuOptionsContainerCss).shouldBe(visible)
                .$$(createMenuSingleOptionCss).findBy(text(optionText)).shouldBe(visible).click();
    }

    public void clickCreate() {
        $(createCss).shouldBe(visible).click();
    }

    public void moveCursorOnSections(String optionText) {
        SelenideElement element = $(createMenuOptionsContainerCss).shouldBe(visible)
                .$$(createMenuSingleOptionCss).findBy(text(optionText)).shouldBe(visible);
        CustomDriver.getAction().moveToElement(element).build().perform();
    }

    public void isAddSectionButtonExists() {
        $(leftToolbarCss).shouldNotBe(visible);
    }

    public void checkToastAppeared() {
        $(toastId).shouldBe(visible);
    }

    public void clickApp(String name) {
        $(popoverAppContainerCss).shouldBe(visible, Duration.ofSeconds(30))
                .$$(createMenuSingleOptionCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void selectPageSettings(String optionText) {
        $(pageSettingsCss).shouldBe(visible).click();
        $(sectionSettingsOptionsBodyCss).shouldBe(visible)
                .$$(sectionSettingsSingleOptionCss).findBy(text(optionText)).click();
    }

    public void logout() {
        $(currentUserNameCss).shouldBe(visible).click();
        $(logoutXpath).shouldBe(visible).click();
        $(logoutConfirmation).shouldBe(visible).click();
    }

    public void clickAddNewUser() {
        $(addUsersButton).shouldBe(visible).click();
    }

    public void checkPageSetToTwoColumn() {
        $(twoPageClassCss).shouldBe(visible);
    }

    public void checkPageSetToOneColumn() {
        $(twoPageClassCss).shouldBe(not(exist));
    }

    public void clickUserWidget() {
        $(userWidgetCss).shouldBe(visible).click();
    }

    public void clickSettingProfUser() {
        $(settingsButton).shouldBe(visible).click();
    }

    public boolean checkHelpButton(String expectedUrl) {
        return $(String.format("[href*= '%s']", expectedUrl)).shouldHave(visible).exists();
    }

    public void checkScriptRun(String pageName, String widgetName, String scriptResult) {
        $$(buttonCreateOnPage).findBy(text(widgetName)).shouldBe(exist).hover();
        SelenideElement element = $("elma-type-string").shouldBe(visible);
        element.hover();
        element.$("span").shouldBe(text(scriptResult));
    }

    public void clickSelectUser(String email) {
        $$(selectUserCss).findBy(text(email)).shouldBe(visible).click();
    }

    public void clickButtonOnAppContent(String buttonName) {
        $$(ButtonsOnAppContentCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void switchOffRightsForUserGroup(String rowName) {
        By checkBoxItemXpath = By.xpath("//tr[contains(.,'" + rowName + "')] //td //*[contains(@class,'p-checkbox-checked')]");
        while ($(checkBoxItemXpath).exists()) {
            $(checkBoxItemXpath).shouldBe(visible).click();
        }
    }

    public void clickHeaderButton(String buttonName) {
        $$(headerButtonsXpath).findBy(text(buttonName)).shouldBe(visible).hover().click();
    }

    public void clickItemMenu(String name) {
        $$(createMenuSingleOptionCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void checkButtonOnAppContentNotExist(String buttonName) {
        $$(ButtonsOnAppContentCss).findBy(text(buttonName)).shouldNot(exist);
    }

    public void checkButtonOnAppContentExist(String buttonName) {
        $$(ButtonsOnAppContentCss).findBy(text(buttonName)).shouldBe(exist);
    }

    public void clickSelectName(String email) {
        $$(selectNameCss).findBy(text(email)).shouldBe(visible).click();
    }

    public void clickOnNameButtonElmaForm(String buttonName) {
        $$(elmaFormButtonsXpath).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void clickOnNameLinkElmaForm(String linkName) {
        $$(elmaFormLinkXpath).findBy(text(linkName)).shouldBe(visible).click();
    }
}