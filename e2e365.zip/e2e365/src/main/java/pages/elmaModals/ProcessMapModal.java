package pages.elmaModals;

import com.codeborne.selenide.CollectionCondition;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class ProcessMapModal extends BasePage {
    //region Selectors
    /**
     * BPMN элемент на карте процесса
     */
    private final By mapBpmnElement = By.cssSelector("[data-drag-container=\"true\"]");
    //endregion

    /**
     * Проверка карты процесса. Проверяет отображение нужного количества BPMN элементов на карте процесса.
     *
     * @param bpmnElements Необходимое количество элементов BPMN на карте процесса;
     */
    public void checkProcessMap(Integer bpmnElements) {
        $$(mapBpmnElement).last().shouldBe(visible);
        $$(mapBpmnElement).shouldHave(CollectionCondition.size(bpmnElements + 1));
    }
}
