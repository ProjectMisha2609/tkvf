package pages.elmaModals;

import infrastructure.elmaBackend.ElmaBackend;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.CollectionCondition.size;
import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class CreateTaskModal extends BasePage {

    @Inject
    protected ElmaBackend elmaBackend;

    private final By subjectCss = By.cssSelector("elma-form input[id='__name']");
    private final By createTaskCss = By.cssSelector("elma-form button[type='submit']");
    private final By extendSearchCss = By.cssSelector("app-user-select button");
    private final By quickExtendSearchCss = By.cssSelector("div[role='dialog'] [class*='quick-list-search'] input");
    private final By foundedExecutorCss = By.cssSelector("[class*='modal-body'] tbody td:nth-child(2)");
    private final By containerTaskModalCss = By.cssSelector("section");
    private final By controlChoiceElementsCss = By.cssSelector("elma-icon-label-option span");
    private final By controlChoiceMenuCss = By.cssSelector("ul[class*='p-dropdown-items']");
    private final By createdTaskConfirmDoneCss = By.cssSelector("div[class*='popover-footer'] button[type='submit']");
    private final By doneTaskStatusCss = By.cssSelector("div[class*='list-status'] span");
    private final By threePointsCss = By.cssSelector("elma-button-template");
    private final By threePointsMenuCss = By.cssSelector("div[class='ctx-menu']");
    private final By threePointsOptionsCss = By.cssSelector("elma-popover-menu-option");
    private final By submitReassignCss = By.cssSelector("div[class*='popover-footer'] button[type='submit']");
    private final By reassignedExecutorCss = By.cssSelector("app-bpm-task-system-executor-widget span");
    private final By successMessageCss = By.cssSelector("elma-top-center-error[class*='toast-success']");
    private final By userDropdownItem = By.xpath("//li[@role='option']//app-user-name");

    public void fillSubject(String subjectText) {
        $(containerTaskModalCss).$(subjectCss).shouldBe(visible).sendKeys(subjectText);
    }

    public void clickExtendSearch() {
        $(extendSearchCss).shouldBe(visible).hover();
        $(extendSearchCss).click();
    }

    public void fillEmailExecutor() {
        $(quickExtendSearchCss).shouldBe(visible).sendKeys(config.adminLogin);
//        waitLoadServices();
    }

    public void clickFoundedExecutor() {
        $$(foundedExecutorCss).shouldBe(size(1));
        $(foundedExecutorCss).shouldBe(visible).click();
    }

    public void clickControlChoice() {
        $(controlChoiceElementsCss).shouldBe(visible).click();
    }

    public void chooseControlType(String controlType) {
        $(controlChoiceMenuCss).shouldBe(visible)
                .$$(controlChoiceElementsCss).findBy(text(controlType)).shouldBe(visible).click();
    }

    public void clickConfirmDone() {
        $(createdTaskConfirmDoneCss).shouldBe(visible).click();
        $(successMessageCss).shouldBe(visible);
    }

    public void clickThreePointsOption(String option) {
        $(threePointsCss).shouldBe(visible).click();
        $(threePointsMenuCss).$$(threePointsOptionsCss).findBy(text(option)).shouldBe(visible).click();
    }

    public void fillReassignExecutor() {
        $(quickExtendSearchCss).shouldBe(visible).sendKeys(config.userLogin);
//        waitLoadServices();
    }

    public void clickSubmitReassign() {
        $(submitReassignCss).shouldBe(visible).click();
        $(successMessageCss).shouldBe(visible);
    }

    public void checkReassignedExecutorEmailCorrect() {
        $(reassignedExecutorCss).shouldBe(visible).shouldHave(text(
                elmaBackend.getUserSurnameAndNameByEmail(config.userLogin)));
    }

    public void checkStatusTaskIsDone() {
        $(doneTaskStatusCss).shouldBe(visible).shouldHave(text("ВЫПОЛНЕНА"));
    }

    public void fillUserContextVariable(String name, String text) {
        $(By.xpath(String.format("//span[contains(text(),'%s')]/../..//input", name)))
                .shouldBe(visible).sendKeys(text);
        $$(userDropdownItem).findBy(text(text)).shouldBe(visible).click();
    }
}
