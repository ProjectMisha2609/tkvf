package pages.elmaModals;

import infrastructure.drivers.CustomDriver;
import infrastructure.utils.Constants;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;
import java.util.Locale;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class ExportModal extends BasePage {
    private final By textareaCss = By.cssSelector("textarea");
    private final By downloadLinkCss = By.cssSelector("a[elmaexternallink*='file']");

    public void clickLinkLoadFile() {
        $(downloadLinkCss).shouldBe(visible).click();
    }

    public void exportSectionInFile(String sectionDescription) {
        $(textareaCss).shouldBe(visible).sendKeys(sectionDescription);
    }

    public void checkFileExported(String... exportName) {
        String fileName = String.format(String.join(".", exportName) + ".e365").toLowerCase(Locale.ROOT);
        File file = new File(Constants.PATH_TO_DOWNLOADS_DIR, fileName.toLowerCase(Locale.ROOT));
        for (int i = 0; i < 30; i++) {
            if (!file.exists()) CustomDriver.waitMills(1000);
        }
        Assertions.assertTrue(file.exists(), "File not found");
        Assertions.assertTrue(file.delete(), "Не удалось удалить экспортированный файл");
    }
}
