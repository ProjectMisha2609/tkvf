package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class NotificationSettingsModal extends BasePage {
    private final By themeInputXpath = By.xpath("//span[contains(text(),'Тема сообщения')]/../..//input");
    private final By messageInputXpath = By.xpath("//span[contains(text(),'Текст сообщения')]/../..//textarea");

    public void fillNotificationTheme(String text) {
        $(themeInputXpath).shouldBe(visible).sendKeys(text);
    }

    public void fillNotificationMessage(String text) {
        $(messageInputXpath).shouldBe(visible).sendKeys(text);
    }

    public void setNotificationAuthor(String text) {
        $(By.xpath(String.format("//span[contains(text(),'Автор')]/../.." +
                "//label[contains(text(),'%s')]/.." +
                "//div[contains(@class,'p-radiobutton-box')]", text))).shouldBe(visible).click();
    }
}
