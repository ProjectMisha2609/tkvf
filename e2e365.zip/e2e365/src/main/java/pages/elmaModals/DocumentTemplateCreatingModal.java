package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import java.io.File;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class DocumentTemplateCreatingModal extends BasePage {
    private final By nameCss = By.cssSelector("[formcontrolname=name]");
    private final By fileCss = By.cssSelector("[data-test=uploadFileI] input");
    private final By fileUploadInputButtonCss = By.cssSelector(".inputButton input[type='file']");
    private final By tabContentPatternCss = By.cssSelector("[class*='content'] app-doctemplate-set-variables elma-form-row");
    private final By fileLoadingBarCss = By.cssSelector(".file-loading__bar");
    private final By fillVariablesCss = By.cssSelector("app-doctemplate-set-variables p-dropdown");
    private final By stringVariableTypeCss = By.cssSelector("p-dropdownitem li[aria-label*='Строка']");
    private final By notificationTextCss = By.cssSelector("elma-notification-popup div[class*='content']");
    private final By fileZoomCss = By.cssSelector("elma-file-zoom");
    private final By itemTreeLabelCss = By.cssSelector(".elma-tree-label");

    public void fillName(String name) {
        $(nameCss).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, name);
    }

    public void uploadFile(String path) {
        $(fileCss).uploadFile(new File(path));
        $(tabContentPatternCss).shouldBe(visible);
    }

    /**
     * Заполнение типа переменных для полей, их всегда 3
     */
    public void templateFillVariables() {
        $(fillVariablesCss).shouldBe(visible);
        for (SelenideElement variable : $$(fillVariablesCss)) {
            variable.click();
            $(stringVariableTypeCss).shouldBe(visible).click();
        }
    }

    /**
     * Проверяет что при замене документа появилось окошко с текстом, что изменилось
     */
    public void checkFileModified() {
        $(notificationTextCss).shouldBe(visible).shouldHave(text("Добавлено: 1"));
        $(notificationTextCss).shouldBe(visible).shouldHave(text("Удалено: 1"));
    }

    public void uploadFileWidget(String filePath) {
        $(fileUploadInputButtonCss).shouldBe(exist).uploadFile(new File(filePath).getAbsoluteFile());
        try {
            $(fileLoadingBarCss).should(appear).should(disappear);
        } catch (com.codeborne.selenide.ex.ElementNotFound ignore) {
            // В случае, если фото загрузилось мгновенно и прогрессбар не отрисовался - ошибку игнорим.
        }
    }

    public void checkFileZoomBarExists() {
        $(fileZoomCss).shouldBe(visible);
    }

    public void chooseDocumentTemplateOnList(String nameDoc, String... paths) {
        $(By.cssSelector(".p-treenode-label .expand-status")).shouldBe(visible);
        for (String path : paths) {

            if ($(By.xpath("//span[@class='elma-tree-label' and contains(text(),'" + path + "')]/../..//span[contains(@class,'expand-status')]")).is(cssClass("collapsed")))
                $(By.xpath("//span[@class='elma-tree-label' and contains(text(),'" + path + "')]/../..//span[contains(@class,'expand-status')]")).shouldBe(visible).click();
        }
        $$(itemTreeLabelCss).findBy(text(nameDoc)).shouldBe(visible).click();
    }

    public void checkGenerationFileName(String rowName, String fileName) {
        $(By.xpath("//elma-form-row[contains(.,'" + rowName + "')]//input")).shouldBe(visible).shouldHave(value(fileName));
    }
}
