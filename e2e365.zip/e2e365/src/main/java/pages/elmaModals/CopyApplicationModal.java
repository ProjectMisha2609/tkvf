package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class CopyApplicationModal extends BasePage {
    private final By primaryBtnCss = By.cssSelector("[class*='modal-footer'] button.btn.btn-primary");
    private final By checkApplicationModalCss = By.cssSelector("[class*=modal-body] ul");
    private final By settingsNewAppModalCss = By.cssSelector("form[novalidate] elma-form-row:first-child");
    private final By selectTargetSectionCss = By.cssSelector("p-dropdown elma-icon-label-option > span");
    private final By sectionContainerCss = By.cssSelector("p-dropdownitem elma-icon-label-option span");
    private final By headerModalCss = By.cssSelector("p-header [class*='dialog-heading'] span");

    public void clickNextStepOnCheckApplicationModal() {
        $(checkApplicationModalCss).shouldBe(visible);
        $(primaryBtnCss).shouldBe(visible, enabled).click();
    }

    public void selectTargetSection(String sectionName) {
        $(selectTargetSectionCss).shouldBe(visible).click();
        $$(sectionContainerCss).findBy(exactText(sectionName)).click();
    }

    public void clickNextStepOnSettingsNewAppModal() {
        $(settingsNewAppModalCss).shouldBe(visible);
        $(primaryBtnCss).shouldBe(visible).click();
    }

    public void clickGoToApplication() {
        $(headerModalCss)
                .should(text("Копирование Приложения успешно завершено"), Duration.ofSeconds(30))
                .shouldBe(visible);
        $(primaryBtnCss).shouldBe(visible).click();
    }
}
