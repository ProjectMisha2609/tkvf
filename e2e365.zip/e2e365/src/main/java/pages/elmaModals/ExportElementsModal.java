package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.utils.Constants;
import infrastructure.utils.Loggers;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static infrastructure.elmaBackend.BackendUser.adminLogin;

@Singleton
public class ExportElementsModal extends BasePage {

    @Inject
    protected ElmaBackend elmaBackend;

    private final By exportSystemInfoCheckboxCss = By.cssSelector("elma-form-row[class*='system-info-fields'] span[class*='checkbox']");
    private final By exportWithFilterCheckboxCss = By.cssSelector("elma-form-row.elma-form-row:nth-child(3) elma-checkbox:first-child");
    private final By downloadLinkCss = By.cssSelector("div[class*='modal-body'] button[elmabutton='link']");

    public void exportSystemInfoCheckboxClick() {
        SelenideElement element = $(exportSystemInfoCheckboxCss);
        element.click();
        element.shouldBe(visible);
    }

    public void exportWithFilterCheckboxClick() {
        SelenideElement element = $(exportWithFilterCheckboxCss);
        element.click();
        element.shouldBe(visible);
    }

    public void downloadLinkClick() {
        $(downloadLinkCss).shouldBe(visible).click();
    }

    public String parseExcelFile(String elementName) {
        String fileName = elementName + ".xlsx";
        File excelFile = new File(Constants.PATH_TO_DOWNLOADS_DIR, fileName.toLowerCase(Locale.ROOT));
        for (int i = 0; i < 30; i++) {
            if (!excelFile.exists()) CustomDriver.waitMills(1000); // ничего умнее не придумал, но работает.
        }
        StringBuilder elementsExport = new StringBuilder();
        try {
            FileInputStream fileInputStream = new FileInputStream(excelFile);
            XSSFWorkbook workbook = new XSSFWorkbook(fileInputStream);
            XSSFSheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();
            iterator.next();
            while (iterator.hasNext()) {
                Row currentRow = iterator.next();
                for (Cell currentCell : currentRow) {
                    elementsExport.append(" ").append(currentCell.toString());
                }
            }
            workbook.close();
            fileInputStream.close();
            if (!excelFile.delete()) Loggers.CONSOLE.warn("Can't remove file");
            return elementsExport.toString();
        } catch (FileNotFoundException e) {
            Loggers.CONSOLE.warn("Export file not Found in dir");
            Assertions.fail("Export file not Found in dir");
            return null;
        } catch (IOException e) {
            Loggers.CONSOLE.warn("Can't parse file");
            Assertions.fail("Can't parse file");
            return null;
        }
    }

    public void checkAllFieldsEquals(String appName, String elementId, String elementName) {
        String fullString = parseExcelFile(appName);
        String authorId = elmaBackend.getUserIdByEmail(adminLogin);
        Assertions.assertAll(
                () -> Assertions.assertTrue(fullString.contains(elementId), "Не найден идентификатор элемента"),
                () -> Assertions.assertTrue(fullString.contains(authorId), "Не найден идентификатор автора элемента"),
                () -> Assertions.assertTrue(fullString.contains(elementName), "Не найдено имя элемента"));
    }
}
