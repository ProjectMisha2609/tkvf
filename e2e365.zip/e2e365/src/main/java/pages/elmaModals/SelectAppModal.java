package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.disappear;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SelectAppModal extends BasePage {

    /**
     * Все разделы доступные в выборе приложения
     */
    private final By allSectionCss = By.cssSelector("app-select-app p-treenode");

    /**
     * Стрелка развернуть раздел для просмотра приложений внутри его
     */
    public final By arrowOpenSectionCss = By.cssSelector("span.expand-status i");

    /**
     * Разворачивает раздел, чтобы посмотреть его приложения
     *
     * @param sectionName Секция приложения;
     */
    public void clickSectionInModal(String sectionName) {
        $("div[aria-label='" + sectionName + "'] span.expand-status i").shouldBe(visible).click();
    }

    /**
     * Кликает на приложение с нужным именем
     *
     * @param appName Имя приложения на которое кликать;
     */
    public void clickAppInModal(String appName) {
        SelenideElement element = $("div[aria-label='" + appName + "']").shouldBe(visible);
        element.click();
        element.shouldBe(disappear);
    }
}
