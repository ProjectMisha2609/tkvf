package pages.elmaModals;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import com.codeborne.selenide.ex.ElementShould;
import infrastructure.utils.Constants;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

import static com.codeborne.selenide.CollectionCondition.size;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class ProcessInstanceModal extends BasePage {
    //region Selectors
    //region Общие
    /**
     * Стандартная синяя кнопка в нижней части формы
     */
    private final By buttonPrimary = By.cssSelector(".btn.btn-primary");
    /**
     * Стандартная прозрачная кнопка в нижней части формы
     */
    private final By buttonDefault = By.cssSelector(".btn.btn-default");
    /**
     * Кнопка "Прервать процесс" на карточке экземпляра процесса
     */
    private final By buttonInterruptProcess = By.cssSelector(".modal-footer .btn-danger");
    /**
     * Поле для комментария в поповере прерывания процесса
     */
    private final By popoverInputComment = By.cssSelector(".popover-content:not(.hide) textarea");
    /**
     * Кнопка "Прервать процесс" в поповере прерывания процесса
     */
    private final By popoverButtonInterruptProcess = By.cssSelector("[type=\"submit\"].btn-danger");
    /**
     * Кнопка "Сохранить" в поповере
     */
    private final By popoverButtonPrimary = By.cssSelector("[type=\"submit\"].btn-primary");
    /**
     * Попап карточки экземпляра процесса
     */
    private final By popupProcessInstance = By.cssSelector("elma-complex-popup .complex-popup");
    /**
     * Кнопка-ссылка на странице
     */
    private final By buttonLink = By.cssSelector(".btn.btn-link");
    /**
     * Действие в поповере
     */
    private final By popoverMenuOption = By.cssSelector("elma-popover-menu-option.ctx-menu__item");
    /**
     * Вкладка на карточке экземпляра процесса ("История" / "Контекст" / "Карта процесса")
     */
    private final By tab = By.cssSelector("[role=\"tab\"]");
    /**
     * Кнопка в поповере (любая)
     */
    private final By popoverButton = By.cssSelector(".popover-content button");
    //endregion
    //region Боковая панель
    /**
     * Строка ввода сообщения на карточке экземпляра процесса
     */
    private final By inputMessage = By.cssSelector("elma-complex-popup [data-placeholder=\"Сообщение\"]");
    /**
     * Инпут для вложения при создании нового сообщения
     */
    private final By inputAttachment = By.cssSelector(".new-message input[type=\"file\"][capture=\"environment\"]");
    /**
     * Текстовое поле для сообщения при добавлении вложения
     */
    private final By inputAttachmentComment = By.cssSelector("[data-placeholder=\"Ваш комментарий\"]");
    /**
     * Вложение в ленте на карточке экземпляра процесса
     */
    private final By feedMessageAttachment = By.cssSelector("app-object-message app-file-list");
    /**
     * Текст сообщения в ленте на карточке экземпляра процесса
     */
    private final By feedMessageInner = By.cssSelector("elma-complex-popup .message__inner");
    /**
     * Свойства экземпляра процесса в боковой панели
     */
    private final By processInstanceProperty = By.cssSelector(".sidebar-widget-body elma-form-row");
    //endregion
    //region Вкладка "История"
    /**
     * Таблица на вкладке история в карточке экземпляра процесса
     */
    private final By tableProcessInstanceHistory = By.cssSelector(".task__history");
    /**
     * Строка таблицы на вкладке история в карточке экземпляра процесса
     */
    private final By rowProcessInstanceHistory = By.cssSelector(".task__history tbody tr");
    /**
     * Отдельная ячейка со значением в таблице истории
     */
    private final By cellProcessInstanceHistory = By.cssSelector("app-task-history-item tbody tr td");
    /**
     * Сообщение об успешном перезапуске шага
     */
    private final By messageAboutReRun = By.cssSelector("div[aria-label='Шаг перезапущен']");
    /**
     * Переключатель для таблицы задач в истории ("Текущие" / "Все")
     */
    private final By switchProcessInstanceHistory = By.cssSelector("elma-switch .ui-button");
    //endregion
    //region Вкладка "Контекст"
    /**
     * Строка со значением контекстной переменной на вкладке "Контекст"
     */
    private final By contextRow = By.cssSelector("app-dynamic-form-row");
    //endregion
    //region Вкладка "Карта процесса"
    /**
     * BPMN элемент на карте процесса
     */
    private final By mapBpmnElement = By.cssSelector("[data-drag-container=\"true\"]");
    /**
     * подсвеченный BPMN элемент на карте процесса (без стрелок)
     */
    private final By mapBpmnHighlightedBlock = By.cssSelector("#highlight-elements rect[stroke=\"#0003ff\"]");
    /**
     * текущий BPMN элемент на карте процесса (подсвечен зеленым)
     */
    private final By mapBpmnCurrentBlock = By.cssSelector("#highlight-elements rect[stroke=\"#14b500\"]");
    private final By allTasksButtonXpath = By.xpath("//p-selectbutton//span[contains(text(),'Все')]");
    private final By activeTasksButtonXpath = By.xpath("//p-selectbutton//span[contains(text(),'Текущие')]");
    private final By messageAboutVersionUpdateCss = By.cssSelector("div[aria-label='Версия обновлена успешно']");
    private final By workAreaContextInMapCss = By.cssSelector("#content g[data-drag-container='true']");
    //endregion

    //endregion

    //region Общие

    /**
     * Открыть указанную вкладку на карточке экземпляра процесса.
     *
     * @param tabName Название вкладки
     */
    public void selectTab(String tabName) {
        $$(tab).findBy(text(tabName)).shouldBe(visible).click();
    }

    /**
     * Нажать на кнопку "Прервать процесс".
     */
    public void interruptProcess() {
        $(buttonInterruptProcess).shouldBe(visible).click();
        $(popoverInputComment).shouldBe(visible).setValue("INTERRUPT PROCESS TEST");
        $(popoverButtonInterruptProcess).shouldBe(visible).click();
        $(popupProcessInstance).should(disappear);
    }

    /**
     * Нажать кнопку "Обновление версии" на карточке экземпляра процесса.
     */
    public void updateVersion() {
        $$(buttonPrimary).findBy(text("Обновление версии")).shouldBe(visible).click();
        $(messageAboutVersionUpdateCss).shouldBe(visible);
    }

    /**
     * Закрыть попап карточки экземпляра процесса.
     */
    public void close() {
        $$(buttonLink).findBy(text(" system_close ")).shouldBe(visible).click();
    }
    //endregion
    //region Боковая панель (свойства экземпляра процесса и лента)

    /**
     * Отправляет сообщение в ленту в окне экземпляра процесса.
     *
     * @param message Текст отправляемого сообщения
     */
    public void sendMessage(String message) {
        $(inputMessage).shouldBe(visible).sendKeys(message + "\n");
    }

    /**
     * Отправляет сообщение с вложением в ленту в окне экземпляра процесса.
     *
     * @param message    Текст отправляемого сообщения
     * @param attachment Имя файла содержащегося в папке "testData"
     */
    public void sendMessage(String message, String attachment) {
        $(inputAttachment).shouldBe(exist).uploadFile(new File(Paths.get(Constants.PATH_TO_DEFAULT_DIR,
                "testData",
                attachment).toString()));
        $(inputAttachmentComment).shouldBe(visible).sendKeys(message);
        $$(buttonPrimary).findBy(text("Загрузить")).shouldBe(visible).click();
    }

    /**
     * Проверяет наличие сообщения в ленте в окне экземпляра процесса.
     *
     * @param message Текст сообщения
     */
    public void checkMessageExists(String message) {
        $(feedMessageInner).shouldBe(visible).shouldHave(text(message));
    }

    /**
     * Проверяет наличие вложения в ленте в окне экземпляра процесса.
     *
     * @param attachment Имя файла
     */
    public void checkAttachmentExists(String attachment) {
        $(feedMessageAttachment).shouldBe(visible).shouldHave(text(attachment));
    }

    /**
     * Проверить, присутствует ли указанное значение (название процесса, дата запуска, инициатор) в свойствах экземпляра процесса.
     *
     * @param value текстовое значение (название процесса, дата запуска, инициатор)
     */
    public void checkValueInProperties(String value) {
        $$(processInstanceProperty).findBy(text(value)).shouldBe(visible);
    }

    /**
     * Проверить, присутствует ли указанное значение (название процесса, дата запуска, инициатор) в свойствах экземпляра процесса.
     *
     * @param pattern regex (шаблон названия процесса, даты запуска)
     */
    public void checkValuePatternInProperties(String pattern) {
        $$(processInstanceProperty).findBy(matchText(pattern)).shouldBe(visible);
    }

    /**
     * Проверить, что версия процесса соответствует указанной.
     *
     * @param version Ожидаемая версия процесса
     */
    public void checkProcessVersion(Integer version) {
        $$(processInstanceProperty).findBy(text("Процесс")).shouldBe(visible).shouldHave(text("вер." + version.toString()));
    }
    //endregion
    //region Вкладка "История"

    /**
     * Проверяет наличие указанного состояния в истории экземпляра процесса.
     *
     * @param condition Искомое состояние ("Ошибка" / "Прервано")
     */
    public void checkProcessInstanceHistory(String condition) {
        try {
            $(tableProcessInstanceHistory).shouldHave(text(condition));
        } catch (ElementShould ignore) {
            Selenide.refresh();
            $(tableProcessInstanceHistory).shouldHave(text(condition));
        }
    }

    /**
     * Пропустить таймер на карточке экземпляра процесса.
     */
    public void skipTimer() {
        $(tableProcessInstanceHistory).$$(buttonLink).findBy(text("Таймер 1")).click();
        $$(popoverMenuOption).findBy(text("Выполнить")).shouldBe(visible).click();
        $(popupProcessInstance).shouldBe(not(exist));
    }

    /**
     * Перезапуск задачи в которой возникла ошибка с карточки экземпляра процесса.
     */
    public void rerunTaskWithError() {
        $$(buttonLink).findBy(text("Ошибка")).shouldBe(visible).click();
        $$(popoverButton).findBy(text("Перезапустить")).click();
        $(messageAboutReRun).shouldBe(visible);
    }

    /**
     * Пропуск задачи в которой возникла ошибка с карточки экземпляра процесса.
     */
    public void skipTaskWithError() {
        $$(buttonLink).findBy(text("Ошибка")).shouldBe(visible).click();
        $$(popoverButton).findBy(text("Пропустить")).click();
    }

    /**
     * Проверить, что количество ячеек в таблице истории с указанным значением соответствует указанному числу.
     *
     * @param value Значение в ячейке
     * @param count Ожидаемое число ячеек с указанным значением
     */
    public void checkCountOfValuesInHistoryTable(String value, Integer count) {
        $$(cellProcessInstanceHistory).filter(text(value)).shouldBe(size(count));
    }

    /**
     * Проверить, что количество ячеек в таблице истории с указанным значением соответствует указанному числу.
     *
     * @param pattern regex (паттерн значения в ячейке)
     * @param count   Ожидаемое число ячеек с указанным значением
     */
    public void checkCountOfValuesByPatternInHistoryTable(String pattern, Integer count) {
        $$(cellProcessInstanceHistory).filter(matchText(pattern)).shouldBe(size(count));
    }

    /**
     * Выбрать указанную вкладку ("Текущие" / "Все") в таблице истории экземпляра процесса.
     *
     * @param tabName Название вкладки
     */
    public void switchToTabInHistoryTable(String tabName) {
        $$(switchProcessInstanceHistory).findBy(text(tabName)).shouldBe(visible).click();
    }

    /**
     * Разница в минутах между датой создания и сроком в указанной строке.
     *
     * @param elementName Название элемента по которому выполняется поиск строки
     * @return Разница в минутах между датой создания и сроком
     */
    public long getDifferenceBetweenDatesInRow(String elementName) {
        String creationDateString = $$(rowProcessInstanceHistory).findBy(text(elementName))
                .$$(cellProcessInstanceHistory).get(2).getText();
        String expirationDateString = $$(rowProcessInstanceHistory).findBy(text(elementName))
                .$$(cellProcessInstanceHistory).get(3).getText();
        LocalDateTime creationDate = LocalDateTime.parse(creationDateString,
                DateTimeFormatter.ofPattern("d MMMM yyyy г., H:mm").withLocale(Locale.forLanguageTag("ru")));
        LocalDateTime expirationDate = LocalDateTime.parse(expirationDateString,
                DateTimeFormatter.ofPattern("d MMMM yyyy г., H:mm").withLocale(Locale.forLanguageTag("ru")));
        return ChronoUnit.MINUTES.between(creationDate, expirationDate);
    }
    //endregion
    //region Вкладка "Контекст"

    /**
     * Проверяет, что указанное значение содержится в указанной контекстной переменной на вкладке "Контекст".
     *
     * @param variableName  Имя контекстной переменной
     * @param variableValue Значение контекстной переменной
     */
    public void checkContext(String variableName, String variableValue) {
        $$(contextRow).findBy(text(variableName)).shouldHave(text(variableValue));
    }

    /**
     * Проверяет, что на вкладке "Контекст" содержатся ТОЛЬКО переменные с указанными названиями.
     */
    public void checkContextsArrayEquals(String... variableNames) {
        ElementsCollection contextArray = $$(contextRow);
        contextArray.last().shouldBe(visible);
        contextArray.shouldHave(size(variableNames.length));
        for (String name : variableNames)
            contextArray.findBy(text(name)).shouldBe(visible);
    }

    /**
     * Изменить контекст на вкладке "Контекст" (работает с процессом ContextChange.json).
     */
    public void changeContext() {
        $$(buttonDefault).findBy(text("Изменить контекст")).shouldBe(visible).click();
        $(By.id("str1")).setValue("After");
        $(By.id("int1")).setValue("321");
        $(By.id("bool1")).click();
        $$(buttonPrimary).findBy(text("сохранить")).shouldBe(visible).click();
        $(popoverInputComment).shouldBe(visible).setValue("CONTEXT CHANGED");
        $(popoverButtonPrimary).click();
    }
    //endregion
    //region Вкладка "Карта процесса"

    /**
     * Проверка карты процесса. Проверяет отображение нужного количества BPMN элементов на карте процесса.
     *
     * @param bpmnElements Необходимое количество элементов BPMN на карте процесса;
     */
    public void processMapCheck(Integer bpmnElements) {
        $$(mapBpmnElement).shouldHave(size(bpmnElements + 1));
    }

    /**
     * Проверяет, что количество подсвеченных блоков на карте соответствует указанному.
     *
     * @param bpmnBlocksCount Ожидаемое количество подсвеченных блоков
     */
    public void processMapCountOfHighlightedBlocks(Integer bpmnBlocksCount) {
        $$(mapBpmnHighlightedBlock).shouldHave(size(bpmnBlocksCount));
    }

    /**
     * Проверяет, что количество блоков по текущим задачам (подсвечены зеленым) на карте соответствует указанному.
     *
     * @param bpmnBlocksCount Ожидаемое количество текущих блоков
     */
    public void processMapCountOfCurrentBlocks(Integer bpmnBlocksCount) {
        $$(mapBpmnCurrentBlock).shouldHave(size(bpmnBlocksCount));
    }

    public void clickAllTasksButton() {
        $(allTasksButtonXpath).shouldBe(visible).click();
    }

    public void clickActiveTasksButton() {
        $(activeTasksButtonXpath).shouldBe(visible).click();
    }

    public void checkValueStateByPatternInHistoryTable(String name, boolean isClosed) {
        SelenideElement taskCell = $$(cellProcessInstanceHistory).findBy(matchText(name)).shouldBe(visible);
        if (isClosed) taskCell.shouldHave(cssClass("closed"));
        else taskCell.shouldNotHave(cssClass("closed"));
    }

    public void checkMapElementVisibility(String name, boolean isVisible) {
        SelenideElement mapElement = $$(workAreaContextInMapCss).findBy(matchText(name));
        if (isVisible) mapElement.shouldBe(visible);
        else mapElement.shouldNotBe(visible);
    }
    //endregion

    public void checkButtonInterruptProcessNotExit() {
        $(buttonInterruptProcess).shouldNot(exist);
    }

    public void checkButtonInterruptProcessExist() {
        $(buttonInterruptProcess).shouldBe(visible);
    }
}
