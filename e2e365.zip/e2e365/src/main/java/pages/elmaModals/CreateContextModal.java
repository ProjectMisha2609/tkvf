package pages.elmaModals;

import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class CreateContextModal extends BasePage {
    private final By nameContextCss = By.cssSelector("elma-form-row:first-child input[formcontrolname='name']");
    private final By createContextCss = By.cssSelector("div.modal-footer button[elmabutton='primary']");
    private final By fieldSelectContextTypeCss = By.cssSelector("elma-form-row elma-select[formcontrolname='type']");
    private final By typeContextAppCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Приложение']");
    private final By typeContextNumberCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Число']");
    private final By typeContextBoolCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Выбор «да/нет»']");
    private final By typeContextDateTimeCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Дата/время']");
    private final By selectAppLinkCss = By.cssSelector("elma-type-settings-collection elma-form-row elma-form-control button");
    private final By typeContextFilesCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Файлы']");
    private final By valueInputCss = By.cssSelector("input[name*='newItemInput']");
    private final By valueInputButtonXpath = By.xpath("//input[contains(@name, 'newItemInput')]/../../button");
    private final By yesValueXpath = By.xpath("//span[contains(text(), 'Варианты')]/../..//input[@placeholder='Да']");
    private final By noValueXpath = By.xpath("//span[contains(text(), 'Варианты')]/../..//input[@placeholder='Нет']");
    private final By typeContextUserLinkCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Пользователи']");
    private final By typeContextStringCss = By.cssSelector("[role='listbox'] [class*='element'] [aria-label='Строка']");

    /**
     * Тип контекстной переменной в выпадающем списке
     */
    private final By typeOfContext = By.cssSelector("[role='listbox'] [class*='element']");

    /**
     * Подтип контекстной переменной, доступен для некоторых типов при их выборе
     */
    private final By subTypeOfContext = By.cssSelector("elma-switch .p-ripple.p-element.p-button");

    /**
     * Чекбокс "Заполняется по формуле"
     */
    private final By calcByFormulaCheckbox = By.cssSelector("elma-checkbox[inputid='calcByFormula']");

    /**
     * Чекбокс "Отображается при выполнении условия"
     */
    private final By visibleByConditionCheckbox = By.cssSelector("elma-checkbox[inputid='visibleByCondition']");

    /**
     * Формула для расчетов контекстной переменной
     */
    private final By formulaOfContext = By.cssSelector("input[formcontrolname='formula']");

    /**
     * Подсказка для контекстной переменной
     */
    private final By tooltipForContext = By.cssSelector("input[formcontrolname='tooltip']");

    /**
     * Название чекбокса
     */
    private final By checkboxLabel = By.cssSelector("label.p-checkbox-label");

    /**
     * Чекбокс
     */
    private final By checkbox = By.cssSelector("p-checkbox .p-checkbox.p-component");

    /**
     * Кнопка-ссылка
     */
    private final By buttonLink = By.cssSelector("button.btn-link"); // .ui-dialog-draggable пришлось удалить

    /**
     * Стандартная белая кнопка
     */
    private final By buttonDefault = By.cssSelector("button.btn-default");

    /**
     * Значение для выбора в поповере
     */
    private final By valueInPopover = By.cssSelector("elma-popover-menu-option");

    /**
     * Ряд в модалке, слева назначение переменной справа ее ввод
     */
    private final By modalRow = By.cssSelector("form elma-form-row");

    /**
     * Селектор для поля ввода переменной
     */
    private final By modalInput = By.cssSelector("input");

    /**
     * Окно ввода "По умолчанию"
     */
    private final By inputDefault = By.cssSelector("elma-field-editor [class*='multiline-container'] input");

    public void fillContextName(String contextName) {
        $(nameContextCss).shouldBe(visible).sendKeys(contextName);
    }

    public void clickFieldSelectType() {
        $(fieldSelectContextTypeCss).shouldBe(visible).click();
    }

    public void clickTypeContextApp() {
        $(typeContextAppCss).shouldBe(visible).click();
    }

    public void clickTypeContextNumber() {
        $(typeContextNumberCss).shouldBe(visible).click();
    }

    public void clickTypeContextBool() {
        $(typeContextBoolCss).shouldBe(visible).click();
    }

    public void clickTypeContextDateTime() {
        $(typeContextDateTimeCss).shouldBe(visible).click();
    }

    public void clickTypeContextFiles() {
        $(typeContextFilesCss).shouldBe(visible).click();
    }

    public void clickTypeContextString() {
        $(typeContextStringCss).shouldBe(visible).click();
    }

    public void clickLinkSelectApp() {
        $(selectAppLinkCss).shouldBe(visible).click();
    }

    public void clickTypeContextUser() {
        $(typeContextUserLinkCss).shouldBe(visible).click();
    }

    /**
     * Выбрать тип контекстной переменной по указанному названию.
     *
     * @param typeName Название типа
     */
    public void selectContextType(String typeName) {
        clickFieldSelectType();
        $$(typeOfContext).findBy(text(typeName)).click();
    }

    /**
     * Выбрать подтип для контекстной переменной по указанному названию (Предварительно необходимо выбрать тип).
     *
     * @param subTypeName Название подтипа
     */
    public void selectContextSubType(String subTypeName) {
        $$(subTypeOfContext).findBy(exactText(subTypeName)).click();
    }

    /**
     * Задать значение по умолчанию для контекстной переменной.
     *
     * @param value значение
     */
    public void setDefaultValue(String value) {
        //старый селектор не подходил потому что для того чтобы он появился надо похоже кликнуть на это поле
        $$(modalRow).findBy(text("По умолчанию")).$(modalInput).shouldBe(visible).setValue(value);
    }

    /**
     * Задать формулу для расчета значения.
     *
     * @param formula формула
     */
    public void setCalcByFormula(String formula) {
        $(calcByFormulaCheckbox).shouldBe(visible).click();
        $(formulaOfContext).shouldBe(visible).setValue(formula);
    }

    /**
     * Задать значение по умолчанию для контекстной переменной.
     *
     * @param tooltip значение
     */
    public void setTooltip(String tooltip) {
        $(tooltipForContext).shouldBe(visible).setValue(tooltip);
    }

    /**
     * Отметить чекбокс с указанным названием.
     *
     * @param name Название (label) чекбокса
     */
    public void setCheckboxByName(String name) {
        $$(checkboxLabel).findBy(text(name)).parent().$(checkbox).shouldBe(visible).click();
    }

    /**
     * Отметить чекбокс "Отображается при выполнении условия" и задать условие для выбранной контекстной переменной.
     *
     * @param operand   - Контекстная переменная для которой будет задано условие
     * @param condition - Условие которое нужно задать в колонки "Операция"
     */
    public void setVisibleByCondition(String operand, String condition) {
        // добавил прокрутку до элемента
        $(visibleByConditionCheckbox).should(exist).scrollTo().shouldBe(visible).click();
        $$(buttonLink).findBy(text("Настроить условия")).should(exist).scrollTo().click();
        $$(buttonDefault).findBy(text("+ Условие")).click();
        $$(buttonLink).findBy(text("<Не определен>")).click();
        $$(valueInPopover).findBy(text(operand)).click();
        $$(buttonLink).findBy(text("=")).click();
        $$(valueInPopover).findBy(text(condition)).click();
        $$(createContextCss).findBy(text("Сохранить")).click();
    }

    public void clickButtonLinkByName(String buttonName) {
        $$(buttonLink).findBy(text(buttonName)).should(exist).scrollTo().shouldBe(visible).click();
    }

    public void clickButtonDefaultByName(String buttonName) {
        $$(buttonDefault).findBy(text(buttonName)).should(exist).scrollTo().shouldBe(visible).click();
    }

    public void selectValueInPopover(String value) {
        $$(valueInPopover).findBy(text(value)).should(exist).scrollTo().shouldBe(visible).click();
    }

    /**
     * Вводит значение в инпут "По умолчанию".
     */
    public void fillInputDefault(String inputDefaultString) {
        $(inputDefault).shouldBe(visible).sendKeys(inputDefaultString);
    }

    public void addValues(String... values) {
        for (String value : values) {
            $(valueInputCss).scrollTo().shouldBe(visible).sendKeys(value);
            $(valueInputButtonXpath).shouldBe(visible).click();
        }
    }

    public void changeYesNoValues(String[] testValues) {
        Assertions.assertEquals(2, testValues.length,
                "При изменении значений выбора Да/Нет нужно указать два варианта");
        $(yesValueXpath).scrollTo().shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, testValues[0]);
        $(noValueXpath).scrollTo().shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, testValues[1]);
    }
}
