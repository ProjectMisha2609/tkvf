package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.time.Duration;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class CreateAppElementModal extends BasePage {
    private final By emailCss = By.cssSelector("input[formcontrolname='email']");
    private final By nameCss = By.cssSelector("elma-form-control input[id='__name']");
    private final By fieldStringCss = By.cssSelector("elma-form-control input[id='stroka']");
    private final By fieldNumberCss = By.cssSelector("elma-form-control input[id='chislo']");
    private final By fieldBoolTrueCss = By.cssSelector("elma-type-boolean div.switch-buttons div[aria-label='Да']");
    private final By fieldDateTimeCss = By.cssSelector("p-calendar button[class*=datepicker-trigger]");
    private final By calendarButtonBarCss = By.cssSelector("div[class*=datepicker-buttonbar] button");
    private final By appNameSearchFieldCss = By.cssSelector("elma-form input[role=searchbox]:last-child");
    private final By appListSearchedCss = By.cssSelector("div.ng-trigger-overlayAnimation ul[role='listbox']");
    private final By searchedAppCss = By.cssSelector("li[role='option']");
    private final By confirmBindProcessButtonXpath = By.xpath("//app-appview-process-buttons-edit//div[contains(@class, 'popover-footer')]//button[contains(text(),'Сохранить')]");
    private final By startProcessAfterTaskConfirmationCheckboxCss = By.cssSelector("elma-form-control elma-checkbox");
    private final By selectProcessToStartAfterTaskConfirmationButtonCss = By.cssSelector("elma-form-control button");
    private final By processTreeNodeElementCss = By.cssSelector("p-treenode span");
    /**
     * Чекбокс "Указать время" на странице создания элемента приложения
     */
    private final By checkBoxSpecifyTime = By.cssSelector("[class='modal__main'] p-checkbox");
    /**
     * Окно ввода времени переменной "Дата/Время" на странице создания элемента приложения
     */
    private final By chooseTime = By.cssSelector("elma-time div[class*='p-dropdown']>input[placeholder*=h]");
    /**
     * Окно ввода даты переменной "Дата/Время" на странице создания элемента приложения
     */
    private final By chooseDate = By.cssSelector("p-calendar");
    /**
     * Окно со значениями переменной "Да/Нет"
     */
    private final By valuesYesNoVariable = By.cssSelector("[role='group']");
    /**
     * Блок подсказки переменной
     */
    private final By blockTooltip = By.cssSelector("elma-form-tooltip");
    /**
     * Окно со значениями переменной "Строка"
     */
    private final By valuesString = By.cssSelector("elma-form-row elma-type-string");

    public void fillEmail(String textEmail) {
        $(emailCss).shouldBe(visible).sendKeys(textEmail);
    }

    public void fillName(String name) {
        $(nameCss).shouldBe(visible).sendKeys(name);
    }

    public void fillFieldString(String inputString) {
        $(fieldStringCss).shouldBe(visible).sendKeys(inputString);
    }

    public void fillFieldNumber(String inputNumber) {
        $(fieldNumberCss).shouldBe(visible).sendKeys(inputNumber);
    }

    public void clickFieldTypeBoolTrue() {
        $(fieldBoolTrueCss).shouldBe(visible).click();
    }

    public void clickTodayInFieldDateTime() {
        $(fieldDateTimeCss).shouldBe(visible).click();
        $$(calendarButtonBarCss).findBy(text("Сегодня")).shouldBe(visible).click();
    }

    /**
     * Выбирает чекбокс "Указать время" переменной "Дата/Время".
     */
    public void clickSpecifyTime() {
        $(checkBoxSpecifyTime).shouldBe(visible).click();
    }

    /**
     * Проверяет появление окна ввода времени переменной "Дата/Время".
     */
    public void checkElementChooseTime() {
        $(chooseTime).shouldBe(visible);
    }

    /**
     * Проверяет отсутствие окна ввода времени переменной "Дата/Время".
     */
    public void checkHiddenElementChoseTime() {
        $(chooseTime).shouldBe(disappear, Duration.ofSeconds(5));
    }

    /**
     * Проверяет отсутствие окна ввода даты переменной "Дата/Время".
     */
    public void checkHiddenElementChoseDate() {
        $(chooseDate).shouldBe(disappear, Duration.ofSeconds(5));
    }

    /**
     * Получает значения переменной типа "Да/Нет".
     */
    public void checkValuesYesNoVariable(String text) {
        $(valuesYesNoVariable).shouldBe(visible).shouldHave(text(text));
    }

    /**
     * Получает значение подсказки переменной.
     */
    public void checkTooltipVariable(String text) {
        $(blockTooltip).shouldBe(visible).shouldHave(text(text));
    }

    /**
     * Получает значение переменной типа "Строка".
     */
    public void checkValuesStringVariable(String text) {
        $(valuesString).shouldBe(visible).shouldHave(text(text));
    }

    /**
     * Проверяет отсутствие переменной типа "Строка".
     */
    public void checkStringVariableNotExists() {
        $("elma-modal-body").shouldBe(visible);
        $(fieldStringCss).shouldNot(exist);
    }

    public void bindProcess(String processName) {
        $(startProcessAfterTaskConfirmationCheckboxCss).shouldBe(visible).click();
        $$(selectProcessToStartAfterTaskConfirmationButtonCss).findBy(text("Выберите процесс")).shouldBe(visible).click();
        $$(processTreeNodeElementCss).findBy(text(processName)).scrollTo().shouldBe(visible).click();
        dialogWindowPressButton("Продолжить");
        $$(confirmBindProcessButtonXpath)
                .findBy(visible).click();
    }
}
