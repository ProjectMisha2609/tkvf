package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class SignSettingsModal extends BasePage {
    private final By searchInputXpath = By.xpath("//app-signature-permissions//input");
    private final By searchInputDropdownOptionsXpath = By.xpath("//ul[@role='listbox']//span|//ul[@role='listbox']//app-user-name");
    private final By addedPermissionsXpath = By.xpath("//div[contains(@class, 'template-selected-list')]//span");

    public void selectUserOrRoleOrGroupByQuery(String query) {
        $(searchInputXpath).shouldBe(visible).click();
        $(searchInputXpath).sendKeys(query);
        $$(searchInputDropdownOptionsXpath).findBy(text(query)).shouldBe(visible).click();
        $$(addedPermissionsXpath).findBy(text(query)).shouldBe(visible);
    }

    public void checkModalOpened() {
        $(searchInputXpath).shouldBe(visible);
    }
}
