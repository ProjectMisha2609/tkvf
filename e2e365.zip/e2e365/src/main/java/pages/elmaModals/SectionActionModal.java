package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SectionActionModal extends BasePage {
    private final By crateSectionFastCss = By.cssSelector("button[data-test='createSectionB']");

    public void clickCreateSectionFast() {
        $(crateSectionFastCss).shouldBe(visible).click();
    }
}
