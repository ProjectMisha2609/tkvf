package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class AppFormSettingsModal extends BasePage {
    private final By simpleFormPropertiesContainerCss = By.cssSelector("app-application-config-dnd-fields-types ngx-dnd-item span");
    private final By appConfigAreaCss = By.cssSelector("app-application-config-dnd-fields");
    private final By selectAppCss = By.cssSelector("app-application-config-fields-field elma-form-control.text-base button");
    private final By addContextCss = By.cssSelector("#context-panel div.header button");
    private final By createTabCss = By.cssSelector("#create");
    private final By contextFieldsContainerCss = By.cssSelector("#create-panel div[class='form-settings__col-body'] ngx-dnd-item");
    private final By contextFieldsContainerViewFormCss = By.cssSelector("#view-panel div[class='form-settings__col-body'] ngx-dnd-item");
    private final By checkBoxReadOnlyCss = By.cssSelector("elma-checkbox[name='readonly'] div[class*='checkbox']");
    private final By itemsInCreateFormCss = By.cssSelector("#create-panel div[class*='form-fields'] ngx-dnd-item");
    private final By arrowInsidePropertyCss = By.cssSelector("i.elma-icons");
    private final By formSelectorCss = By.cssSelector("app-template-selector");
    private final By formSelectorDropDown = By.cssSelector("app-template-selector elma-select");
    private final By createFormButtonXpath = By.xpath("//button[text()[contains(.,  'Создать форму')]]");
    private final By editExistingFormButtonXpath = By.xpath("//button[text()[contains(.,  'Редактировать форму')]]");

    /**
     * Настройка типа "Дата/Время" форме элемента приложения
     */
    private final By selectTypeDateTime = By.cssSelector("[role='group'] [role='button']");

    /**
     * Блок с чебоксами настроек пременной "Дата/Время" форме элемента приложения
     */
    private final By settingsDateTime = By.cssSelector("elma-type-settings-datetime [class*='elma-form-row']");

    /**
     * Окно ввода значения "Да" в переменной «да/нет»
     */
    private final By inputYesInVariableYesNo = By.cssSelector("[class='itemscope']>:nth-child(1) [type='text']");

    /**
     * Окно ввода значения "Нет" в переменной «да/нет»
     */
    private final By inputNoInVariableYesNo = By.cssSelector("[class='itemscope']>:nth-child(2) [type='text']");

    /**
     * Окно ввода подсказки последней добавленной переменной
     */
    private final By variableTooltipInput = By.cssSelector("[class*='ngx-dnd-container']>:last-child app-application-config-fields-options>:first-child input");

    /**
     * Вкладка на форму просмотра
     */
    private final By viewTabCss = By.cssSelector("#view");

    /**
     * Кнопка удаления контекста (Простой режим отображения)
     */
    private final By buttonDeleteContext = By.cssSelector("[title='Удалить']");

    /**
     * Кнопка подтверждения удаления контекста (Простой режим отображения)
     */
    private final By buttonConfirmationDeleteContext = By.cssSelector("[elmabutton='danger']");

    private final By tabsSettingFormAppCss = By.cssSelector("li .nav-link");
    private final By popoverButtonsCss = By.cssSelector("elma-popover-footer button");

    public void dragAndDropProperty(String propertyName) {
        CustomDriver.getAction().dragAndDrop($$(simpleFormPropertiesContainerCss)
                .findBy(exactText(propertyName))
                .shouldBe(visible), $(appConfigAreaCss)).build().perform();
    }

    public void clickSelectApp() {
        $(selectAppCss).shouldBe(visible).click();
    }

    public void clickAddContext() {
        $(addContextCss).shouldBe(visible).click();
    }

    public void clickCreateTab() {
        $(createTabCss).shouldBe(visible).click();
    }

    /**
     * Перемещает элемент на форме Создания.
     */
    public void movePropertyOnForm(String contextName) {
        $$(contextFieldsContainerCss).findBy(text(contextName)).shouldBe(visible)
                .$(arrowInsidePropertyCss).shouldBe(visible).click();
    }

    /**
     * Перемещает элемент на форме Просмотра.
     */
    public void movePropertyOnViewForm(String contextName) {
        $$(contextFieldsContainerViewFormCss).findBy(text(contextName)).shouldBe(visible)
                .$(arrowInsidePropertyCss).shouldBe(visible).click();
    }

    public void clickReadOnlyField(String name) {
        SelenideElement element = $$(itemsInCreateFormCss).findBy(text(name)).shouldBe(visible);
        element.$(checkBoxReadOnlyCss).shouldBe(visible).click();
    }

    /**
     * Выбирает тип переменной "Дата/Время".
     */
    public void clickTypeDateTime(String blockName) {
        $$(selectTypeDateTime).findBy(exactText(blockName)).shouldBe(visible).click();
    }

    /**
     * Отмечает чекбокс "Время опционально" в настройке переменной "Дата/Время".
     */
    public void clickTimeOptional() {
        $$(settingsDateTime).findBy(text("Время опционально")).shouldBe(visible).click();
    }

    /**
     * Выбирает какое время будет установлено в настройке переменной "Дата/Время" ("Начало дня" - "Конец дня").
     */
    public void selectTimeOptional(String blockName) {
        $$(selectTypeDateTime).findBy(text(blockName)).shouldBe(visible).click();
    }

    /**
     * Очищает инпут и вводит значение в вариант "Да" в переменной «да/нет»
     */
    public void fillInputYes(String inputString) {
        $(inputYesInVariableYesNo).shouldBe(visible).clear();
        $(inputYesInVariableYesNo).sendKeys(inputString);
    }

    /**
     * Очищает инпут и вводит значение в вариант "Нет" в переменной «да/нет»
     */
    public void fillInputNo(String inputString) {
        $(inputNoInVariableYesNo).shouldBe(visible).clear();
        $(inputNoInVariableYesNo).sendKeys(inputString);
    }

    /**
     * Вводит значение в инпут подсказки переменной.
     */
    public void fillVariableTooltip(String tooltipString) {
        $(variableTooltipInput).shouldBe(visible).sendKeys(tooltipString);
    }

    /**
     * Кликает на вкалдку "Просмотр".
     */
    public void clickViewTab() {
        $(viewTabCss).shouldBe(visible).click();
    }

    /**
     * Кликает на кнопку удаления контекста и подтверждает удаление.
     */
    public void clickDeleteContext() {
        $(buttonDeleteContext).shouldBe(visible).click();
        $(buttonConfirmationDeleteContext).shouldBe(visible).click();
    }

    public void createDefaultForm() {
        $(formSelectorCss).shouldBe(visible).click();
        $(createFormButtonXpath).shouldBe(visible).click();
    }

    public void openExistingForm() {
        $(editExistingFormButtonXpath).shouldBe(visible).click();
    }

    /**
     * @param tabName - название вкладки, которую нужно открыть
     */
    @Override
    public void selectModalWindowTab(String tabName) {
        $(By.xpath("//app-application-advanced-forms//elma-tabset//ul[contains(@role,'tablist')]/li/a[contains(text(),'" + tabName + "')]"))
                .shouldBe(visible).click();
    }

    public void checkInContextTab(String name) {
        $(By.xpath("//div[contains(@class,'modal-body')]//ngx-dnd-item//span[contains(@class,'name')][contains(text(),'" + name + "')]"))
                .shouldBe(visible);
    }

    public void clickInContextTab(String name) {
        $(By.xpath("//div[contains(@class,'modal-body')]//ngx-dnd-item//span[contains(@class,'name')][contains(text(),'" + name + "')]"))
                .shouldBe(visible).click();
    }

    public void chooseTabSettingFormApp(String tabName) {
        $$(tabsSettingFormAppCss).findBy(text(tabName)).shouldBe(visible).click();
    }

    public void clickPopoverFooterButton(String buttonName) {
        $$(popoverButtonsCss).findBy(text(buttonName)).shouldBe(visible).click();
    }
}
