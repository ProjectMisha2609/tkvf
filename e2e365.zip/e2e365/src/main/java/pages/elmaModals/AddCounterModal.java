package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class AddCounterModal extends BasePage {
    private final By counterNameCss = By.cssSelector("[class*=ng-pristine][class*=ng-invalid]");

    public void fillName(String name) {
        SelenideElement element = $(counterNameCss).shouldBe(visible);
        element.click();
        element.sendKeys(name);
    }
}