package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class CreateBpModal extends BasePage {
    private final By patternTextStringCss = By.cssSelector("input[name='name']");

    public void dialogWindowEnterName(String name) {
        $(patternTextStringCss).shouldBe(visible).sendKeys(name);
    }
}
