package pages.elmaModals;

import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static java.lang.String.format;
import static org.openqa.selenium.Keys.BACK_SPACE;

/**
 * Открыть главную страницу системы
 * Нажать на имя пользователя в правом верхнем углу
 * Нажать на кнопку 'Настройки'
 * Модальное окно 'Настройки пользователя'
 */
@Singleton
public class UserSettingsModal extends BasePage {
    private final By lastNameCss = By.cssSelector("input[placeholder *= 'Фамилия']");
    private final By firstNameCss = By.cssSelector("input[placeholder *= 'Имя']");
    private final By middleNameCss = By.cssSelector("input[placeholder *= 'Отчество']");
    private final By buttonSaveCss = By.cssSelector("button[class*= 'btn btn-primary ng-star-inserted']");
    private final By workPhoneCss = By.cssSelector("[class*='tel'][data-intl-tel-input-id*='0']");
    private final By mobilePhoneCss = By.cssSelector("[class*='tel'][data-intl-tel-input-id*='1']");
    private final By dataBirthdayCss = By.cssSelector("input[class*='p-inputtext p-component']");
    private final By removePhotoCss = By.cssSelector("[class*='upload-list']>[class*='remove']");
    private final By buttonThreeDotsCss = By.cssSelector("[class*='drop-area'] [class*='default']");
    private final By buttonSavePhotoCss = By.cssSelector("[class='modal-footer']>[class*='primary']");
    private final By buttonSelectFiles = By.xpath("//*[text()[contains(.,'Выбрать из Раздела \"Файлы\"')]]");
    private final By buttonMyFileCss = By.cssSelector("[class*='demo elma-modal-window'] [class*='disk-list__item']:nth-child(3) [class*='directory__name']");
    private final String buttonNamePhoto = "//*[contains(@class,'demo elma-modal-window')]//div[text()[contains(.,'%s')]]";


    public void inputLastName(String lastName) {
        $(lastNameCss).shouldBe(visible).clear();
        $(lastNameCss).sendKeys(lastName);
    }

    public void inputFirstName(String firstName) {
        $(firstNameCss).shouldBe(visible).clear();
        $(firstNameCss).sendKeys(firstName);
    }

    public void inputMiddleName(String middleName) {
        $(middleNameCss).shouldBe(visible).clear();
        $(middleNameCss).sendKeys(middleName);
    }

    public void clickButtonSave() {
        $(buttonSaveCss).shouldBe(visible).click();
    }

    public void inputWorkPhone(String phoneNumber) {
        $(workPhoneCss).shouldBe(visible).clear();
        $(workPhoneCss).shouldBe(visible).sendKeys(phoneNumber);
    }

    public void inputMobilePhone(String phoneNumber) {
        $(mobilePhoneCss).shouldBe(visible).clear();
        $(mobilePhoneCss).shouldBe(visible).sendKeys(phoneNumber);
    }

    public void inputDataBirthday(String data) {
        $(dataBirthdayCss).shouldBe(visible).sendKeys(BACK_SPACE);
        $(middleNameCss).shouldBe(visible).click();
        $(dataBirthdayCss).sendKeys(data);
    }

    public void clickRemovePhoto() {
        $(removePhotoCss).shouldBe(visible).click();
    }

    public void clickButtonThreeDots() {
        $(buttonThreeDotsCss).shouldBe(visible).click();
        $(buttonSelectFiles).shouldBe(visible).click();
    }

    public void clickMyFile() {
        $(buttonMyFileCss).shouldBe(visible).click();
    }

    public void choosePhoto(String namePhoto) {
        $(By.xpath(format(buttonNamePhoto, namePhoto))).shouldBe(visible).click();
        $(buttonSavePhotoCss).click();
        CustomDriver.waitMills(3000);
    }

    public void uploadingPhotos(String filePath) {
        $("[data-test='uploadFileI']>input").sendKeys(new File("").getAbsoluteFile() + filePath);
        $(buttonSavePhotoCss).click();
        CustomDriver.waitMills(3000);
    }

    public boolean isImg(String nameFile) {
        return $(format("[alt*='%s']", nameFile)).shouldBe(visible).exists();
    }
}

