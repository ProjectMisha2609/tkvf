package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class AddGroupOrRoleModal extends BasePage {
    private final By nameId = By.cssSelector("[data-test=addGroupOrRoleNameTb]");
    private final By descriptionId = By.cssSelector("[data-test=addGroupOrRoleDescriptionTb]");
    private final By chooseRoleId = By.cssSelector("div[aria-pressed='false']");

    public void fillName(String name) {
        SelenideElement element = $(nameId).shouldBe(visible);
        element.click();
        element.sendKeys(name);
    }

    public void clearFillName() {
        $(nameId).shouldBe(visible).clear();
    }

    public void fillDescription(String description) {
        SelenideElement element = $(descriptionId).shouldBe(visible);
        element.click();
        element.sendKeys(description);
    }

    public void clickRoleSelect() {
        $(chooseRoleId).shouldBe(visible).click();
    }

    public void checkNameContextWidgetOnGroupOrRoleModal(String field, String text) {
        $(By.xpath("//span[(contains(text(),'" + field + "'))]/ancestor::elma-form-row//elma-form-control"))
                .shouldHave(text(text));
    }

    public void checkNameFieldHighlightedInRed() {
        $(nameId).shouldBe(visible).shouldHave(cssClass("ng-dirty"));
    }

    public void clickRemoveButtonByUser(String userName) {
        $(By.xpath("//span[contains(text(),'" + userName + "')]/ancestor::div[contains(@class,'chips-wrapper')]//button[contains(@class,'button-remove')]"))
                .shouldBe(visible).click();
    }

    public void checkRemoveButtonByUser(String userName) {
        $(By.xpath("//span[contains(text(),'" + userName + "')]/ancestor::div[contains(@class,'chips-wrapper')]//button[contains(@class,'button-remove')]"))
                .shouldBe(visible);
    }
}
