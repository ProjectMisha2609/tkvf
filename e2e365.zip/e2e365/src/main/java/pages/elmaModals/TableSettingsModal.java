package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static com.codeborne.selenide.CollectionCondition.size;
import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

@Singleton
public class TableSettingsModal extends BasePage {
    private final By plusColumnButtonCss = By.cssSelector("i[class*='elma-icons'][class*='column-plus']");
    private final By cellDataTypesOptionsCss = By.cssSelector("span[class*='ctx-menu__text']");
    private final By setFooterButtonCss = By.cssSelector(".table-settings-column-footer button");
    private final By tableFooterInput = By.cssSelector(".table-settings-column-footer input");
    private final By appElementTitle = By.cssSelector("app-collection-readonly-link a");
    private final By hideHeaderButton = By.cssSelector(".visible-header button");
    private final By hideFooterButton = By.cssSelector(".visible-footer button");
    private final By tableFieldXpath = By.xpath("//elma-table-full-field");
    private final By elmaTableFullLine = By.xpath("//elma-type-table-full-line");
    private final By elmaTableField = By.xpath("//elma-type-table-full-line//tr//td");
    private final By columnResizer = By.cssSelector("elma-type-table-settings-column .column-resizer");
    private final By columnWidthIndicator = By.cssSelector(".column-width span");
    private final By fullWindowViewXpath = By.xpath("//p-selectbutton//span[contains(text(),'по ширине окна')]");
    private final By appElementInputFieldXpath = By.xpath("//elma-type-collection//input[contains(@placeholder,'поиска элемента')]");
    private final By columnSettingsButtonCss = By.cssSelector("elma-type-table-settings-column .column-style-settings");
    private final By colorSettingsButtonCss = By.cssSelector(".popover_is-visible elma-colorpicker button");
    private final By greenColorTileCss = By.cssSelector(".popover_is-visible elma-colorselect .color-tile[style='background-color: rgb(56, 118, 28);']");
    private final By saveStyleButtonCss = By.cssSelector(".popover_is-visible .btn-primary");


    public void plusDataColumn() {
        $(plusColumnButtonCss).shouldBe(visible).click();
        $$(cellDataTypesOptionsCss).findBy(text("Данные")).click();
    }

    public void plusFormulaColumn() {
        $(plusColumnButtonCss).shouldBe(visible).click();
        $$(cellDataTypesOptionsCss).findBy(text("Формула")).click();
    }

    public void setFooterText(String footerText) {
        $(setFooterButtonCss).shouldBe(visible).click();
        $$(cellDataTypesOptionsCss).findBy(text("Надпись")).click();
        $(tableFooterInput).shouldBe(visible).sendKeys(footerText);
    }

    public void hideHeader() {
        $(hideHeaderButton).shouldBe(visible).click();
    }

    public void hideFooter() {
        $(hideFooterButton).shouldBe(visible).click();
    }

    public void checkTableLinesCount(int count) {
        $$(elmaTableFullLine).last().shouldBe(visible);
        $$(elmaTableFullLine).shouldHave(size(count));
    }

    public void checkTextExistsOnTableFooter(String text) {
        $(By.xpath("//elma-type-table-full-line[@data-index='2']" +
                "//th[contains(text(),'" + text + "')]")).shouldBe(visible);
    }

    public void checkTextExistsOnTableHeader(String text) {
        $(By.xpath("//elma-type-table-full-line[@data-index='0']" +
                "//th[contains(text(),'" + text + "')]")).shouldBe(visible);
    }

    public void changeTableSize(int yOffset) {
        $(columnResizer).shouldBe(visible);
        actions().clickAndHold($(columnResizer)).moveByOffset(yOffset, 0).release().perform();
    }

    public void checkTableSizeInTextIndicator(String... width) {
        $$(columnWidthIndicator).last().shouldBe(visible);
        for (int i = 0; i < width.length; i++)
            $$(columnWidthIndicator).get(i).shouldBe(visible).shouldHave(text(width[i]));
    }

    public void checkTableSizeInPercents(String... width) {
        // проверка видимости всех td элементов таблицы
        $$(elmaTableField).shouldHave(size(width.length))
                .get(width.length - 1).shouldBe(visible);
        // для каждого элемента в таблице
        for (int i = 0; i < width.length; i++) {
            // проверить что:
            Assertions.assertTrue(
                    // существует атрибут "style"
                    Objects.requireNonNull(
                            $$(elmaTableField).get(i).getAttribute("style")
                    // атрибут "style" содержит переданный текст
                    ).contains(width[i]));
        }
    }

    public void checkTableSizeInPixels(int width) {
        $(elmaTableField).shouldBe(visible).shouldHave(cssValue("width", width + "px"));
    }

    public void setTableViewFullSize() {
        $(fullWindowViewXpath).shouldBe(visible).click();
    }

    public void selectAppElementInTableField(String name) {
        $(tableFieldXpath).shouldBe(visible).click();
        $(appElementInputFieldXpath).shouldBe(visible).sendKeys(name);
        selectDropdownOptionByText(name);
        $$(appElementTitle).findBy(text(name)).shouldBe(visible);
    }

    public void checkAppElementNameInTable(String name) {
        $$(appElementTitle).findBy(text(name)).shouldBe(visible);
    }

    public void openColumnSettings() {
        $(columnSettingsButtonCss).shouldBe(visible).click();
    }

    public void openTextColorSettings() {
        $$(colorSettingsButtonCss).findBy(text("fill_text")).shouldBe(visible).click();
    }

    public void openBackgroundColorSettings() {
        $$(colorSettingsButtonCss).findBy(text("fill_background")).shouldBe(visible).click();
    }

    public void selectGreenColor() {
        $(greenColorTileCss).shouldBe(visible).click();
        $$(greenColorTileCss).shouldHave(size(2));
        actions().sendKeys(Keys.ESCAPE).perform();
    }

    public void saveStyleSettings() {
        $(saveStyleButtonCss).shouldBe(visible).click();
    }

    public void checkTextColorIsGreen() {
        $(tableFieldXpath).shouldBe(visible).click();
        actions().sendKeys("green text sample for test", Keys.ENTER).perform();
        checkElementColorIsGreen($(By.xpath("//span[contains(text(),'text sample for test')]")));
    }

    public void checkBackgroundColorIsGreen() {
        $(elmaTableField).shouldBe(visible);
        checkElementBackgroundColorIsGreen($(elmaTableField));
    }
}
