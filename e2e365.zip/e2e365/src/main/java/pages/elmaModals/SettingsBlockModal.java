package pages.elmaModals;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import java.time.LocalDate;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static java.lang.String.valueOf;

@Singleton
public class SettingsBlockModal extends BasePage {
    private final By blockNameSettingCss = By.cssSelector("elma-tab[id*='elma-tab'] elma-form-control input[name='name']");
    private final By addNewFunctionCss = By.cssSelector("elma-tab[id*='elma-tab']  app-script-select button");
    private final By nameFieldCss = By.cssSelector("elma-form-control input.input[placeholder='Название']");
    private final By createCss = By.cssSelector("button[elmabutton='primary'][class*='create-button']");
    private final By openFunctionCss = By.cssSelector("elma-form-control button[elmabutton='default'].btn-default");
    private final By functionArrowCss = By.cssSelector("elma-form-control span.p-inputtext:not(.p-element)");
    private final By functionsInDropdownCss = By.cssSelector("ul.p-dropdown-items");
    private final By functionNameCss = By.cssSelector("p-dropdownitem");
    private final By selectProcessCss = By.cssSelector("div[role='dialog'] elma-form elma-form-control [elmabutton='link']");
    private final By syncOrAsyncStartCss = By.cssSelector("div[role='dialog'] div.p-checkbox:not(.ui-state-disabled)");
    private final By tabSetNames = By.cssSelector("elma-form elma-tabset>ul>li>a");
    private final By formSelectorCss = By.cssSelector("app-template-selector");
    private final By formSelectorDropDown = By.cssSelector("app-template-selector elma-select");
    private final By createFormButtonXpath = By.xpath("//button[text()[contains(.,  'Создать форму')]]");
    private final By editExistingFormButtonXpath = By.xpath("//button[text()[contains(.,  'Редактировать форму')]]");
    private final By contextFields = By.cssSelector("app-form-editor-field");
    private final By modalContentButtonsCss = By.cssSelector(".modal-content button");
    private final By checkBoxLimitDeadline = By.cssSelector("[name='limitByTime'] [class='p-checkbox-box']");
    private final By inputDateLimitDeadline = By.cssSelector("[class*='short']:nth-child(2) [inputmode='decimal']");
    private final By inputTimeMinuteLimitDeadline = By.cssSelector("[class*='short']:nth-child(6) [inputmode='decimal']");
    private final By checkBoxFromTakeIntoAccountWorkCalendar = By.cssSelector("[class*='ml-4'] [class*='p-checkbox-box']");
    private final By checkBoxFormNameOfTaskAccordToTemplate = By.cssSelector("[class='p-checkbox-box']");
    private final By inputPattern = By.cssSelector("input[name='task-title']");
    private final By checkboxScheduleTaskInCalendar = By.cssSelector("[name='planDates'] [class='p-checkbox-box']");
    private final By inputDateStart = By.cssSelector("elma-form-fieldset>:first-child [class*='elma-icons']");
    private final By dayStartXpath = By.xpath("//span[contains(text(), 'dayStart')]");
    private final By inputDateFinish = By.cssSelector("elma-form-fieldset>:last-child [class*='elma-icons']");
    private final By dayEndXpath = By.xpath("//span[contains(text(), 'dayEnd')]");
    private final By itemsMenuFileCss = By.cssSelector(".ctx-menu__text");
    private final By iconTimeCss = By.cssSelector("[class='p-dropdown-trigger-icon elma-icons time-preset-button']");
    private final By radioButtonVariable = By.cssSelector("[class*='mr-3'] [class='p-radiobutton-box']");
    private final By buttonExpandDueDateMenu = By.cssSelector("[class='p-dropdown-trigger']");
    private final By radiobuttonCss = By.cssSelector("[class='p-radiobutton-box']");
    private final By buttonParallel = By.cssSelector("div[aria-labelledby='Параллельное']");
    private final By checkBoxInModalWindow = By.cssSelector("[class='p-checkbox-box']");
    private final By buttonConsistent = By.cssSelector("div[aria-labelledby='Последовательное']");
    private final By buttonAgreed = By.cssSelector("elma-switch div[aria-labelledby='Согласовано']");
    private final By radiobuttonManually = By.xpath("//elma-modal-window//label[contains(text(),'Вручную')]");
    private final By checkboxAbort = By.cssSelector("div[class='d-flex align-items-center'] div[class='p-checkbox-box']");


    /**
     * Элемент оргструктуры в настройках зоны ответственности
     */
    private final By orgStructurePositionElementCss = By.cssSelector("div[role='dialog'] div[class='os-item']:first-child");
    private final By buttonSettingZoneCss = By.cssSelector("span[class*='p-button-text']");
    private final By osItemCss = By.cssSelector(".os-item");
    private final By itemsInCreateFormCss = By.cssSelector("div[class*='form-fields'] ngx-dnd-item");
    private final By checkBoxReadOnlyCss = By.cssSelector("elma-checkbox[name='readonly'] div[class*='checkbox']");
    private final By buttonDeleteXpath = By.xpath("//button[contains(text(),'Удалить')]");
    private final By scheduledRunCheckboxXpath = By.xpath("//elma-form-row//span[contains(text(), 'Расписание')]/../..//p-checkbox");
    private final By doNotRepeatRadioXpath = By.xpath("//p-radiobutton//label[contains(text(), 'Однократно')]");
    private final By scheduledRunTimeXpath = By.xpath("//elma-time");
    private final By scheduledRunTimeInputCss = By.cssSelector("elma-time input[class*='p-inputtext']");
    private final By featuresCss = By.cssSelector("app-form-editor-context-field span");

    public void fillNameBlock(String newName) {
        SelenideElement textBox = $(blockNameSettingCss).shouldBe(visible);
        textBox.clear();
        textBox.sendKeys(newName);
    }

    public void clickAddNewFunction() {
        $(addNewFunctionCss).shouldBe(visible).click();
    }

    public void fillFunctionName(String functionName) {
        SelenideElement element = $(nameFieldCss).shouldBe(visible);
        element.click();
        element.sendKeys(functionName);
    }

    public void clickCreateFunction() {
        $(createCss).shouldBe(visible).click();
    }

    public void clickOpenFunction() {
        $(openFunctionCss).shouldBe(visible).click();
    }

    public void selectFunction(String functionName) {
        $(functionArrowCss).shouldBe(exist).click();
        $(functionsInDropdownCss).shouldBe(visible)
                .$$(functionNameCss).findBy(text(functionName)).shouldBe(visible).click();
    }

    public void clickSelectProcess() {
        $(selectProcessCss).shouldBe(visible).click();
    }

    public void clickSyncOrAsyncStart() {
        $(syncOrAsyncStartCss).shouldBe(visible).click();
    }

    /**
     * Выбор исполнителя для зоны ответственности.
     */
    public void selectExecutorInZoneResponsibility() {
        $(orgStructurePositionElementCss).click();
    }

    public void chooseTab(String tabName) {
        $$(tabSetNames).findBy(text(tabName)).shouldBe(visible).click();
    }

    public void createDefaultForm() {
        chooseTab("Форма");
        $(formSelectorCss).shouldBe(visible).click();
        $(createFormButtonXpath).shouldBe(visible).click();
    }

    public void openExistingForm() {
        chooseTab("Форма");
        $(editExistingFormButtonXpath).shouldBe(visible).click();
    }

    public void setContextVariable(String contextVariableName) {
        chooseTab("Форма");
        $$(contextFields).findBy(text(contextVariableName)).$("i").shouldBe(visible).click();
    }

    public void noteContextVariable(String contextVariableName) {
        $$(contextFields).findBy(text(contextVariableName)).shouldBe(visible).click();
    }

    public void clickContentButtonSettingWindow(String buttonName) {
        $$(modalContentButtonsCss).findBy(text(buttonName)).shouldBe(visible, enabled).click();
    }

    public void clickButtonSettingZone(String buttonName) {
        $$(buttonSettingZoneCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void selectOrgStructure(String structureName) {
        $$(osItemCss).findBy(text(structureName)).shouldBe(visible).scrollTo().click();
    }

    public void setConditionReadOnlyField(String name, boolean condition) {
        SelenideElement element = $$(itemsInCreateFormCss).findBy(text(name)).shouldBe(visible);
        if ($$(itemsInCreateFormCss).findBy(text(name)).shouldBe(visible).$(".form-check.readonly .p-checkbox").is(Condition.cssClass("p-checkbox-checked")) != condition)
            element.$(checkBoxReadOnlyCss).shouldBe(visible).click();
    }

    public void clickCheckBoxLimitDeadline() {
        $(checkBoxLimitDeadline).shouldBe(visible).click();
    }

    public void inputDateLimitDeadline(int date) {
        $(inputDateLimitDeadline).shouldBe(visible).sendKeys(valueOf(date));
    }

    public void inputTimeMinuteLimitDeadline(int timeMinute) {
        $(inputTimeMinuteLimitDeadline).shouldBe(visible).sendKeys(valueOf(timeMinute));
    }

    public void removeCheckMarkFromTakeIntoAccountWorkCalendar() {
        $(checkBoxFromTakeIntoAccountWorkCalendar).shouldBe(visible).click();
    }

    public void checkBoxFormNameOfTaskAccordToTemplate() {
        $(checkBoxFormNameOfTaskAccordToTemplate).shouldBe(visible).click();
    }

    public void inputPattern(String pattern) {
        $(inputPattern).shouldBe(visible).sendKeys(pattern);
    }

    public void checkboxScheduleTaskInCalendar() {
        $(checkboxScheduleTaskInCalendar).shouldBe(visible).click();
    }

    public void selectDateStartAndFinish() {
        $(inputDateStart).shouldBe(visible).click();
        $(dayStartXpath).shouldBe(visible).click();
        $(inputDateFinish).shouldBe(visible).click();
        $(dayEndXpath).shouldBe(visible).click();
    }

    public void clickItemContextMenu(String itemName) {
        $$(itemsMenuFileCss).findBy(text(itemName)).shouldBe(visible).click();
    }

    public void inputDateInColumnVariable(String itemName, LocalDate date) {
        $(String.format("input[id='%s']", itemName.toLowerCase())).shouldBe(visible).sendKeys(date.format(FORMATTER_DD_MM_YYYY));
        $(iconTimeCss).click();
    }

    public void clickRadioButtonVariable() {
        $(radioButtonVariable).shouldBe(visible).click();
    }

    public void expandDueDateMenuAndSelect(String name) {
        $$(buttonExpandDueDateMenu).findBy(visible).click();
        $$(String.format("[aria-label='%s']", name)).findBy(visible).click();
    }

    public void clickRadioButton() {
        $$(radiobuttonCss).findBy(visible).click();
    }

    public void setNonRepeatableScheduledRunToday(String time) {
        $(scheduledRunCheckboxXpath).shouldBe(visible).click();
        $(doNotRepeatRadioXpath).shouldBe(visible).click();
        $(scheduledRunTimeXpath).shouldBe(visible).click();
        $(scheduledRunTimeInputCss).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, time.replace(":", ""));
    }

    public void clickButtonZoomAllWithRowName(String rowName) {
        $(By.xpath("//elma-form-row[contains(.,'" + rowName + "')]//button[contains(text(),'tool_zoom_all')]")).shouldBe(visible).hover().click();
    }

    public void expandMenuOfSelectedFieldAndSelectType(String nameField, String typeName) {
        String expandMenuField = "//span[contains(text(),'%s')]/ancestor::elma-form-row//div[contains(@aria-label,'dropdown trigger')]";
        $(By.xpath(String.format(expandMenuField, nameField))).shouldBe(visible).click();
        $(String.format("li[aria-label*='%s']", typeName)).shouldBe(visible).click();
    }

    public void expandMenuOfSelectedFieldAndSelectType(String nameField, int index, String typeName) {
        String expandMenuField = "//span[contains(text(),'%s')]/ancestor::elma-form-row//elma-form-control/div[%s]//div[contains(@aria-label,'dropdown trigger')]";
        $(By.xpath(String.format(expandMenuField, nameField, index))).shouldBe(visible).click();
        $(String.format("li[aria-label*='%s']", typeName)).shouldBe(visible).click();
    }

    public void expandMenuWaitStatusAndSelectStatus(String statusName) {
        String expandMenuField = "//span[contains(text(),'Ожидать статус')]/ancestor::elma-form-row//div[contains(@class,'p-multiselect-trigger')]";
        $(By.xpath(expandMenuField)).shouldBe(visible).click();
        $(String.format("li[aria-label*='%s']", statusName)).shouldBe(visible).click();
    }

    public void clickButtonParallel() {
        $(buttonParallel).shouldBe(visible).click();
    }

    public void clickButtonConsistent() {
        $(buttonConsistent).shouldBe(visible).click();
    }

    public void clickButtonAgreed() {
        $(buttonAgreed).shouldBe(visible).click();
    }

    public void checkBoxLeaveOnlyActualParticipants() {
        $$(checkBoxInModalWindow).findBy(visible).click();
    }

    public void clickRadiobuttonManually() {
        $(radiobuttonManually).shouldBe(visible).click();
    }

    public void checkBoxAllowSelectCaseInAssignedTask() {
        $$(checkBoxInModalWindow).findBy(visible).click();
    }

    public void clickCheckboxAbortAndSelectNextStep() {
        $(checkboxAbort).shouldBe(visible).click();
        expandMenuOfSelectedFieldAndSelectType("Прервать", "-> Задача 1");
    }

    public void clickRadioButtonByName(String name) {
        String radiobuttonByName = "//button[contains(text(),'%s')]/ancestor::ngx-dnd-item//div[contains(@class,'p-radiobutton-box')]";
        $$(By.xpath(String.format(radiobuttonByName, name))).last(1).findBy(visible).click();
    }

    public void deleteFeature(String name) {
        $$(featuresCss).findBy(text(name)).shouldBe(visible).click();
        $(buttonDeleteXpath).click();
    }

    public void setDaysHoursMinutes(int days, int hours, int minutes) {
        String dateTimeXpath = "//span[text()='%s']/following-sibling::elma-number[1]//input";
        $(By.xpath(String.format(dateTimeXpath, "Дни:"))).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, String.valueOf(days));
        $(By.xpath(String.format(dateTimeXpath, "Часы:"))).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, String.valueOf(hours));
        $(By.xpath(String.format(dateTimeXpath, "Минуты:"))).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, String.valueOf(minutes));
    }
}