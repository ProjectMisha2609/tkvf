package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class NotificationModal extends BasePage {

    private final By receiversXpath = By.xpath("//app-receivers//span");
    private final By messageThemeInputXpath = By.xpath("//span[contains(text(),'Тема сообщения')]/../..//input");
    private final By messageTextInputXpath = By.xpath("//span[contains(text(),'Текст сообщения')]/../..//textarea");
    private final By messageAuthorRadioXpath = By.xpath("//span[contains(text(),'Автор')]/../..//label");
    private final By addMessageReceiversButtonXpath = By.xpath("//app-receivers//button[contains(text(), 'Добавить')]");
    private final By messageReceiversRadioXpath = By.xpath("//app-receiver-add//elma-radiobutton//label");
    private final By deleteMessageReceiverButtonXpath = By.xpath("//app-receivers//button[contains(@class,'button-remove')]");
    private final By variableDropdownItemXpath = By.xpath("//p-dropdownitem//span");
    private final By groupDropdownItemXpath = By.xpath("//elma-icon-label-option//span");
    private final By orgStructureElementDropdownItemXpath = By.xpath("//elma-os-item//span");
    private final By groupOrVariableDropdownTriggerXpath = By.xpath("//span[contains(@class,'p-dropdown-trigger-icon')]");
    private final By orgStructureDropdownTriggerXpath = By.xpath("//span[contains(@class,'selectbox-arrow')]");
    private final By contextVariableAuthorDropdownCss = By.cssSelector("p-dropdown");
    private final By contextVariableAuthorDropdownItemCss = By.cssSelector("p-dropdownitem elma-icon-label-option span");

    public void fillTheme(String theme) {
        $(messageThemeInputXpath).shouldBe(visible).sendKeys(theme);
    }

    public void fillText(String text) {
        $(messageTextInputXpath).shouldBe(visible).sendKeys(text);
    }

    public void setContextVariableAuthor(String user) {
        $$(messageAuthorRadioXpath).findBy(text("Контекстная переменная")).shouldBe(visible).click();
        $(contextVariableAuthorDropdownCss).shouldBe(visible).click();
        $$(contextVariableAuthorDropdownItemCss)
                .findBy(text(user)).shouldBe(visible).click();
    }

    public void setAuthor(String author) {
        $$(messageAuthorRadioXpath).findBy(text(author)).shouldBe(visible).click();
    }

    public void addRecipient(String... recipient) {
        $(addMessageReceiversButtonXpath).shouldBe(visible).click();
        $$(messageReceiversRadioXpath).findBy(text(recipient[0])).shouldBe(visible).click();
        if (recipient[0].contains("пользователь")) {
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[0])).shouldBe(visible);
        } else if (recipient[0].contains("оргструктуры")) {
            $(orgStructureDropdownTriggerXpath).shouldBe(visible).click();
            $$(orgStructureElementDropdownItemXpath).findBy(text(recipient[1])).shouldBe(visible).click();
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[1])).shouldBe(visible);
        } else if (recipient[0].contains("Группа")) {
            $(groupOrVariableDropdownTriggerXpath).shouldBe(visible).click();
            $$(groupDropdownItemXpath).findBy(text(recipient[1])).scrollTo().shouldBe(visible).click();
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[1])).shouldBe(visible);
        } else if (recipient[0].contains("переменная")) {
            $(groupOrVariableDropdownTriggerXpath).shouldBe(visible).click();
            $$(variableDropdownItemXpath).findBy(text(recipient[1])).scrollTo().shouldBe(visible).click();
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[1])).shouldBe(visible);
        }
    }

    public void deleteRecipient() {
        $(deleteMessageReceiverButtonXpath).shouldBe(visible).click();
    }
}
