package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class EmailNotificationModal extends BasePage {

    private final By breakCheckBoxIndicatorXpath = By.xpath("//span[contains(text(),'Прервать')]/../..//div//span");
    private final By breakCheckBoxXpath = By.xpath("//span[contains(text(),'Прервать')]/../..//div");
    private final By alertCheckBoxIndicatorXpath = By.xpath("//span[contains(text(),'Оповещение')]/../..//div//span[contains(@class,'p-checkbox-icon')]");
    private final By alertCheckBoxXpath = By.xpath("//span[contains(text(),'Оповещение')]/../..//div[contains(@class,'p-checkbox-box')]");
    private final By receiverInputXpath = By.xpath("//span[contains(text(),'Получатель')]/../..//input");
    private final By themeInputXpath = By.xpath("//span[contains(text(),'Тема письма')]/../..//input");
    private final By textInputXpath = By.xpath("//span[contains(text(),'Текст письма')]/../..//textarea");
    private final By transitionSelectorXpath = By.xpath("//span[contains(text(),'Переход')]/../..//elma-select");
    private final By transitionDropdownItemsXpath = By.xpath("//p-dropdownitem//elma-icon-label-option//span");
    private final By addAlertReceiverButtonXpath = By.xpath("//elma-tab[contains(@class,'active')]//button[contains(text(),'Добавить')]");
    private final By alertReceiversRadioXpath = By.xpath("//app-receiver-add//elma-radiobutton//label");
    private final By receiversXpath = By.xpath("//app-receivers//span");
    private final By variableDropdownItemXpath = By.xpath("//p-dropdownitem//span");
    private final By groupDropdownItemXpath = By.xpath("//elma-icon-label-option//span");
    private final By orgStructureElementDropdownItemXpath = By.xpath("//elma-os-item//span");
    private final By groupDropdownTriggerXpath = By.xpath("//span[contains(text(),'Выберите группу')]");
    private final By orgStructureDropdownTriggerXpath = By.xpath("//span[contains(@class,'selectbox-arrow')]");
    private final By variableDropdownTriggerXpath = By.xpath("//span[contains(text(),'Выберите переменную')]");

    public void fillRecipient(String email) {
        $(receiverInputXpath).shouldBe(visible).sendKeys(email);
    }

    public void fillTheme(String theme) {
        $(themeInputXpath)
                .shouldBe(visible).sendKeys(theme);
    }

    public void fillText(String text) {
        $(textInputXpath)
                .shouldBe(visible).sendKeys(text);
    }

    public void setBreakCheckbox(boolean condition) {
        $(breakCheckBoxXpath).shouldBe(visible);
        if ($(breakCheckBoxIndicatorXpath).is(cssClass("pi-check")) != condition) {
            $(breakCheckBoxXpath).click();
        }
    }

    public void setTransition(String option) {
        $(transitionSelectorXpath).shouldBe(visible).click();
        $$(transitionDropdownItemsXpath).findBy(text(option)).shouldBe(visible).click();
    }

    public void setAlertRecipientsIfFail(String... recipient) {
        $(alertCheckBoxXpath).shouldBe(visible);
        if (!$(alertCheckBoxIndicatorXpath).is(cssClass("pi-check")))
            $(alertCheckBoxXpath).click();
        $(addAlertReceiverButtonXpath).shouldBe(visible).click();
        $$(alertReceiversRadioXpath).findBy(text(recipient[0])).shouldBe(visible).click();
        if (recipient[0].contains("пользователь")) {
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[0])).shouldBe(visible);
        } else if (recipient[0].contains("оргструктуры")) {
            $(orgStructureDropdownTriggerXpath).shouldBe(visible).click();
            $$(orgStructureElementDropdownItemXpath).findBy(text(recipient[1])).shouldBe(visible).click();
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[1])).shouldBe(visible);
        } else if (recipient[0].contains("Группа")) {
            $(groupDropdownTriggerXpath).shouldBe(visible).click();
            $$(groupDropdownItemXpath).findBy(text(recipient[1])).scrollTo().shouldBe(visible).click();
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[1])).shouldBe(visible);
        } else if (recipient[0].contains("переменная")) {
            $(variableDropdownTriggerXpath).shouldBe(visible).click();
            $$(variableDropdownItemXpath).findBy(text(recipient[1])).scrollTo().shouldBe(visible).click();
            dialogWindowPressButton("Выбрать");
            $$(receiversXpath).findBy(text(recipient[1])).shouldBe(visible);
        }
    }
}
