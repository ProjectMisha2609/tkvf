package pages.elmaModals;

import com.codeborne.selenide.Condition;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class SelectProcessModal extends BasePage {
    private final By processContainerCss = By.cssSelector("div[role='dialog'] elma-tree");
    private final By processCss = By.cssSelector("div[role='treeitem'] span.p-treenode-label");
    private final By fieldsModalCss = By.cssSelector("elma-tab.active div.modal-body elma-form-row elma-form-control");
    private final By fieldSettingsBtnCss = By.cssSelector("app-bpm-bind [class*='form-control'] button");
    private final By systemProcessesCss = By.cssSelector("button[class*=btn-link]");
    private final By systemProcessesOptionsBodyCss = By.cssSelector("app-bptemplate-admin-page-tree-category");
    private final By systemProcessesOptionCss = By.cssSelector("a");

    @Deprecated // В base modal есть метод, опционально раскрывающий папки/приложения что бы выбрать процесс.
    public void selectProcessByName(String processName) {
        $(processContainerCss)
                .shouldBe(visible)
                .$$(processCss).findBy(text(processName)).shouldBe(visible).click();
    }

    public void checkProcessAddedInProcessBlock(String processName) {
        $$(fieldsModalCss).findBy(text(processName)).shouldBe(visible);
    }

    public void checkProcessAddedInButtonRun(String processName) {
        $$(fieldSettingsBtnCss).findBy(text(processName)).shouldBe(visible);
    }

    public void selectFromSystemProcesses(String option) {
        $$(systemProcessesCss).findBy(Condition.text("Системные процессы")).shouldBe(visible).click();
        $(systemProcessesOptionsBodyCss).shouldBe(visible)
                .$$(systemProcessesOptionCss).findBy(Condition.text(option)).shouldBe(visible).click();
    }
}