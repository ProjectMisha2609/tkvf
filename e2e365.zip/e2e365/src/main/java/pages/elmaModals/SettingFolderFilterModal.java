package pages.elmaModals;

import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class SettingFolderFilterModal extends BasePage {
    private final By buttonMainSettingFilterCss = By.cssSelector("div.search-control-group button.search-control");
    private final By footerButtonsCss = By.cssSelector(".footer button");
    private final By inputNewNameFilterCss = By.cssSelector(".footer input");
    private final By listFiltersCss = By.cssSelector("app-appview-search-filter");
    private final By searchFilterTitleListCss = By.cssSelector("app-appview-search-filters .title");

    public void clickButtonMainSettingFilter() {
        $(buttonMainSettingFilterCss).shouldBe(visible).click();
    }

    public void setParameterInputSearchBox(String rowName, String inputText) {
        $(By.xpath("//app-appview-search-row[contains(.,'" + rowName + "')] //input[@role='searchbox']")).shouldBe(visible).sendKeys(inputText);
    }

    public void setParameterSingleInput(String rowName, String inputText) {
        $(By.xpath("//app-appview-search-row[contains(.,'" + rowName + "')] //input")).shouldBe(visible).sendKeys(inputText);
    }

    public void clickParameterSingleButton(String rowName) {
        $(By.xpath("//app-appview-search-row[contains(.,'" + rowName + "')] //button")).shouldBe(visible).click();
    }

    public void setParameterMinDate(String rowName) {
        $(By.xpath("//app-appview-search-row[contains(.,'" + rowName + "')] //elma-type-datetime[@formcontrolname='min'] //input")).shouldBe(visible).click();
    }

    public void setParameterMaxDate(String rowName) {
        $(By.xpath("//app-appview-search-row[contains(.,'" + rowName + "')] //elma-type-datetime[@formcontrolname='max'] //input")).shouldBe(visible).click();
    }

    public void clickParameterCheckBox(String rowName, String checkBoxName) {
        $(By.xpath("//app-appview-search-row[contains(.,'" + rowName + "')] //p-checkbox //*[contains(.,'" + checkBoxName + "')]")).shouldBe(visible).click();
    }

    public void clickFooterButton(String buttonName) {
        $$(footerButtonsCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void setNameNewFilter(String newFilterName) {
        $(inputNewNameFilterCss).shouldBe(visible).click();
        $(inputNewNameFilterCss).shouldBe(visible).sendKeys(newFilterName);
    }

    public void checkFilterExistsOnList(String filterName) {
        $$(listFiltersCss).findBy(text(filterName)).shouldBe(visible).exists();
    }

    public void chooseSearchFilterFromList(String filterName) {
        $$(searchFilterTitleListCss).findBy(text(filterName)).shouldBe(visible).click();
    }

    public void closeSettingPageWithKeyESCAPE() {
        CustomDriver.getAction().sendKeys(Keys.ESCAPE).perform();
    }

    public void clickButtonInPopoverBody(String buttonName) {
        $(By.xpath("//elma-popover-body//button[contains(text(),'" + buttonName + "')]"))
                .shouldBe(visible).click();
    }
}
