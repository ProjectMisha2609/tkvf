package pages.elmaModals;

import com.codeborne.selenide.Condition;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

@Singleton
public class LogicGatewaySettingsModal extends BasePage {
    private final By addConditionButtonXpath = By.xpath("//button[contains(text(),'Условие')]");
    private final By notDefinedParameterButtonXpath = By.xpath("//button[contains(text(),'Не определен')]");
    private final By dropdownParametersCss = By.cssSelector("elma-popover-menu-option span");
    private final By yesNoButtonsCss = By.cssSelector("p-selectbutton div");
    private final By variableUsageCheckboxCss = By.cssSelector("app-gateway-settings div[class*='p-checkbox-box']");
    private final By serviceVariableTypeDropdownXpath = By.xpath("//elma-form-label/span[text()='Тип']/../../elma-form-control");
    private final By dropdownOptionsCss = By.cssSelector("p-dropdownitem");
    private final By scenarioNameInputXpath = By.xpath("//elma-script-select//button[contains(text(),'Создать')]/../input");
    private final By createScenarioButtonXpath = By.xpath("//elma-script-select//button[contains(text(),'Создать')]");
    private final By openScenarioButtonXpath = By.xpath("//elma-script-select//button[contains(text(),'Открыть')]");
    private final By functionInnerLineXpath = By.xpath("//div[@class='view-lines monaco-mouse-cursor-text']/div[3]");
    private final By operandButtonXpath = By.xpath("//button[contains(text(),'=')]");
    private final By numericInputCss = By.cssSelector("input[inputmode='decimal']");
    private final By monacoErrorXpath = By.xpath("//div[contains(@class, 'squiggly-error')] ");

    public void addBooleanCondition(String parameter, String condition) {
        $(addConditionButtonXpath).shouldBe(visible).click();
        $(notDefinedParameterButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text(parameter)).shouldBe(visible).click();
        $(notDefinedParameterButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text("Ввести значение")).shouldBe(visible).click();
        $$(yesNoButtonsCss).findBy(Condition.attribute("aria-label", condition))
                .shouldBe(visible).click();
    }

    public void addConditionWithNonNullCheck(String parameter, String check) {
        $(addConditionButtonXpath).shouldBe(visible).click();
        $(notDefinedParameterButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text(parameter)).shouldBe(visible).click();
        $(operandButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text(check)).shouldBe(visible).click();
    }

    public void addConditionIntCheck(String parameter, String operand, int check) {
        $(addConditionButtonXpath).shouldBe(visible).click();
        $(notDefinedParameterButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text(parameter)).shouldBe(visible).click();
        $(operandButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text(operand)).shouldBe(visible).click();
        $(notDefinedParameterButtonXpath).shouldBe(visible).click();
        $$(dropdownParametersCss).findBy(text("Ввести значение")).shouldBe(visible).click();
        $(numericInputCss).shouldBe(visible).sendKeys(String.valueOf(check));
    }

    public void clickServiceVariableUsage() {
        $(variableUsageCheckboxCss).shouldBe(visible).click();
    }

    public void setServiceVariable(String text) {
        $(serviceVariableTypeDropdownXpath).shouldBe(visible).click();
        $$(dropdownOptionsCss).findBy(text(text)).shouldBe(visible).click();
    }

    public void createAndOpenScenario(String name) {
        $(createScenarioButtonXpath).shouldBe(visible).click();
        // кнопок "создать" зачем-то две друг над другом, сохраняю имя через enter
        $(scenarioNameInputXpath).shouldBe(visible).sendKeys(name, Keys.ENTER);
        $(openScenarioButtonXpath).shouldBe(visible).click();
    }

    public void fillFunction(String function) {
        $(functionInnerLineXpath).shouldBe(visible);
        $(monacoErrorXpath).shouldBe(visible);
        actions().sendKeys(function).perform();
        $(monacoErrorXpath).should(disappear);
        CustomDriver.waitMills(1000);
    }


}
