package pages.elmaModals;

import infrastructure.utils.Constants;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;
import java.nio.file.Paths;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class ImportElementsModal extends BasePage {
    private final By importAreaCss = By.cssSelector("[data-test=uploadFileI] input");
    private final By elementNameCss = By.cssSelector("div[class='tile-view'] span[class='ng-star-inserted']");
    private final By fileDeleteBtnCss = By.cssSelector("span[data-test='uploadedFileNameS'] ~ button");

    public void importFile() {
        $(importAreaCss)
                .uploadFile(new File(Paths.get(Constants.PATH_TO_DEFAULT_DIR,
                        "testData",
                        "dataImportElementsTest.xlsx").toString()));
        $(fileDeleteBtnCss).shouldBe(visible);
    }

    public void checkElementExist(String text) {
        $(elementNameCss).shouldBe(visible).shouldHave(text(text));
    }
}