package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class NomenclatureModal extends BasePage {
    private final By dropDownItemCss = By.cssSelector("li.p-dropdown-item");

    public void setParameterSingleInput(String rowName, String inputText) {
        $(By.xpath("//app-nomenclature//elma-form-row[contains(.,'" + rowName + "')]//input")).shouldBe(visible).sendKeys(inputText);
    }

    public void clearParameterSingleInput(String rowName) {
        $(By.xpath("//app-nomenclature//elma-form-row[contains(.,'" + rowName + "')]//input")).shouldBe(visible).clear();
    }

    public void setParameterCheckBox(String rowName, String checkBoxName) {
        $(By.xpath("//app-nomenclature//elma-form-row[contains(.,'" + rowName + "')]//p-checkbox[contains(.,'" + checkBoxName + "')]")).shouldBe(visible).click();
    }

    public void setInnerParameterSingleInput(String rowName, String inputText) {
        $(By.xpath("//elma-form-control//elma-form-row[contains(.,'" + rowName + "')]//input")).shouldBe(visible).sendKeys(inputText);
    }

    public void clearInnerParameterSingleInput(String rowName) {
        $(By.xpath("//elma-form-control//elma-form-row[contains(.,'" + rowName + "')]//input")).shouldBe(visible).clear();
    }

    public void clickInnerParameterButton(String rowName) {
        $(By.xpath("//elma-form-control//elma-form-row[contains(.,'" + rowName + "')]//button")).shouldBe(visible).click();
    }

    public void chooseParameterRadioButton(String rowName, String buttonName) {
        $$(By.xpath("//app-nomenclature//elma-form-row[contains(.,'" + rowName + "')]//p-radiobutton")).findBy(text(buttonName)).shouldBe(visible).click();
    }

    public void clickAndSelectDropDownItemWithNameForm(String titleForm, String dropDownLabelName, String itemName) {
        $$(By.xpath("//elma-modal-window[contains(.,'" + titleForm + "')]//p-dropdown")).findBy(text(dropDownLabelName)).shouldBe(visible).click();
        $$(dropDownItemCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    public void clearInputWithNameForm(String titleForm) {
        $(By.xpath("//elma-modal-window[contains(.,'" + titleForm + "')]//input")).shouldBe(visible).clear();
    }

    public void setInputWithNameForm(String titleForm, String number) {
        $(By.xpath("//elma-modal-window[contains(.,'" + titleForm + "')]//input")).shouldBe(visible).sendKeys(number);
    }
}
