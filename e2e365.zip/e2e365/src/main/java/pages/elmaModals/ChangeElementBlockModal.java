package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class ChangeElementBlockModal extends BasePage {
    private final By rowButtonFieldOnBindingTableCss = By.cssSelector("app-binding-table button:not([disabled])");
    private final By rowButtonFieldOnAppConditionCss = By.cssSelector("app-condition button:not([disabled])");
    private final By itemMenuCss = By.cssSelector("div.visible .ctx-menu__text");
    private final By operandInputCss = By.cssSelector("app-condition input");
    private final By inputManualBindingCss = By.cssSelector("input[id='__name']");

    public void setAppBinding(String fieldAppName, String contextVariableName) {
        $$(rowButtonFieldOnBindingTableCss).findBy(text("Выберите поле")).shouldBe(visible).click();
        $$(itemMenuCss).findBy(text(fieldAppName)).shouldBe(visible).click();
        $$(rowButtonFieldOnBindingTableCss).findBy(text("Выберите поле")).shouldBe(visible).click();
        $$(itemMenuCss).findBy(text(contextVariableName)).shouldBe(visible).click();
    }

    public void setFieldAppBinding(String... pathFieldApp) {
        $$(rowButtonFieldOnBindingTableCss).findBy(text("Выберите поле")).shouldBe(visible).click();
        for (String item : pathFieldApp) {
            $$(itemMenuCss).findBy(text(item)).shouldBe(visible).click();
        }
    }

    public void setFieldContextBPBinding(String... pathToVariable) {
        $$(rowButtonFieldOnBindingTableCss).findBy(text("Выберите поле")).shouldBe(visible).click();
        for (String item : pathToVariable) {
            $$(itemMenuCss).findBy(text(item)).shouldBe(visible).click();
        }
    }

    public void checkChooseFieldBinding(String fieldName) {
        $$(rowButtonFieldOnBindingTableCss).findBy(text(fieldName)).shouldBe(visible);
    }

    public void setDisplayConditionField(String... pathToVariable) {
        $$(rowButtonFieldOnAppConditionCss).findBy(text("<Не определен>")).shouldBe(visible).click();
        for (String item : pathToVariable) {
            $$(itemMenuCss).findBy(text(item)).shouldBe(visible).click();
        }
    }

    public void setDisplayConditionFieldManually(String userText, String... pathToVariable) {
        $$(rowButtonFieldOnAppConditionCss).findBy(text("<Не определен>")).shouldBe(visible).click();
        for (String item : pathToVariable) {
            $$(itemMenuCss).findBy(text(item)).shouldBe(visible).click();
        }
        $(operandInputCss).shouldBe(visible).sendKeys(userText);
    }

    public void setManualTextInput(String text) {
        $(inputManualBindingCss).shouldBe(visible).sendKeys(text);
    }
}
