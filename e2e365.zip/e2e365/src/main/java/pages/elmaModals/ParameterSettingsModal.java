package pages.elmaModals;

import com.codeborne.selenide.ElementsCollection;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Класс для работы с модальными окнами дополнительных параметров и колонок таблицы.
 * В связи с тем, что одинаковые модальные окна могут рекурсивно накладываться друг на друга,
 * а в их состоянии это никак не отражается, во вложенном статичном классе реализован
 * итеративные методы клика и ввода до успешного исхода.
 * <p>
 * Все итеративные методы хранятся во вложенном статичном классе, во избежание случайных обращений.
 * Все локаторы хранятся как статичные, для доступа к ним из вложенного класса.
 */
@Singleton
public class ParameterSettingsModal extends BasePage {
    private static final By companyPatternsSectionXpath = By.xpath("//elma-form-control//span[contains(., 'Шаблоны компании')]");
    private static final By parameterNameInputXpath = By.xpath("//elma-form-row//span[contains(., 'Отображаемое имя')]/../..//input");
    private static final By valueInputXpath = By.xpath("//elma-form-row//span[contains(., 'Значение')]/../..//input");
    private static final By hintInputXpath = By.xpath("//elma-form-row//span[contains(., 'Подсказка')]/../..//input");
    private static final By typeDropdownXpath = By.xpath("//elma-form-row//span[contains(., 'Тип')]/../..//p-dropdown");
    private static final By overlayDropdownOptionsCss = By.cssSelector("div[class*='p-overlay-content'] li[role*=option]");
    private static final By overlayDropdownOptionsNameXpath = By.xpath("//div[contains(@class, 'p-overlay-content')]//li[contains(@role,'option')]//span");
    private static final By tableSettingsButtonXpath = By.xpath("//button[contains(., 'Настройка таблицы')]");
    private final By itemsMenuFileCss = By.cssSelector(".ctx-menu__text");
    private final By dropDownCss = By.cssSelector("elma-modal-window .p-dropdown");
    private final By dropDownItemCss = By.cssSelector("li.p-dropdown-item");
    private final By selectBoxCss = By.cssSelector(".selectbox-input");
    private final By selectBoxItemCss = By.cssSelector(".os-item");
    private final By checkbox = By.xpath("//elma-form-row//span[contains(., 'Прервать')]/../..//elma-checkbox");
    private final By dropdownItemCss = By.cssSelector(".p-dropdown-item");
    private final By fileUploaderCss = By.cssSelector("elma-modal-body elma-file-uploader");
    private static final By processSelectorButtonXpath = By.xpath("//button[contains(., 'Выберите процесс')]");

    /**
     * вызов вложенного класса с итеративными методами
     */
    public IterativeMethods iterativeMethods() {
        return new IterativeMethods();
    }

    public void checkSelectedSectionIsCompanyPatterns() {
        $(companyPatternsSectionXpath).scrollTo().shouldBe(visible);
    }

    public void fillParameterValue(String value) {
        $(valueInputXpath).scrollTo().shouldBe(visible).sendKeys(value);
    }

    public void clickTableParameters() {
        $(tableSettingsButtonXpath).scrollTo().shouldBe(visible).click();
    }

    public void fillParameterName(String name) {
        $(parameterNameInputXpath).scrollTo().shouldBe(visible).sendKeys(name);
    }

    public void clearParameterName() {
        $(parameterNameInputXpath).scrollTo().shouldBe(visible).clear();
    }

    public void selectParameterTypeByText(String name) {
        $(typeDropdownXpath).click();
        $$(overlayDropdownOptionsCss).findBy(text(name)).scrollTo().click();
    }

    public void selectParameterTypeByAriaLabel(String name) {
        $(typeDropdownXpath).click();
        $$(overlayDropdownOptionsCss).findBy(attribute("aria-label", name)).scrollTo().click();
    }

    public void fillParameterHint(String parameterHint) {
        $(hintInputXpath).scrollTo().shouldBe(visible).sendKeys(parameterHint);
    }

    public void checkSelectedSectionName(String sectionName) {
    }

    /* TODO: тикет по видимости фоновых модальных окон:
        нет css класса, определяющего видимое "верхнее" окно, или затенённые фоновые окна
         все модальные окна считаются видимыми и активными, локаторы цепляют элементы фоновых,
          средствами selenide даже можно ввести текст в фоновое окно */
    public static class IterativeMethods {

        /**
         * Метод, позволяющий перебирать коллекцию элементов и кликать, пока не получится.
         *
         * @param elements - коллекция элементов для попыток клика.
         * @return порядковый номер элемента, который удалось кликнуть.
         */
        public int clickUntilItClicks(ElementsCollection elements) {
            boolean clicked = false;
            int iterator = 0;
            while (!clicked & iterator < 10) {
                try {
                    elements.get(iterator).click();
                    clicked = true;
                } catch (Throwable e) {
                    iterator++;
                }
            }
            return iterator;
        }

        public void fillParameterName(String name) {
            ElementsCollection elements = $$(parameterNameInputXpath);
        /* что бы понять куда вводить, нужно выяснить какой элемент кликабелен,
         иначе ввод происходит в неактивное окно, что даже не вызывает ошибки selenide */
            elements.get(clickUntilItClicks(elements)).scrollTo().shouldBe(visible).sendKeys(name);
        }

        public void selectParameterType(String name) {
            ElementsCollection elements = $$(typeDropdownXpath);
            clickUntilItClicks(elements);
            $$(overlayDropdownOptionsCss).findBy(text(name)).scrollTo().click();
        }

        public void selectExactParameterType(String name) {
            ElementsCollection elements = $$(typeDropdownXpath);
            clickUntilItClicks(elements);
            $$(overlayDropdownOptionsNameXpath).findBy(exactText(name)).scrollTo().click();
        }
    }

    public void clickButtonOnField(String fieldName) {
        $(By.xpath("//span[text()='" + fieldName + "']/../..//button")).hover().shouldBe(visible).click();
    }

    public void clickItemContextMenu(String itemName) {
        $$(itemsMenuFileCss).findBy(text(itemName)).shouldBe(visible).click();
    }

    public void clickAndSelectDropDownItem(String dropDownLabelName, String itemName) {
        $$(dropDownCss).findBy(text(dropDownLabelName)).shouldBe(visible).click();
        $$(dropDownItemCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    public void clickAndSelectBoxItem(String selectBoxLabelName, String itemName) {
        $$(selectBoxCss).findBy(text(selectBoxLabelName)).shouldBe(visible).click();
        $$(selectBoxItemCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    public void clickCheckBoxOnField(String fieldName) {
        $(By.xpath("//span[text()='" + fieldName + "']/../..//elma-checkbox")).hover().shouldBe(visible).click();
    }

    public void clickDropDownOnField(String fieldName) {
        $(By.xpath("//span[text()='" + fieldName + "']/../..//p-dropdown")).hover().shouldBe(visible).click();
    }

    public void fillFieldSetting(String fieldName, String text) {
        $(By.xpath("//span[text()='" + fieldName + "']/../..//input")).hover().shouldBe(visible).click();
        $(By.xpath("//span[text()='" + fieldName + "']/../..//input")).sendKeys(text);
    }

    public void clickParameterDropDown(String rowName) {
        $(By.xpath("//elma-form-row[contains(.,'" + rowName + "')] //p-dropdown")).shouldBe(visible).click();
    }

    public void chooseParameterItemDropDown(String itemName) {
        $$(dropdownItemCss).findBy(text(itemName)).shouldBe(visible).click();
    }

    public void clickDropDownOnFieldAndChooseItem(String fieldName, String itemName) {
        $(By.xpath("//span[text()='" + fieldName + "']/../..//p-dropdown")).hover().shouldBe(visible).click();
        $$(dropDownItemCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    public void hoverFileUploader(String name) {
        $$(fileUploaderCss).findBy(text(name)).shouldBe(visible).hover();
    }

    public void selectProcessParameter(String sectionName, String processName) {
        $(processSelectorButtonXpath).click();
        By expandButtonXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]//span[contains(@class, 'collapsed')]"
                , sectionName));
        if ($(expandButtonXpath).is(exist)) {
            $(expandButtonXpath).click();
        }
        By applicationToClickXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]/../..//span[text()='%s']"
                , sectionName, processName));
        $(applicationToClickXpath).click();
    }
}
