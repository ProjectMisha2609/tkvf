package pages.elmaModals;

import jakarta.inject.Singleton;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class AddCreateEventModal extends BasePage {
    private final String inputsModalCss = "input";
    private final String buttonsModalCss = "button";
    private final String containerStringsModalCss = "app-dynamic-form-row";
    private final String containerModalCss = "[class*='modal__main']";
    private final String todayDateCss = "[class*='p-datepicker-buttonbar'] button:first-child";
    private final String saveButtonCss = "[data-test='createVacancyB']";
    private final String errorValidationCss = "[class*='elma-form-errors']";

    public void fillName(String blockName) {
        $(containerModalCss).shouldBe(visible)
                .$$(containerStringsModalCss).findBy(text("Название")).$(inputsModalCss).shouldBe(visible)
                .sendKeys(blockName);
    }

    public void chooseDate(String text) {
        $(containerModalCss).shouldBe(visible).$$(containerStringsModalCss).findBy(text(text))
                .$(buttonsModalCss).shouldBe(visible).click();
        $(todayDateCss).shouldBe(visible).click();
        $(todayDateCss).should(disappear);
    }

    public void isErrorValidationExists() {
        $(containerModalCss).shouldBe(visible)
                .$$(saveButtonCss).findBy(text("Сохранить")).shouldBe(visible).click();
        if (!$(errorValidationCss).getText().contains("Обязательное поле")) {
            org.junit.jupiter.api.Assertions.fail("Validation doesn't work");
        }
    }
}
