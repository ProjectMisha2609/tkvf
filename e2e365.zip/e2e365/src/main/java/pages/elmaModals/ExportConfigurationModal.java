package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class ExportConfigurationModal extends BasePage {
    private final By titleExportConfigurationCss = By.cssSelector("p-header [class*='dialog-heading']");

    public String getPageHeaderText() {
        return $(titleExportConfigurationCss).shouldBe(visible).getText();
    }

    public void checkHeaderContainsText(String text) {
        $(titleExportConfigurationCss).shouldBe(visible).shouldHave(text(text));
    }
}
