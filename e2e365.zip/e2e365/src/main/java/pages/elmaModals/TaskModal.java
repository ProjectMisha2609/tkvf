package pages.elmaModals;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static java.lang.String.format;

@Singleton
public class TaskModal extends BasePage {
    private final By fieldContainerCss = By.cssSelector("div.modal-content elma-modal-body app-dynamic-form-row");
    private final By nextOrTaskCompleteCss = By.cssSelector("div[class*='modal'] [class*='modal-footer__panel'] button");
    private final By selectAppPopoverCss = By.cssSelector("[role='listbox'] > [role='option']");
    private final By confirmCss = By.cssSelector("elma-top-center-error div[class*='col-9']");
    private final By confirmDoneTaskButtonCss = By.cssSelector("app-task-exit-confirmation button[class*='btn-primary']");
    private final By topCenterConfirmCss = By.cssSelector("elma-top-center-error div[class*='col-9']");
    private final By inputFieldMessage = By.cssSelector("app-html-editor div[data-placeholder='Сообщение']");
    private final By buttonSelectUser = By.cssSelector("app-html-editor button[title='Выбрать пользователя']");
    private final By uploadFile = By.cssSelector("app-feed-message-file-uploader input");
    private final By buttonsInUploaderModal = By.cssSelector("app-file-uploader-modal button");
    private final By nameOfUploadedFile = By.cssSelector("app-file-list .attach__item-name");

    public void checkScriptCompleteSuccess(String resultField) {
        $$(fieldContainerCss).findBy(Condition.matchText(resultField)).shouldBe(visible);
    }

    public void inputTableCellString(String inputVar, int row, int coll) {
        SelenideElement element = $("elma-type-table-full-line [data-lineindex='" + row + "'][data-columnindex='" + coll + "']")
                .shouldBe(visible);
        element.click();
        SelenideElement elementInput = element.$("input").shouldBe(visible);
        elementInput.sendKeys(inputVar);
        elementInput.pressEnter();
        element.shouldBe(text(inputVar));
    }

    public void clickNext() {
        CustomDriver.waitMills(1000);
        $$(nextOrTaskCompleteCss).first().click();
        $(confirmCss).shouldBe(visible);
    }

    public void checkValueTableCell(String checkVar, int row, int coll) {
        $("elma-type-table-full-line [data-lineindex='" + row + "'][data-columnindex='" + coll + "']")
                .shouldBe(visible).shouldHave(text(checkVar));
    }

    public void checkLinkTableCell(String checkVar, int row, int coll) {
        $("elma-type-table-full-line [data-lineindex='" + row + "']" +
                "[data-columnindex='" + coll + "'] a[title*='Просмотр элемента']")
                .shouldBe(visible).shouldHave(text(checkVar));
    }

    public void inputTableCellTypeApp(String inputVar, int row, int coll) {
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        SelenideElement element = $("elma-type-table-full-line [data-lineindex='" + row + "'][data-columnindex='" + coll + "']")
                .shouldBe(visible);
        element.click();
        SelenideElement elementInput = element.$("input").shouldBe(visible);
        elementInput.sendKeys(inputVar);
        $(selectAppPopoverCss).shouldBe(visible).click();
        element.shouldBe(text(inputVar));
    }

    public void inputTableCellNumber(String inputVar, int row, int coll) {
        SelenideElement element = $("elma-type-table-full-line[data-index='" + row + "']");
        SelenideElement elementInside = element.$("[data-columnindex='" + coll + "']").shouldBe(visible);
        elementInside.click();
        SelenideElement elementInput = elementInside.$("input").shouldBe(visible);
        elementInput.sendKeys(inputVar);
        elementInput.pressEnter();
        element.shouldBe(text(inputVar));
    }

    public void confirmCompleteTask() {
        $(confirmDoneTaskButtonCss).shouldBe(visible).click();
        $(topCenterConfirmCss).shouldBe(visible);
    }

    public void confirmInfoStartTask(String taskName) {
        $$(confirmCss).findBy(text(taskName)).shouldBe(visible);
    }

    public void clickInputFieldMessage() {
        $(inputFieldMessage).shouldBe(visible).click();
    }

    public void clickButtonAtSignAndSelectUser(String name) {
        $(buttonSelectUser).shouldBe(visible).click();
        $(format("app-html-editor li[data-name='%s']", name)).shouldBe(visible).click();
    }

    public void uploadFile(String path) {
        $(uploadFile).sendKeys(new File("").getAbsoluteFile() + path);
        CustomDriver.waitMills(3000);
        $$(buttonsInUploaderModal).findBy(text("Загрузить")).shouldBe(visible);
    }

    public void clickButtonDownload() {
        $$(buttonsInUploaderModal).findBy(text("Загрузить")).shouldBe(visible).click();
    }

    public void checkNameOfUploadedFile(String fileName) {
        $(nameOfUploadedFile).shouldHave(text(fileName));
    }
}
