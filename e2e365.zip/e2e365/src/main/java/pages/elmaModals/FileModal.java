package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Модальное окно файлов (Открывается при нажатии на файл)
 */
@Singleton
public class FileModal extends BasePage {
    private final By buttonsInBlockTask = By.cssSelector("div.linked-tasks__form button");
    private final By inputNameNewTask = By.cssSelector("div.linked-tasks__form input[placeholder='Новая задача']");
    private final By inputTaskPerformer = By.cssSelector("div.linked-tasks__form input[placeholder='Исполнитель']");
    private final By listTaskPerFormer = By.cssSelector("ul app-user app-user-name");
    private final By buttonToSendIconDown = By.cssSelector("app-disk-preview-controls button[class*='edit-button more-action']");
    private final By buttonToSend = By.xpath("//app-disk-preview-controls//button[contains(text(),'Отправить')]");
    private final By buttonToSendAgreement = By.cssSelector(".popover-body button[class*='edit-button']");
    private final By buttonAdvancedSearch = By.cssSelector("elma-modal-body button[title='Расширенный поиск']");
    private final By listUsersName = By.cssSelector("tbody .cell___name button");
    private final By buttonParallel = By.cssSelector("elma-form-control div[aria-label='Параллельное']");
    private final By buttonSequential = By.cssSelector("elma-form-control div[aria-label='Последовательное']");
    private final By buttonInterrupt = By.cssSelector("elma-form-control div[aria-label='Прерывать']");
    private final By buttonContinuation = By.cssSelector("elma-form-control div[aria-label='Продолжать']");
    private final By goToNextStageButton = By.xpath("//button[@data-test='createVacancyB'][text()[contains(., '->')]]");

    public void clickPlusTaskButton() {
        $$(buttonsInBlockTask).findBy(text("Задача")).shouldBe(visible).click();
    }

    public void inputNameNewTask(String taskName) {
        $(inputNameNewTask).shouldBe(visible).sendKeys(taskName);
    }

    public void inputTaskPerformerAndSelectFromList(String userName) {
        $(inputTaskPerformer).shouldBe(visible).sendKeys(userName);
        $$(listTaskPerFormer).findBy(text(userName)).shouldBe(visible).click();
    }

    public void clickSaveButton() {
        $$(buttonsInBlockTask).findBy(text("Сохранить")).shouldBe(visible).click();
    }

    public void clickButtonToSendIconDown() {
        $(buttonToSendIconDown).shouldBe(visible).click();
    }

    public void clickButtonToSend() {
        $(buttonToSend).shouldBe(visible).click();
    }

    public void clickButtonToSendAgreement() {
        $(buttonToSendAgreement).shouldBe(visible).click();
    }

    public void clickButtonAdvancedSearchAndSelectUser(String userName) {
        $$(buttonAdvancedSearch).findBy(visible).shouldBe(visible).click();
        $$(listUsersName).findBy(text(userName)).shouldBe(visible).click();
    }

    public void clickButtonParallel() {
        $(buttonParallel).shouldBe(visible).click();
    }

    public void clickButtonSequential() {
        $(buttonSequential).shouldBe(visible).click();
    }

    public void clickButtonInterrupt() {
        $(buttonInterrupt).shouldBe(visible).click();
    }

    public void clickButtonContinuation() {
        $(buttonContinuation).shouldBe(visible).click();
    }

    public void clickNextStageOrExit() {
        $(goToNextStageButton).shouldBe(visible).click();
    }
}
