package pages.elmaModals;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class WidgetSettingsModal extends BasePage {
    private final By typePieGraphCss = By.xpath("//elma-chart//elma-chart-pie");
    private final By typeLineGraphCss = By.xpath("//elma-chart//elma-chart-line");
    private final By typeBarGraphCss = By.xpath("//elma-chart//elma-chart-bar");
    private final By controlInHeaderOnModal = By.cssSelector("div[class*='modal-header__controls']");
    private final By taskPercentInHeaderOnModal = By.cssSelector("app-task-percent[class='@clickable']");
    private final By titleComplexPopupInfoOnModal = By.cssSelector("elma-sidebar-widget span[class='sidebar-widget-title']");
    private final By codeEditorLastLineCss = By.cssSelector("elma-html-editor-code div.view-lines div.view-line:last-child");
    private final By textInputAreaCss = By.cssSelector("div.tox-edit-area iframe");
    private final By inscriptionInputCss = By.cssSelector("#text");
    private final By panelName = By.cssSelector("elma-tab[role='tabpanel'].active  elma-type-string input");
    private final By linkButtonOnActiveTabCss = By.cssSelector("elma-tab.active button[title='Установить связь с полем']");
    private final By activeTabButtonsCss = By.cssSelector("elma-tab.active button");
    private final By arrowRightButtonXpath = By.xpath("//i[text()='arrow_right']");
    private final By selectableItemsTreeCss = By.cssSelector("span.elma-tree-label.selectable");
    private final By buttonCss = By.cssSelector("button");
    private final By itemOuterCss = By.cssSelector(".item-outer");
    private final By elmaFormRowCss = By.cssSelector("elma-form-row");
    private final By menuOptionCss = By.cssSelector("elma-popover-menu-option");
    private final By dropDownItemCss = By.cssSelector("p-dropdownitem");
    private final By userFilterCss = By.cssSelector("elma-modal-window li a");
    private final By listUserFilterCss = By.cssSelector(".setting-value");
    private final By typeGraphCss = By.cssSelector("elma-icon-label-option");
    private final By buttonZoomAllXpath = By.xpath("//button[contains(text(),'tool_zoom_all')]");
    private final By itemsTableTBodyCss = By.cssSelector("tbody tr");
    private final By buttonSetXpath = By.xpath("//button[contains(text(), '-> Отправить')]");
    private final By treeComponentCss = By.cssSelector(".p-tree.p-component");
    private final By listApprovalAndFamiliarizationCss = By.cssSelector("elma-modal-body .user-name");
    private final By listDropDownCss = By.cssSelector("p-dropdownitem");
    private final By StandardFormElementCss = By.xpath("//app-dynamic-form");
    private final By visibleListApproval = By.cssSelector("div[class*='list-status']");
    private final By contentInBlockApprovalList = By.cssSelector("app-approval-list-widget-wrapper .all-list");

    public void fillCodeInCodeEditor(String code) {
        SelenideElement element = $(codeEditorLastLineCss).shouldBe(visible);
        element.click();
        CustomDriver.getAction().moveToElement(element).sendKeys(code).build().perform();
    }

    public void fillTextInTextWidget(String text) {
        SelenideElement element = $(textInputAreaCss).shouldBe(visible);
        element.click();
        CustomDriver.getAction().moveToElement(element).sendKeys(text).build().perform();
    }

    public void fillInscriptionWidget(String text) {
        $(inscriptionInputCss).shouldBe(visible).sendKeys(text);
    }

    public void clearPanelHeaderName() {
        $(panelName).clear();
    }

    public void fillPanelWithHeaderName(String name) {
        $(panelName).sendKeys(name);
    }

    public void linkWidgetNameWithAppName() {
        $(linkButtonOnActiveTabCss).shouldBe(visible).click();
        $$(activeTabButtonsCss).findBy(text("<Не установлено>")).click();
        $(arrowRightButtonXpath).click();
        $$(selectableItemsTreeCss).findBy(exactText("Идентификатор")).click();
    }

    /**
     * вызов класса с методами для работы с модальным окном добавления виджета "Вкладки"
     */
    public TabWidgetSettingsModal tabWidgetSettingsModal() {
        return new TabWidgetSettingsModal();
    }

    /**
     * вызов класса с методами для работы с модальным окном добавления виджета "Панель с текстом"
     */
    public PanelWidgetSettingsModal panelWidgetSettingsModal() {
        return new PanelWidgetSettingsModal();
    }

    /**
     * вызов класса с методами для работы с модальным окном добавления виджета "Таблица"
     */
    public TableWidgetSettingsModal tableWidgetSettingsModal() {
        return new TableWidgetSettingsModal();
    }

    public static class TableWidgetSettingsModal {
        private final By selectApplicationButtonCss = By.cssSelector("app-application-control button");
        private final By applicationButtonsCss = By.cssSelector("p-treenode span[class = 'elma-tree-label']");

        public void selectApplication(String sectionName, String applicationName) {
            SelenideElement targetSectionTogglerCollapsed = $(By.xpath(
                    String.format("//div[contains(@aria-label, '%s')]//span[contains(@class, 'collapsed')]", sectionName)));
            $(selectApplicationButtonCss).shouldBe(visible).click();
            if (targetSectionTogglerCollapsed.is(exist)) {
                targetSectionTogglerCollapsed.scrollTo().shouldBe(visible).click();
            }
            $$(applicationButtonsCss).findBy(text(applicationName)).should(exist).scrollTo().shouldBe(visible).click();
        }

        public void addItemToViewedFields(String itemName) {
            SelenideElement targetItemPlusButtonOnViewTab = $(By.xpath(String.format(
                    "//elma-form-row//span[contains(text(), 'Отображаемые')]/../..//span[contains(text(),'%s')]/../button", itemName)));
            targetItemPlusButtonOnViewTab.scrollTo().shouldBe(visible).click();
        }

        public void addItemToAggregatedFields(String itemName) {
            SelenideElement targetItemPlusButtonOnViewTab = $(By.xpath(String.format(
                    "//elma-form-row//span[contains(text(), 'агрегации')]/../..//span[contains(text(),'%s')]/../button", itemName)));
            targetItemPlusButtonOnViewTab.scrollTo().shouldBe(visible).click();
        }

        public void addItemToFilteringFields(String itemName) {
            SelenideElement targetItemPlusButtonOnViewTab = $(By.xpath(String.format(
                    "//elma-form-row//span[contains(text(), 'фильтрации')]/../..//span[contains(text(),'%s')]/../button", itemName)));
            targetItemPlusButtonOnViewTab.scrollTo().shouldBe(visible).click();
        }
    }

    public static class PanelWidgetSettingsModal {
        private final By collapsibleSettingsXpath = By.xpath("//elma-form-row//span[contains(.,'Сворачиваемая')]/../..//span");
        private final By foldedSettingsXpath = By.xpath("//elma-form-row//span[contains(.,'Развернута')]/../..//span");
        private final By overlayingDropdownWithOptionsXpath = By.cssSelector("div[class*='p-overlay'] span");
        private final By panelDisplayingModeXpath = By.xpath("//elma-form-label/span[text()[contains(., 'Вид отображения')]]/../../elma-form-control");

        public void setCollapsibleMode(String text) {
            $$(collapsibleSettingsXpath).find(text(text)).click();
        }

        public void setFoldedMode(String text) {
            $$(foldedSettingsXpath).find(text(text)).click();
        }

        public void setPanelWithHeaderDisplayingMode(String modeName) {
            $(panelDisplayingModeXpath).shouldBe(visible).click();
            $$(overlayingDropdownWithOptionsXpath).findBy(text(modeName)).shouldBe(visible).click();
        }
    }

    public static class TabWidgetSettingsModal {
        private final By horizontalCheckboxCss = By.cssSelector("elma-checkbox[id='horizontal']>p-checkbox");
        private final By hideSinglePageCheckboxCss = By.cssSelector("elma-checkbox[id='hideSinglePage']>p-checkbox");

        public void changeHorizontalCheckboxValue() {
            $(horizontalCheckboxCss).click();
        }

        public void changeHideSinglePageCheckboxValue() {
            $(hideSinglePageCheckboxCss).click();
        }
    }

    public void fillGraphWithFilterField(String sectionName, String appForGraphName) {
        $$(buttonCss).findBy(text("Выберите Приложение")).click();
        $$(itemOuterCss).findBy(text(sectionName)).$("i").click();
        $$(itemOuterCss).findBy(text(appForGraphName)).click();

        $$(elmaFormRowCss).findBy(text("Измерение")).$(buttonCss).click();
        $$(menuOptionCss).findBy(text("Название")).shouldBe(visible).click();

        $$(elmaFormRowCss).findBy(text("Показатель")).$(buttonCss).click();
        $$(menuOptionCss).findBy(text("Количество")).shouldBe(visible).click();

        $$(userFilterCss).findBy(text("Пользовательские фильтры")).shouldBe(visible).click();
        $$(listUserFilterCss).findBy(text("Название")).$(buttonCss).click();
    }

    public void fillGraphType(String nameGraph, String sectionName, String appForGraphName) {
        $$(buttonCss).findBy(text("Выберите Приложение")).click();
        $$(itemOuterCss).findBy(text(sectionName)).$("i").click();
        $$(itemOuterCss).findBy(text(appForGraphName)).click();

        $$(elmaFormRowCss).findBy(text("Измерение")).$(buttonCss).click();
        $$(menuOptionCss).findBy(text("Название")).shouldBe(visible).click();

        $$(elmaFormRowCss).findBy(text("Показатель")).$(buttonCss).click();
        $$(menuOptionCss).findBy(text("Количество")).shouldBe(visible).click();

        $$(elmaFormRowCss).findBy(text("Тип графика")).$(typeGraphCss).click();
        $$(dropDownItemCss).findBy(text(nameGraph)).shouldBe(visible).click();
    }

    public void setAlignmentLine(String typeAlignment) {
        $$(elmaFormRowCss).findBy(text("По левому краю")).$(typeGraphCss).click();
        $$(dropDownItemCss).findBy(text(typeAlignment)).shouldBe(visible).click();
    }

    public void linkItemAppApprovalListWidget() {
        $$(elmaFormRowCss).filter(text("Элемент Приложения")).first().$(buttonCss).click();
        $$(treeComponentCss).findBy(text("Элемент Приложения")).click();
    }

    public void setListApprovalAndFamiliarizationUsers() {
        $(buttonZoomAllXpath).click();
        $$(itemsTableTBodyCss).get(0).click();
        $(buttonZoomAllXpath).click();
        $$(itemsTableTBodyCss).get(1).click();
        $(buttonSetXpath).click();
    }

    public void checkCountUsersApprovalAndFamiliarizationList() {
        $$(listApprovalAndFamiliarizationCss).shouldHave(CollectionCondition.size(2));
    }

    public void fillCardOfDateStartProcess() {
        $$(elmaFormRowCss).findBy(text("Контекст")).$(buttonCss).shouldBe(visible).click();
        $$(getSelectorRowButton("Контекст", "Создать")).find(visible);
        $$(selectableItemsTreeCss).findBy(text("Контекст")).click();
    }

    public void fillInscriptionWithJoin() {
        $(linkButtonOnActiveTabCss).shouldBe(visible).click();
        $$(activeTabButtonsCss).findBy(text("<Не установлено>")).click();
        $(arrowRightButtonXpath).click();
        $$(selectableItemsTreeCss).findBy(exactText("Название")).click();
    }

    public void fillUploaderFileViewWidget(String nameContextVariable) {
        $$(activeTabButtonsCss).findBy(text("<Не установлено>")).click();
        $(arrowRightButtonXpath).click();
        $$(selectableItemsTreeCss).findBy(text(nameContextVariable)).click();
    }

    public void createFuncForMoveOutsideClientServer(String nameFunc, String clientServer) {
        String nameRow = "Событие при перемещении курсора за границы";
        $$(getSelectorRowDropDown(nameRow)).find(visible).click();
        $$(listDropDownCss).findBy(text(clientServer)).shouldBe(visible).click();
        $$(getSelectorRowButton(nameRow, "Создать")).find(visible).click();
        $$(getSelectorRowInput(nameRow)).find(visible).sendKeys(nameFunc);
        $$(getSelectorRowButton(nameRow, "Создать")).find(visible).click();
        $$(getSelectorRowButton(nameRow, "Открыть")).find(visible).click();
    }

    /**
     * Получить селектор для поиска кнопок и полей по наименаванию блока на форме настроек виджета
     */
    private By getSelectorRowButton(String nameRow, String textButton) {
        return By.xpath("//span[text()='" + nameRow + "']/../..//elma-form-control//button[contains(text(),'" + textButton + "')]");
    }

    private By getSelectorRowInput(String nameRow) {
        return By.xpath("//span[text()='" + nameRow + "']/../..//elma-form-control//input");
    }

    private By getSelectorRowDropDown(String nameRow) {
        return By.xpath("//span[text()='" + nameRow + "']/../..//elma-form-control//elma-select");
    }

    public void checkCountStandardFormElement() {
        $$(StandardFormElementCss).shouldHave(CollectionCondition.size(2));
    }

    public void fillRegDocumentWidget() {
        $(getSelectorRowButton("Приложение", "<Не установлено>")).shouldBe(visible).click();
        $$(selectableItemsTreeCss).findBy(exactText("Приложение")).click();
        $(getSelectorRowButton("Элемент Приложения", "<Не установлено>")).shouldBe(visible).click();
        $$(selectableItemsTreeCss).findBy(exactText("Элемент Приложения")).click();
    }

    public void setListApprovalAndFamiliarizationUsers(String userFIO) {
        $(buttonZoomAllXpath).click();
        $$(itemsTableTBodyCss).findBy(text(userFIO)).click();
        $(buttonSetXpath).click();
    }

    public void checkVisibleListApproval(String statusText) {
        $(visibleListApproval).shouldHave(text(statusText));
    }

    public void checkVisibleQuestionMarkAndUserApproval(String userName) {
        $(By.xpath(String.format("//i[contains(text(),'unresolved')]/..//span[contains(text(),'%s')]", userName))).shouldBe(visible);
    }

    public void checkVisibleCheckMarkAndUserApproval(String userName) {
        $(By.xpath(String.format("//i[contains(text(),'approved')]/..//span[contains(text(),'%s')]", userName))).shouldBe(visible);
    }

    public void checkContentInBlockApprovalList(String text) {
        $$(contentInBlockApprovalList).findBy(text(text)).shouldBe(visible);
    }

    public void checkTypePieGraphExists() {
        $(typePieGraphCss).should(exist);
    }

    public void checkTypeLineGraphExists() {
        $(typeLineGraphCss).should(exist);
    }

    public void checkTypeBarGraphExists() {
        $(typeBarGraphCss).should(exist);
    }

    public void checkExistHeaderControlOnModal() {
        $(taskPercentInHeaderOnModal).shouldBe(visible);
        $$(controlInHeaderOnModal).findBy(text("map")).shouldBe(visible);
        $$(controlInHeaderOnModal).findBy(text("menu_vertical")).shouldBe(visible);
        $$(controlInHeaderOnModal).findBy(text("fullscreen_enter")).shouldBe(visible);
        $$(controlInHeaderOnModal).findBy(text("system_close")).shouldBe(visible);
    }

    public void checkExistTitleComplexPopupInfoOnModal(String titlePopupModalInfo) {
        $$(titleComplexPopupInfoOnModal).findBy(text(titlePopupModalInfo)).shouldBe(visible);
    }

    public void checkTooltipTextByButtonName(String buttonName, String text) {
        $(By.xpath("//section//i[contains(text(),'" + buttonName + "')]")).shouldBe(visible).hover();
        $(By.xpath("//div[contains(@class,'p-tooltip-text')]")).shouldBe(visible).shouldHave(text(text));
    }
}
