package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class SelectWidgetsModal extends BasePage {
    private final By windowsModalBodyCss = By.cssSelector(".widget-container .widget-item__title");
    private final By addWidgetBtnCss = By.cssSelector("button[title='Добавить виджет']");
    private final By addNewWidgetCss = By.cssSelector("[class*='link-add-widget']");
    private final By nameWidgetCss = By.cssSelector("elma-form-row input[name='name']");
    private final By widgetOptionsButtonsCss = By.cssSelector("elma-widget-template-item-tools button");
    private final By confirmDeleteWidgetCss = By.cssSelector("div[class*='popover-body'] button");
    private final By redactPageButtonCss = By.cssSelector("button[class*='custom-page-edit']");
    private final By titleBarWidgetCss = By.cssSelector("elma-groupbox");
    private final By widgetListCss = By.cssSelector("div[class='widget-item__title']");
    private final By inputWidgetNameCss = By.cssSelector("input[id='title']");
    private final By pageContentCss = By.cssSelector("app-page-content");
    private final By modalHeaderCss = By.cssSelector("p-header");

    public void selectWidget(String name) {
        $(addWidgetBtnCss).shouldBe(visible).click();
        $$(windowsModalBodyCss).findBy(text(name)).shouldBe(visible).click();
    }

    public void clickCreateNewWidget() {
        $(addNewWidgetCss).shouldBe(visible).click();
    }

    public void fillWidgetName(String widgetName) {
        $(nameWidgetCss).shouldBe(visible).sendKeys(widgetName);
    }

    public void deleteTitleBarWidget(String titleBarText) {
        $(titleBarWidgetCss).shouldBe(visible).shouldHave(text(titleBarText)).click();
        $$(widgetOptionsButtonsCss).findBy(text("app_trash\n")).shouldBe(visible).click();
        $(confirmDeleteWidgetCss).shouldBe(visible).click();
        $(titleBarWidgetCss).shouldNot(exist);
        $(redactPageButtonCss).shouldBe(visible).click();
    }

    public void checkTitleBarWidgetDeleted() {
        $(pageContentCss).shouldBe(visible);
        $(titleBarWidgetCss).shouldNot(exist);
    }

    public void openSettingsTitleBarWidget(String titleBarText) {
        $(titleBarWidgetCss).shouldBe(visible).shouldHave(text(titleBarText)).click();
        $$(widgetOptionsButtonsCss).findBy(text("settings\n")).shouldBe(visible).click();
    }

    public void checkTitleBarWidgetSettingsOpened() {
        $(modalHeaderCss).shouldBe(visible).shouldHave(text("Панель с заголовком: Настройки"));
    }

    public void pressCreateTitleBarWidget() {
        $$(widgetListCss).findBy(text("Панель с заголовком")).shouldBe(visible).click();
    }

    public void createTitleBarWidget(String widgetName) {
        $(inputWidgetNameCss).shouldBe(visible).sendKeys(widgetName);
        dialogWindowPressButton("Сохранить");
        $$(titleBarWidgetCss).findBy(text(widgetName)).shouldBe(visible);
    }

    public void pressCreateWidget(String widgetName) {
        $$(widgetListCss).findBy(text(widgetName)).shouldBe(visible).click();
    }

}
