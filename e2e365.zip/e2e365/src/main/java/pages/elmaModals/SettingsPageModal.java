package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SettingsPageModal extends BasePage {
    private final By twoColumnsButtonCss = By.cssSelector("[aria-label='Две колонки']");
    private final By oneColumnsButtonCss = By.cssSelector("[aria-label='Одна колонка']");

    public void selectTwoColumns() {
        $(twoColumnsButtonCss).shouldBe(visible).click();
    }

    public void selectOneColumns() {
        $(oneColumnsButtonCss).shouldBe(visible).click();
    }
}
