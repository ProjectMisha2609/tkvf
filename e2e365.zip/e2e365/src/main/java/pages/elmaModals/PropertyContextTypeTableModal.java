package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class PropertyContextTypeTableModal extends BasePage {
    private final By nameContextCss = By.cssSelector("[role='dialog'][class*='show']:last-of-type elma-form-row:first-child input[formcontrolname='name']");
    private final By selectAppCss = By.cssSelector("[class*='element'] [aria-label='Приложение']");
    private final By settingsTableCss = By.cssSelector("elma-form [class*='form-row'] [class*='control'] button[elmabutton='link']");
    private final By addNewDataCss = By.cssSelector("[class*='table-settings-columns'] [class*='column-plus']");
    private final By popoverSelectTypeColumnCss = By.cssSelector("elma-popover-menu-option");
    private final By selectTypeColumnCss = By.cssSelector("[role='dialog'][class*='show']:last-of-type div[aria-haspopup='listbox']");
    private final By linkSelectAppCss = By.cssSelector("[role='dialog'][class*='show']:last-of-type [class*='form-control'] > [elmabutton='link']");
    private final By selectNumberCss = By.cssSelector("[class*='element'] [aria-label='Число']");
    private final By selectStringCss = By.cssSelector("[class*='element'] [aria-label='Строка']");
    private final By inputFormulaCss = By.cssSelector("[formcontrolname='formula']");

    public void clickSettingsTable() {
        $(settingsTableCss).shouldBe(visible).click();
    }

    public void clickAddColumn(String selectType) {
        $(addNewDataCss).shouldBe(visible).click();
        $$(popoverSelectTypeColumnCss).findBy(text(selectType)).shouldBe(visible).click();
    }

    public void fillNameColumn(String columnName) {
        $(nameContextCss).shouldBe(visible).sendKeys(columnName);
    }

    public void selectTypeApp() {
        $(selectTypeColumnCss).shouldBe(visible).click();
        $(selectAppCss).shouldBe(visible).click();
    }

    public void clickLinkSelectApp() {
        $(linkSelectAppCss).shouldBe(visible).click();
    }

    public void selectTypeNumber() {
        $(selectTypeColumnCss).shouldBe(visible).click();
        $(selectNumberCss).shouldBe(visible).click();
    }

    public void selectTypeString() {
        $(selectTypeColumnCss).shouldBe(visible).click();
        $(selectStringCss).shouldBe(visible).click();
    }

    public void inputSimpleFormula(String formula) {
        $(inputFormulaCss).shouldBe(visible).sendKeys(formula);
    }
}
