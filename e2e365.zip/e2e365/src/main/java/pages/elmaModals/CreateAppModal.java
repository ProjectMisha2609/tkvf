package pages.elmaModals;

import com.codeborne.selenide.SelenideElement;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class CreateAppModal extends BasePage {
    private final By nameId = By.cssSelector("[data-test=createAppFormAppNameTb]");
    private final By pageNameCss = By.cssSelector("input[name='name']");
    private final By appCreationTypeCss = By.cssSelector("elma-switch[name='type'] div[class*='p-element']");
    private final By appCreationElementNameCss = By.cssSelector("app-form-application input[name='elementName']");
    private final By creationTypeInSectionCss = By.cssSelector("div[class*='p-dialog-header'] p-selectbutton div[class*='p-element']");
    private final By patternTextStringCss = By.cssSelector("input[name='name']");
    private final By linkInSectionCss = By.cssSelector("input[name='url']");
    private final By linkIconInSectionCss = By.cssSelector("app-iconpicker i");

    public void fillName(String name) {
        SelenideElement element = $(nameId).shouldBe(visible);
        element.click();
        element.sendKeys(name);
        $(appCreationElementNameCss).shouldBe(visible).shouldHave(value(name));
    }

    public void fillPageName(String name) {
        SelenideElement element = $(pageNameCss).shouldBe(visible);
        element.click();
        element.sendKeys(name);
    }

    public void chooseTypeOfApp(String appType) {
        $$(appCreationTypeCss).findBy(text(appType)).shouldBe(visible).click();
    }

    public void chooseAppType(String appType) {
        $$(creationTypeInSectionCss).findBy(text(appType)).shouldBe(visible).click();
    }

    public String fillLinkAppType(String linkName, String link) {
        $(patternTextStringCss).shouldBe(visible).sendKeys(linkName);
        $(linkInSectionCss).shouldBe(visible).sendKeys(link);
        dialogWindowPressButton("Создать");
        return $(linkIconInSectionCss).shouldBe(visible).getText();
    }
}
