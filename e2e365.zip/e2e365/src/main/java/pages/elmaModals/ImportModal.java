package pages.elmaModals;

import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import java.io.File;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class ImportModal extends BasePage {
    private final By nameId = By.cssSelector("[data-test=sectionNameTb]");
    private final By sectionLinkId = By.cssSelector("[data-test=sectionLinkTb]");
    private final By continueId = By.cssSelector("[data-test=sectionImportContinueB]");
    private final By appExchangeProgressId = By.cssSelector("[data-test=appExchangeProgress]");
    private final By continueButtonCss = By.cssSelector("div[class='modal-footer'] button[class*='btn-primary']");
    private final By uploadFileCss = By.cssSelector("[data-test=uploadFileI] input");
    private final By fileDeleteBtnCss = By.cssSelector("span[data-test='uploadedFileNameS'] ~ button");
    private final By modalFooterPrimaryBtnCss = By.cssSelector("div[class*='modal-footer'] button[class*='btn-primary']");
    private final By nextButtonInImportCss = By.cssSelector("div[aria-labelledby='pr_id_4-label'] button[class='btn btn-primary']");

    public void fillName(String name) {
        $(nameId).shouldBe(visible).sendKeys(name);
    }

    public void fillSectionLink(String sectionLink) {
        $(sectionLinkId).shouldBe(visible).sendKeys(sectionLink);
    }

    public void clickContinue() {
        $(continueId).click();
        $(appExchangeProgressId).should(disappear);
        $(continueButtonCss).shouldBe(visible, enabled).click();
    }

    public void uploadApplication(String filePath) {
        $(uploadFileCss).uploadFile(new File(filePath));
        $(fileDeleteBtnCss).shouldBe(visible);
    }

    public void clickContinuePreview() {
        CustomDriver.waitMills(1500);
        $(modalFooterPrimaryBtnCss).shouldBe(visible).shouldHave(text("Далее")).click();
        $(nextButtonInImportCss).shouldBe(visible, enabled).shouldHave(text("Далее")).click();
    }

    public void confirmSectionNameIfRequired(String name) {
        try {
            checkInputFormRowValue("Название", name);
            dialogWindowPressButton("Далее");
        } catch (com.codeborne.selenide.ex.ElementNotFound ignore) {
        }
    }
}
