package pages.elmaModals;

import jakarta.inject.Singleton;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class SectionSettingsModal extends BasePage {
    private final String nameSectionCss = "[class*='dialog-content'] input[name='name']";
    private final String descriptionSectionCss = "[class*='dialog-content'] textarea[name='description']";
    private final String iconsContainerCss = "div[class='popover-body'] div[class='icon-picker']";
    private final String iconCss = "i[class*='elma-icons']";
    private final String selectNewIcon = "div[class*='modal-body'] button[elmabutton='default'][class*='form-control']";

    public void fillNewSectionName(String sectionName) {
        $(nameSectionCss).shouldBe(visible).sendKeys(sectionName);
    }

    public void fillSectionDescription(String description) {
        $(descriptionSectionCss).shouldBe(visible).sendKeys(description);
    }

    public void selectNewSectionIcon() {
        $(selectNewIcon).shouldBe(visible).click();
        $(iconsContainerCss).shouldBe(visible).$$(iconCss)
                .findBy(text("bullseye_arrow")).shouldBe(visible).click();
    }
}
