package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

/**
 * Модальное окно установки правила дублей
 */
@Singleton
public class CrmDoublesModal extends BasePage {

    public void selectOperationByFirstColumnValue(String firstColumnValue, String operation) {

    }

    public void setWeightByFirstColumnValue(String firstColumnValue, int weight) {
        $(By.xpath("//button[contains(text(),'" + firstColumnValue
                + "')]/ancestor::app-rule-condition[1]//elma-number//input")).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, String.valueOf(weight));
    }

    public void clickCheckboxInModalLearnMoreDuplicates(String nameField) {
        $(By.xpath("//app-similars-table-cell[contains(.,'" + nameField + "')]/ancestor::tr//div[contains(@class,'p-checkbox')]"))
                .shouldBe(visible).click();
    }

    public void clickButtonInModalWindowCombineLeads(String buttonName) {
        $(By.xpath("//app-duplicates-merge//button[contains(text(),'" + buttonName + "')]")).shouldBe(visible).click();
    }

    public void checkContentModalBodyInModalWindow(String text) {
        $(By.xpath("//app-application-duplicates-widget//div[contains(@class,'modal-body')]" +
                "//*[contains(.,'" + text + "')]")).shouldBe(visible);
    }
}
