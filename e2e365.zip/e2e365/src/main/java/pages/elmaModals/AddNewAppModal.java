package pages.elmaModals;

import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;

@Singleton
public class AddNewAppModal extends BasePage {
    private final By uploadApplicationId = By.cssSelector("[data-test=uploadApplicationB]");
    private final By createAppPageCss = By.cssSelector("[data-test=quickCreatePageB]");
    private final By quickCreateApplicationId = By.cssSelector("[data-test=quickCreateApplicationB]");

    public void clickUploadFile() {
        $(uploadApplicationId).shouldBe(visible).click();
    }

    public void clickQuickCreatePage() {
        $(createAppPageCss).shouldBe(visible).click();
    }

    public void clickQuickCreateApplication() {
        $(quickCreateApplicationId).shouldBe(visible).click();
    }
}
