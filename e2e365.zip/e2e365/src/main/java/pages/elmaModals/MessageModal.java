package pages.elmaModals;

import jakarta.inject.Singleton;
import pages.BasePages.BasePage;

/**
 * Модельное окно сообщения.
 * В основном используется для читаемого вызова методов базового модального окна,
 * которое является абстрактным классом.
 */
@Singleton
public class MessageModal extends BasePage {
}
