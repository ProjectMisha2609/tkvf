package pages.elmaModals;

import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;
import org.openqa.selenium.By;
import pages.BasePages.BasePage;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

@Singleton
public class SettingsActionsButtonModal extends BasePage {
    private final By colorActionCss = By.cssSelector("div[class*='popover_is-visible'] elma-form-row[class*='@compact'] elma-select:not([labelprefix*='@permission'])");
    private final By colorCss = By.cssSelector("p-dropdownitem [aria-label='Важно']");
    private final By fieldNameCss = By.cssSelector("div[class*='popover_is-visible'] elma-form-row:first-child elma-form-control[class*='text-base'] input");
    private final By saveChangesCss = By.cssSelector("div[class*='popover_is-visible'] [class*=footer] button.btn-primary");
    private final By selectProcessLinkCss = By.cssSelector("app-bpm-bind button[elmabutton='link']");
    private final By checkboxFieldCss = By.cssSelector("elma-form-control elma-checkbox");
    private final By getCheckboxFieldCss = By.cssSelector("div[class*='check']");

    public void fillName(String buttonName) {
        $(fieldNameCss).shouldBe(visible).setValue(buttonName);
    }

    public void selectColorImportant() {
        $(colorActionCss).shouldBe(visible).click();
        $(colorCss).shouldBe(visible).click();
        //если нажать один раз то выбор цвета не закрывается и тупит, локально вроде он протупливает
        // но в пайплайне на этом моменте падает, попробую второй клик через секунду добавить
        CustomDriver.waitMills(1000);
        if ($(colorCss).exists())
            $(colorCss).shouldBe(visible).click();
    }

    public void clickSave() {
        $(saveChangesCss).shouldBe(visible).click();
    }

    public void clickSelectProcess() {
        $(selectProcessLinkCss).shouldBe(visible).click();
    }

    public void clickDrawFormBesideButton() {
        $$(checkboxFieldCss).findBy(text("Рисовать форму рядом с кнопкой")).shouldBe(visible).$(getCheckboxFieldCss).shouldBe(visible).click();
    }
}
