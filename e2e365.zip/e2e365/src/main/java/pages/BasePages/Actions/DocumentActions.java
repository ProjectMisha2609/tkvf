package pages.BasePages.Actions;

import infrastructure.helpers.docs.DocxDocument;
import infrastructure.helpers.docs.PdfDocument;

import java.io.File;

public interface DocumentActions {
    /**
     * Получить параграф из файла docx по номеру (нумерация от 1)
     *
     * @param file            - файл для чтения
     * @param paragraphNumber - номер параграфа
     */
    default String getParagraphFromDocxFileByNum(File file, int paragraphNumber) {
        return new DocxDocument(file).getParagraphTextByNumber(paragraphNumber);
    }

    /**
     * Получить весь текст из страницы pdf файла по номеру (нумерация от 1)
     *
     * @param file - файл для чтения
     */
    default String getTextFromPdfPage(File file, int pageNumber) {
        return new PdfDocument(file).getTextFromPage(pageNumber);
    }
}
