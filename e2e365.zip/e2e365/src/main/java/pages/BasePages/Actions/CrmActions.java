package pages.BasePages.Actions;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Интерфейс, описывающий стандартные действия для секции CRM.
 */
public interface CrmActions {
    By dropDownItemCss = By.cssSelector("li.p-dropdown-item");

    /**
     * Выбрать элемент из выпадающего списка наеденного
     *
     * @param rowName           - имя списка (отображается слева).
     * @param dropDownLabelName - надпись в поле.
     * @param itemName          - имя элемента для выбора.
     */
    default void clickAndSelectDropDownItemWithLabelRow(String rowName, String dropDownLabelName, String itemName) {
        String locator = String.format("//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//p-dropdown[contains(.,'%s')]", rowName, dropDownLabelName);
        $(By.xpath(locator)).shouldBe(visible).click();
        $$(dropDownItemCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    /**
     * Установить период по имени строки
     *
     * @param rowName   - имя списка (отображается слева).
     * @param startDate - надпись в поле.
     * @param endDate   - имя элемента для выбора.
     */
    default void setPeriodWithLabelRow(String rowName, String startDate, String endDate) {
        String locator1 = String.format("//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//i[contains(text(),'minus')]/preceding-sibling::*//input", rowName);
        String locator2 = String.format("//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//i[contains(text(),'minus')]/following-sibling::*//input", rowName);
        $(By.xpath(locator1)).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, startDate, Keys.TAB);
        $(By.xpath(locator2)).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, endDate, Keys.TAB);
    }

    /**
     * Установить период по имени строки
     *
     * @param rowName - имя списка (отображается слева).
     * @param date    - дата.
     */
    default void setPeriodWithLabelRow(String rowName, String date) {
        String locator = String.format("//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//preceding-sibling::*//input", rowName);
        $(By.xpath(locator)).shouldBe(visible).sendKeys(Keys.chord(Keys.CONTROL, "a")
                + Keys.DELETE, date, Keys.TAB);
    }
}
