package pages.BasePages.Actions;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.*;

public interface ModalActions {
    By sectionCss = By.cssSelector("section");
    By modalWindowCss = By.cssSelector("elma-modal-window");
    By elmaModalBodyCss = By.cssSelector("elma-modal-body");
    By modalWindowTabsCss = By.cssSelector("elma-modal-window ul[role='tablist'] a");
    By dialogWindowCss = By.cssSelector("p-dialog div[class*='p-element']");
    By modalWindowButtonsXpath = By.xpath("//elma-modal-window//button");
    By modalWindowFooterButtonsCss = By.cssSelector("footer div[class*='modal-footer__panel'] button");
    By modalWindowHeaderButtonsCss = By.cssSelector("header div[class*='modal-header'] button");
    By dialogWindowButtonCss = By.cssSelector("div[role='dialog'] [class*='footer'] button:not([disabled])");
    By titleInHeaderOnModal = By.cssSelector("header[class='modal-header'] div[class='modal-title']");
    // Кнопка-ссылка перехода
    By transitionButtonLinkCss = By.cssSelector("ngx-dnd-item button[class*='btn-link']");

    /**
     * Проверить название модального окна
     */
    default void checkModalWindowHeader(String titleName) {
        $$(titleInHeaderOnModal).findBy(text(titleName)).shouldBe(exist);
    }

    /**
     * Нажать вкладку модального окна
     */
    default void selectModalWindowTab(String name) {
        $$(modalWindowTabsCss).findBy(text(name)).shouldBe(visible).click();
    }

    /**
     * Нажать кнопку в диалоговом окне
     */
    default void dialogWindowPressButton(String buttonText) {
        $(dialogWindowCss).shouldBe(visible);
        $$(modalWindowCss).last().shouldBe(visible).
                $$(dialogWindowButtonCss).findBy(text(buttonText)).shouldBe(visible, enabled).click();
    }

    /**
     * Проверить наличие кнопки в диалоговом окне
     */
    default void dialogWindowCheckButton(String buttonText) {
        $(dialogWindowCss).shouldBe(visible);
        $$(modalWindowCss).last().shouldBe(visible).
                $$(dialogWindowButtonCss).findBy(text(buttonText)).shouldBe(visible, enabled);
    }

    /**
     * Проверяет что кнопка внизу модального окна НЕ существует
     *
     * @param buttonName - название кнопки
     */
    default void checkNameButtonInFooterModalWindowNotExists(String buttonName) {
        $$(sectionCss).last().shouldBe(visible).
                $$(modalWindowFooterButtonsCss).findBy(text(buttonName)).shouldNot(exist);
    }

    /**
     * Проверяет что кнопка внизу модального окна существует
     *
     * @param buttonName - название кнопки
     */
    default void checkNameButtonInFooterModalWindowExists(String buttonName) {
        $$(sectionCss).last().shouldBe(visible).
                $$(modalWindowFooterButtonsCss).findBy(text(buttonName)).shouldBe(exist, visible);
    }

    /**
     * @param buttonName - имя кнопки на модальном окне, которую нужно нажать.
     */
    default void clickButtonOnModalWindowByName(String buttonName) {
        $$(modalWindowButtonsXpath).findBy(text(buttonName)).shouldBe(visible, enabled).click();
    }

    /**
     * Нажать кнопку в модальном окне сверху
     */
    default void clickModalHeaderButton(String buttonText) {
        $$(sectionCss).last().shouldBe(visible).
                $$(modalWindowHeaderButtonsCss).findBy(text(buttonText)).shouldBe(visible).click();
    }

    /**
     * Проверить, что видна кнопка в модальном окне сверху
     */
    default void checkModalHeaderButtonVisible(String buttonText) {
        $$(sectionCss).last().shouldBe(visible).
                $$(modalWindowHeaderButtonsCss).findBy(text(buttonText)).shouldBe(visible);
    }

    /**
     * Нажать кнопку в модальном окне снизу
     */
    default void clickModalFooterButton(String buttonText) {
        $$(sectionCss).last().shouldBe(visible).
                $$(modalWindowFooterButtonsCss).findBy(text(buttonText)).shouldBe(visible).click();
    }

    /**
     * Проверить, что виджет с заданным именем есть в модальном окне
     */
    default void checkExistWidgetOnBodyModal(String widgetName) {
        $$(elmaModalBodyCss).findBy(text(widgetName)).shouldBe(exist);
    }


    /**
     * Проверить, что виджет с указанным именем не существует в модальном окне.
     */
    default void checkWidgetNotExistsOnBodyModal(String widgetName) {
        $$(elmaModalBodyCss).findBy(text(widgetName)).shouldNot(exist);
    }

    /**
     * @param name - имя устанавливаемого перехода по умолчанию
     */
    default void selectDefaultTransition(String name) {
        $(By.xpath(String.format("//ngx-dnd-item" +
                "//*[contains(text(), '%s')]/../..//elma-radiobutton", name)))
                .shouldBe(visible).click();
    }

    /**
     * @param name   - имя перемещаемого перехода
     * @param target - имя перехода, ниже которого нужно переместить переход
     */
    default void moveTransitionSlightlyBelowTransition(String name, String target) {
        By transition = By.xpath(String.format("//ngx-dnd-item" +
                "//*[contains(text(), '%s')]", name));
        By targetTransition = By.xpath(String.format("//ngx-dnd-item" +
                "//*[contains(text(), '%s')]", target));
        actions().clickAndHold($(transition).shouldBe(visible))
                .moveToElement($(targetTransition).shouldBe(visible))
                // компенсация уплывшей разметки
                .moveToElement($(targetTransition).shouldBe(visible))
                // перемещение вниз на пиксель, что бы не попасть в центр
                .moveByOffset(0, -1).release().build().perform();
        int transitionPositionY = $(transition).shouldBe(visible).getCoordinates().onPage().y;
        int targetTransitionPositionY = $(targetTransition).shouldBe(visible).getCoordinates().onPage().y;
        Assertions.assertTrue(transitionPositionY > targetTransitionPositionY,
                String.format("элемент %s имеет позицию по высоте %s, что выше позиции %s у элемента %s",
                        name, transitionPositionY, targetTransitionPositionY, target));
    }

    /**
     * @param name - имя перехода, настройки которого нужно открыть
     */
    default void openTransitionSettings(String name) {
        $$(transitionButtonLinkCss).findBy(text(name)).shouldBe(visible).click();
    }

    /**
     * Проверить, что имеется текст в выбранной строке формы без привязки к какому-то тегу.
     *
     * @param rowName - имя строки в форме (можно неполное).
     * @param text    - фрагмент текста для проверки.
     */
    default void checkTextForRowValue(String rowName, String text) {
        $(By.xpath("//span[contains(text(),'" + rowName + "')]" +
                "//ancestor::elma-form-row[1]//*[contains(text(),'" + text + "')]")).shouldBe(visible);
    }

    /**
     * Удалить старый текст и ввести новый текст в поле ввода по имени строки формы и названию формы.
     *
     * @param formName - заголовок формы
     * @param rowName  - имя строки формы (отображается слева).
     * @param text     - вводимый текст
     */
    default void setTextInputByModalNameAndFormRowName(String formName, String rowName, String text) {
        $(By.xpath("//*[contains(@class,'maintitle') and contains(text(),'" + formName + "')]" +
                "/ancestor::section[1]//elma-form-row//span[contains(text(),'" + rowName + "')]" +
                "/ancestor::elma-form-row[1]//input")).should(exist).scrollTo().shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, text);
    }

    /**
     * Нажать на кнопку в item-box
     *
     * @param itemName   - название itemName
     * @param buttonName - имя кнопку
     */
    default void clickButtonInItemBoxByItemName(String itemName, String buttonName) {
        $(By.xpath("//span[contains(text(),'" + itemName + "')]" +
                "/ancestor::div[contains(@class,'item-box')]//button[contains(text(),'" + buttonName + "')]"))
                .shouldBe(visible).click();
    }
}
