package pages.BasePages.Actions;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Condition.visible;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;

/**
 * Интерфейс, описывающий стандартные для страниц с верхним тулбаром действия.
 */
public interface ConstructorPageActions {
    By saveInToolbarCss = By.cssSelector("app-button[name='diagram.header-actions@save']");
    By backInToolbarCss = By.cssSelector("elma-editor-header a[title*='Назад']");
    By checkInToolbarCss = By.cssSelector("app-button[name='diagram.header-actions@validate']");
    // Вкладка в конструкторе процессов (Схема / Контекст / Формы / ...)
    By tabRouterLink = By.cssSelector("[routerlinkactive='active']");

    /**
     * Открыть указанную вкладку в верхнем тулбаре.
     *
     * @param tabName Название вкладки (Схема / Контекст / Формы / Сценарии / Настройки)
     */
    default void selectTab(String tabName) {
        $$(tabRouterLink).findBy(text(tabName)).click();
    }

    /**
     * Нажать кнопку "сохранить" в верхнем тулбаре.
     */
    default void clickSave() {
        $(saveInToolbarCss).shouldBe(visible).click();
    }

    /**
     * Нажать кнопку "назад" в верхнем тулбаре.
     */
    default void clickBack() {
        $(backInToolbarCss).shouldBe(visible).click();
    }

    /**
     * Нажать кнопку "проверить" в верхнем тулбаре.
     */
    default void clickCheck() {
        $(checkInToolbarCss).shouldBe(visible).click();
    }

}
