package pages.BasePages.Actions;

import org.openqa.selenium.By;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static java.lang.String.format;

/**
 * Интерфейс, описывающий базовые действия на страницах настроек.
 * Работает только со страницами, содержащими app-admin-params и подобные элементы настроек.
 */
public interface ConfigPageActions {
    /**
     * Корневой элемент - обертка над настройками секций и приложений
     */
    String rootElementXpath = "//div[contains(@class,'app-content__inner')]";
    /**
     * Контент страницы настроек (название страницы в левом блоке не входит)
     */
    String pageContentXpath = "//app-page-content";
    /**
     * Корневой элемент таблицы-древа
     */
    String treeNodeXpath = "//elma-treetable";

    /**
     * @param buttonName - имя кнопки на встраиваемом элементе, которую нужно нажать
     */
    default void clickButtonOnConfigPage(String buttonName) {
        $(By.xpath(rootElementXpath + format("//button[contains(text(),'%s')]", buttonName)))
                .should(exist).scrollTo().shouldBe(visible).click();
    }

    /**
     * @param name - текстовый элемент в поле таблицы, наличие которого нужно проверить
     */
    default void checkItemExistOnConfigPageTable(String name) {
        $(By.xpath(rootElementXpath + pageContentXpath + format("//span[contains(.,'%s')]", name)))
                .should(exist).scrollTo().shouldBe(visible);
    }

    /**
     * @param name - текстовый элемент в поле таблицы, который нужно открыть
     */
    default void openItemOnContentPageTable(String name) {
        $(By.xpath(rootElementXpath + pageContentXpath + format("//span[contains(.,'%s')]", name)))
                .should(exist).scrollTo().shouldBe(visible).click();
    }

    /**
     * @param text - текст в поле ввода, наличие которого нужно проверять
     */
    default void checkTextInFieldInput(String text) {
        $$(By.xpath(rootElementXpath + pageContentXpath + "//input[contains(@type,'text')]"))
                .findBy(value(text)).shouldBe(visible);
    }

    /**
     * @param tabName - название вкладки, которую нужно открыть
     */
    default void chooseTabOnConfigPage(String tabName) {
        $(By.xpath(rootElementXpath + pageContentXpath + format("//ul/li[contains(.,'%s')]", tabName)))
                .shouldBe(visible).click();
    }
}
