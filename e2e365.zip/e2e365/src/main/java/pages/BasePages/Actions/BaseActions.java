package pages.BasePages.Actions;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import infrastructure.helpers.configs.E2eTestConfig;
import infrastructure.utils.Constants;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.io.File;
import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static infrastructure.utils.Constants.TimeWait.SECONDS_1;

/**
 * Интерфейс, описывающий базовые действия на страницах,
 * такие как заполнение полей ввода форм, установка чекбоксов, выбор кнопок-селекторов.
 */
public interface BaseActions {

    E2eTestConfig config = E2eTestConfig.getInstance();
    By appTrashButtonCss = By.cssSelector("elma-modal-window *[title='Удалить']");
    By confirmDeletionButton = By.cssSelector("div[class*='popover-outer'] button[elmabutton='danger']");
    By radioButtonLabelCss = By.cssSelector("label.p-radiobutton-label");
    By modalHeaderCss = By.cssSelector("p-header");
    By zoomAllCss = By.cssSelector("elma-modal-body button.input-group-search");
    By rowTableCss = By.cssSelector("elma-modal-window tbody td");
    // Кастомный элемент p-checkbox, хранит в себе название и чекбокс
    By pCheckboxXpath = By.xpath("//p-checkbox");
    // Div в элементе p-checkbox
    By pCheckboxDiv = By.cssSelector("p-checkbox .p-checkbox.p-component");
    // Название чекбокса
    By checkboxLabel = By.cssSelector("label.p-checkbox-label");
    By dropDownItemCss = By.cssSelector("li.p-dropdown-item");
    // Элементы переменной на форме
    By variablesOnFormCss = By.cssSelector("elma-tab div[class*='form-fields'] ngx-dnd-item");
    By applicationSelectorButtonXpath = By.xpath("//button[contains(., 'Выберите Приложение')]");

    /**
     * @param title - параметр title у кнопки, которую нужно нажать (строгое соответствие)
     */
    default void clickButtonByTitleParameterFullMatch(String title) {
        $(By.xpath("//button[@title='" + title + "']")).should(exist)
                .scrollTo().shouldBe(visible).click();
    }

    /**
     * @param formRow - название строки формы
     * @param option  - элемент выпадающего списка, который нужно выбрать
     */
    default void selectDropDownItemByFormRowName(String formRow, String option) {
        $(By.xpath("//span[contains(text(),'" + formRow +
                "')]/ancestor::elma-form-row[1]//div[@aria-label='dropdown trigger']")).shouldBe(visible).click();
        $(By.xpath("//p-dropdownitem[contains(.,'" + option +
                "')]")).shouldBe(visible).click();
    }

    /**
     * @param formRow - название строки формы
     * @param text    - текст, который должен содержаться в строке формы (проверяет все элементы).
     */
    default void checkFormRowWithNameContainsText(String formRow, String text) {
        $(By.xpath("//span[contains(text(),'" + formRow +
                "')]/ancestor::elma-form-row[1][contains(.,'" + text + "')]")).shouldBe(visible);
    }

    /**
     * @param formRow    - название строки формы
     * @param buttonName - текст кнопки, которую нужно нажать.
     */
    default void clickButtonByNameAndFormRowName(String formRow, String buttonName) {
        $(By.xpath("//span[contains(text(),'" + formRow +
                "')]/ancestor::elma-form-row[1]//button[contains(.,'"
                + buttonName + "')]")).shouldBe(visible).click();
    }

    /**
     * Выбрать из всплывающего списка кнопку, которую нужно добавить
     *
     * @param buttonName - название Добавляемой кнопки
     */
    default void selectPopoverOptionByName(String buttonName) {
        $$("elma-popover-menu-option span").findBy(text(buttonName)).shouldBe(visible).click();
    }

    /**
     * Нажать кнопку удалить и подтвердить удаление
     */
    default void clickDeleteButtonAndConfirm() {
        $(appTrashButtonCss).shouldBe(visible).click();
        $(confirmDeletionButton).shouldBe(visible).click();
    }

    /**
     * Проверить, что поле ввода с введённым фрагментом текста видимо в выбранной строке формы.
     *
     * @param rowName - имя строки в форме (можно неполное).
     * @param text    - фрагмент текста для проверки.
     */
    default void checkInputFormRowValue(String rowName, String text) {
        $(By.xpath("//span[contains(text(),'" + rowName + "')]" +
                "//ancestor::elma-form-row[1]//input[contains(text(),'')]"))
                .shouldBe(visible).shouldHave(value(text));
    }

    /**
     * Установить чекбокс по отображаемому справа от него тексту
     *
     * @param label     - имя чекбокса (отображается справа).
     * @param condition - состояние отмечен/не отмечен
     */
    default void setCheckboxConditionByLabel(String label, boolean condition) {
        if ($$(pCheckboxXpath).findBy(text(label)).shouldBe(visible).$("div").is(Condition.cssClass("p-checkbox-checked")) != condition) {
            $$(checkboxLabel).findBy(text(label)).parent().$(pCheckboxDiv).shouldBe(visible).click();
        }
    }

    /**
     * Установить чекбокс по отображаемому справа от него тексту
     *
     * @param label     - имя чекбокса (отображается справа).
     * @param condition - состояние отмечен/не отмечен
     */
    default void setCheckboxConditionByFormRowAndLabel(String rowName, String label, boolean condition) {
        By checkBoxNameXpath = By.xpath("//elma-form-row//span[contains(text(), '" + rowName + "')]" +
                "/ancestor::elma-form-row[1]//p-checkbox[contains(.,'" + label + "')]//div[contains(@class,'p-checkbox-box')]");
        SelenideElement element = $(checkBoxNameXpath).shouldBe(visible);
        if ($(checkBoxNameXpath).is(Condition.cssClass("p-highlight")) != condition)
            element.click();
    }


    /**
     * Установить чекбокс в таблице по названию его колонки и содержащемуся в строке тексту.
     *
     * @param columnName - название колонки в шапке таблицы.
     * @param rowName    - элемент label в строке тела таблицы, обычно - название строки слева, но можно зацепиться за другую ячейку.
     * @param condition  - целевое состояние чекбокса на пересечении строки и колонки.
     */
    default void setCheckboxInTableByColumnNameAndNameInRow(String columnName, String rowName, boolean condition) {
        $(By.xpath("//thead//tr//th[contains(text(),'" + columnName + "')]")).shouldBe(visible);
        $(By.xpath("//tbody//tr//td//span[contains(text(),'" + rowName + "')]")).shouldBe(visible);
        int columnNum = $$(By.xpath("//thead//tr//th[contains(text(),'" + columnName + "')]/preceding-sibling::th")).size() + 1;
        By targetCheckbox = By.xpath("//tbody//tr//td//span[contains(text(),'" + rowName + "')]/ancestor::tr[1]/td[" + columnNum + "]//p-checkbox");
        if ($(targetCheckbox).shouldBe(visible).$("div").is(cssClass("p-checkbox-checked")) != condition) {
            $(targetCheckbox).click();
        }
        if (condition) $(targetCheckbox).shouldBe(visible).$("div").shouldHave(cssClass("p-checkbox-checked"));
        else $(targetCheckbox).shouldBe(visible).$("div").shouldNotHave(cssClass("p-checkbox-checked"));
    }


    /**
     * Нажать кнопку в строке формы по названию строки формы и тексту кнопки
     */
    default void clickButtonOnFormRow(String rowName, String buttonText) {
        $(By.xpath("//span[contains(text(),'" + rowName +
                "')]/ancestor::elma-form-row[1]//button[contains(text(),'"
                + buttonText + "')]")).should(exist).scrollTo().shouldBe(visible).click();
    }

    /**
     * Нажать кнопку с изображением лупы по названию содержащей её строки формы.
     *
     * @param rowName - имя строки формы (отображается слева).
     */
    default void clickLoupeButtonByFormRowName(String rowName) {
        clickButtonOnFormRow(rowName, "tool_zoom_all");
    }

    /**
     * Выбрать кнопку по отображаемому справа от неё тексту
     *
     * @param label - имя кнопки (отображается справа).
     */
    default void clickRadioButtonByLabel(String label) {
        $$(radioButtonLabelCss).findBy(text(label)).shouldBe(visible).click();
    }

    /**
     * Выбрать кнопку-свитч по отображаемому на ней тексту
     *
     * @param rowName    - имя строки формы (отображается слева).
     * @param buttonName - текст на кнопке - свитче.
     */
    default void clickSwitchButtonByFormRowName(String rowName, String buttonName) {
        $(By.xpath("//elma-form-row//span[contains(text(), '"
                // сделал возврат вверх до элемента, а не на количество шагов
                + rowName + "')]/ancestor::elma-form-row[1]//elma-switch" +
                // выбрать кнопку-свитч
                "//span[contains(text(),'" + buttonName + "')]")).shouldBe(visible).click();
    }

    /**
     * Удалить старый текст и ввести новый текст в блок текста по имени строки формы.
     *
     * @param rowName - имя строки формы (отображается слева).
     * @param text    - вводимый текст
     */
    default void setTextBlockByFormRowName(String rowName, String text) {
        $(By.xpath("//elma-form-row//span[contains(text(), '"
                // сделал возврат вверх до элемента, а не на количество шагов
                + rowName + "')]/ancestor::elma-form-row[1]//textarea")).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, text);
    }

    /**
     * Удалить старый текст и ввести новый текст в строку ввода текста по имени строки формы.
     *
     * @param rowName - имя строки формы (отображается слева).
     * @param text    - вводимый текст
     */
    default void setTextInputByFormRowName(String rowName, String text) {
        $(By.xpath("//elma-form-row//span[contains(text(), '" + rowName + "')]" +
                "/ancestor::elma-form-row[1]//input")).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, text, Keys.TAB);
    }

    /**
     * Установить значение в поле ввода с поиском по имени строки формы.
     *
     * @param rowName - имя строки формы (отображается слева).
     * @param text    - вводимый текст
     */
    default void setTextInputWithSearchByFormRowName(String rowName, String text) {
        $(By.xpath("//elma-form-row//span[contains(text(), '" + rowName + "')]" +
                "/ancestor::elma-form-row[1]//input")).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, text);
        selectDropdownOptionByText(text);
    }

    /**
     * Выбрать элемент выпадающего списка под полем ввода с поиском.
     */
    default void selectDropdownOptionByText(String text) {
        $(By.xpath(String.format("//ul[contains(@class,'p-autocomplete-items')]" +
                "//li[@role='option' and contains(.,'%s')]", text))).shouldBe(visible).click();
    }

    /**
     * Удалить старый текст и ввести новый текст в строку ввода текста по имени строки формы и названию поля ввода.
     * Применяется в тех случаях, когда строка формы содержит несколько полей ввода
     *
     * @param rowName    - имя строки формы (отображается слева).
     * @param inputLabel - название поля ввода (отображается рядом с полем ввода)
     * @param text       - вводимый текст
     */
    default void setTextInputByLabelAndFormRowName(String rowName, String inputLabel, String text) {
        String locator = String.format("" +
                "//elma-form-row//span[contains(text(), '%s')]/ancestor::elma-form-row[1]//elma-form-label" +
                "//span[contains(text(),'%s')]/ancestor::elma-form-row[1]//input", rowName, inputLabel);
        $(By.xpath(locator)).shouldBe(visible)
                .sendKeys(Keys.chord(Keys.CONTROL, "a") + Keys.DELETE, text);
    }

    /**
     * Выбрать элемент из выпадающего списка наеденного по названию модальной формы, названию списка и самого текста в поле.
     * Применяется в тех случаях, когда строка формы содержит несколько выпадающих списков
     *
     * @param titleForm         - имя модальной формы.
     * @param rowName           - имя списка (отображается слева).
     * @param dropDownLabelName - надпись в поле.
     * @param itemName          - имя элемента для выбора.
     */
    default void clickAndSelectDropDownItemWithLabelAndNameModalForm(String titleForm, String rowName, String dropDownLabelName, String itemName) {
        String locator = String.format("" +
                "//elma-modal-window[contains(.,'%s')]//elma-form-row//span[contains(text(), '%s')]" +
                "/ancestor::elma-form-row[1]//p-dropdown[contains(.,'%s')]", titleForm, rowName, dropDownLabelName);
        $(By.xpath(locator)).shouldBe(visible).click();
        $$(dropDownItemCss).findBy(text(itemName)).scrollTo().shouldBe(visible).click();
    }

    /**
     * @param buttonName - имя кнопки-селектора, которую нужно нажать.
     */
    default void clickRadioButton(String buttonName) {
        $$(radioButtonLabelCss).findBy(text(buttonName)).shouldBe(visible).click();
    }

    /**
     * @param windowName - заголовок модельного окна, наличие которого нужно проверить
     */
    default void checkModalWindowWithNameVisible(String windowName) {
        $$(modalHeaderCss).findBy(text(windowName)).shouldBe(visible);
    }

    /**
     * @param windowName - заголовок модельного окна, наличие которого НЕ существует
     */
    default void checkModalWindowWithNameNotVisible(String windowName) {
        $$(modalHeaderCss).findBy(text(windowName)).shouldNot(exist);
    }

    /**
     * Нажать кнопку X что бы удалить карточку группы, пользователя или должности под полем выбора.
     *
     * @param userName - название группы, пользователя или должности, карточку которой нужно удалить
     */
    default void clickRemoveUserOrGroupButton(String userName) {
        $(By.xpath("//app-group-name[contains(.,'" + userName + "')]/../button")).shouldBe(visible).click();
    }

    // todo: рефакторинг
    default void clickZoomAll() {
        $(zoomAllCss).shouldBe(visible).click();
    }

    // todo: рефакторинг
    default void chooseRowTable(String rowName) {
        $$(rowTableCss).findBy(text(rowName)).shouldBe(visible).click();
    }

    // todo: рефакторинг
    default void fillCommentConfirmDialog(String text) {
        $(By.cssSelector(".confirm-dialog textarea")).shouldBe(visible).sendKeys(text);
    }

    // todo: рефакторинг
    default void clickConfirmDialogButton(String buttonName) {
        $$(".confirm-dialog.visible button").findBy(text(buttonName)).shouldBe(visible).click();
    }

    /**
     * Проверить, что в поле выбора выбран элемент
     *
     * @param rowName  - название строки формы
     * @param itemName - название элемента
     */
    default void checkChooseFieldLinkedWithElement(String rowName, String itemName) {
        $(By.xpath("//elma-modal-window//elma-form-row[contains(.,'" + rowName + "')]")).shouldBe(visible).shouldHave(text(itemName));
    }

    /**
     * Раскрывает путь к вложенному целевому элементу в tree node и выбирает его,
     * опционально раскрывая указанные секции и приложения.
     */
    default void selectFoldedTreeNodeElementByName(String sectionName, String target) {
        openTreeNodeElementIfNotOpened(sectionName);
        $(By.xpath(String.format("//span[contains(@class,'p-treenode-label')]" +
                "//span[contains(text(),'%s')]", target))).should(exist).scrollTo().shouldBe(visible).click();
    }

    /**
     * Раскрывает путь к целевому элементу в tree node через два элемента-родителя и выбирает его,
     * опционально раскрывая указанные секции и приложения.
     */
    default void selectDoubleFoldedTreeNodeElementByName(String sectionName, String appName, String target) {
        openTreeNodeElementIfNotOpened(sectionName);
        openTreeNodeElementIfNotOpened(appName);
        $(By.xpath(String.format("//span[contains(@class,'p-treenode-label')]" +
                "//span[contains(text(),'%s')]", target))).should(exist).scrollTo().shouldBe(visible).click();
    }

    /**
     * Раскрывает элемент дерева процессов и подобных tree node в модальных окнах.
     *
     * @param name - имя элемента, который надо открыть.
     */
    default void openTreeNodeElementIfNotOpened(String name) {
        SelenideElement sectionFoldedStatus = $(By.xpath(String.format("//span[contains(text(),'%s')]" +
                "/ancestor::span[contains(@class,'p-treenode-label')][1]" +
                "//span[contains(@class,'expand-status')]", name))).should(exist).scrollTo().shouldBe(visible);
        if (sectionFoldedStatus.is(cssClass("collapsed"))) sectionFoldedStatus.shouldBe(visible).click();
    }

    /**
     * Установить кнопку-переключатель (radio button) по названию строки формы и названию кнопки
     *
     * @param rowName - имя строки формы (отображается слева).
     * @param label   - вводимый текст
     */
    default void chooseRadioButtonByFormRowNameAndLabel(String rowName, String label) {
        $(By.xpath("//elma-form-row//span[contains(text(), '" + rowName + "')]" +
                "/ancestor::elma-form-row[1]//p-radiobutton[contains(., '" + label + "')]")).shouldBe(visible).click();
    }

    /**
     * Проверить какие чекбоксы отмечены на форме по названию формы
     *
     * @param formName       - Название на форме
     * @param requiredToFill - Обязательность заполнения (true - отмечен чекбокс, false - пустой чекбокс)
     * @param readOnly       - только для чтения (true - отмечен чекбокс, false - пустой чекбокс)
     */
    default void checkRequiredToFillInAndReadOnly(String formName, boolean requiredToFill, boolean readOnly) {
        SelenideElement elementReadonly = $$(variablesOnFormCss).findBy(text(formName)).$("elma-checkbox[name='readonly']").shouldBe(visible);
        SelenideElement elementRequired = $$(variablesOnFormCss).findBy(text(formName)).$("elma-checkbox[name='required']").shouldBe(visible);

        if (readOnly) $(elementReadonly).shouldBe(visible).$("div").shouldHave(cssClass("p-checkbox-checked"));
        else $(elementReadonly).shouldBe(visible).$("div").shouldNotHave(cssClass("p-checkbox-checked"));

        if (requiredToFill) $(elementRequired).shouldBe(visible).$("div").shouldHave(cssClass("p-checkbox-checked"));
        else $(elementRequired).shouldBe(visible).$("div").shouldNotHave(cssClass("p-checkbox-checked"));
    }

    /**
     * Проверить существует название переменной на форме
     *
     * @param formName - Название на форме
     */
    default void checkFormNameExists(String formName) {
        $$(variablesOnFormCss).findBy(text(formName)).shouldBe(visible);
    }

    /**
     * Проверить состояние радиобаттона по отображаемому справа от него тексту
     *
     * @param label     - имя радиобаттона (отображается справа).
     * @param condition - состояние отмечен/не отмечен
     */
    default void checkStatusOfRadiobuttonByLabel(String label, boolean condition) {
        SelenideElement pElement = $(By.xpath("//*[contains(text(), '" + label + "')]/../..//p-radiobutton"));
        if (condition) $(pElement).shouldBe(visible).$("div").shouldHave(cssClass("p-radiobutton-checked"));
        else $(pElement).shouldBe(visible).$("div").shouldNotHave(cssClass("p-radiobutton-checked"));
    }

    /**
     * Выбрать приложение в поле ввода формы.
     * Работает с первым найденным полем "выберите приложение"
     *
     * @param sectionName     - название раздела, содержащего приложение
     * @param applicationName - название приложения
     */
    default void selectApplicationParameter(String sectionName, String applicationName) {
        $(applicationSelectorButtonXpath).click();
        By expandButtonXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]//span[contains(@class, 'collapsed')]"
                , sectionName));
        if ($(expandButtonXpath).is(exist)) {
            $(expandButtonXpath).click();
        }
        By applicationToClickXpath = By.xpath(String.format(
                "//span[contains(.,'%s')]/../..//span[text()='%s']"
                , sectionName, applicationName));
        $(applicationToClickXpath).click();
    }

    /**
     * Установить приложение в поле ввода формы, если форма уже заполнена.
     *
     * @param sectionName     - название раздела, содержащего приложение
     * @param applicationName - название приложения
     */
    default void setApplicationByRowName(String rowName, String sectionName, String applicationName) {
        By trash = By.xpath("//span[contains(text(),'" + rowName + "')]//ancestor::elma-form-row[1]//button[contains(text(),'app_trash')]");
        $(By.xpath("//span[contains(text(),'" + rowName + "')]//ancestor::elma-form-row[1]")).shouldBe(visible);
        if ($(trash).is(visible)) $(trash).shouldBe(visible).click();
        selectApplicationParameter(sectionName, applicationName);
    }

    /**
     * Проверить, что на экране присутствует JS alert с текстом
     *
     * @param text - фрагмент текста для поиска
     */
    default void checkAlertWithTextFragmentExists(String text) {
        $(By.xpath(String.format("//elma-top-center-error//div[contains(text(), '%s')]", text))).shouldBe(visible);
    }

    /**
     * @param placeholder - текст, содержащийся в незаполненном поле input, заглушка.
     * @param text        - текст, который нужно ввести в поле.
     */
    default void setTextInputByPlaceholder(String placeholder, String text) {
        $(By.xpath("//input[contains(@placeholder,'" + placeholder + "')]")).should(exist)
                .scrollTo().shouldBe(visible).sendKeys(text);
    }

    /**
     * Проверить, что цвет элемента зелёный и непрозрачный.
     */
    default void checkElementColorIsGreen(SelenideElement element) {
        element.shouldBe(visible).shouldHave(element.should(exist).scrollTo()
                .shouldBe(visible).getCssValue("color").contains("rgba")
                        ? cssValue("color", "rgba(56, 118, 28, 1)")
                        : cssValue("color", "rgb(56, 118, 28)"));
    }

    /**
     * Проверить, что фоновый цвет элемента зелёный и непрозрачный.
     */
    default void checkElementBackgroundColorIsGreen(SelenideElement element) {
        element.shouldBe(visible).shouldHave(element.should(exist).scrollTo()
                .shouldBe(visible).getCssValue("color").contains("rgba")
                ? cssValue("background-color", "rgba(56, 118, 28, 1)")
                : cssValue("background-color", "rgb(56, 118, 28)"));
    }

    /**
     * Проверить, что фоновый цвет элемента соответствует значениям RGB или RGBA.
     */
    default void checkElementBackgroundColor(SelenideElement element, int r, int g, int b) {
        boolean isRGBA = element.scrollTo().shouldBe(visible).getCssValue("background-color").contains("rgba");
        element.shouldHave((isRGBA)
                ? cssValue("background-color", "rgba(" + r + ", " + g + ", " + b + ", 1)")
                : cssValue("background-color", "rgb(" + r + ", " + g + ", " + b + ")"));
    }

    default void checkFileExistsInDownloadsFolderByPartOfName(String fileName) {
        boolean isExist = false;
        for (int i = 0; i < 15 && !isExist; CustomDriver.waitMills(SECONDS_1 + i++))
            isExist = Arrays.stream(Objects.requireNonNull(new File(Constants.PATH_TO_DOWNLOADS_DIR).listFiles()))
                    .sequential().anyMatch(e -> e.getName().contains(fileName));
        Assertions.assertTrue(isExist, "Файл с фрагментом названия " + fileName + " не найден в папке загрузок");
    }
}
