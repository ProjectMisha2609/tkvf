package pages.BasePages;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import infrastructure.drivers.CustomDriver;
import infrastructure.helpers.configs.E2eTestConfig;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import pages.BasePages.Actions.BaseActions;
import pages.BasePages.Actions.CrmActions;
import pages.BasePages.Actions.ModalActions;

import java.time.Duration;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.codeborne.selenide.Condition.*;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static infrastructure.utils.Constants.TimeWait.SECONDS_1;

public abstract class BasePage implements BaseActions, ModalActions, CrmActions {

    protected static E2eTestConfig config = E2eTestConfig.getInstance();
    final private By greySpinnerXpath = By.xpath("//elma-spinner");

    /**
     * Открыть страницу
     *
     * @param route путь до ресурса
     */
    public void open(String... route) {
        String baseUrl = config.standUrl;
        String fullUrl = String.format(baseUrl + String.join("/", route)).toLowerCase(Locale.ROOT);
        Selenide.open(fullUrl);
        checkAlert();
        // часто сталкивался со слишком ранними манипуляциями с контентом страницы, добавил ожидание сообщений в левом тулбаре.
        sectionToolbar().waitForSectionInLeftToolbarInitialized("messages");
    }

    /**
     * Обновить страницу (действие браузера)
     */
    public void refreshPage() {
        Selenide.refresh();
        checkAlert();
    }

    /**
     * Нажать кнопку назад (действие браузера)
     */
    public void clickBack() {
        Selenide.back();
        checkAlert();
    }

    /**
     * Получить айдишку из текущего URL
     *
     * @return возвращает первый попавшийся айди из текущего URL
     */
    public String getCurrentId() {
        Pattern pattern = Pattern.compile("[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-4[a-fA-F0-9]{3}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}");
        String result = null;
        Matcher matcher;
        int tries = 0;
        while (result == null && tries < 15) {
            tries++;
            CustomDriver.waitMills(SECONDS_1);
            matcher = pattern.matcher(CustomDriver.getCurrentUrl());
            if (matcher.find()) result = matcher.group();
        }
        Assertions.assertNotNull(result, "Не найден ID в ссылке");
        return result;
    }

    /**
     * Проверяем что нет никаких JS алертов и ждем когда перестанут грузится спиннеры
     */
    protected void checkAlert() {
        // доступ изменён на protected, что бы наследники могли вызвать метод.
        CustomDriver.alertAccept();
    }

    /**
     * Подождать появления серых спиннеров, если есть - дождаться исчезновения.
     */
    public void waitGreySpinnerDisappear() {
        // создание коллекции спиннеров
        ElementsCollection greySpinners = $$(greySpinnerXpath);
        try {
            // попытка дождаться появления спиннеров, даётся одна секунда
            greySpinners.last().shouldBe(visible, Duration.ofSeconds(1));
        } catch (com.codeborne.selenide.ex.ElementNotFound ignore) {
            // если спиннеров нет, здесь метод закончит работу, ибо foreach применять не на чем
        } finally {
            for (SelenideElement spinner : greySpinners) {
                spinner.shouldBe(hidden, Duration.ofSeconds(60));
            }
        }
    }

    /**
     * Получает информацию о текущем пользователе из хэдера.
     *
     * @return Фамилия текущего пользователя / логин, если не указана
     */
    public String getCurrentUserCredentialsFirstWord() {
        String[] fio = $(By.cssSelector("app-user-name"))
                .shouldBe(visible).getText().split(" ");
        return fio[0];
    }

    /**
     * Тулбар с разделами
     *
     * @return new SectionToolbar
     */
    public SectionToolbar sectionToolbar() {
        return new SectionToolbar();
    }

    /**
     * Тулбар с приложениями
     *
     * @return new AppToolbar
     */
    public AppToolbar appToolbar() {
        return new AppToolbar();
    }

    /**
     * Верхний тулбар с названием и кнопками действий
     *
     * @return new AppPageHeaderMenu
     */
    public AppPageHeaderMenu appHeaderToolbar() {
        return new AppPageHeaderMenu();
    }

    /**
     * Верхний тулбар задачи с названием и кнопками действий
     *
     * @return new TaskPageHeaderMenu
     */
    public TaskPageHeaderMenu TaskPageHeaderMenu() {
        return new TaskPageHeaderMenu();
    }


    /**
     * Класс для работы с левым тулбаром разделов
     */
    public static class SectionToolbar {
        /**
         * вызов класса для работы с подменю левого тулбара
         */
        public toolbarSubmenu toolbarSubmenu() {
            return new toolbarSubmenu();
        }

        /**
         * класс для работы с подменю (любым) левого тулбара
         * вносить только те методы, которые являются универсальными
         */
        public static class toolbarSubmenu {
            // селектор для получения блоков текстов всех открытых кнопок подменю
            private final By submenuButtons = By.cssSelector("div[class*='side-nav__item']>a");

            /**
             * метод клика на кнопку подменю левого тулбара по её ссылке
             */
            public void clickSubmenuButtonByHref(String href) {
                $$(submenuButtons).findBy(href(href)).shouldBe(exist).scrollTo().click();
            }
        }

        public final By mainToolbarCss = By.cssSelector("app-navigation-main-item");
        private final By companyLogo = By.cssSelector("app-navigation-main a[href='/']");
        private final By addSection = By.xpath("//div[@class='side-nav__buttons']//i[text()='system_add_round']/..");
        private final By settingsSection = By.xpath("//div[@class='side-nav__buttons']//i[text()='tool_wrench']/..");

        /**
         * Метод для ожидания появления (существования, не видимости) раздела в левом тулбаре.
         *
         * @param codeName - название JS элемента, на который перенаправляет кнопка тулбара
         */
        public void waitForSectionInLeftToolbarInitialized(String codeName) {
            $(By.xpath(String.format("//app-navigation-main-item/a[contains(@href,'%s')]",
                    codeName.toLowerCase(Locale.ROOT))))
                    .should(exist);
        }

        /**
         * Метод перехода в раздел в левом тулбаре.
         * Требует инициализации тулбара, желательно применять после waitForSectionInLeftToolbarInitialized
         *
         * @param codeName - название JS элемента, на который перенаправляет кнопка тулбара
         */
        public void selectSectionByCode(String codeName) {
            $$(mainToolbarCss).shouldBe(CollectionCondition.sizeGreaterThan(1));
            $(By.xpath(String.format("//app-navigation-main-item/a[contains(@href,'%s')]",
                    codeName.toLowerCase(Locale.ROOT))))
                    .shouldBe(visible)
                    .scrollTo()
                    .hover()
                    .click();
        }

        /**
         * Нажать на кнопку настройки разделов
         */
        public void clickSettings() {
            $(settingsSection).shouldBe(visible).hover().click();
        }

        /**
         * Нажать на кнопку добавить раздел
         */
        public void clickAddSection() {
            $(addSection).shouldBe(visible).hover().click();
        }

        /**
         * Нажать на кнопку "На главную" - Логотип компании
         */
        public void clickElmaIcon() {
            $(companyLogo).shouldBe(visible).click();
        }

        /**
         * Проверить, что существует секция с заданным названием
         */
        public void checkSectionExist(String sectionName) {
            $$(mainToolbarCss).findBy(text(sectionName)).shouldBe(exist);
        }

        /**
         * Проверить, что НЕ существует секция с заданным названием
         */
        public void checkSectionNotExist(String sectionName) {
            $$(mainToolbarCss).findBy(text(sectionName)).shouldNot(exist);
        }
    }

    /**
     * Класс для работы с левым тулбаром приложений
     */
    public static class AppToolbar {
        private final By sectionNameCss = By.cssSelector("app-navigation-submenu-title");
        private final By sectionSettingsButtonCss = By.cssSelector("a[data-test='sectionSettingsTopDd']");
        private final By popoverSectionSettingsCss = By.cssSelector("app-namespace-options div[data-test='namespaceOptionsPopoverBody']");
        private final By sectionSettingCss = By.cssSelector("a[class*='menu-group__option']");
        private final By appOptionsCss = By.cssSelector("a[data-test='appSettingsB']");
        private final By appOptionsPopoverCss = By.cssSelector("app-application-options div[data-test='applicationOptionsPopoverBody']");
        private final By appOptionCss = By.cssSelector("a[class*='menu-group__option']");
        private final By pageOptionPopoverCss = By.cssSelector("app-page-options");
        private final By pageOptionCss = By.cssSelector("[class*='ctx-menu__text']");
        private final By appCss = By.cssSelector("div[class*='side-nav'] span[class*='side-nav']");
        private final By addNewAppInToolbar = By.xpath("//*[@class='sidebar-controls']/button/i[contains(text(),'system_add_round')]/..");
        private final By appSettingInToolbar = By.xpath("//*[@class='sidebar-controls']/button/i[contains(text(),'tool_wrench')]/..");
        private final By contactOptionPopoverCss = By.cssSelector("app-contract-sub-menu");
        private final By contactOptionCss = By.cssSelector("[class*='menu-group__option']");

        /**
         * Выбрать приложение внутри раздела
         *
         * @param sectionCode код раздела
         * @param appCode     код приложения
         */
        public void selectAppByCode(String sectionCode, String appCode) {
            $(By.xpath(String.format("//*[contains(@class,'submenu-sidebar')]/descendant::a[contains(@href,'/%s/%s')]",
                    sectionCode.toLowerCase(Locale.ROOT),
                    appCode.toLowerCase(Locale.ROOT))))
                    .shouldBe(visible)
                    .scrollTo()
                    .hover()
                    .click();
        }

        /**
         * Нажать на приложение по имени
         * Использовать только в крайних случаях!
         *
         * @param appName название приложения
         */
        public void selectAppByName(String appName) {
            $$(appCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(appName))
                    .shouldBe(visible)
                    .scrollTo()
                    .hover()
                    .click();
        }

        /**
         * Проверить имя раздела
         */
        public void checkSectionName(String text) {
            $(sectionNameCss).shouldBe(visible).shouldHave(text(text));
        }

        /**
         * Выбрать настройки раздела
         *
         * @param settingsName название настройки
         */
        public void selectSettingsSections(String settingsName) {
            $(sectionSettingsButtonCss).shouldBe(visible).hover().click();
            $(popoverSectionSettingsCss).shouldBe(visible)
                    .$$(sectionSettingCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(settingsName)).shouldBe(visible).hover().click();
        }

        /**
         * Выбрать настройку приложения
         *
         * @param settingsName название опции
         */
        public void selectSettingsApp(String settingsName) {
            $(appOptionsCss).shouldBe(visible).hover().click();
            $(appOptionsPopoverCss).shouldBe(visible)
                    .$$(appOptionCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(settingsName)).shouldBe(visible).hover().click();
        }

        /**
         * Выбрать настройки контактов в разделе
         *
         * @param settingsName название настройки
         */
        public void selectSettingsContract(String settingsName) {
            $(appOptionsCss).shouldBe(visible).hover().click();
            $(contactOptionPopoverCss).shouldBe(visible)
                    .$$(contactOptionCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(settingsName)).shouldBe(visible).hover().click();
        }

        /**
         * Выбрать настройки страницы в разделе
         *
         * @param settingsName название настройки
         */
        public void selectSettingsPage(String settingsName) {
            $(appOptionsCss).shouldBe(visible).hover().click();
            $(pageOptionPopoverCss).shouldBe(visible)
                    .$$(pageOptionCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(settingsName)).shouldBe(visible).hover().click();
        }

        /**
         * Нажать на кнопку "добавить приложение" в разделе
         */
        public void clickAddNewAppInToolbar() {
            $(addNewAppInToolbar)
                    .shouldBe(visible)
                    .hover()
                    .click();
        }

        /**
         * Нажать на кнопку "настройки" (гаечный ключ) в разделе
         */
        public void clickSettingsInToolbar() {
            $(appSettingInToolbar)
                    .shouldBe(visible)
                    .hover()
                    .click();
        }
    }

    /**
     * todo: нужно описание класса и вложенных методов
     */
    public static class AppPageHeaderMenu {
        private final By popoverActionSettingsCss = By.cssSelector("[class*='bottom'][class*='visible'] elma-popover-menu-option");
        private final By actionSettings = By.xpath("//app-page-header/div[contains(@class,'buttons')]/button[contains(text(),'settings')]");
        private final By exportImport = By.xpath("//app-page-header//button[contains(text(),'menu_vertical')]");
        private final By pageHeaderText = By.xpath("//app-page-header//*[contains(@class, 'title')]//nav");
        private final By exportData = By.xpath("//elma-popover-menu-option/i[contains(text(),'sign_out')]/..");
        private final By importData = By.xpath("//elma-popover-menu-option/i[contains(text(),'sign_in')]/..");
        private final By closeActionButton = By.xpath("//div[contains(@class,'controls')]//button[contains(text(),'system_close')]");
        private final By addActionButton = By.xpath("//div[contains(@class,'controls')]//button[contains(text(),'system_add_round')]");

        public String getHeaderText() {
            return $(pageHeaderText).shouldBe(visible).text();
        }

        public void checkHeaderContainsText(String text) {
            $(pageHeaderText).shouldBe(visible).shouldHave(text(text));
        }

        public void clickActionButton(String buttonName) {
            $(By.xpath(String.format("//app-page-header//button[(@data-test or contains(@class, 'btn')) and contains(text(),'%s')]", buttonName)))
                    .shouldBe(visible)
                    .hover()
                    .click();
        }

        public void selectActionSettings(String settingName) {
            $(actionSettings)
                    .shouldBe(visible)
                    .hover()
                    .click();
            $$(popoverActionSettingsCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(settingName))
                    .shouldBe(visible)
                    .hover()
                    .click();
        }

        public void clickExportData() {
            $(exportImport)
                    .shouldBe(visible)
                    .click();
            $(exportData).shouldBe(visible).hover().click();
        }

        public void clickImportData() {
            $(exportImport)
                    .shouldBe(visible)
                    .click();
            $(importData).shouldBe(visible).hover().click();
        }

        public void clickPlusActionAndSelectOptions(String optionName) {
            $(addActionButton).shouldBe(visible).hover().click();
            $$(popoverActionSettingsCss).shouldBe(CollectionCondition.sizeGreaterThan(0))
                    .findBy(text(optionName))
                    .shouldBe(visible)
                    .hover()
                    .click();
        }

        public void clickSettingsInLastActionButton() {
            $(addActionButton).shouldBe(visible);
            $(By.xpath("//ngx-dnd-container//ngx-dnd-item[last()]//button[contains(text(),'settings')]"))
                    .shouldBe(visible)
                    .hover()
                    .click();
        }

        public void clickCloseActionButton() {
            $(closeActionButton).shouldBe(visible).hover().click();
        }
    }

    /**
     * todo: нужно описание класса и вложенных методов
     */
    public static class TaskPageHeaderMenu {
        private final By menuActionsTaskXpath = By.xpath("//header//button[contains(text(),'menu_vertical')]");
        private final By actionsTaskCss = By.cssSelector(".popover-outer.visible span");

        public void actionsTask(String actionName) {
            $(menuActionsTaskXpath).shouldBe(visible).click();
            $$(actionsTaskCss).findBy(text(actionName)).shouldBe(visible).click();
        }

        public void checkNotExistsActionButton(String actionName) {
            $(menuActionsTaskXpath).shouldBe(visible).click();
            $$(actionsTaskCss).findBy(text(actionName)).shouldNot(exist);
        }
    }
}