package infrastructure;

import org.junit.platform.engine.ConfigurationParameters;
import org.junit.platform.engine.support.hierarchical.ParallelExecutionConfiguration;
import org.junit.platform.engine.support.hierarchical.ParallelExecutionConfigurationStrategy;

import java.util.concurrent.ForkJoinPool;
import java.util.function.Predicate;

/**
 * Стратегия запуска, которая устанавливает желаемое количество потоков в экземпляре JVM.
 */
public class CustomStrategy implements ParallelExecutionConfiguration, ParallelExecutionConfigurationStrategy {
    public final int THREAD_COUNT = 1;

    @Override
    public int getParallelism() {
        return THREAD_COUNT;
    }

    @Override
    public int getMinimumRunnable() {
        return THREAD_COUNT;
    }

    @Override
    public int getMaxPoolSize() {
        return THREAD_COUNT;
    }

    @Override
    public int getCorePoolSize() {
        return THREAD_COUNT;
    }

    @Override
    public int getKeepAliveSeconds() {
        return THREAD_COUNT;
    }

    @Override
    public ParallelExecutionConfiguration createConfiguration(ConfigurationParameters configurationParameters) {
        return this;
    }

    /**
     * Переопределение метода, необходимое для корректной работы многопоточного запуска на JDK выше версии 16.
     * До JDK 16 включительно устанавливался как forkJoinPool -> true автоматически, в более поздних версиях приходится устанавливать явно.
     *
     * @return предикат, устанавливающий запуск многопоточных процессов через forkJoinPool
     */
    @Override
    public Predicate<? super ForkJoinPool> getSaturatePredicate() {
        return forkJoinPool -> true;
    }
}
