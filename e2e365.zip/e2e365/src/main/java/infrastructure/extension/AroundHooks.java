package infrastructure.extension;

import com.codeborne.selenide.WebDriverRunner;
import com.codeborne.selenide.logevents.SelenideLogger;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendUser;
import infrastructure.helpers.configs.E2eTestConfig;
import infrastructure.utils.Constants;
import io.qameta.allure.selenide.AllureSelenide;
import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static infrastructure.utils.Loggers.CONSOLE;

public class AroundHooks implements BeforeAllCallback, BeforeEachCallback, AfterEachCallback {
    private final E2eTestConfig config = E2eTestConfig.getInstance();

    @Override
    public void beforeAll(ExtensionContext extensionContext) {
        //Установили пользователям временную зону текущей машины
        if (isWebTest(extensionContext)) {
            BackendUser.setTimeZoneLocalMachine(BackendUser.getAuthTokenAdmin(), config.adminLogin);
            BackendUser.setTimeZoneLocalMachine(BackendUser.getAuthTokenUser(), config.userLogin);
        }
        try {
            Files.createDirectories(Paths.get(Constants.PATH_TO_REPORT));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        BackendUser.setAdminFio("Админов", "Админ", "Админович");
    }

    @Override
    public void beforeEach(ExtensionContext extensionContext) {
        if (!SelenideLogger.hasListener("AllureSelenide")) {
            SelenideLogger.addListener("AllureSelenide", new AllureSelenide()
                    .savePageSource(false)
                    .screenshots(true));
        }
        if (isWebTest(extensionContext)) {
            if (!CustomDriver.isDriverRun()) CustomDriver.initDriver();
            CustomDriver.setCookieAdmin();
        }
    }

    @Override
    public void afterEach(ExtensionContext extensionContext) {
        if (extensionContext.getExecutionException().isPresent()) {
            CONSOLE.error("Тест " + extensionContext.getRequiredTestClass().getName().replaceAll("[.]\\w+[$]", ".")
                    + " - \"" + extensionContext.getDisplayName() + "\" завершён с ошибкой.");
        } else {
            CONSOLE.info("Тест " + extensionContext.getRequiredTestClass().getName().replaceAll("[.]\\w+[$]", ".")
                    + " - \"" + extensionContext.getDisplayName() + "\" успешно пройден.");
        }
        WebDriverRunner.closeWebDriver();
    }

    public boolean isWebTest(ExtensionContext extensionContext) {
        return extensionContext.getTestClass()
                .filter(tClass -> tClass.getPackageName()
                        .contains("e2eTests"))
                .isPresent();
    }
}
