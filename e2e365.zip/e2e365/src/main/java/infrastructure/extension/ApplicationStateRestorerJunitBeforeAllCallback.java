package infrastructure.extension;

import infrastructure.utils.SshStateRestorerService;
import infrastructure.utils.StateRestorerService;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;


public class ApplicationStateRestorerJunitBeforeAllCallback implements BeforeAllCallback {
    private final StateRestorerService stateRestorerService = new SshStateRestorerService();

    @Override
    public void beforeAll(ExtensionContext extensionContext) throws Exception {
        stateRestorerService.restoreBackup();
    }
}
