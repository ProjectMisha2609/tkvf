package infrastructure.utils;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import infrastructure.helpers.configs.E2eTestConfig;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class SshStateRestorerService implements StateRestorerService {
    private final E2eTestConfig config = E2eTestConfig.getInstance();
    private final String shellCmd = String.format("elma365ctl restore --path=%s", config.backupPath);
    private static Session session;

    @Override
    public void restoreBackup() throws Exception {
        if (!config.isCleaningRequired || session != null) return;
        String host = config.sshHost;
        int port = config.sshPort;
        byte[] password = ResourceProvider.getResource(config.sshPassword);
        //byte[] secretKey = ResourceProvider.getResource(config.sshSecretKey);
        byte[] knownHosts = ResourceProvider.getResource(config.sshKnownHosts);
        String username = config.sshUser;
        JSch jSch = new JSch();
        //jSch.addIdentity("", secretKey, null, null);
        jSch.setKnownHosts(new ByteArrayInputStream(knownHosts));
        session = jSch.getSession(username, host, port);
        session.setPassword(password);
        session.setConfig("server_host_key", "ecdsa-sha2-nistp256");
        session.connect();
        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand(shellCmd);
        channel.setInputStream(null);
        channel.setErrStream(System.err); //todo handle errors;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(channel.getInputStream(), StandardCharsets.UTF_8))) {
            channel.connect();
            Loggers.CONSOLE.info("[SSH SHELL] Output: {}", reader.lines().collect(Collectors.joining("\n")));
        }
    }

    private static class ResourceProvider {
        protected static byte[] getResource(String configValue) {
            String[] parts = configValue.split(":");
            if (parts.length == 1) return fromString(configValue); //interpret as string if no prefix
            try {
                switch (parts[0]) {
                    case "classpath":
                        return fromClassPath(parts[1]);
                    case "file":
                        return fromFile(parts[1]);
                    case "string":
                        return fromString(parts[1]);
                    default:
                        throw new RuntimeException("Not supported prefix: " + parts[0]);
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        private static byte[] fromInputStream(InputStream inputStream) throws IOException {
            return inputStream.readAllBytes();
        }

        protected static byte[] fromClassPath(String classPath) throws IOException {
            InputStream inputStream = ResourceProvider.class.getClassLoader().getResourceAsStream(classPath);
            if (inputStream == null)
                throw new NullPointerException(String.format("Can't read classpath resource \"%s\"", classPath));
            return fromInputStream(inputStream);
        }

        protected static byte[] fromFile(String path) throws IOException {
            File file = new File(path);
            if (!file.exists())
                throw new NullPointerException(String.format("Can't read file \"%s\", file isn't exist", path));
            return fromInputStream(new FileInputStream(file));
        }

        protected static byte[] fromString(String content) {
            return content.getBytes(StandardCharsets.UTF_8);
        }
    }
}
