package infrastructure.utils;

public interface StateRestorerService {
    void restoreBackup() throws Exception;
}
