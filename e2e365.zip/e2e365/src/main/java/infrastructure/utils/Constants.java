package infrastructure.utils;

import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class Constants {
    public static final String ELMA_TMS = "elmaTms";
    public static final String PATH_TO_REPORT = Paths.get(System.getProperty("user.dir"), "target", "tests_report").toString();
    public static final String PATH_TO_DEFAULT_DIR = Paths.get(System.getProperty("user.dir")).toString();
    public static final String PATH_TO_DOWNLOADS_DIR = Paths.get(System.getProperty("user.dir"), "target", "downloads").toString();
    public static final boolean IS_GITLAB_CI = System.getenv("CI") != null;
    /**
     * Класс с временем ожидания (миллисекунды)
     * При необходимости раскомментировать нужное ожидание для тестов
     */
    public static final class TimeWait {
        public final static long SECONDS_1 = 1000;
        public final static long SECONDS_5 = 5000;
        public final static long SECONDS_10 = 10000;
        public final static long SECONDS_40 = 40000;
        public final static long MINUTES_1 = 60000;
        public final static long MINUTES_2 = 120000;
        public final static long MINUTES_3 = 180000;
        public final static long MINUTES_5 = 300000;
        public final static long MINUTES_30 = 1800000;
        public final static long MINUTES_40 = 2400000;
    }

    /**
     * Класс со статусами пользователей, для лучшей читаемости тестов.
     * 0 - Приглашен
     * 1 - Приглашение отклонено
     * 2 - Активный
     * 3 - Заблокирован
     * 4 - Приглашение отменено
     */
    public static final class UserStatus {
        public final static int INVITED = 0;
        public final static int DENIED = 1;
        public final static int ACTIVE = 2;
        public final static int BLOCKED = 3;
        public final static int CANCELLED = 4;
    }

    /**
     * Коды системных групп
     */
    public static final class SystemGroups {
        public static final String ADMINISTRATORS = "administrators";
        public static final String EXTERNAL_USERS = "external_users";
        public static final String ALL_USERS = "all";
    }

    /**
     * Форматтеры даты и времени
     */
    public static final class DateAndTimeFormatters {
        public static final DateTimeFormatter FORMATTER_DD_MM_YYYY = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale.ROOT);
        public static final DateTimeFormatter FORMATTER_HH_MM = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);
        public static final DateTimeFormatter FORMATTER_HH_MM_SS = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ROOT);
    }

    private Constants() {
    }
}