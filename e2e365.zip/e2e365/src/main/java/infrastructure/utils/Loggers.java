package infrastructure.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Loggers {
    public static final Logger CONSOLE = LoggerFactory.getLogger("console");
    public static final Logger FILE_LOGGER = LoggerFactory.getLogger("");

    private Loggers() {
    }
}