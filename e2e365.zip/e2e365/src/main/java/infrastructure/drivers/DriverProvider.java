package infrastructure.drivers;

import com.codeborne.selenide.WebDriverProvider;
import infrastructure.utils.Constants;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;

import javax.annotation.Nonnull;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DriverProvider implements WebDriverProvider {
    @Nonnull
    @Override
    public WebDriver createDriver(@Nonnull Capabilities capabilities) {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-extensions");
        options.addArguments("--disable-gpu");
        options.addArguments("--no-sandbox");
        options.addArguments("--window-size=1920x1080");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-dev-shm-usage");
        // Обновление безопасности на 111 версии хрома, не подключается к WebSocket
        options.addArguments("--remote-allow-origins=*");
        // options.addArguments("headless=new");
        HashMap<String, Object> chromePrefs = new HashMap<>();
        chromePrefs.put("download.default_directory", Constants.PATH_TO_DOWNLOADS_DIR);
        options.setExperimentalOption("prefs", chromePrefs);
        options.setAcceptInsecureCerts(true);
        LoggingPreferences logPref = new LoggingPreferences();
        logPref.enable(LogType.DRIVER, Level.SEVERE);
        options.setCapability("goog:loggingPrefs", logPref);
        RemoteWebDriver driver;
        if (Constants.IS_GITLAB_CI) {
            Logger.getLogger("org.openqa.selenium").setLevel(Level.SEVERE);
            URL remoteDriverUrl = null;
            try {
                remoteDriverUrl = new URL("http://selenium__standalone-chrome:4444/wd/hub");
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            // В новом хроме нужно указывать версию headless new, иначе не грузит файлы.
            options.addArguments("--headless=new");
            Assertions.assertNotNull(remoteDriverUrl);
            driver = new RemoteWebDriver(remoteDriverUrl, options);
            driver.setFileDetector(new LocalFileDetector());
        } else {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver(options);
        }
        return driver;
    }
}
