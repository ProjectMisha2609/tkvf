package infrastructure.elmaBackend;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import infrastructure.drivers.CustomDriver;
import jakarta.inject.Singleton;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Класс для работы с запущенными бизнес-процессами через API.
 * TODO: возможно, стоит вложить класс в ElmaBackend, ибо размерами наполнения не блещет,
 *  а его методы не требуют наследования от ElmaBackend.
 */
@Singleton
public class BackendTasks extends ElmaBackend {

    /**
     * API ручка с параметрами URL
     */
    private static final String handlerEncode = "/api/processor/tasks/income?from=0&size=1000&q=%7B%22and%22%3A%5B%7B%22in%22%3A%5B%7B%22field%22%3A+%22state%22%7D%2C%7B%22list%22%3A%5B%22assignment%22%2C%22in_progress%22%5D%7D%5D%7D%5D%7D&sortField=__createdAt";

    /**
     * @param instanceId айди инстанцса запущенного процесса
     * @param timeWait   время ожидания появления задачи
     * @return возвращает айдишник задачи
     */
    public String getTaskByInstanceId(String instanceId, long timeWait) {
        long timeNow = new Date().getTime();
        while (true) {
            CustomDriver.waitMills(500);
            String result = findTask(instanceId);
            if (result != null) {
                return result;
            }
            long deltaTime = new Date().getTime() - timeNow;
            if (deltaTime >= timeWait) {
                throw new Error("TASK NOT FOUND! By instanceID:" + instanceId + " TIME ELAPSED " + deltaTime + " ms");
            }
        }
    }

    /**
     * Задачи из указанных инстансов
     *
     * @param instanceId список айди инстансов
     * @param timeWait   время ожидания
     * @return вернет список айди задач
     */
    public List<String> getTasksByManyInstances(List<String> instanceId, long timeWait) {
        List<String> tasksId = new ArrayList<>();
        long timeNow = new Date().getTime();
        for (int i = 0; i < instanceId.size(); i++) {
            String getId = instanceId.get(i);
            while (true) {
                CustomDriver.waitMills(500);
                String result = findTask(getId);
                if (result != null) {
                    tasksId.add(result);
                    break;
                }
                long deltaTime = new Date().getTime() - timeNow;
                if (deltaTime >= timeWait) {
                    break;
                }
            }
        }
        return tasksId;
    }

    /**
     * Найти ID всех задач по инстансу процесса
     *
     * @param instanceId айди инстанса
     * @param timeWait   время ожидания
     * @return вернет список айди задач
     */
    public List<String> getAllTaskFromInstance(String instanceId, long timeWait) {
        long timeNow = new Date().getTime();
        while (true) {
            CustomDriver.waitMills(500);
            List<String> result = findAllTask(instanceId);
            if (result.size() > 0) {
                return result;
            }
            long deltaTime = new Date().getTime() - timeNow;
            if (deltaTime >= timeWait) {
                throw new Error("TASK NOT FOUND! By instanceID:" + instanceId + " TIME ELAPSED " + deltaTime + " ms");
            }
        }
    }

    private List<String> findAllTask(String instanceId) {
        String response = getTasks();
        List<String> tasksId = new ArrayList<>();
        if (response != null) {
            JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
            JsonArray array = jsonObject.getAsJsonArray("result");
            for (int i = 0; i < array.size(); i++) {
                JsonObject getObject = array.get(i).getAsJsonObject();
                JsonObject objectInstance = getObject.getAsJsonObject("instance");
                String getInstanceId = objectInstance.get("__id").toString().replace("\"", "");
                if (instanceId.equals(getInstanceId)) {
                    tasksId.add(getObject.get("__id").toString().replace("\"", ""));
                }
            }
        }
        return tasksId;
    }

    private String findTask(String instanceId) {
        String response = getTasks();
        if (response != null) {
            JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
            JsonArray array = jsonObject.getAsJsonArray("result");
            for (int i = 0; i < array.size(); i++) {
                JsonObject getObject = array.get(i).getAsJsonObject();
                JsonObject objectInstance = getObject.getAsJsonObject("instance");
                String getInstanceId = objectInstance.get("__id").toString().replace("\"", "");
                if (instanceId.equals(getInstanceId)) {
                    return getObject.get("__id").toString().replace("\"", "");
                }
            }
        }
        return null;
    }

    private String getTasks() {
        String query = URLEncoder.encode("{\"and\":[{\"in\":[{\"field\":\"state\"},{\"list\":[\"assignment\",\"in_progress\"]}]}]}", StandardCharsets.UTF_8);
        String url = "/api/processor/tasks/income?from=0&size=1000&q=" + query + "&sortField=__createdAt";
        return micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
    }
}
