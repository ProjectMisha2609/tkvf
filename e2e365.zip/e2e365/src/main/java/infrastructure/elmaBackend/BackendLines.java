package infrastructure.elmaBackend;

import com.jayway.jsonpath.JsonPath;
import infrastructure.helpers.RandomString;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.LineJsonBodies.*;
import static infrastructure.utils.Constants.TimeWait.SECONDS_1;
import static infrastructure.utils.Loggers.CONSOLE;

@Singleton
public class BackendLines extends ElmaBackend {

    /**
     * Получить id первой существующей линии.
     *
     * @return id линии если есть / пустую строку если линии нет.
     */
    public String checkAnyLineExists() {
        String answer = micronautHttpClient.authorizedJsonGet("/api/messengers/admin/lines", getAuthTokenAdmin());
        // Хотел сделать через equals "[]", но пару раз не сработало. Решил зацепиться за длину ответа.
        if (answer.length() < 5) return "";
        return JsonPath.using(configuration).parse(answer)
                // путь прописан с учётом получения в массиве
                .read("$.[0].id").toString().replace("\"", "");
    }

    /**
     * Создаёт линию, удаляя существующую.
     *
     * @return id линии
     */
    public String createNewLineAndDeleteExisting(String lineName, String operators, String supervisors) {
        String lineId = checkAnyLineExists();
        if (!lineId.isBlank()) deleteLineWithIdIfExists(lineId);
        sleep(SECONDS_1);
        String json = JsonPath.using(configuration).parse(CREATE_LINE_JSON_BODY)
                .set("$.name", lineName)
                .set("$.__name", lineName)
                .set("$.operators[0]", getSystemGroupId(operators))
                .set("$.supervisors[0]", getSystemGroupId(supervisors))
                .json().toString();
        String answer = micronautHttpClient.authorizedJsonPost("/api/messengers/admin/lines/create", json, getAuthTokenAdmin());
        return JsonPath.using(configuration).parse(answer)
                // путь прописан без массива, ибо это ответ на POST
                .read("$.id").toString().replace("\"", "");
    }

    /**
     * Удаляет линию, если существует.
     *
     * @return id удалённой линии
     */
    public String deleteLineIfExists() {
        String lineId = checkAnyLineExists();
        if (!lineId.isBlank()) deleteLineWithIdIfExists(lineId);
        return lineId;
    }

    /**
     * Удаляет первую линию по её ID.
     *
     * @return полное тело ответа, если линию удалось удалить, null если линия не найдена.
     */
    public String deleteLineWithIdIfExists(String id) {
        String line = checkAnyLineExists();
        if (line == null) return null; // ветвление во избежание NPE
        else if (!line.equals(id)) return null;
        else return micronautHttpClient.authorizedJsonPost("/api/messengers/admin/lines/delete",
                    String.format("{\"id\":\"%s\"}", id), getAuthTokenAdmin());
    }

    /**
     * Изменяет линию по её ID.
     *
     * @param lineId      - идентификатор линии
     * @param lineName    - имя линии
     * @param operators   - имя группы операторов, принадлежащее системе
     * @param supervisors - имя группы супервизоров, принадлежащее системе
     * @param clients     - имя группы клиентов, принадлежащее системе
     * @param appName     - имя подключаемого приложения
     * @param sectionName - раздел, содержащий подключаемое приложение
     */
    public void updateLine(String lineId, String lineName, String operators, String supervisors, String clients, String sectionName, String appName) {
        Assertions.assertEquals(lineId, checkAnyLineExists(), "Линия не существует");
        String json = JsonPath.using(configuration).parse(UPDATE_LINE_ADD_APP_AND_CLIENTS_JSON_BODY)
                .set("$.id", lineId)
                .set("$.__id", lineId)
                .set("$.name", lineName)
                .set("$.__name", lineName)
                .set("$.operators[0]", getSystemGroupId(operators))
                .set("$.supervisors[0]", getSystemGroupId(supervisors))
                .set("$.members[0].id", getSystemGroupId(clients))
                .set("$.sessionBindItems[0].application.code", appName.toLowerCase(Locale.ROOT))
                .set("$.sessionBindItems[0].application.namespace", sectionName.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/messengers/admin/lines/update", json, getAuthTokenAdmin());
    }

    /**
     * Изменяет линию по её ID.
     *
     * @param lineId      - идентификатор линии
     * @param lineName    - имя линии
     * @param operators   - имя группы операторов, принадлежащее системе
     * @param supervisors - имя группы супервизоров, принадлежащее системе
     * @param clients     - имя группы клиентов, принадлежащее системе
     * @param template    - подготовленный шаблон линии
     */
    public void updateLine(String lineId, String lineName, String operators, String supervisors, String clients, String template) {
        Assertions.assertEquals(lineId, checkAnyLineExists(), "Линия не существует");
        String json = JsonPath.using(configuration).parse(template)
                .set("$.id", lineId)
                .set("$.__id", lineId)
                .set("$.name", lineName)
                .set("$.__name", lineName)
                .set("$.operators[0]", getSystemGroupId(operators))
                .set("$.supervisors[0]", getSystemGroupId(supervisors))
                .set("$.members[0].id", getSystemGroupId(clients))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/messengers/admin/lines/update", json, getAuthTokenAdmin());
    }

    /**
     * Изменяет линию по её ID.
     *
     * @param lineId      - идентификатор линии
     * @param lineName    - имя линии
     * @param operators   - имена групп операторов, принадлежащих компании
     * @param supervisors - имя группы супервизоров, принадлежащее системе
     * @param clients     - имя группы клиентов, принадлежащее системе
     * @param template    - подготовленный шаблон линии
     */
    public void updateLine(String lineId, String lineName, Set<String> operators, String supervisors, String clients, String template) {
        Assertions.assertEquals(lineId, checkAnyLineExists(), "Линия не существует");
        Set<String> operatorIds = new HashSet<>();
        for (String group : operators) {
            operatorIds.add(getCompanyGroupId(group));
        }
        String json = JsonPath.using(configuration).parse(template)
                .set("$.id", lineId)
                .set("$.__id", lineId)
                .set("$.name", lineName)
                .set("$.__name", lineName)
                .set("$.operators", operatorIds)
                .set("$.supervisors[0]", getSystemGroupId(supervisors))
                .set("$.members[0].id", getSystemGroupId(clients))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/messengers/admin/lines/update", json, getAuthTokenAdmin());
    }

    /**
     * Изменяет линию по её ID.
     *
     * @param lineId      - идентификатор линии
     * @param lineName    - имя линии
     * @param operators   - имена групп операторов, принадлежащих компании
     * @param supervisors - имена групп супервизоров, принадлежащих компании
     * @param clients     - имя группы клиентов, принадлежащее системе
     * @param template    - подготовленный шаблон линии
     */
    public void updateLine(String lineId, String lineName, Set<String> operators, Set<String> supervisors, String clients, String template) {
        Assertions.assertEquals(lineId, checkAnyLineExists(), "Линия не существует");
        Set<String> operatorIds = new HashSet<>();
        for (String group : operators) {
            operatorIds.add(getCompanyGroupId(group));
        }
        Set<String> supervisorIds = new HashSet<>();
        for (String group : supervisors) {
            supervisorIds.add(getCompanyGroupId(group));
        }
        String json = JsonPath.using(configuration).parse(template)
                .set("$.id", lineId)
                .set("$.__id", lineId)
                .set("$.name", lineName)
                .set("$.__name", lineName)
                .set("$.operators", operatorIds)
                .set("$.supervisors", supervisorIds)
                .set("$.members[0].id", getSystemGroupId(clients))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/messengers/admin/lines/update", json, getAuthTokenAdmin());
    }

    /**
     * Отправляет сообщение в линию по её ID от имени пользователя с переданным email.
     *
     * @param lineId  - ID линии для отправки сообщения
     * @param message - тело сообщения
     * @param login   - email пользователя
     */
    public void sendMessageToLine(String lineId, String login, String message) {
        String token = "";
        if (login.equals(userLogin)) token = getAuthTokenUser();
        else if (login.equals(adminLogin)) token = getAuthTokenAdmin();
        else Assertions.fail("Неизвестный пользователь");
        String json = JsonPath.using(configuration).parse(MESSAGE_JSON_BODY)
                .set("$.__id", RandomString.getUUID())
                .set("$.__createdAt", "2023-02-03T05:47:55.861Z")
                .set("$.author", getUserIdByEmail(login))
                .set("$.body", "<p> " + message + " </p>")
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/messengers/channels/" + lineId + "/message", json, token);
    }

    /**
     * Получить id первой не распределённой сессии.
     */
    public String getUnassignedSessionId() {
        for (int i = 0; i < 5; i++) {
            try {
                sleep(SECONDS_1);
                return JsonPath.using(configuration)
                        .parse(micronautHttpClient
                                .authorizedJsonGet("/api/messengers/sessions/all", getAuthTokenAdmin()))
                        .read("$.unassignedSessions[0].id")
                        .toString().replace("\"", "");
            } catch (com.jayway.jsonpath.PathNotFoundException e) {
                CONSOLE.error("Не удалось получить ID не распределённой сессии");
                i++;
            }
        }
        Assertions.fail("Не удалось получить ID не распределённой сессии после пяти попыток");
        return null;
    }

    /**
     * Создать шаблон ответа
     */
    public void createTemplate(String name) {
        String json = JsonPath.using(configuration).parse(LINE_MESSAGE_TEMPLATE)
                .set("$.payload.__id", RandomString.getUUID())
                .set("$.payload.__name", name)
                .set("$.payload._description", name + "description")
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/apps/_lines/_templates/items", json, getAuthTokenAdmin());
    }

    /**
     * Создать статью
     */
    public void createArticle(String name) {
        String json = JsonPath.using(configuration).parse(LINE_ARTICLE)
                .set("$.payload.__id", RandomString.getUUID())
                .set("$.payload.__name", name)
                .set("$.payload._template", name + "template")
                .set("$.payload._url", "https://www.google.com/")
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/apps/_lines/_articles/items", json, getAuthTokenAdmin());
    }

    public void assignSessionToUser(String sessionId, String userLogin) {
        String json = String.format("""
                {
                    "operatorId": "%s",
                    "sessionId": "%s"
                }""", getUserIdByEmail(userLogin), sessionId);
        micronautHttpClient.authorizedJsonPost("/api/messengers/operators/session/assign", json, getAuthTokenAdmin());
    }
}
