package infrastructure.elmaBackend;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;
import infrastructure.helpers.ParseUrl;
import infrastructure.helpers.configs.E2eTestConfig;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.client.BlockingHttpClient;
import io.micronaut.http.client.HttpClient;
import jakarta.inject.Singleton;
import org.apache.commons.lang3.concurrent.ConcurrentException;
import org.apache.commons.lang3.concurrent.ConcurrentInitializer;
import org.apache.commons.lang3.concurrent.LazyInitializer;
import org.junit.jupiter.api.Assertions;

import java.time.*;
import java.util.HashMap;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static infrastructure.elmaBackend.ElmaBackend.configuration;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_HH_MM;
import static infrastructure.utils.Loggers.CONSOLE;

/**
 * Класс-конфигуратор, содержащий статические методы, необходимые для работы с данными пользователей перед началом тестирования.
 * Лениво получает токены пользователя и админа, хранит и выдаёт их во время тестирования.
 * Выставляет часовые пояса на локальной машине и на сервере.
 * Хранит конфигурацию тестирования E2eTestConfig.
 * Использует вложенный клиент SimpleMicronautClient, который рассчитан на работу со статикой.
 * Участвует в конфигурировании тестов на стадии beforeAll, чем и обусловлена статичность методов.
 * <p>
 * Является родителем для всех классов, работающих c API, в связи с необходимостью доступа к данным пользователя и конфигурации.
 */
@Singleton
public class BackendUser {
    private static final E2eTestConfig config = E2eTestConfig.getInstance();
    public static final String standAndCompanyUrl = config.standUrl;
    public static final String adminLogin = config.adminLogin;
    public static final String adminPassword = config.adminPassword;
    public static final String userLogin = config.userLogin;
    public static final String userPassword = config.userPassword;
    private static final ConcurrentInitializer<String> lazyTokenInitializerAdmin;
    private static final ConcurrentInitializer<String> lazyTokenInitializerUser;

    static {
        lazyTokenInitializerAdmin = new LazyInitializer<>() {
            @Override
            protected String initialize() {
                return createAuthToken(config.adminLogin, config.adminPassword);
            }
        };
        lazyTokenInitializerUser = new LazyInitializer<>() {
            @Override
            protected String initialize() {
                return createAuthToken(config.userLogin, config.userPassword);
            }
        };
    }

    public static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            CONSOLE.error(e.getMessage());
        }
    }

    public static String createAuthToken(String login, String password) {
        String standUrl = config.standUrl;
        String vahterUrl;
        String origin;
        if (ParseUrl.checkUrl(standUrl)) {
            vahterUrl = String.format("%s://%s.%s/guard/login", ParseUrl.getProtocol(standUrl), ParseUrl.getStandName(standUrl), ParseUrl.getLocation(standUrl));
            origin = standAndCompanyUrl;
        } else {
            vahterUrl = standAndCompanyUrl + "/guard/login";
            origin = standUrl;
        }
        String json = String.format("{\"email\":\"%s\",\"password\":\"%s\"}", login, password);
        String responseString = new SimpleMicronautClient().createTokenPost(vahterUrl, json, origin);
        return parseToken(responseString);
    }

    private static String parseToken(String body) {
        Pattern pattern = Pattern.compile("\"token\":\"(.*)\"");
        Matcher matcher = pattern.matcher(body);
        String token = "";
        if (matcher.find()) {
            token = matcher.group(1);
        }
        return token;
    }

    public static String getAuthTokenAdmin() {
        try {
            return lazyTokenInitializerAdmin.get();
        } catch (ConcurrentException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getAuthTokenUser() {
        try {
            return lazyTokenInitializerUser.get();
        } catch (ConcurrentException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Устанавливаем временную зону пользователя
     *
     * @param token токен авторизации пользователя
     * @param email мейл пользователя
     */
    public static void setTimeZoneLocalMachine(String token, String email) {
        String localMachineCurrentTimezone = ZonedDateTime.now(ZoneId.systemDefault()).getZone().getId();
        if (localMachineCurrentTimezone.equals("GMT"))
            localMachineCurrentTimezone = "Africa/Abidjan";
        setTimeZoneInSettings(localMachineCurrentTimezone, token);
        setTimeZoneInProfile(localMachineCurrentTimezone, token, email);
        CONSOLE.info("Set User Time Zone - " + localMachineCurrentTimezone);
    }

    /**
     * Изменяет временную зону пользователя в настройках
     *
     * @param timeZone временная зона
     * @param token    токен авторизации
     */
    private static void setTimeZoneInSettings(String timeZone, String token) {
        String settingsJson = String.format("""
                {
                    "key": "timezone",
                    "value": "%s"
                }""", timeZone);
        String url = standAndCompanyUrl + "/api/settings/user";
        new SimpleMicronautClient().authorizedPut(url, settingsJson, token);
    }

    /**
     * Изменяет временную зону пользователя в профиле
     *
     * @param timeZone временная зона
     * @param token    токен авторизации
     * @param email    мейл пользователя
     */
    private static void setTimeZoneInProfile(String timeZone, String token, String email) {
        JsonObject profileJson = getUserJsonByEmail(email);
        if (profileJson != null) {
            profileJson.addProperty("timezone", timeZone);
            new SimpleMicronautClient().authorizedPut(standAndCompanyUrl + "/api/users/profile", profileJson.toString(), token);
        } else Assertions.fail("Не удалось установить временную зону в профиле");
    }

    public static JsonObject getUserJsonByEmail(String email) {
        String url = standAndCompanyUrl + "/api/auth/users?offset=0&limit=100";
        String responseBody = new SimpleMicronautClient().authorizedGet(url, getAuthTokenAdmin());
        JsonObject allObject = JsonParser.parseString(responseBody).getAsJsonObject();
        JsonArray userArray = allObject.get("result").getAsJsonArray();
        for (int i = 0; i < userArray.size(); i++) {
            JsonObject getUser = userArray.get(i).getAsJsonObject();
            String userEmail = getUser.get("email").toString().replace("\"", "");
            if (userEmail.equals(email)) {
                return getUser;
            }
        }
        return null;
    }

    public static void setAdminFio(String... fio) {
        JsonObject orig = Objects.requireNonNull(getUserJsonByEmail(adminLogin));
        String id = orig.get("__id").toString().replace("\"", "");
        String json = JsonPath.using(configuration).parse(orig.toString())
                .set("$.fullname.firstname", fio[1])
                .set("$.fullname.lastname", fio[0])
                .set("$.fullname.middlename", fio[2])
                .json().toString();
        new SimpleMicronautClient().authorizedPut(standAndCompanyUrl + "api/users/" + id, json, getAuthTokenAdmin());
    }

    /**
     * Обёртка клиента micronaut для работы в статических методах, принадлежит данному классу и не используется потомками;
     */
    protected static class SimpleMicronautClient {

        public String createTokenPost(String url, String jsonBody, String origin) {
            BlockingHttpClient client = HttpClient.create(null).toBlocking();
            HashMap<CharSequence, CharSequence> headersMap = new HashMap<>();
            headersMap.put("Origin", origin);
            headersMap.put("Content-Type", "application/json");
            HttpRequest<?> req = HttpRequest.POST(url, jsonBody).headers(headersMap);
            return client.retrieve(req);
        }

        public String authorizedGet(String url, String token) {
            BlockingHttpClient client = HttpClient.create(null).toBlocking();
            HashMap<CharSequence, CharSequence> headersMap = new HashMap<>();
            headersMap.put("Cookie", "vtoken=" + token);
            headersMap.put("Content-Type", "application/json");
            HttpRequest<?> req = HttpRequest.GET(url).headers(headersMap);
            return client.retrieve(req);
        }

        public String authorizedPut(String url, String jsonBody, String token) {
            BlockingHttpClient client = HttpClient.create(null).toBlocking();
            HashMap<CharSequence, CharSequence> headersMap = new HashMap<>();
            headersMap.put("Cookie", "vtoken=" + token);
            headersMap.put("Content-Type", "application/json");
            HttpRequest<?> req = HttpRequest.PUT(url, jsonBody).headers(headersMap);
            int code = client.exchange(req).code();
            return String.valueOf(code);
        }
    }

    /**
     * Класс для работы с unix временем в API
     */
    public static class UnixTimeConverter {
        /**
         * Возвращает дату в формате dd.MM.yyyy
         *
         * @param timeStamp - дата в формате unix epoch
         */
        public static String getDayMonthYearFromUnix(String timeStamp) {
            Instant instant = Instant.ofEpochSecond(Long.parseLong(timeStamp));
            LocalDate localDate = LocalDate.ofInstant(instant, ZoneOffset.UTC);
            return localDate.format(FORMATTER_DD_MM_YYYY);
        }

        /**
         * Возвращает время в формате HH.ss
         *
         * @param timeStamp - время в формате unix time
         */
        public static String getHoursAndMinutesFromUnix(String timeStamp) {
            Instant instant = Instant.ofEpochSecond(Long.parseLong(timeStamp));
            LocalTime localTime = LocalTime.ofInstant(instant, ZoneOffset.UTC);
            return localTime.format(FORMATTER_HH_MM);
        }

        /**
         * Конвертер даты в Unix
         *
         * @param date - дата
         * @return - возвращает значение в Unix
         */
        public static long convertDateToUnix(LocalDate date) {
            return date.toEpochSecond(LocalTime.MIDNIGHT, ZoneOffset.UTC);
        }

        /**
         * Конвертер времени в Unix
         *
         * @param time - время
         * @return - возвращает значение в Unix
         */
        public static long convertTimeToUnix(LocalTime time) {
            return time.toEpochSecond(LocalDate.EPOCH, ZoneOffset.UTC);
        }
    }
}