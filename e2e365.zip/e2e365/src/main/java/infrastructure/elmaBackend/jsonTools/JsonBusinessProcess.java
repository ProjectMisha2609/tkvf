package infrastructure.elmaBackend.jsonTools;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import infrastructure.utils.Constants;
import infrastructure.utils.Loggers;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Locale;

@Deprecated
public class JsonBusinessProcess {
    protected JsonObject jsonObject;
    public static final boolean PUBLISH_PROCESS = false;
    public static final boolean SAVE_PROCESS = true;

    public static class Builder {

        public static class ContextProcess {
            private String contextName;
            private String contextCode;
            private String contextType;
            private boolean array;
            private boolean single;
            private final JsonObject object;

            {
                this.object = JsonParser.parseString("""
                        {
                            "type": null,
                            "code": null,
                            "searchable": false,
                            "indexed": false,
                            "deleted": false,
                            "array": null,
                            "single": true,
                            "required": false,
                            "defaultValue": null,
                            "data": {},
                            "view": {
                                "name": null,
                                "data": {}
                            },
                            "calcByFormula": false,
                            "formula": "",
                            "sortable": false
                        }""").getAsJsonObject();
            }

            private ContextProcess() {
            }

            public ContextProcess(String contextName, ContextType contextType) {
                this.contextName = contextName;
                this.contextCode = contextName.toLowerCase();
                this.contextType = contextType.name();
                this.array = true;
                this.single = true;
            }

            public ContextProcess(String contextName, ContextType contextType, boolean array) {
                this.contextName = contextName;
                this.contextCode = contextName.toLowerCase();
                this.contextType = contextType.name();
                this.array = array;
                this.single = true;
            }

            public ContextProcess(String contextName, ContextType contextType, boolean array, boolean single) {
                this.contextName = contextName;
                this.contextCode = contextName.toLowerCase();
                this.contextType = contextType.name();
                this.array = array;
                this.single = single;
            }

            public ContextProcess setDataField(String sectionCode, String appCode) {
                JsonObject obj = new JsonObject();
                obj.addProperty("code", appCode);
                obj.addProperty("namespace", sectionCode);
                this.object.add("data", obj);
                return this;
            }

            public ContextProcess setViewField(boolean timeOptional, String additionalType, String defaultTimeType, boolean setCurrentDatetime) {
                JsonObject obj = new JsonObject();
                obj.addProperty("timeOptional", timeOptional);
                obj.addProperty("additionalType", additionalType);
                obj.addProperty("defaultTimeType", defaultTimeType);
                obj.addProperty("setCurrentDatetime", setCurrentDatetime);
                JsonObject view = this.object.getAsJsonObject("view");
                view.add("data", obj);
                return this;
            }

            public JsonObject getJsonObject() {
                this.object.addProperty("type", this.contextType);
                this.object.addProperty("code", this.contextCode);
                this.object.addProperty("array", this.array);
                this.object.addProperty("single", this.single);
                JsonObject view = this.object.getAsJsonObject("view");
                view.addProperty("name", this.contextName);
                this.object.add("view", view);
                return this.object;
            }
        }

        private final JsonBusinessProcess json;

        public Builder() {
            json = new JsonBusinessProcess();
        }

        public Builder setJsonFile(String fileName) {
            try {
                FileReader reader = new FileReader(new File(Constants.PATH_TO_DEFAULT_DIR, fileName));
                json.jsonObject = JsonParser.parseReader(reader).getAsJsonObject();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return this;
        }

        public Builder setName(String processName) {
            json.jsonObject.addProperty("__name", processName);
            json.jsonObject.addProperty("code", processName.toLowerCase(Locale.ROOT));
            return this;
        }

        public Builder setId(String processId) {
            json.jsonObject.addProperty("__id", processId);
            return this;
        }

        public Builder setNamespace(String sectionName) {
            json.jsonObject.addProperty("namespace", sectionName);
            return this;
        }

        public Builder setCreatedAt(String createdAt) {
            json.jsonObject.addProperty("createdAt", createdAt);
            return this;
        }

        public Builder setCreatedBy(String createdBy) {
            json.jsonObject.addProperty("createdBy", createdBy);
            return this;
        }

        public Builder setUpdatedAt(String updatedAt) {
            json.jsonObject.addProperty("updatedAt", updatedAt);
            return this;
        }

        /**
         * Устанавливает временные значения для элемента таймер.
         *
         * @param timerElementUid UID элемента в процессе
         * @param parameter       Изменяемый параметр ("days" / "hours" / "minutes")
         * @param value           Значение для временного параметра
         */
        public Builder setTimeInTimerSettings(String timerElementUid, String parameter, Integer value) {
            json.jsonObject.getAsJsonObject("process").getAsJsonObject("items").getAsJsonObject(timerElementUid)
                    .getAsJsonObject("settings")
                    .getAsJsonObject("timer")
                    .addProperty(parameter, value);
            return this;
        }

        /**
         * Устанавливает зависимость от рабочего календаря (параметр "absolute") для элемента таймер.
         *
         * @param timerElementUid UID элемента в процессе
         * @param value           Значение (true - не зависит от рабочего календаря / false - зависит от рабочего календаря)
         */
        public Builder setAbsoluteInTimerSettings(String timerElementUid, Boolean value) {
            json.jsonObject.getAsJsonObject("process").getAsJsonObject("items").getAsJsonObject(timerElementUid)
                    .getAsJsonObject("settings")
                    .getAsJsonObject("timer")
                    .addProperty("absolute", value);
            return this;
        }

        /**
         * Сохранить или опубликовать процесс в зависимости от параметра draftStatus.
         *
         * @param draftStatus true - сохранить, false - публиковать
         */
        public Builder setDraft(boolean draftStatus) {
            json.jsonObject.addProperty("draft", draftStatus);
            return this;
        }

        /**
         * Устанавливает в процесс функцию TypeScript
         *
         * @param tsFunction - функция для встраивания в процесс.
         */
        public Builder putFunction(String tsFunction) {
            json.jsonObject.addProperty("scripts", tsFunction);
            return this;
        }

        public Builder setComment(String comment) {
            json.jsonObject.addProperty("comment", "");
            return this;
        }

        public Builder setGroupCode(String groupCode) {
            json.jsonObject.getAsJsonObject("process").getAsJsonObject("lanes")
                    .getAsJsonObject("32928604-cfd7-4cf7-a3c1-3878045dd6f7").getAsJsonObject("settings")
                    .getAsJsonObject("group")
                    .addProperty("code", groupCode);
            json.jsonObject.getAsJsonObject("process").getAsJsonObject("lanes")
                    .getAsJsonObject("32928604-cfd7-4cf7-a3c1-3878045dd6f7").getAsJsonObject("settings")
                    .getAsJsonArray("groups").get(0).getAsJsonObject()
                    .addProperty("code", groupCode);
            return this;
        }

        public Builder addContextVariable(ContextProcess context) {
            json.jsonObject.getAsJsonArray("context").add(context.getJsonObject());
            return this;
        }

        /**
         * Вынести переменную на форму стартового события бизнес-процесса
         *
         * @param contextName - название переменной
         * @param tooltip     - подсказка переменной
         * @param required    - обязательна ли для заполнения
         * @param readonly    - только для чтения
         * @param hideEmpty   - скрывать пустые значения
         */
        public Builder addContextOnDefaultStartForm(String contextName, String tooltip, boolean required, boolean readonly, boolean hideEmpty) {
            return addContextToActionFormByActionId("00000000-0000-0000-0000-000000000000", contextName, tooltip, required, readonly, hideEmpty);
        }

        /**
         * Вынести переменную на форму элемента бизнес-процесса
         *
         * @param actionId    - идентификатор элемента бизнес-процесса
         * @param contextName - название переменной
         * @param tooltip     - подсказка переменной
         * @param required    - обязательна ли для заполнения
         * @param readonly    - только для чтения
         * @param hideEmpty   - скрывать пустые значения
         */
        public Builder addContextToActionFormByActionId(String actionId, String contextName, String tooltip, boolean required, boolean readonly, boolean hideEmpty) {
            JsonArray array = json.jsonObject.getAsJsonArray("context");
            if (array.size() == 0)
                // todo: защита от дурака хорошая, но урезает возможности.
                //  было бы неплохо иметь возможность подтянуть __name и подобные "дефолтные" переменные.
                Loggers.CONSOLE.error("Контекстные переменные должны быть созданы, перед тем как добавлять их на форму");
            JsonObject foundObject = null;
            for (int i = 0; i < array.size(); i++) {
                JsonObject obj = array.get(i).getAsJsonObject();
                if (obj.getAsJsonObject("view").get("name").getAsString().equals(contextName)) {
                    foundObject = obj;
                    break;
                }
            }
            if (foundObject == null) {
                throw new IllegalArgumentException("Not Found Context Variable by Name" + contextName);
            }
            JsonObject newObj = new JsonObject();
            newObj.addProperty("code", foundObject.get("code").getAsString());
            newObj.addProperty("tooltip", tooltip);
            newObj.addProperty("required", required);
            newObj.addProperty("readonly", readonly);
            newObj.addProperty("hideEmpty", hideEmpty);
            json.jsonObject.getAsJsonObject("process")
                    .getAsJsonObject("items")
                    .getAsJsonObject(actionId)
                    .getAsJsonObject("settings")
                    .getAsJsonArray("formFields")
                    .add(newObj);
            return this;
        }

        public String buildAndGetAsString() {
            return json.jsonObject.toString();
        }
    }
}
