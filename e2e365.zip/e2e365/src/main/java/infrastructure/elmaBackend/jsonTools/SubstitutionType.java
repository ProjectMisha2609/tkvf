package infrastructure.elmaBackend.jsonTools;

/**
 * Перечисление типов замещений и соответствующих им фрагментов json файла.
 */
public enum SubstitutionType {
    INFORMATION("[\n" +
            "                {\n" +
            "                    \"code\": \"information\",\n" +
            "                    \"name\": \"Информирование\"\n" +
            "                }\n" +
            "            ]"),
    FULL("[\n" +
            "        {\n" +
            "            \"code\": \"full\",\n" +
            "            \"name\": \"Полная передача прав\"\n" +
            "        }\n" +
            "    ]"),
    REASSIGN("[\n" +
            "        {\n" +
            "            \"code\": \"reassign\",\n" +
            "            \"name\": \"Переназначение задач\"\n" +
            "        }\n" +
            "    ]");
    private final String text;

    /**
     * @param text - json объект с описанием замещения в String формате.
     */
    SubstitutionType(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }
}
