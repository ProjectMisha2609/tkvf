package infrastructure.elmaBackend.jsonTools;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import infrastructure.utils.Constants;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class JsonOrgStructure {
    protected JsonArray jsonArray = new JsonArray();

    public static class Builder {
        private final JsonOrgStructure jsonOrgStructure;
        private JsonObject jsonObject;
        public String defaultId = "242c7e76-ff4f-5523-815d-b219626acb54";

        public Builder() {
            jsonOrgStructure = new JsonOrgStructure();
        }

        public Builder setJsonFile(String fileName) {
            try {
                FileReader reader = new FileReader(new File(Constants.PATH_TO_DEFAULT_DIR, fileName));
                jsonObject = JsonParser.parseReader(reader).getAsJsonObject();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return this;
        }

        public Builder setName(String positionName) {
            jsonObject.addProperty("name", positionName);
            return this;
        }

        public Builder setId(String positionId) {
            jsonObject.addProperty("__id", positionId);
            return this;
        }

        public Builder setParentId(String parentId) {
            jsonObject.addProperty("parent", parentId);
            return this;
        }

        public Builder setType(String type) {
            jsonObject.addProperty("type", type);
            return this;
        }

        public Builder setSort(int sort) {
            jsonObject.addProperty("sort", sort);
            return this;
        }

        public JsonObject createDefault() {
            jsonObject.addProperty("__id", defaultId);
            jsonObject.addProperty("type", "POSITION");
            jsonObject.addProperty("name", "Генеральный директор");
            jsonObject.addProperty("sort", 0);
            jsonObject.addProperty("page", false);
            jsonObject.addProperty("parent", (Character) null);
            return jsonObject;
        }

        public Builder addStructureInJsonArray() {
            jsonOrgStructure.jsonArray.add(jsonObject);
            return this;
        }

        public Builder addNewPositionInJson(JsonObject object) {
            jsonOrgStructure.jsonArray.add(object);
            return this;
        }

        public String buildAndGetAsString() {
            return jsonOrgStructure.jsonArray.toString();
        }
    }
}
