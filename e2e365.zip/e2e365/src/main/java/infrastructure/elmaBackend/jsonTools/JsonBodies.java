package infrastructure.elmaBackend.jsonTools;

/**
 * Класс для хранения json файлов в виде String блоков. Для сворачивания и разворачивания использовать CTRL SHIFT +/- и CTRL ALT +/-
 * Редактирование происходит через JsonPath, потому каждое тело может быть константой,
 * а так же может быть многократно использовано при создании запросов.
 * В свете этих факторов, а так же по причине необходимости обработки исключений при работе с ридером,
 * было решено отказаться от хранения в файлах и использования ридеров в пользу String констант.
 * <p>
 * Поля, которые нужно заполнить другим значением, содержат placeholder "CHANGE_ME_PLEASE" для удобства поиска.
 * Неизменяемые json тела, расположенные в папке JsonProcess так же внесены в константы, во вложенном классе JsonProcess
 * <p>
 * Сервисы для поиска путей JsonPath:
 * jsonpathfinder.com - генерирует путь по выбранному объекту, так же есть beautify и minify.
 * jsonpath.com - проверяет передаваемый путь путём вывода найденного по нему значения.
 */

public final class JsonBodies {

    /**
     * пустое тело для встраивания, а так же отправки пустых запросов
     *///language=json
    public static final String EMPTY_JSON = "{}";

    /**
     * Опции POST запроса получения списка системных групп из приложения
     * Лучше не переводить в текстовый блок, ибо обладает вложенным String json в поле query.
     */
    public static final String QUERY_TO_GET_SYSTEM_GROUPS = "{\"options\":{\"from\":0,\"size\":10000,\"sortExpressions\":[{\"field\":\"__name\",\"ascending\":true}]},\"filter\":{\"active\":false,\"query\":\"{\\\"and\\\":[{\\\"or\\\":[{\\\"eq\\\":[{\\\"field\\\":\\\"namespace\\\"},{\\\"const\\\":\\\"system\\\"}]}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"331e62d2-072e-58ac-9581-74abcc67f050\\\"}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"5b1a8e53-b76f-58ab-95c2-6495ae051dc3\\\"}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"44d8a7a2-4154-5174-92de-68b2226101ef\\\"}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"d89a33dc-3177-5854-9580-f7f860a5ab7c\\\"}]}]}]}]}]}]}\"}}";

    /**
     * Опции POST запроса получения списка принадлежащих компании групп из приложения
     * Лучше не переводить в текстовый блок, ибо обладает вложенным String json в поле query.
     */
    public static final String QUERY_TO_GET_COMPANY_GROUPS = "{\"options\":{\"from\":0,\"size\":10000,\"sortExpressions\":[{\"field\":\"__name\",\"ascending\":true}]},\"filter\":{\"active\":false,\"query\":\"{\\\"and\\\":[{\\\"or\\\":[{\\\"eq\\\":[{\\\"field\\\":\\\"namespace\\\"},{\\\"const\\\":\\\"global\\\"}]}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"331e62d2-072e-58ac-9581-74abcc67f050\\\"}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"5b1a8e53-b76f-58ab-95c2-6495ae051dc3\\\"}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"44d8a7a2-4154-5174-92de-68b2226101ef\\\"}]},{\\\"and\\\":[{\\\"neq\\\":[{\\\"field\\\":\\\"__id\\\"},{\\\"const\\\":\\\"d89a33dc-3177-5854-9580-f7f860a5ab7c\\\"}]}]}]}]}]}]}\"}}";

    /**
     * Стандартная оргструктура из одного гендиректора - администратора.
     *///language=json
    public static final String DEFAULT_ORG_STRUCTURE = """
            [
              {
                "__id": "242c7e76-ff4f-5523-815d-b219626acb54",
                "type": "POSITION",
                "name": "Генеральный директор",
                "sort": 0,
                "page": false,
                "parent": null
              }
            ]""";

    /**
     * Создать приложение в разделе.
     *///language=json
    public static final String CREATE_APP_JSON_BODY = """
            {
              "name": "CHANGE_ME_PLEASE",
              "elementName": "CHANGE_ME_PLEASE",
              "code": "CHANGE_ME_PLEASE",
              "namespace": "CHANGE_ME_PLEASE",
              "appViewType": "STANDARD",
              "icon": "system_cloud",
              "pageData": {
                "layout": "tiles",
                "menu": {
                  "type": "namespace"
                },
                "widgets": [
                  {
                    "type": "appview",
                    "data": {
                      "namespaceCode": "CHANGE_ME_PLEASE",
                      "pageCode": "CHANGE_ME_PLEASE"
                    }
                  }
                ]
              },
              "pageType": "APPLICATION",
              "sort": 1,
              "system": false,
              "__permissions": {
                "inheritParent": false,
                "values": [
                  {
                    "group": {
                      "type": "group",
                      "id": "fda5c295-230a-5025-9797-b8b4e99e08aa"
                    },
                    "types": [
                      "read"
                    ],
                    "inherited": false
                  }
                ]
              }
            }""";

    /**
     * Создать раздел.
     *///language=json
    public static final String CREATE_SECTION_JSON_BODY = """
            {
              "namespace": "global",
              "type": "NAMESPACE",
              "name": "CHANGE_ME_PLEASE",
              "code": "CHANGE_ME_PLEASE",
              "icon": "system_inbox",
              "data": {
                "columns": 1,
                "widgets": [],
                "menu": {
                  "type": "namespace",
                  "showName": true
                }
              },
              "__permissions": {
                "inheritParent": false,
                "values": [
                  {
                    "group": {
                      "type": "group",
                      "id": "fda5c295-230a-5025-9797-b8b4e99e08aa"
                    },
                    "types": [
                      "read"
                    ],
                    "inherited": false
                  }
                ]
              }
            }""";

    /**
     * Создать страницу
     *///language=json
    public static final String CREATE_PAGE_JSON_BODY = """
            {
              "namespace": "CHANGE_ME_PLEASE",
              "type": "PAGE",
              "name": "CHANGE_ME_PLEASE",
              "code": "CHANGE_ME_PLEASE",
              "icon": "file_type_text",
              "data": {
                "columns": 1,
                "widgets": [],
                "menu": {
                  "type": "main"
                }
              },
              "sort": 1,
              "__permissions": {
                "inheritParent": false,
                "values": [
                  {
                    "group": {
                      "type": "group",
                      "id": "fda5c295-230a-5025-9797-b8b4e99e08aa"
                    },
                    "types": [
                      "read"
                    ],
                    "inherited": false
                  }
                ]
              }
            }""";

    /**
     * Создать контракт
     *///language=json
    public static final String CREATE_CONTRACT_JSON_BODY = """
            {
              "namespace": "CHANGE_ME_PLEASE",
              "type": "CONTRACT",
              "name": "CHANGE_ME_PLEASE",
              "code": "CHANGE_ME_PLEASE",
              "icon": "system_cloud",
              "data": {
                "columns": 1,
                "widgets": [],
                "menu": {
                  "type": "main"
                }
              },
              "sort": 1,
              "__permissions": {
                "inheritParent": false,
                "values": [
                  {
                    "group": {
                      "type": "group",
                      "id": "fda5c295-230a-5025-9797-b8b4e99e08aa"
                    },
                    "types": [
                      "read"
                    ],
                    "inherited": false
                  }
                ]
              }
            }""";

    /**
     * установить дефолтные настройки контракта
     *///language=json
    public static final String SET_DEFAULT_SETTING_CONTRACT_JSON_BODY = """
            {
                "view": {
                    "namespace": "CHANGE_ME_PLEASE",
                    "code": "CHANGE_ME_PLEASE",
                    "name": "CHANGE_ME_PLEASE",
                    "icon": "",
                    "layout": "tiles",
                    "settings": {},
                    "fields": [],
                    "appViewType": "STANDARD",
                    "pageType": "CONTRACT"
                }
            }""";

    /**
     * Установить приложение в качестве источника контрактов
     *///language=json
    public static final String SET_APP_SOURCE_CONTRACT_JSON_BODY = """
            {
            	"sources": [
            		{
            			"contractCode": "CHANGE_ME_PLEASE",
            			"contractNamespace": "CHANGE_ME_PLEASE",
            			"sourceCode": "CHANGE_ME_PLEASE",
            			"sourceNamespace": "CHANGE_ME_PLEASE",
            			"state": "creating",
            			"settings": {
            				"matchingFields": {
            					"__createdAt": {
            						"target": {
            							"kind": "context",
            							"value": "__createdAt"
            						},
            						"source": {
            							"kind": "context",
            							"value": "__createdAt"
            						}
            					},
            					"__createdBy": {
            						"target": {
            							"kind": "context",
            							"value": "__createdBy"
            						},
            						"source": {
            							"kind": "context",
            							"value": "__createdBy"
            						}
            					},
            					"__updatedAt": {
            						"target": {
            							"kind": "context",
            							"value": "__updatedAt"
            						},
            						"source": {
            							"kind": "context",
            							"value": "__updatedAt"
            						}
            					},
            					"__updatedBy": {
            						"target": {
            							"kind": "context",
            							"value": "__updatedBy"
            						},
            						"source": {
            							"kind": "context",
            							"value": "__updatedBy"
            						}
            					},
            					"__deletedAt": {
            						"target": {
            							"kind": "context",
            							"value": "__deletedAt"
            						},
            						"source": {
            							"kind": "context",
            							"value": "__deletedAt"
            						}
            					},
            					"__name": {
            						"target": {
            							"kind": "context",
            							"value": "__name"
            						},
            						"source": {
            							"kind": "context",
            							"value": "__name"
            						}
            					}
            				},
            				"useByDefault": false
            			}
            		}
            	]
            }""";

    /**
     * Создать элемент приложения
     *///language=json
    public static final String CREATE_APP_ELEMENT_JSON_BODY = """
            {
              "payload": {
                "__createdAt": null,
                "__createdBy": null,
                "__debug": null,
                "__deletedAt": null,
                "__directory": null,
                "__externalId": null,
                "__externalProcessMeta": null,
                "__id": null,
                "__index": null,
                "__name": "CHANGE_ME_PLEASE",
                "__tasks": null,
                "__tasks_earliest_duedate": null,
                "__tasks_performers": null,
                "__updatedAt": null,
                "__updatedBy": null,
                "__version": 0
              }
            }""";

    /**
     * Создать три тестовых параметра компании
     *///language=json
    public static final String PUT_THREE_TEST_COMPANY_PARAMETERS = """
            {
              "fields": [
                {
                  "view": {
                    "data": {
                      "additionalType": "string"
                    },
                    "name": "test1"
                  },
                  "type": "STRING",
                  "code": "test1",
                  "deleted": false,
                  "required": false,
                  "array": false,
                  "single": true,
                  "indexed": false,
                  "searchable": false,
                  "sortable": false,
                  "defaultValue": "",
                  "calcByFormula": false,
                  "formula": "",
                  "data": {
                    "ns": "global"
                  },
                  "isNewField": true,
                  "isNameChanged": true,
                  "id": 1
                },
                {
                  "view": {
                    "data": {
                      "additionalType": "string"
                    },
                    "name": "test2"
                  },
                  "type": "STRING",
                  "code": "test2",
                  "deleted": false,
                  "required": false,
                  "array": false,
                  "single": true,
                  "indexed": false,
                  "searchable": false,
                  "sortable": false,
                  "defaultValue": "",
                  "calcByFormula": false,
                  "formula": "",
                  "data": {
                    "ns": "global"
                  },
                  "isNewField": true,
                  "isNameChanged": true,
                  "id": 2
                },
                {
                  "view": {
                    "data": {
                      "additionalType": "string"
                    },
                    "name": "test3"
                  },
                  "type": "STRING",
                  "code": "test3",
                  "deleted": false,
                  "required": false,
                  "array": false,
                  "single": true,
                  "indexed": false,
                  "searchable": false,
                  "sortable": false,
                  "defaultValue": "",
                  "calcByFormula": false,
                  "formula": "",
                  "data": {
                    "ns": "global"
                  },
                  "isNewField": true,
                  "isNameChanged": true,
                  "id": 3
                }
              ],
              "values": {
                "test1": "test",
                "test2": "test",
                "test3": "test"
              }
            }""";

    /**
     * Создать пустой пользовательский виджет
     *///language=json
    public static final String CREATE_EMPTY_USER_WIDGET = """
            {
              "namespace": "global",
              "code": "CHANGE_ME_PLEASE",
              "__name": "CHANGE_ME_PLEASE",
              "description": "",
              "hidden": false,
              "draft": true,
              "descriptor": {
                "code": "global@CHANGE_ME_PLEASE",
                "template": {
                  "descriptor": "component",
                  "values": {},
                  "content": {
                    "": []
                  },
                  "fixed": false
                },
                "icon": "user_man_sign",
                "fields": [],
                "types": []
              }
            }""";

    /**
     * Внести изменения на страницу для теста (контекст строка добавлена на страницу в режиме только для чтения)
     *///language=json
    public static final String PREPARE_WIDGET_PAGE = """
            {
              "draft": true,
              "descriptor": {
                "types": [
                  "page"
                ],
                "fields": [
                  {
                    "type": "STRING",
                    "code": "testcontext",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": {},
                    "view": {
                      "name": "TestContext",
                      "data": {
                        "additionalType": "string"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  }
                ],
                "fieldVisibilityConditions": {
                  "testcontext": {
                    "enabled": false,
                    "conditions": []
                  }
                },
                "template": {
                  "id": "71cfc448-cc8a-402a-af5a-ec3fd61d5bf8",
                  "descriptor": "custom-page",
                  "content": {
                    "": [
                      {
                        "id": "827e2e5f-80cf-4b01-acab-0e534d728ad5",
                        "descriptor": "page-header",
                        "values": {},
                        "content": {
                          "[title]": [
                            {
                              "id": "c2fc92a9-d88f-4297-8e40-3c19ca57d611",
                              "descriptor": "label",
                              "values": {
                                "text": "testPage"
                              },
                              "content": {},
                              "fixed": false
                            }
                          ]
                        },
                        "fixed": false
                      },
                      {
                        "id": "aefde9f0-cbf1-42d7-959e-7faadaf2adf8",
                        "descriptor": "page-content",
                        "values": {},
                        "content": {
                          "": [
                            {
                              "id": "703d4e35-8674-44a2-b6eb-c67e390b5573",
                              "descriptor": "dynamic-form-row",
                              "values": {
                                "control": {
                                  "path": [
                                    "testcontext"
                                  ]
                                },
                                "showDisplayName": true,
                                "bindingMode": false,
                                "required": false,
                                "hideEmpty": false,
                                "__isConstValues": [],
                                "tooltip": null,
                                "__readOnly": true
                              }
                            }
                          ]
                        },
                        "fixed": false
                      }
                    ]
                  },
                  "values": {}
                },
                "scriptOptions": {},
                "clientScripts": "/**\\nHere you can write scripts for initialization and processing data.\\nTo write scripts, use TypeScript: https://www.typescriptlang.org\\nYou can use ELMA365 TypeScript SDK: https://tssdk.elma365.com\\n**/\\n",
                "clientScriptOptions": {
                  "allowServer": true,
                  "isClientScript": true
                },
                "serverScripts": "",
                "serverScriptOptions": {}
              }
            }""";


    /**
     * Страница с виджетом и переменной типа string, к которой обращается кнопка Test
     *///language=json
    public static final String PREPARE_WIDGET_PAGE_WITH_CONTEXT = """
            {
                "draft": true,
                "descriptor": {
                    "types": [
                        "page"
                    ],
                    "fields": [
                        {
                            "type": "STRING",
                            "code": "stroka",
                            "searchable": false,
                            "indexed": false,
                            "deleted": false,
                            "array": false,
                            "single": true,
                            "required": false,
                            "defaultValue": null,
                            "data": {},
                            "view": {
                                "name": "Строка",
                                "data": {
                                    "additionalType": "string"
                                }
                            },
                            "calcByFormula": false,
                            "formula": "",
                            "sortable": false
                        }
                    ],
                    "fieldVisibilityConditions": {
                        "stroka": {
                            "enabled": false,
                            "conditions": []
                        }
                    },
                    "template": {
                        "id": "c8dc8eb6-6574-4fcd-a2bf-3c76b194ea74",
                        "descriptor": "custom-page",
                        "content": {
                            "": [
                                {
                                    "id": "77d16b35-53e6-4827-9064-f386c3553d0a",
                                    "descriptor": "page-header",
                                    "values": {},
                                    "content": {
                                        "[title]": [
                                            {
                                                "id": "f5f4d7ef-dc4c-452f-ade2-4b0b751b664f",
                                                "descriptor": "label",
                                                "values": {
                                                    "text": "Стр"
                                                },
                                                "content": {},
                                                "fixed": false
                                            }
                                        ]
                                    },
                                    "fixed": false
                                },
                                {
                                    "id": "6332dcdb-4718-400d-90ff-db99b510e3c6",
                                    "descriptor": "dynamic-form-row",
                                    "values": {
                                        "required": false,
                                        "showDisplayName": true,
                                        "tooltip": null,
                                        "__isConstValues": [],
                                        "__readOnly": null,
                                        "bindingMode": false,
                                        "control": {
                                            "path": [
                                                "stroka"
                                            ]
                                        },
                                        "hideEmpty": false
                                    },
                                    "content": {},
                                    "fixed": false
                                },
                                {
                                    "id": "60653458-fb51-4cce-8063-d796a9837018",
                                    "descriptor": "button",
                                    "values": {
                                        "__isConstValues": [],
                                        "action": null,
                                        "label": "Тест",
                                        "onClick": {
                                            "kind": "Function",
                                            "name": "test",
                                            "type": "server"
                                        },
                                        "processPopoverSize": [
                                            {
                                                "code": "default",
                                                "name": "shared.common.button@widget-process-popover-size-default",
                                                "translate": true
                                            }
                                        ],
                                        "runActionEnum": [
                                            {
                                                "code": "undefined",
                                                "name": "shared.common.button@widget-runAction-none",
                                                "translate": true
                                            }
                                        ],
                                        "runInPopover": null,
                                        "view": "default"
                                    },
                                    "content": {},
                                    "fixed": false
                                },
                                {
                                    "id": "ca32c173-982e-481a-a826-06bdb3109937",
                                    "descriptor": "page-content",
                                    "values": {},
                                    "content": {
                                        "": []
                                    },
                                    "fixed": false
                                }
                            ]
                        },
                        "values": {}
                    },
                    "scriptOptions": {},
                    "clientScripts": "",
                    "clientScriptOptions": {
                        "allowServer": true,
                        "isClientScript": true
                    },
                    "serverScripts": "",
                    "serverScriptOptions": {}
                }
            }""";

    /**
     * Внести изменения на страницу для теста
     *///language=json
    public static final String CREATE_WIDGET_PAGE = """
            {
              "namespace": "CHANGE_ME_PLEASE",
              "code": "_page",
              "__name": "CHANGE_ME_PLEASE",
              "hidden": true,
              "draft": true,
              "descriptor": {
                "code": "CHANGE_ME_PLEASE",
                "template": {
                  "descriptor": "custom-page",
                  "values": {},
                  "content": {
                    "": [
                      {
                        "id": "b9d50d73-27ec-4b84-aebc-fe1b573d4726",
                        "descriptor": "page-header",
                        "values": {},
                        "content": {
                          "[title]": [
                            {
                              "id": "550e77c5-76f2-46dd-b8e6-0c103a1eea54",
                              "descriptor": "label",
                              "values": {
                                "text": "This Head Name"
                              },
                              "content": {},
                              "fixed": false
                            }
                          ]
                        },
                        "fixed": false
                      },
                      {
                        "id": "61e823a1-2523-4eef-8cf0-253448adf0f5",
                        "descriptor": "page-content",
                        "values": {},
                        "content": {
                          "": []
                        },
                        "fixed": false
                      }
                    ]
                  },
                  "fixed": false
                },
                "fields": [],
                "types": [
                  "page"
                ],
                "clientScripts": ""
              }
            }""";

    /**
     * Создать пользовательский виджет с вкладками
     *///language=json
    public static final String CREATE_USER_WIDGET_WITH_TABS = """
            {
              "namespace": "global",
              "code": "CHANGE_ME_PLEASE",
              "__name": "CHANGE_ME_PLEASE",
              "description": "",
              "hidden": false,
              "draft": true,
              "descriptor": {
                "code": "global@CHANGE_ME_PLEASE",
                "template": {
                  "descriptor": "component",
                  "values": {},
                  "content": {
                    "": [
                      {
                        "descriptor": "tabset",
                        "content": {
                          "": [
                            {
                              "descriptor": "tab",
                              "values": {
                                "title": "CHANGE_ME_PLEASE",
                                "__renderContentOnDemand": false,
                                "__renderContentAsync": false
                              },
                              "content": {
                                "": [
                                  {
                                    "descriptor": "modal-body",
                                    "content": {
                                      "": []
                                    }
                                  }
                                ]
                              }
                            }
                          ]
                        },
                        "values": {
                          "__renderContentAsync": false
                        }
                      }
                    ]
                  },
                  "fixed": false
                },
                "icon": "business_structure",
                "fields": [],
                "types": []
              }
            }""";

    /**
     * Создать приложение с типом "документ" в разделе.
     *///language=json
    public static final String CREATE_APP_DOCUMENT_TYPE_JSON_BODY = """
            {
              "name": "CHANGE_ME_PLEASE",
              "elementName": "CHANGE_ME_PLEASE",
              "code": "CHANGE_ME_PLEASE",
              "namespace": "CHANGE_ME_PLEASE",
              "appViewType": "DOCUMENT",
              "icon": "system_cloud",
              "pageData": {
                "layout": "tiles",
                "menu": {
                  "type": "namespace"
                },
                "widgets": [
                  {
                    "type": "appview",
                    "data": {
                      "namespaceCode": "CHANGE_ME_PLEASE",
                      "pageCode": "CHANGE_ME_PLEASE"
                    }
                  }
                ]
              },
              "pageType": "APPLICATION",
              "sort": 1,
              "system": false,
              "__permissions": {
                "inheritParent": false,
                "values": [
                  {
                    "group": {
                      "type": "group",
                      "id": "fda5c295-230a-5025-9797-b8b4e99e08aa"
                    },
                    "types": [
                      "read"
                    ],
                    "inherited": false
                  }
                ]
              }
            }""";

    /**
     * Создать место регистрации.
     *///language=json
    public static final String CREATE_PLACE_OF_REGISTRATION = """
            {
              "__name": "CHANGE_ME_PLEASE",
              "type": "place"
            }""";

    /**
     * Создать место регистраци.
     *///language=json
    public static final String CREATE_SERIAL_NUM_FOR_NOMENCLATURE = """
            {
                "__id": "",
                "namespace": "nomenclature",
                "code": "CHANGE_ME_PLEASE",
                "name": "CHANGE_ME_PLEASE",
                "nextValue": 1,
                "settings": {
                    "useReleased": true,
                    "iterationStep": 1,
                    "sequence": true
                },
                "apps": []
            }""";

    /**
     * Создать Дело.
     *///language=json
    public static final String CREATE_DOSSIER_NOMENCLATURE = """
            {
                "__id": "CHANGE_ME_PLEASE",
                "__name": "CHANGE_ME_PLEASE",
                "directory": "CHANGE_ME_PLEASE",
                "serialId": "CHANGE_ME_PLEASE",
                "docFlow": "input",
                "registrationSettings": {
                    "templateEnabled": true,
                    "template": "{$__index}",
                    "resetInPeriod": false,
                    "through": false,
                    "throughSerialId": "",
                    "minLength": 1,
                    "reserveEnabled": false,
                    "editAfterRegistration": false
                }
            }""";

    /**
     * Заменить все параметры раздела одним
     *///language=json
    public static final String PUT_SECTION_PARAMETER_JSON_BODY = """
            {
              "fields": [
                {
                  "view": {
                    "data": {
                      "additionalType": "string"
                    },
                    "name": "CHANGE_ME_PLEASE"
                  },
                  "type": "STRING",
                  "code": "CHANGE_ME_PLEASE",
                  "deleted": false,
                  "required": false,
                  "array": false,
                  "single": true,
                  "indexed": false,
                  "searchable": false,
                  "sortable": false,
                  "defaultValue": "",
                  "calcByFormula": false,
                  "formula": "",
                  "data": {
                    "ns": "CHANGE_ME_PLEASE"
                  },
                  "isNewField": true,
                  "isNameChanged": true,
                  "id": 1
                }
              ],
              "values": {
                "test": "CHANGE_ME_PLEASE"
              }
            }""";


    /**
     * Создать директорию
     *///language=json
    public static final String CREATE_DIRECTORY_APP = """
            {
            	"id": "CHANGE_ME_PLEASE",
            	"name": "CHANGE_ME_PLEASE",
            	"parent": "00000000-0000-0000-0000-000000000000",
            	"level": 1,
            	"sort": 100
            }""";

    /**
     * Создать элемент приложения с директорией
     *///language=json
    public static final String CREATE_APP_ELEMENT_WITH_DIRECTORY_JSON_BODY = """
            {
            	"payload": {
            		"__createdBy": null,
            		"__createdAt": null,
            		"__updatedBy": null,
            		"__updatedAt": null,
            		"__deletedAt": null,
            		"__version": 0,
            		"__directory": "CHANGE_ME_PLEASE",
            		"__currentUserPermissions": [
            			"read",
            			"create",
            			"update",
            			"delete",
            			"assign",
            			"bpmanage",
            			"export",
            			"import"
            		],
            		"__name": "CHANGE_ME_PLEASE",
            		"__index": null,
            		"__tasks": null,
            		"__tasks_earliest_duedate": null,
            		"__tasks_performers": null,
            		"__debug": null,
            		"__externalProcessMeta": null,
            		"__externalId": null
            	},
            	"tempData": {
            		"withEventForceCreate": false
            	}
            }""";

    /**
     * Тела запросов для работы с линиями.
     */
    public static final class LineJsonBodies {

        /**
         * Создать линию
         *///language=json
        public static final String CREATE_LINE_JSON_BODY = """
                {
                    "name": "CHANGE_ME_PLEASE",
                    "__name": "CHANGE_ME_PLEASE",
                    "routingRules": [],
                    "supervisors": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "operators": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "readers": [],
                    "sessionBindItems": [],
                    "showOperator": false,
                    "members": [],
                    "integrations": []
                }""";

        /**
         * Добавить приложение в линию
         *///language=json
        public static final String UPDATE_LINE_ADD_APP_AND_CLIENTS_JSON_BODY = """
                {
                    "id": "CHANGE_ME_PLEASE",
                    "__id": "CHANGE_ME_PLEASE",
                    "name": "CHANGE_ME_PLEASE",
                    "__name": "CHANGE_ME_PLEASE",
                    "routingRules": [],
                    "supervisors": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "operators": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "readers": [],
                    "sessionBindItems": [
                        {
                        "application": {
                            "code": "CHANGE_ME_PLEASE",
                            "namespace": "CHANGE_ME_PLEASE"
                         },
                        "fieldCode": "uchetnaya_zapis"
                        }
                    ],
                    "clientBindItem": null,
                    "showOperator": false,
                    "members": [
                        {
                            "id": "CHANGE_ME_PLEASE",
                            "type": "group"
                        }
                    ],
                    "integrations": [],
                    "createdAt": "CHANGE_ME_PLEASE",
                    "__createdAt": "CHANGE_ME_PLEASE",
                    "templates": {
                        "name": "{if {$__groupName}} {$__groupName} {else} {$__clientName} {end} - {DateTime(\\"YYYY-MM-DD\\", {$__sessionCreatedAt})}"
                    }
                }
                """;

        /**
         * Отправить сообщение в линию
         *///language=json
        public static final String MESSAGE_JSON_BODY = """
                {
                  "__id": "CHANGE_ME_PLEASE",
                  "__createdAt": "CHANGE_ME_PLEASE",
                  "author": "CHANGE_ME_PLEASE",
                  "type": "",
                  "body": "CHANGE_ME_PLEASE",
                  "files": [],
                  "reaction": {}
                }""";

        /**
         * Линия со встроенным обработчиком аккаунтов из CRM
         *///language=json
        public static final String LINE_WITH_CLIENTS = """
                {
                	"id": "CHANGE_ME_PLEASE",
                	"__id": "CHANGE_ME_PLEASE",
                	"name": "CHANGE_ME_PLEASE",
                	"__name": "CHANGE_ME_PLEASE",
                    "routingRules": [],
                    "supervisors": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "operators": [
                        "CHANGE_ME_PLEASE"
                    ],
                	"readers": [],
                	"sessionBindItems": [],
                	"clientBindItem": null,
                	"showOperator": false,
                	"members": [
                		{
                			"id": "CHANGE_ME_PLEASE",
                			"type": "group"
                		}
                	],
                	"integrations": [],
                	"createdAt": "2023-02-03T05:47:55.861953879Z",
                	"__createdAt": "2023-02-03T05:47:55.861953879Z",
                	"templates": {
                		"name": "{if {$__groupName}} {$__groupName} {else} {$__clientName} {end} - {DateTime(\\"YYYY-MM-DD\\", {$__sessionCreatedAt})}"
                	}
                }""";

        /**
         * Линия со встроенным правилом
         * todo: возможно, лучше создать билдер линии с правилом/правилами.
         *///language=json
        public static final String LINE_WITH_RULE = """
                {
                	"id": "CHANGE_ME_PLEASE",
                	"__id": "CHANGE_ME_PLEASE",
                	"name": "CHANGE_ME_PLEASE",
                	"__name": "CHANGE_ME_PLEASE",
                	"routingRules": [
                		{
                			"id": "df1f17fb-10c6-477e-8c68-012025d51dfa",
                			"active": true,
                			"conditions": [
                				{
                					"conjunction": false,
                					"inversion": false,
                					"type": "STRING",
                					"a": {
                						"kind": "context",
                						"value": "_custom.dayOfWeek"
                					},
                					"b": {
                						"kind": "manual",
                						"value": "Monday"
                					},
                					"operation": {
                						"relation": "equal",
                						"inversion": false,
                						"caseInsensitive": false
                					},
                					"conditions": null
                				}
                			],
                			"name": "rule_name",
                			"rule": "whoFirst",
                			"operators": [],
                			"bot": null
                		}
                	],
                	"supervisors": [
                		"CHANGE_ME_PLEASE"
                	],
                	"operators": [
                		"CHANGE_ME_PLEASE"
                	],
                	"readers": [],
                	"sessionBindItems": [],
                	"clientBindItem": null,
                	"showOperator": false,
                	"members": [
                		{
                			"id": "CHANGE_ME_PLEASE",
                			"type": "group"
                		}
                	],
                	"integrations": [],
                	"createdAt": "2023-02-03T05:47:55.861953879Z",
                	"__createdAt": "2023-02-03T05:47:55.861953879Z",
                	"templates": {
                		"name": "{if {$__groupName}} {$__groupName} {else} {$__clientName} {end} - {DateTime(\\"YYYY-MM-DD\\", {$__sessionCreatedAt})}"
                	}
                }""";

        /**
         * Линия со встроенным обработчиком аккаунтов из CRM
         *///language=json
        public static final String LINE_WITH_CRM_ACCOUNT_BINDER = """
                {
                	"id": "CHANGE_ME_PLEASE",
                	"__id": "CHANGE_ME_PLEASE",
                	"name": "CHANGE_ME_PLEASE",
                	"__name": "CHANGE_ME_PLEASE",
                    "routingRules": [],
                    "supervisors": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "operators": [
                        "CHANGE_ME_PLEASE"
                    ],
                	"readers": [],
                	"sessionBindItems": [],
                	"clientBindItem": {
                		"fieldCode": "_account",
                		"application": {
                			"namespace": "_clients",
                			"code": "_contacts"
                		}
                	},
                	"showOperator": false,
                	"members": [
                		{
                			"id": "CHANGE_ME_PLEASE",
                			"type": "group"
                		}
                	],
                	"integrations": [],
                	"createdAt": "2023-02-03T05:47:55.861953879Z",
                	"__createdAt": "2023-02-03T05:47:55.861953879Z",
                	"templates": {
                		"name": "{if {$__groupName}} {$__groupName} {else} {$__clientName} {end} - {DateTime(\\"YYYY-MM-DD\\", {$__sessionCreatedAt})}"
                	}
                }""";

        /**
         * Шаблон ответа для линии
         *///language=json
        public static final String LINE_MESSAGE_TEMPLATE = """
                {
                	"payload": {
                		"__id": "CHANGE_ME_PLEASE",
                		"__createdBy": null,
                		"__createdAt": null,
                		"__updatedBy": null,
                		"__updatedAt": null,
                		"__deletedAt": null,
                		"__version": 0,
                		"__directory": null,
                		"__currentUserPermissions": [
                			"read",
                			"create",
                			"update",
                			"delete",
                			"assign",
                			"bpmanage",
                			"export",
                			"import"
                		],
                		"__name": "CHANGE_ME_PLEASE",
                		"__externalProcessMeta": null,
                		"__externalId": null,
                		"_description": "CHANGE_ME_PLEASE",
                		"_template": "template_template",
                		"__index": null,
                		"__tasks": null,
                		"__tasks_earliest_duedate": null,
                		"__tasks_performers": null,
                		"__debug": null
                	},
                	"tempData": {
                		"withEventForceCreate": false
                	}
                }""";

        /**
         * Статья для линии
         *///language=json
        public static final String LINE_ARTICLE = """
                {
                	"payload": {
                		"__id": "CHANGE_ME_PLEASE",
                		"__createdBy": null,
                		"__createdAt": null,
                		"__updatedBy": null,
                		"__updatedAt": null,
                		"__deletedAt": null,
                		"__version": 0,
                		"__directory": null,
                		"__currentUserPermissions": [
                			"read",
                			"create",
                			"update",
                			"delete",
                			"assign",
                			"bpmanage",
                			"export",
                			"import"
                		],
                		"__name": "CHANGE_ME_PLEASE",
                		"__externalProcessMeta": null,
                		"__externalId": null,
                		"_template": "CHANGE_ME_PLEASE",
                		"_url": "CHANGE_ME_PLEASE",
                		"__index": null,
                		"__tasks": null,
                		"__tasks_earliest_duedate": null,
                		"__tasks_performers": null,
                		"__debug": null
                	},
                	"tempData": {
                		"withEventForceCreate": false
                	}
                }""";
    }

    /**
     * Создать роль компании
     *///language=json
    public static final String CREATE_ROLE_COMPANY_JSON_BODY = """
            {
              "__name": "CHANGE_ME_PLEASE",
              "isDefault": false,
              "isRole": true,
              "subOrgunitIds": [
                "CHANGE_ME_PLEASE"
              ],
              "namespace": "CHANGE_ME_PLEASE"
            }""";

    /**
     * Создать группу компании
     *///language=json
    public static final String CREATE_GROUP_COMPANY_JSON_BODY = """
            {
              "__name": "CHANGE_ME_PLEASE",
              "subOrgunitIds": [
                "CHANGE_ME_PLEASE"
              ],
              "namespace": "CHANGE_ME_PLEASE"
            }""";

    /**
     * Тела запросов для работы в классе BackendCrm.
     *///language=json
    public static final class CrmJsonBodies {

        /**
         * Создать компанию в разделе CRM
         *///language=json
        public static final String CREATE_COMPANY_CRM_JSON_BODY = """
                {
                  "payload": {
                    "__id": "CHANGE_ME_PLEASE",
                    "__createdBy": null,
                    "__createdAt": null,
                    "__updatedBy": null,
                    "__updatedAt": null,
                    "__deletedAt": null,
                    "__version": 0,
                    "__directory": null,
                    "__currentUserPermissions": [
                      "read",
                      "create",
                      "update",
                      "delete",
                      "assign",
                      "bpmanage",
                      "export",
                      "import"
                    ],
                    "__name": "CHANGE_ME_PLEASE",
                    "_phone": null,
                    "_email": null,
                    "_website": null,
                    "_address": null,
                    "_inn": null,
                    "_kpp": null,
                    "_leads": null,
                    "_opportunities": null,
                    "_contacts": null,
                    "_legalName": null,
                    "_ogrn": null,
                    "_legalAddress": null,
                    "_correspondenceAddress": null,
                    "_bank": null,
                    "_bik": null,
                    "_operatingAccount": null,
                    "_correspondentAccount": null,
                    "_superiorName": null,
                    "_industries": null,
                    "_segment": null,
                    "__index": null,
                    "__tasks": null,
                    "__tasks_earliest_duedate": null,
                    "__tasks_performers": null,
                    "__debug": null,
                    "__externalProcessMeta": null,
                    "__externalId": null
                  },
                  "tempData": {
                    "withEventForceCreate": false
                  }
                }""";

        /**
         * Создать контакт в разделе CRM
         *///language=json
        public static final String CREATE_CONTACT_CRM_JSON_BODY = """
                {
                  "payload": {
                    "__name": "CHANGE_ME_PLEASE",
                    "_fullname": null,
                    "_position": null,
                    "_phone": null,
                    "_email": null,
                    "_skype": null,
                    "_companies": null,
                    "_leads": null,
                    "_opportunities": null,
                    "__index": null,
                    "__tasks": null,
                    "__tasks_earliest_duedate": null,
                    "__tasks_performers": null,
                    "__debug": null,
                    "_account": null,
                    "__externalProcessMeta": null,
                    "__externalId": null
                  }
                }""";

        /**
         * Создать сделку в разделе CRM
         *///language=json
        public static final String CREATE_DEAL_CRM_JSON_BODY = """
                {
                  "payload": {
                    "__name": "CHANGE_ME_PLEASE",
                    "_owner": [
                      "CHANGE_ME_PLEASE"
                    ],
                    "_companies": null,
                    "_contacts": null,
                    "_budget": null,
                    "_address": null,
                    "_plannedDueDate": null,
                    "__statusComment": null,
                    "utm_source": null,
                    "utm_medium": null,
                    "utm_campaign": null,
                    "__index": null,
                    "__tasks": null,
                    "__tasks_earliest_duedate": null,
                    "__tasks_performers": null,
                    "__status": null,
                    "__debug": null,
                    "_qualified": true,
                    "_opportunity": null,
                    "__externalProcessMeta": null,
                    "__externalId": null
                  },
                   	"tempData": {
                   		"statusGroupId": "00000000-0000-0000-0000-000000000000",
                   		"withEventForceCreate": false
                   	}
                }""";

        /**
         * Создать Сделку с бюджетом в разделе CRM
         *///language=json
        public static final String CREATE_DEAL_WITH_BUDGET_CRM_JSON_BODY = """
                {
                    "payload": {
                        "__name": "CHANGE_ME_PLEASE",
                        "_owner": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_companies": null,
                        "_contacts": null,
                        "_budget": {
                            "cents": "CHANGE_ME_PLEASE",
                            "currency": "RUB"
                        },
                        "_address": null,
                        "_plannedDueDate": null,
                        "__statusComment": null,
                        "utm_source": null,
                        "utm_medium": null,
                        "utm_campaign": null,
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__status": null,
                        "__debug": null,
                        "_qualified": true,
                        "_opportunity": null,
                        "__externalProcessMeta": null,
                        "__externalId": null
                    },
                    "tempData": {
                        "statusGroupId": "00000000-0000-0000-0000-000000000000",
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать Статью дохода в разделе Поступлении
         *///language=json
        public static final String CREATE_INCOME_ITEM_JSON_BODY = """
                {
                    "payload": {
                        "__name": "CHANGE_ME_PLEASE",
                        "__externalProcessMeta": null,
                        "__externalId": null,
                        "_description": null,
                        "_responsible": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__debug": null
                    },
                    "tempData": {
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать плановое поступление в разделе Поступлении
         *///language=json
        public static final String CREATE_PLANNED_RECEIPT_JSON_BODY = """
                {
                    "payload": {
                        "__externalProcessMeta": null,
                        "__externalId": null,
                        "_responsible": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_contractor": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_totalAmount": 100,
                        "_plannedPaymentDate": "CHANGE_ME_PLEASE",
                        "_actualPaymentDate": null,
                        "_planFact": [
                            {
                                "code": "plan",
                                "name": "План"
                            }
                        ],
                        "_actualReceipts": null,
                        "_factIncome": null,
                        "_incomeDistribution": {
                            "rows": [
                                {
                                    "_incomeItem": [
                                        "CHANGE_ME_PLEASE"
                                    ],
                                    "_frc": [
                                        "CHANGE_ME_PLEASE"
                                    ],
                                    "_amount": 100
                                }
                            ],
                            "result": {
                                "_amount": 100,
                                "__count": 1
                            },
                            "view": "Элементов: 1"
                        },
                        "_outgoingInvoices": null,
                        "_currencyType": [
                            "5107e04d-d8c7-4740-a536-6f229127e91c"
                        ],
                        "_distributedInvoice": null,
                        "_incomeItemsUsed": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_frcUsed": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_basis": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_plan": null,
                        "_probability": [
                            {
                                "code": "50",
                                "name": "50%"
                            }
                        ],
                        "__status": null,
                        "__name": null,
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__debug": null
                    },
                    "tempData": {
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать ЦФО в разделе Поступлении
         *///language=json
        public static final String CREATE_CFO_JSON_BODY = """
                {
                    "payload": {
                        "__name": "CHANGE_ME_PLEASE",
                        "__externalProcessMeta": null,
                        "__externalId": null,
                        "_description": "CHANGE_ME_PLEASE",
                        "_manager": null,
                        "_approver": null,
                        "_finalApprover": null,
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__debug": null
                    },
                    "tempData": {
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать фактическое поступление
         *///language=json
        public static final String CREATE_ACTUAL_RECEIPT_JSON_BODY = """
                {
                    "payload": {
                        "__externalProcessMeta": null,
                        "__externalId": null,
                        "_responsible": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_contractor": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_totalAmount": null,
                        "_plannedPaymentDate": null,
                        "_actualPaymentDate": "CHANGE_ME_PLEASE",
                        "_planFact": [
                            {
                                "code": "fact",
                                "name": "Факт"
                            }
                        ],
                        "_actualReceipts": 1000,
                        "_factIncome": null,
                        "_incomeDistribution": {
                            "rows": [
                                {
                                    "_incomeItem": [
                                        "CHANGE_ME_PLEASE"
                                    ],
                                    "_frc": [
                                        "CHANGE_ME_PLEASE"
                                    ],
                                    "_amount": 1000
                                }
                            ],
                            "result": {
                                "_amount": 1000,
                                "__count": 1
                            },
                            "view": "Элементов: 1"
                        },
                        "_outgoingInvoices": null,
                        "_currencyType": [
                            "5107e04d-d8c7-4740-a536-6f229127e91c"
                        ],
                        "_distributedInvoice": null,
                        "_incomeItemsUsed": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_frcUsed": [
                           "CHANGE_ME_PLEASE"
                        ],
                        "_basis": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_plan": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_probability": null,
                        "__status": null,
                        "__name": null,
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__debug": null
                    },
                    "tempData": {
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать Цель
         *///language=json
        public static final String CREATE_GOAL_CRM_JSON_BODY = """
                {
                    "payload": {
                        "__name": "CHANGE_ME_PLEASE",
                        "__externalProcessMeta": null,
                        "__externalId": null,
                        "_type": [
                            {
                                "code": "common",
                                "name": "Цель компании"
                            }
                        ],
                        "_responsible": [
                            "CHANGE_ME_PLEASE"
                        ],
                        "_periodBeginning": "2023-01-01T00:00:00.000Z",
                        "_periodEnd": "2023-12-31T00:00:00.000Z",
                        "_amount": 1000000,
                        "_currencyType": [
                            "5107e04d-d8c7-4740-a536-6f229127e91c"
                        ],
                        "_commonGoal": null,
                        "_teamGoal": null,
                        "_salesTeam": null,
                        "_period": [
                            {
                                "code": "year",
                                "name": "Год"
                            }
                        ],
                        "_year": [
                            {
                                "code": "",
                                "name": ""
                            }
                        ],
                        "_month": null,
                        "_quarter": null,
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__debug": null
                    },
                    "tempData": {
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать отрасль в разделе CRM
         *///language=json
        public static final String CREATE_INDUSTRY_CRM_JSON_BODY = """
                {
                 	"payload": {
                 		"__createdBy": null,
                 		"__createdAt": null,
                 		"__updatedBy": null,
                 		"__updatedAt": null,
                 		"__deletedAt": null,
                 		"__version": 0,
                 		"__directory": null,
                 		"__currentUserPermissions": [
                 			"read",
                 			"create",
                 			"update",
                 			"delete",
                 			"assign",
                 			"bpmanage",
                 			"export",
                 			"import"
                 		],
                 		"__name": "CHANGE_ME_PLEASE",
                 		"_description": null,
                 		"__externalProcessMeta": null,
                 		"__externalId": null,
                 		"__index": null,
                 		"__tasks": null,
                 		"__tasks_earliest_duedate": null,
                 		"__tasks_performers": null,
                 		"__debug": null
                 	},
                 	"tempData": {
                 		"withEventForceCreate": false
                 	}
                }""";

        /**
         * Создать сегмент в разделе CRM
         *///language=json
        public static final String CREATE_SEGMENT_CRM_JSON_BODY = """
                {
                    "payload": {
                        "__createdBy": null,
                        "__createdAt": null,
                        "__updatedBy": null,
                        "__updatedAt": null,
                        "__deletedAt": null,
                        "__version": 0,
                        "__directory": null,
                        "__currentUserPermissions": [
                            "read",
                            "create",
                            "update",
                            "delete",
                            "assign",
                            "bpmanage",
                            "export",
                            "import"
                        ],
                        "__name": "CHANGE_ME_PLEASE",
                        "__externalProcessMeta": null,
                        "__externalId": null,
                        "_description": null,
                        "__index": null,
                        "__tasks": null,
                        "__tasks_earliest_duedate": null,
                        "__tasks_performers": null,
                        "__debug": null
                    },
                    "tempData": {
                        "withEventForceCreate": false
                    }
                }""";

        /**
         * Создать потенциального клиента в разделе CRM
         *///language=json
        public static final String CREATE_LEAD_CRM_JSON_BODY = """
                {
                  "payload": {
                    "__name": "CHANGE_ME_PLEASE",
                    "__externalProcessMeta": null,
                    "__externalId": null,
                    "_owner": [
                      "CHANGE_ME_PLEASE"
                    ],
                    "_company": null,
                    "_contacts": null,
                    "_products": null,
                    "_lead": null,
                    "_warmup": null,
                    "_marketing_efforts": null,
                    "_lead_source": null,
                    "_need_level": null,
                    "_qualification_type": null,
                    "__statusComment": null,
                    "utm_source": null,
                    "utm_medium": null,
                    "utm_campaign": null,
                    "__index": null,
                    "__tasks": null,
                    "__tasks_earliest_duedate": null,
                    "__tasks_performers": null,
                    "__debug": null,
                    "__status": null
                  }
                }""";

        /**
         * Настройки дублей к исходному состоянию
         *///language=json
        public static final String DEFAULT_SETTING_DOUBLES = """
                {
                    "namespace": "_clients",
                    "namespaceSettings": {
                        "highRelationThreshold": 70,
                        "lowRelationThreshold": 30,
                        "minimumTextCharacters": 3
                    },
                    "settings": [
                        {
                            "namespace": "_clients",
                            "code": "_opportunities",
                            "enabled": false,
                            "isChecking": false,
                            "rules": [
                                {
                                    "name": "Лид-Лид",
                                    "description": "Проверка на совпадения внутри приложения \\"Лиды\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_opportunities"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                },
                                {
                                    "name": "Лид-Сделка",
                                    "description": "Проверка на совпадения между элементами приложений \\"Лиды\\" и \\"Сделки\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_leads"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                },
                                {
                                    "name": "Лид-Компания",
                                    "description": "Проверка на совпадения между элементами приложений \\"Лиды\\" и \\"Компании\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_companies"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                }
                            ],
                            "extra": {
                                "searchStatusIds": [],
                                "finalStatusId": 0
                            },
                            "lastCheck": {
                                "userId": "CHANGE_ME_PLEASE",
                                "startDateTime": "2023-03-31T10:14:07.023Z",
                                "endDateTime": "2023-03-31T10:14:08.237Z"
                            }
                        },
                        {
                            "namespace": "_clients",
                            "code": "_leads",
                            "enabled": false,
                            "isChecking": false,
                            "rules": [
                                {
                                    "name": "Сделка-Сделка",
                                    "description": "Проверка на совпадения внутри приложения \\"Сделки\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_leads"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                },
                                {
                                    "name": "Сделка-Лид",
                                    "description": "Проверка на совпадения между элементами приложений \\"Сделки\\" и \\"Лиды\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_opportunities"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                },
                                {
                                    "name": "Сделка-Компания",
                                    "description": "Проверка на совпадения между элементами приложений \\"Сделки\\" и \\"Компании\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_companies"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                }
                            ],
                            "extra": {
                                "searchStatusIds": [],
                                "finalStatusId": 0
                            }
                        },
                        {
                            "namespace": "_clients",
                            "code": "_companies",
                            "enabled": false,
                            "isChecking": false,
                            "rules": [
                                {
                                    "name": "Компания-Компания",
                                    "description": "Проверка на совпадения внутри приложения \\"Компании\\"",
                                    "status": "inactive",
                                    "compareWithApplication": {
                                        "namespace": "_clients",
                                        "code": "_companies"
                                    },
                                    "conditions": [
                                        {
                                            "conjunction": false,
                                            "precision": 40,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "__name"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "PHONE",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._phone"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "EMAIL",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts._email"
                                            },
                                            "operation": {
                                                "relation": "similar"
                                            }
                                        },
                                        {
                                            "conjunction": false,
                                            "precision": 20,
                                            "type": "STRING",
                                            "a": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "b": {
                                                "kind": "context",
                                                "value": "_contacts.__name"
                                            },
                                            "operation": {
                                                "relation": "equal"
                                            }
                                        }
                                    ],
                                    "changeStatus": {
                                        "enabled": false,
                                        "status": 0
                                    },
                                    "scheduleCheck": {
                                        "enabled": false,
                                        "time": "",
                                        "repeat": {
                                            "kind": "daily",
                                            "every": 1,
                                            "days": null,
                                            "weekDays": null,
                                            "months": null
                                        }
                                    }
                                }
                            ],
                            "extra": {
                                "searchStatusIds": [],
                                "finalStatusId": 0
                            }
                        },
                        {
                            "namespace": "_clients",
                            "code": "_contacts",
                            "enabled": false,
                            "isChecking": false,
                            "rules": [],
                            "extra": {
                                "searchStatusIds": [],
                                "finalStatusId": 0
                            }
                        }
                    ]
                }""";

    }

    /**
     * Создать папку в иерархическом справочнике
     *///language=json
    public static final String CREATE_FOLDER_IN_HIERARCHICAL_DIRECTORY = """
            {
                "id": "CHANGE_ME_PLEASE",
                "name": "CHANGE_ME_PLEASE",
                "parent": "00000000-0000-0000-0000-000000000000",
                "level": 1,
                "sort": 100
            }""";

    /**
     * Создать элемент приложения в папке
     *///language=json
    public static final String CREATE_APP_ITEM_IN_FOLDER = """
            {
                "payload": {
                    "__id": "CHANGE_ME_PLEASE",
                    "__createdBy": null,
                    "__createdAt": null,
                    "__updatedBy": null,
                    "__updatedAt": null,
                    "__deletedAt": null,
                    "__version": 0,
                    "__directory": "CHANGE_ME_PLEASE",
                    "__currentUserPermissions": [
                        "read",
                        "create",
                        "update",
                        "delete",
                        "assign",
                        "bpmanage",
                        "export",
                        "import"
                    ],
                    "__name": "CHANGE_ME_PLEASE",
                    "__index": null,
                    "__tasks": null,
                    "__tasks_earliest_duedate": null,
                    "__tasks_performers": null,
                    "__debug": null,
                    "__externalProcessMeta": null,
                    "__externalId": null
                },
                "tempData": {
                    "withEventForceCreate": false
                }
            }""";

    /**
     * Создать файл в папке по id папки
     *///language=json
    public static final String CREATE_FILE_IN_FOLDER = """
            {
                "__name": "CHANGE_ME_PLEASE",
                "originalName": "CHANGE_ME_PLEASE",
                "directory": "CHANGE_ME_PLEASE",
                "size": 0,
                "version": 1
            }
            """;

    /**
     * Настройки “Использование Office 365”
     *///language=json
    public static final String SETTING_USING_OFFICE_365 = """
            {
                "key": "msoffice365.edit",
                "value": "CHANGE_ME_PLEASE"
            }""";


    /**
     * Добавить кнопку "Запуск процесса" на страницу приложения
     * todo: нужно заменить билдером приложения
     *///language=json
    public static final String ADD_PROCESS_START_BUTTON_TO_APP = """
            {
                "listCard": {
                    "places": [],
                    "width": "md",
                    "displaySystemInfo": true,
                    "expandCard": false,
                    "showTasks": false
                },
                "userGuide": {
                    "text": ""
                },
                "advancedForms": {
                    "enabled": false,
                    "create": {
                        "fields": []
                    },
                    "view": {
                        "fields": []
                    },
                    "edit": {
                        "fields": []
                    },
                    "tile": {
                        "fields": []
                    },
                    "fieldVisibilityConditions": {},
                    "massEdit": {
                        "fields": []
                    }
                },
                "listSettings": {
                    "buttons": [
                        {
                            "id": "00000000-0000-0000-0000-000000000001",
                            "label": "+ Приложение",
                            "type": "primary",
                            "code": "create",
                            "processLinkChanged": false,
                            "permission": "create",
                            "useSimpleForm": false,
                            "silentRun": false,
                            "bindings": [],
                            "simpleFormSize": "default",
                            "showForAllowedStatuses": false,
                            "allowedStatusIds": [],
                            "immutable": false,
                            "defaultValues": {},
                            "showForAllowedStatusGroups": false,
                            "allowedGroupIds": []
                        },
                        {
                            "id": "00000000-0000-0000-0000-000000000001",
                            "label": "Запуск процесса",
                            "type": "default",
                            "processNamespace": "CHANGE_ME_PLEASE",
                            "processCode": "CHANGE_ME_PLEASE",
                            "processField": "CHANGE_ME_PLEASE",
                            "processLinkChanged": true,
                            "useSimpleForm": false,
                            "silentRun": false,
                            "bindings": [],
                            "simpleFormSize": "default",
                            "showForAllowedStatuses": false,
                            "allowedStatusIds": [],
                            "immutable": false,
                            "showForAllowedStatusGroups": false,
                            "allowedGroupIds": []
                        }
                    ],
                    "limit": 10,
                    "sort": {
                        "field": "",
                        "direction": "",
                        "additionalSortSettings": null
                    },
                    "aggregateField": "",
                    "enabledMassActions": false,
                    "autoUpdateCards": false
                },
                "tableSettings": {
                    "displayFields": [
                        "__name"
                    ]
                },
                "viewSettings": {
                    "buttons": []
                },
                "createSettings": {
                    "processCode": ""
                },
                "editSettings": null,
                "restoreSettings": {
                    "buttons": []
                },
                "documentSettings": {
                    "pathId": "",
                    "printFormSettings": {
                        "downloadPrintForm": false,
                        "isWatermarksEnabled": false,
                        "watermarkTemplates": []
                    }
                },
                "registrationSettings": {
                    "enabled": true,
                    "restrictRegistration": "",
                    "nomenclatureIds": [],
                    "orgunitIdModel": [],
                    "preliminaryReservationSettings": {
                        "enabled": false,
                        "nomenclatureIds": []
                    }
                },
                "status": {
                    "enabled": false,
                    "manualChange": false,
                    "nextId": 1,
                    "items": [],
                    "groups": [
                        {
                            "id": "00000000-0000-0000-0000-000000000000",
                            "name": "",
                            "code": "__default",
                            "flow": {
                                "type": "manual",
                                "forwardOnly": false
                            }
                        }
                    ],
                    "transitionLog": false
                },
                "nameSettings": {
                    "titleGenerateMethod": "keyvar",
                    "titleTemplate": ""
                },
                "indexSettings": {
                    "serialNamespace": "",
                    "serialCode": "__default"
                },
                "feederSettings": {
                    "onCreateElementEnabled": false
                },
                "dirsSettings": {
                    "enabled": false
                },
                "signature": {
                    "excludeFields": [],
                    "excludeSystemFields": true,
                    "userAccess": []
                },
                "docflow": {
                    "excludeFields": [],
                    "excludeSystemFields": false,
                    "excludeAllFields": true
                },
                "defaultFilterId": null,
                "massSettings": {
                    "buttons": []
                }
            }""";

    /**
     * Отправить элемент приложения на согласование
     *///language=json
    public static final String SEND_APP_ELEMENT_FOR_APPROVAL = """
            {
                "approval_object": {
                    "namespace": "CHANGE_ME_PLEASE",
                    "code": "CHANGE_ME_PLEASE",
                    "id": "CHANGE_ME_PLEASE"
                },
                "parallel": false,
                "interruptOnFirstReject": false,
                "respondents": [
                    "CHANGE_ME_PLEASE}"
                ],
                "__validateResult": {
                    "kind": "BlobObject"
                },
                "system._process_approval.respondents": [
                    "CHANGE_ME_PLEASE"
                ],
                "system._process_approval.parallel": false,
                "system._process_approval.interruptOnFirstReject": false
            }""";

    /**
     * Отправить элемент приложения на ознакомление
     *///language=json
    public static final String SEND_APP_ELEMENT_FOR_FAMILIARIZATION = """
            {
                "inform_object": {
                    "namespace": "CHANGE_ME_PLEASE",
                    "code": "CHANGE_ME_PLEASE",
                    "id": "CHANGE_ME_PLEASE"
                },
                "isInform": true,
                "receivers": [
                    "CHANGE_ME_PLEASE"
                ],
                "__validateResult": {
                    "kind": "BlobObject"
                },
                "system._process_inform.receivers": [
                    "CHANGE_ME_PLEASE"
                ],
                "system._process_inform.isInform": true
            }""";

    /**
     * Тела запросов для работы в классе BackendBusinessProcess.
     *///language=json
    public static final class BackendBusinessProcessJsonBodies {

        /**
         * Дефолтный жсон карточки инстанса процесса
         *///language=json
        public static final String DEFAULT_INSTANCE_CARD = """
                {
                    "allFields": true,
                    "formFields": [
                    ]
                }
                """;

        /**
         * Дефолтный JSON для работы с контекстом на форме
         *///language=json
        public static final String DEFAULT_CONTEXT_ON_FORM = """
                {
                    "code": "CHANGE_ME",
                    "tooltip": "CHANGE_ME",
                    "required": false,
                    "readonly": false,
                    "hideEmpty": false
                }
                """;

        /**
         * Базовый JSON при создании процесса
         *///language=json
        public static final String JSON_BASE = """
                {
                    "type": "bpmn",
                    "__name": "CHANGE_ME",
                    "namespace": "CHANGE_ME",
                    "code": "CHANGE_ME",
                    "category": "00000000-0000-0000-0000-000000000000",
                    "version": 0,
                    "context": [],
                    "draft": true,
                    "scripts": "/**\\nHere you can write scripts for complex server processing of the context during process execution.\\nTo write scripts, use TypeScript (https://www.typescriptlang.org).\\nELMA365 SDK documentation available on https://tssdk.elma365.com.\\n**/\\n",
                    "manualRun": null,
                    "hideInList": false,
                    "readonly": false,
                    "settings": {
                        "logged": true,
                        "notifyOnStart": true,
                        "allowGlobal": false,
                        "targetFeed": {
                            "type": "CHANGE_ME",
                            "variable": "CHANGE_ME"
                        },
                        "applicationContext": false
                    }
                }
                """;

        /**
         * Контекст типа приложения при создании процесса
         *///language=json
        public static final String JSON_APP_CONTEXT = """
                {
                    "type": "SYS_COLLECTION",
                    "code": "CHANGE_ME",
                    "array": true,
                    "single": true,
                    "data": {
                        "namespace": "CHANGE_ME",
                        "code": "CHANGE_ME"
                    },
                    "view": {
                        "name": "CHANGE_ME"
                    }
                }
                """;
        /**
         * Настройка приложения для запуска процесса при создании элемента
         * поле createSettings
         *///language=json
        public static final String CREATE_BUTTON_SETTINGS = """
                {
                    "processCode": "",
                    "buttons": [
                        {
                            "id": "CHANGE_ME",
                            "label": "CHANGE_ME",
                            "type": "primary",
                            "code": "save",
                            "processNamespace": "CHANGE_ME",
                            "processCode": "CHANGE_ME",
                            "processField": "CHANGE_ME",
                            "processLinkChanged": true,
                            "useSimpleForm": false,
                            "silentRun": false,
                            "bindings": [],
                            "simpleFormSize": "default",
                            "showForAllowedStatuses": false,
                            "allowedStatusIds": [],
                            "immutable": false,
                            "showForAllowedStatusGroups": false,
                            "allowedGroupIds": []
                        },
                        {
                            "id": "CHANGE_ME",
                            "label": "CHANGE_ME",
                            "type": "default",
                            "code": "cancel",
                            "processLinkChanged": false,
                            "useSimpleForm": false,
                            "silentRun": false,
                            "bindings": [],
                            "simpleFormSize": "default",
                            "showForAllowedStatuses": false,
                            "allowedStatusIds": [],
                            "immutable": true,
                            "showForAllowedStatusGroups": false,
                            "allowedGroupIds": []
                        }
                    ]
                }
                """;
        /**
         * Создать бизнес-процесс.
         *///language=json
        @Deprecated
        public static final String CREATE_BUSINESS_PROCESS_JSON_BODY = """
                {
                  "type": "bpmn",
                  "__name": "CHANGE_ME_PLEASE",
                  "namespace": "CHANGE_ME_PLEASE",
                  "code": "CHANGE_ME_PLEASE",
                  "category": "00000000-0000-0000-0000-000000000000",
                  "version": 0,
                  "context": [],
                  "draft": true,
                  "scripts": "/**\\nHere you can write scripts for complex server processing of the context during process execution.\\nTo write scripts, use TypeScript (https://www.typescriptlang.org).\\nELMA365 SDK documentation available on https://tssdk.elma365.com.\\n**/\\n",
                  "manualRun": true,
                  "hideInList": false,
                  "readonly": false,
                  "settings": {
                    "logged": true,
                    "notifyOnStart": true,
                    "allowGlobal": false,
                    "targetFeed": {
                      "type": "instance",
                      "variable": ""
                    },
                    "applicationContext": false
                  }
                }""";
    }

    /**
     * Содержимое Json файлов из папки JsonProcess, имена идентичны.
     *///language=json
    public static final class JsonProcess {

        /**
         * Бизнес-процесс с полями статусов.
         *///language=json
        public static final String PROCESS_WITH_STATUS_FIELDS = """
                [
                  {
                    "code": "__name",
                    "type": "STRING",
                    "searchable": true,
                    "indexed": true,
                    "deleted": false,
                    "array": false,
                    "required": true,
                    "single": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Название",
                      "system": true,
                      "data": {
                        "additionalType": "string"
                      }
                    }
                  },
                  {
                    "code": "__directory",
                    "type": "CATEGORY",
                    "searchable": false,
                    "indexed": true,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {
                      "fields": [
                        {
                          "code": "name",
                          "data": null,
                          "type": "STRING",
                          "view": {},
                          "array": false,
                          "single": false,
                          "deleted": false,
                          "formula": "",
                          "indexed": false,
                          "required": false,
                          "searchable": true,
                          "defaultValue": null,
                          "calcByFormula": false
                        },
                        {
                          "code": "parent",
                          "data": null,
                          "type": "STRING",
                          "view": {},
                          "array": false,
                          "single": false,
                          "deleted": false,
                          "formula": "",
                          "indexed": false,
                          "required": false,
                          "searchable": true,
                          "defaultValue": null,
                          "calcByFormula": false
                        },
                        {
                          "code": "level",
                          "data": null,
                          "type": "INTEGER",
                          "view": {},
                          "array": false,
                          "single": false,
                          "deleted": false,
                          "formula": "",
                          "indexed": false,
                          "required": false,
                          "searchable": true,
                          "defaultValue": null,
                          "calcByFormula": false
                        },
                        {
                          "code": "sort",
                          "data": null,
                          "type": "INTEGER",
                          "view": {},
                          "array": false,
                          "single": false,
                          "deleted": false,
                          "formula": "",
                          "indexed": false,
                          "required": false,
                          "searchable": true,
                          "defaultValue": null,
                          "calcByFormula": false
                        }
                      ]
                    },
                    "view": {
                      "name": "Папка в иерархии",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "additionalType": "string"
                      }
                    }
                  },
                  {
                    "code": "__externalProcessMeta",
                    "type": "JSON",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Данные внешних процессов",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "additionalType": "object"
                      }
                    }
                  },
                  {
                    "code": "__externalId",
                    "type": "STRING",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Внешний идентификатор",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "additionalType": "string"
                      }
                    }
                  },
                  {
                    "code": "__id",
                    "type": "STRING",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Идентификатор",
                      "system": true,
                      "data": {
                        "additionalType": "string"
                      }
                    }
                  },
                  {
                    "code": "__index",
                    "type": "FLOAT",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Индекс",
                      "system": true,
                      "data": {
                        "additionalType": "integer"
                      }
                    }
                  },
                  {
                    "code": "__tasks",
                    "type": "JSON",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Задачи",
                      "system": true,
                      "hidden": true
                    }
                  },
                  {
                    "code": "__tasks_earliest_duedate",
                    "type": "DATETIME",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Срок выполнения ближайшей задачи",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    }
                  },
                  {
                    "code": "__tasks_performers",
                    "type": "SYS_USER",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": true,
                    "required": false,
                    "single": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Исполнители",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    }
                  },
                  {
                    "code": "__debug",
                    "type": "BOOLEAN",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Режим отладки",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "noValue": "no",
                        "yesValue": "yes"
                      }
                    }
                  },
                  {
                    "code": "__createdAt",
                    "type": "DATETIME",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Дата создания",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    }
                  },
                  {
                    "code": "__createdBy",
                    "type": "SYS_USER",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Автор",
                      "system": true
                    }
                  },
                  {
                    "code": "__updatedAt",
                    "type": "DATETIME",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Дата изменения",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    }
                  },
                  {
                    "code": "__updatedBy",
                    "type": "SYS_USER",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Редактор",
                      "system": true
                    }
                  },
                  {
                    "code": "__deletedAt",
                    "type": "DATETIME",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Дата удаления",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    }
                  },
                  {
                    "code": "__status",
                    "type": "STATUS",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "required": false,
                    "single": true,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "view": {
                      "name": "Статус",
                      "system": true,
                      "hidden": false
                    }
                  }
                ]""";
    }

    /**
     * Тела запросов для работы встраивания полей в приложения.
     *///language=json
    public static final class ApplicationFields {

        /**
         * Добавить поле учётная запись.
         *///language=json
        public static final String APPLICATION_WITH_ACCOUNT_FIELD = """
                [
                  {
                    "view": {
                      "name": "Название",
                      "system": true,
                      "data": {
                        "additionalType": "string"
                      },
                      "sort": 0
                    },
                    "type": "STRING",
                    "code": "__name",
                    "deleted": false,
                    "required": true,
                    "array": false,
                    "single": false,
                    "indexed": true,
                    "searchable": true,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "text_fields",
                    "id": 1
                  },
                  {
                    "view": {
                      "name": "Папка в иерархии",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "additionalType": "string"
                      }
                    },
                    "type": "CATEGORY",
                    "code": "__directory",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": true,
                    "indexed": true,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {
                      "fields": [
                        {
                          "code": "name",
                          "type": "STRING",
                          "searchable": true,
                          "indexed": false,
                          "deleted": false,
                          "array": false,
                          "required": false,
                          "single": false,
                          "defaultValue": null,
                          "calcByFormula": false,
                          "formula": "",
                          "data": null,
                          "view": {}
                        },
                        {
                          "code": "parent",
                          "type": "STRING",
                          "searchable": true,
                          "indexed": false,
                          "deleted": false,
                          "array": false,
                          "required": false,
                          "single": false,
                          "defaultValue": null,
                          "calcByFormula": false,
                          "formula": "",
                          "data": null,
                          "view": {}
                        },
                        {
                          "code": "level",
                          "type": "INTEGER",
                          "searchable": true,
                          "indexed": false,
                          "deleted": false,
                          "array": false,
                          "required": false,
                          "single": false,
                          "defaultValue": null,
                          "calcByFormula": false,
                          "formula": "",
                          "data": null,
                          "view": {}
                        },
                        {
                          "code": "sort",
                          "type": "INTEGER",
                          "searchable": true,
                          "indexed": false,
                          "deleted": false,
                          "array": false,
                          "required": false,
                          "single": false,
                          "defaultValue": null,
                          "calcByFormula": false,
                          "formula": "",
                          "data": null,
                          "view": {}
                        }
                      ]
                    },
                    "icon": "system_warning",
                    "id": 2
                  },
                  {
                    "view": {
                      "name": "Данные внешних процессов",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "additionalType": "object"
                      }
                    },
                    "type": "JSON",
                    "code": "__externalProcessMeta",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "circle",
                    "id": 3
                  },
                  {
                    "view": {
                      "name": "Внешний идентификатор",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "additionalType": "string"
                      }
                    },
                    "type": "STRING",
                    "code": "__externalId",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "text_fields",
                    "id": 4
                  },
                  {
                    "view": {
                      "data": {},
                      "name": "Учетная запись",
                      "sort": 1
                    },
                    "type": "ACCOUNT",
                    "code": "uchetnaya_zapis",
                    "deleted": false,
                    "required": false,
                    "array": true,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {},
                    "icon": "user_single",
                    "isNewField": true,
                    "selectOnFirstFocus": false,
                    "id": 6
                  },
                  {
                    "type": "STRING",
                    "code": "__id",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Идентификатор",
                      "system": true,
                      "data": {
                        "additionalType": "string"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "FLOAT",
                    "code": "__index",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": false,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Индекс",
                      "system": true,
                      "data": {
                        "additionalType": "integer"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "JSON",
                    "code": "__tasks",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Задачи",
                      "system": true,
                      "hidden": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "DATETIME",
                    "code": "__tasks_earliest_duedate",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Срок выполнения ближайшей задачи",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "SYS_USER",
                    "code": "__tasks_performers",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": true,
                    "single": false,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Исполнители",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "BOOLEAN",
                    "code": "__debug",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Режим отладки",
                      "system": true,
                      "hidden": true,
                      "data": {
                        "yesValue": "yes",
                        "noValue": "no"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "DATETIME",
                    "code": "__createdAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Дата создания",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "SYS_USER",
                    "code": "__createdBy",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Автор",
                      "system": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "DATETIME",
                    "code": "__updatedAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Дата изменения",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "SYS_USER",
                    "code": "__updatedBy",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Редактор",
                      "system": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  },
                  {
                    "type": "DATETIME",
                    "code": "__deletedAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                      "name": "Дата удаления",
                      "system": true,
                      "data": {
                        "additionalType": "datetime"
                      }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                  }
                ]""";
    }

    /**
     * Добавить поле Строка.
     *///language=json
    public static final String APPLICATION_WITH_STRING = """
            [
                {
                    "view": {
                        "name": "Название",
                        "system": true,
                        "data": {
                            "additionalType": "string"
                        },
                        "sort": 0
                    },
                    "type": "STRING",
                    "code": "__name",
                    "deleted": false,
                    "required": true,
                    "array": false,
                    "single": false,
                    "indexed": true,
                    "searchable": true,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "text_fields",
                    "id": 1,
                    "isNameChanged": true
                },
                {
                    "view": {
                        "name": "Папка в иерархии",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "additionalType": "string"
                        }
                    },
                    "type": "CATEGORY",
                    "code": "__directory",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": true,
                    "indexed": true,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {
                        "fields": [
                            {
                                "code": "name",
                                "type": "STRING",
                                "searchable": true,
                                "indexed": false,
                                "deleted": false,
                                "array": false,
                                "required": false,
                                "single": false,
                                "defaultValue": null,
                                "calcByFormula": false,
                                "formula": "",
                                "data": null,
                                "view": {}
                            },
                            {
                                "code": "parent",
                                "type": "STRING",
                                "searchable": true,
                                "indexed": false,
                                "deleted": false,
                                "array": false,
                                "required": false,
                                "single": false,
                                "defaultValue": null,
                                "calcByFormula": false,
                                "formula": "",
                                "data": null,
                                "view": {}
                            },
                            {
                                "code": "level",
                                "type": "INTEGER",
                                "searchable": true,
                                "indexed": false,
                                "deleted": false,
                                "array": false,
                                "required": false,
                                "single": false,
                                "defaultValue": null,
                                "calcByFormula": false,
                                "formula": "",
                                "data": null,
                                "view": {}
                            },
                            {
                                "code": "sort",
                                "type": "INTEGER",
                                "searchable": true,
                                "indexed": false,
                                "deleted": false,
                                "array": false,
                                "required": false,
                                "single": false,
                                "defaultValue": null,
                                "calcByFormula": false,
                                "formula": "",
                                "data": null,
                                "view": {}
                            }
                        ]
                    },
                    "icon": "system_warning",
                    "id": 2
                },
                {
                    "view": {
                        "name": "Данные внешних процессов",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "additionalType": "object"
                        }
                    },
                    "type": "JSON",
                    "code": "__externalProcessMeta",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "circle",
                    "id": 3
                },
                {
                    "view": {
                        "name": "Внешний идентификатор",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "additionalType": "string"
                        }
                    },
                    "type": "STRING",
                    "code": "__externalId",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "text_fields",
                    "id": 4
                },
                {
                    "view": {
                        "data": {
                            "additionalType": "string"
                        },
                        "name": "Строка",
                        "sort": 1
                    },
                    "type": "STRING",
                    "code": "stroka",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": true,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {},
                    "icon": "text_fields",
                    "isNewField": true,
                    "selectOnFirstFocus": false,
                    "id": 6
                },
                {
                    "type": "STRING",
                    "code": "__id",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Идентификатор",
                        "system": true,
                        "data": {
                            "additionalType": "string"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "FLOAT",
                    "code": "__index",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": false,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Индекс",
                        "system": true,
                        "data": {
                            "additionalType": "integer"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "JSON",
                    "code": "__tasks",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Задачи",
                        "system": true,
                        "hidden": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__tasks_earliest_duedate",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Срок выполнения ближайшей задачи",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "SYS_USER",
                    "code": "__tasks_performers",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": true,
                    "single": false,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Исполнители",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "BOOLEAN",
                    "code": "__debug",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Режим отладки",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "yesValue": "yes",
                            "noValue": "no"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__createdAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Дата создания",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "SYS_USER",
                    "code": "__createdBy",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Автор",
                        "system": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__updatedAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Дата изменения",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "SYS_USER",
                    "code": "__updatedBy",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Редактор",
                        "system": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__deletedAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Дата удаления",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                }
            ]""";

    /**
     * Добавить поле типа таблица.
     * todo: нужно заменить билдером приложения
     *///language=json
    public static final String APPLICATION_WITH_TABLE = """
            [
                {
                    "view": {
                        "name": "Название",
                        "system": true,
                        "data": {
                            "additionalType": "string"
                        },
                        "sort": 0
                    },
                    "type": "STRING",
                    "code": "__name",
                    "deleted": false,
                    "required": true,
                    "array": false,
                    "single": false,
                    "indexed": true,
                    "searchable": true,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "text_fields",
                    "id": 1
                },
                {
                    "view": {
                        "name": "Папка в иерархии",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "additionalType": "string"
                        }
                    },
                    "type": "CATEGORY",
                    "code": "__directory",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": true,
                    "indexed": true,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {
                        "fields": [
                            {
                                "code": "name",
                                "data": null,
                                "type": "STRING",
                                "view": {},
                                "array": false,
                                "single": false,
                                "deleted": false,
                                "formula": "",
                                "indexed": false,
                                "required": false,
                                "searchable": true,
                                "defaultValue": null,
                                "calcByFormula": false
                            },
                            {
                                "code": "parent",
                                "data": null,
                                "type": "STRING",
                                "view": {},
                                "array": false,
                                "single": false,
                                "deleted": false,
                                "formula": "",
                                "indexed": false,
                                "required": false,
                                "searchable": true,
                                "defaultValue": null,
                                "calcByFormula": false
                            },
                            {
                                "code": "level",
                                "data": null,
                                "type": "INTEGER",
                                "view": {},
                                "array": false,
                                "single": false,
                                "deleted": false,
                                "formula": "",
                                "indexed": false,
                                "required": false,
                                "searchable": true,
                                "defaultValue": null,
                                "calcByFormula": false
                            },
                            {
                                "code": "sort",
                                "data": null,
                                "type": "INTEGER",
                                "view": {},
                                "array": false,
                                "single": false,
                                "deleted": false,
                                "formula": "",
                                "indexed": false,
                                "required": false,
                                "searchable": true,
                                "defaultValue": null,
                                "calcByFormula": false
                            }
                        ]
                    },
                    "icon": "system_warning",
                    "id": 2
                },
                {
                    "view": {
                        "name": "Данные внешних процессов",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "additionalType": "object"
                        }
                    },
                    "type": "JSON",
                    "code": "__externalProcessMeta",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "circle",
                    "id": 3
                },
                {
                    "view": {
                        "name": "Внешний идентификатор",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "additionalType": "string"
                        }
                    },
                    "type": "STRING",
                    "code": "__externalId",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": false,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": null,
                    "icon": "text_fields",
                    "id": 4
                },
                {
                    "view": {
                        "data": {
                            "viewTemplate": "Элементов: {$__count}"
                        },
                        "name": "table",
                        "sort": 1
                    },
                    "type": "TABLE",
                    "code": "table",
                    "deleted": false,
                    "required": false,
                    "array": false,
                    "single": true,
                    "indexed": false,
                    "searchable": false,
                    "sortable": false,
                    "defaultValue": null,
                    "calcByFormula": false,
                    "formula": "",
                    "data": {},
                    "isNewField": true,
                    "isNameChanged": true,
                    "id": 5
                },
                {
                    "type": "STRING",
                    "code": "__id",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Идентификатор",
                        "system": true,
                        "data": {
                            "additionalType": "string"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "FLOAT",
                    "code": "__index",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": false,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Индекс",
                        "system": true,
                        "data": {
                            "additionalType": "integer"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "JSON",
                    "code": "__tasks",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Задачи",
                        "system": true,
                        "hidden": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__tasks_earliest_duedate",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Срок выполнения ближайшей задачи",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "SYS_USER",
                    "code": "__tasks_performers",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": true,
                    "single": false,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Исполнители",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "BOOLEAN",
                    "code": "__debug",
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Режим отладки",
                        "system": true,
                        "hidden": true,
                        "data": {
                            "noValue": "no",
                            "yesValue": "yes"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__createdAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Дата создания",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "SYS_USER",
                    "code": "__createdBy",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Автор",
                        "system": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__updatedAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Дата изменения",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "SYS_USER",
                    "code": "__updatedBy",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Редактор",
                        "system": true
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                },
                {
                    "type": "DATETIME",
                    "code": "__deletedAt",
                    "searchable": true,
                    "indexed": false,
                    "deleted": false,
                    "array": false,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": null,
                    "view": {
                        "name": "Дата удаления",
                        "system": true,
                        "data": {
                            "additionalType": "datetime"
                        }
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                }
            ]""";


    /**
     * Создать проект
     *///language=json
    public static final String CREATE_PROJECT_JSON_BODY = """
            {
                "payload": {
                    "__createdBy": null,
                    "__createdAt": null,
                    "__updatedBy": null,
                    "__updatedAt": null,
                    "__deletedAt": null,
                    "__version": 0,
                    "__directory": null,
                    "__currentUserPermissions": [
                        "read",
                        "create",
                        "update",
                        "delete",
                        "assign",
                        "bpmanage",
                        "export",
                        "import"
                    ],
                    "__name": "CHANGE_ME_PLEASE",
                    "__externalProcessMeta": null,
                    "__externalId": null,
                    "_project_template": null,
                    "_start_date": "2023-04-05T00:00:00.000Z",
                    "_end_date": "2023-04-05T00:00:00.000Z",
                    "_description": null,
                    "_project_manager": [
                        "CHANGE_ME_PLEASE"
                    ],
                    "_supervisor": null,
                    "_current_plan": null,
                    "_archived_plans": null,
                    "_drafts": null,
                    "_planeditors": null,
                    "_participants": null,
                    "_is_template": false,
                    "_template_project": null,
                    "_project_folder": null,
                    "__index": null,
                    "__tasks": null,
                    "__tasks_earliest_duedate": null,
                    "__tasks_performers": null,
                    "__debug": null,
                    "__status": null,
                    "_use_work_calendar": false
                },
                "tempData": {
                    "statusGroupId": "00000000-0000-0000-0000-000000000000",
                    "withEventForceCreate": false
                }
            }""";
}
