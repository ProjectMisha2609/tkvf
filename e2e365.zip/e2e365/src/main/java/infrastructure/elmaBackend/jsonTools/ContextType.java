package infrastructure.elmaBackend.jsonTools;

/**
 * Типы переменных приложения, бизнес-процесса
 */
public enum ContextType {
    STRING,
    FILE,
    SYS_USER,
    DATETIME,
    SYS_COLLECTION, // Для приложений
    REF_ITEM // Для пакетных данных
}
