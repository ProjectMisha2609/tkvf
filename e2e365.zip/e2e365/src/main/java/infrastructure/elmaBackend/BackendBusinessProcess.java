package infrastructure.elmaBackend;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;
import infrastructure.drivers.CustomDriver;
import infrastructure.helpers.MicronautHttpClient;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;

import java.util.*;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.BackendBusinessProcessJsonBodies.CREATE_BUSINESS_PROCESS_JSON_BODY;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;

/**
 * Класс с API методами обработки бизнес-процессов, а так же методами получения информации о них.
 */
@Deprecated
@Singleton
public class BackendBusinessProcess extends ElmaBackend {
    @Inject
    protected MicronautHttpClient micronautHttpClient;

    public String createBusinessProcess(String sectionName, String businessProcessName) {
        String json = JsonPath.using(configuration).parse(CREATE_BUSINESS_PROCESS_JSON_BODY)
                .set("$.__name", businessProcessName)
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.code", businessProcessName.toLowerCase(Locale.ROOT))
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/bpm/templates", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String lock(String processId) {
        String response = micronautHttpClient.authorizedJsonPost("/api/bpm/templates/" + processId + "/lock", EMPTY_JSON, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("hash").toString().replace("\"", "");
    }

    public void saveChanges(String processId, String lockHashHeader, String jsonBody) {
        micronautHttpClient.authorizedLockHashJsonPut("/api/bpm/templates/" + processId, lockHashHeader, jsonBody, getAuthTokenAdmin());
    }

    public void unlock(String processId, String lockHashHeader) {
        micronautHttpClient.authorizedLockHashJsonDelete("/api/bpm/templates/" + processId + "/lock", lockHashHeader, getAuthTokenAdmin());
    }

    @Deprecated // todo: устаревший метод, не работает в секциях, лучше использовать метод с телом.
    public String run(String processId) {
        String json = micronautHttpClient.authorizedJsonPut("/api/bpm/templates/public/" + processId + "/1/run", EMPTY_JSON, getAuthTokenAdmin());
        String instance = null;
        if(json != null) {
            JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();
            instance = jsonObject.get("__id").getAsString();
        }
        return instance;
    }

    /**
     * Запуск процесса (в системе есть системные процессы их тоже можно так запускать, при условии, что нам не надо смотреть форму запуска)
     *
     * @param processId               идентификатор процесса
     * @param contextStartProcessJson JSON с переменными которые передаются при запуске (на форме стартового события), если ничего не передается то просто указать {}
     * @return вернет ID инстанса запущенного процесса
     */
    public String run(String processId, String contextStartProcessJson) {
        //TODO лучше использовать такой метод в других тестах потом сам переделаю
        int processVersion = getCurrentVersionProcess(processId);//узнаем текущую версию процесса
        if (processVersion <= 0) {
            throw new IllegalStateException("Процесс должен иметь версию 1 и выше");
        }
        String json = micronautHttpClient.authorizedJsonPut("/api/bpm/templates/public/" + processId
                + "/" + processVersion + "/run", contextStartProcessJson, getAuthTokenAdmin());
        String instance = null;
        if(json != null) {
            JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();
            instance = jsonObject.get("__id").getAsString();
        }
        return instance;
    }

    /**
     * Узнаем текущую версию процесса
     *
     * @param processId ID проесса
     * @return версия
     */
    public int getCurrentVersionProcess(String processId) {
        String json = micronautHttpClient.authorizedJsonGet("/api/bpm/templates/" + processId, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();
        return jsonObject.get("version").getAsInt();
    }

    /**
     * Прервать процесс по его инстансу
     *
     * @param processInstanceId ID инстанса
     */
    public void interrupt(String processInstanceId) {
        String jsonBody = "{\"__updateComment\": \"INTERRUPT BY API COMMENT!\"}";
        micronautHttpClient.authorizedJsonPut("/api/bpm/instances/"
                + processInstanceId + "/interrupt", jsonBody, getAuthTokenAdmin());
    }

    /**
     * Получить все инстанс айди по айдишке процесса
     *
     * @param processId айди процесса
     * @return возвращает список айди инстансов
     */
    public List<String> getAllInstanceIDByProcessID(String processId) {
        List<String> list = new ArrayList<>();
        CustomDriver.waitMills(1000);
        String response = getAllInstanceByProcessID(processId);
        if (response != null) {
            JsonObject getAllJson = JsonParser.parseString(response).getAsJsonObject();
            JsonArray array = getAllJson.getAsJsonArray("result");
            for (int i = 0; i < array.size(); i++) {
                JsonObject getFromArray = array.get(i).getAsJsonObject();
                list.add(getFromArray.get("__id").toString().replace("\"", ""));
            }
        }
        return list;
    }

    /**
     * Получить JSON инстансов процесса по его айди
     *
     * @param processId айди процесса
     * @return возвращает JSON стркоу инстансов
     */
    private String getAllInstanceByProcessID(String processId) {
        String url = "/api/processor/monitor/" + processId + "/instances" +
                "?from=0&size=1000&q=%7B%22eq%22%3A%5B%7B%22field%22%3A%22__templateId%22%7D%2C%7B%22const%22%3A%22" +
                processId + "%22%7D%5D%7D&withPermissions=true&sortField=__createdAt&ascending=false";
        return micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
    }

    /**
     * Получает JsonArray с контекстом процесса.
     *
     * @param processId ИД процесса
     * @return JsonArray c контекстом процесса
     */
    public JsonArray getContext(String processId) {
        String response = micronautHttpClient.authorizedJsonGet("/api/bpm/templates/" + processId, getAuthTokenAdmin());
        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        return json.getAsJsonArray("context");
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам.
     *
     * @param processId      ИД процесса
     * @param index          Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName    Название контекстной переменной
     * @param type           Тип контекстной переменной
     * @param additionalType Подтип контекстной переменной
     */
    public void checkContext(String processId, int index, String contextName, String type, String additionalType) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        String propertySubType = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("additionalType").getAsString();
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals(propertyType, type,
                "Тип переменной не совпадает с выбранным");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        Assertions.assertEquals(propertySubType, additionalType,
                "Подтип не совпадает с выбранным");
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам.
     * Проверяет значения переменных через сравнение с переданным массивом.
     *
     * @param processId        ИД процесса
     * @param index            Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName      Название контекстной переменной
     * @param type             Тип контекстной переменной, "ENUM" или "BOOLEAN"
     * @param contextVariables Значения контекстной переменной
     */
    public void checkContextVariableValues(String processId, int index, String contextName, String type, String[] contextVariables) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        JsonArray jsonBodyWithVariables;
        Set<String> variableValuesSet = new HashSet<>();
        // блок сохранения значений переменных типа ENUM
        if (type.equals("ENUM")) {
            jsonBodyWithVariables = context.get(index).getAsJsonObject().getAsJsonObject("data").getAsJsonArray("enumItems");
            for (JsonElement variable : jsonBodyWithVariables) {
                // итеративное добавление имён переменных в список уникальных значений
                variableValuesSet.add(variable.getAsJsonObject().get("name").toString().replace("\"", ""));
            }
        }
        // блок сохранения значений переменных типа BOOLEAN
        else if (type.equals("BOOLEAN")) {
            variableValuesSet.add(context.get(index).getAsJsonObject().getAsJsonObject("view")
                    .get("data").getAsJsonObject()
                    .get("yesValue").toString().replace("\"", ""));
            variableValuesSet.add(context.get(index).getAsJsonObject().getAsJsonObject("view")
                    .get("data").getAsJsonObject()
                    .get("noValue").toString().replace("\"", ""));
        } else {
            Assertions.fail("Неизвестный тип переменной");
        }
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals(propertyType, type,
                "Тип переменной не совпадает с выбранным");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        for (String contextVariable : contextVariables) {
            Assertions.assertTrue(variableValuesSet.contains(contextVariable),
                    String.format("В значениях переменных не найдено: %s", contextVariable));
        }
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам.
     *
     * @param processId   ИД процесса
     * @param index       Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName Название контекстной переменной
     * @param type        Тип контекстной переменной
     * @param single      параметр Одиночное(true)/Множественное(false)
     */
    public void checkContext(String processId, int index, String contextName, String type, Boolean single) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        Boolean isPropertySingle = context.get(index).getAsJsonObject().get("single").getAsBoolean();
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals(propertyType, type,
                "Тип переменной не совпадает с выбранным. Ожидался %s, а не %s");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        Assertions.assertEquals(isPropertySingle, single,
                "Отображаемое значение одиночное/множественное не совпадает с указанным");
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам (Для типа "Деньги").
     *
     * @param processId   ИД процесса
     * @param index       Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName Название контекстной переменной
     * @param currency    Выбранная валюта для типа деньги
     */
    public void checkContext(String processId, int index, String contextName, String currency) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        String propertyCurrency = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("currency").getAsString();
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals("MONEY", propertyType,
                "Тип переменной не совпадает с выбранным");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        Assertions.assertEquals(propertyCurrency, currency,
                "Валюта не совпадает с выбранной");
    }

    /**
     * Проверяет значение по умолчанию в контексте процесса.
     *
     * @param processId    ИД процесса
     * @param index        Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param defaultValue Значение по умолчанию для контекстной переменной
     */
    public void checkContextDefaultValue(String processId, int index, String defaultValue) {
        JsonArray context = getContext(processId);
        String propertyDefaultValue = context.get(index).getAsJsonObject().get("defaultValue").getAsString();
        Assertions.assertEquals(propertyDefaultValue, defaultValue,
                "Значение по умолчанию не совпадает с указанным");
    }

    /**
     * Проверяет формулу для свойства в контексте процесса.
     *
     * @param processId ИД процесса
     * @param index     Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param formula   Значение по умолчанию для контекстной переменной
     */
    public void checkContextFormula(String processId, int index, String formula) {
        JsonArray context = getContext(processId);
        String propertyFormula = context.get(index).getAsJsonObject().get("formula").getAsString();
        Assertions.assertEquals(propertyFormula, formula,
                "Значение по умолчанию не совпадает с указанным");
    }

    /**
     * Проверяет подсказку для свойства в контексте процесса.
     *
     * @param processId ИД процесса
     * @param index     Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param tooltip   Значение по умолчанию для контекстной переменной
     */
    public void checkContextTooltip(String processId, int index, String tooltip) {
        JsonArray context = getContext(processId);
        String propertyTooltip = context.get(index).getAsJsonObject().getAsJsonObject("view").get("tooltip").getAsString();
        Assertions.assertEquals(propertyTooltip, tooltip,
                "Подсказка не совпадает с указанной");
    }

    /**
     * Проверяет параметр "Указывать текущее время" для свойства типа Дата/Время в контексте процесса.
     *
     * @param processId       ИД процесса
     * @param index           Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param currentDateTime (Bool) параметр "Указывать текущее время"
     */
    public void checkContextDateTimeCurrent(String processId, int index, Boolean currentDateTime) {
        JsonArray context = getContext(processId);
        Boolean propertyCurrentDatetime = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("setCurrentDatetime").getAsBoolean();
        Assertions.assertEquals(propertyCurrentDatetime, currentDateTime,
                "Параметр Указывать текущее время не совпадает");
    }

    /**
     * Проверяет параметр "Указывать текущее время" для свойства типа Дата/Время в контексте процесса.
     *
     * @param processId       ИД процесса
     * @param index           Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param timeOptional    (Bool) параметр "Время опционально"
     * @param defaultTimeType Тип опционального времени startOfDay/endOfDay
     */
    public void checkContextDateTimeOptional(String processId, int index, Boolean timeOptional, String defaultTimeType) {
        JsonArray context = getContext(processId);
        Boolean propertyTimeOptional = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("timeOptional").getAsBoolean();
        String propertyDefaultTimeType = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("defaultTimeType").getAsString();
        Assertions.assertEquals(propertyTimeOptional, timeOptional,
                "Параметр Время опционально не совпадает");
        Assertions.assertEquals(propertyDefaultTimeType, defaultTimeType,
                "Тип опционального времени не совпадает");
    }

    /**
     * Проверяет параметр "Показывать заблокированных" для свойства типа "Пользователь" в контексте процесса.
     *
     * @param processId   ИД процесса
     * @param index       Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param showBlocked (Bool) параметр "Показывать заблокированных"
     */
    public void checkContextUserShowBlocked(String processId, int index, Boolean showBlocked) {
        JsonArray context = getContext(processId);
        Boolean propertyShowBlocked = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("showBlocked").getAsBoolean();
        Assertions.assertEquals(propertyShowBlocked, showBlocked,
                "Параметр 'Показывать заблокированных' не совпадает");
    }

    /**
     * Проверяет параметр "Выбирать фрагмент изображения при загрузке" для свойства типа "Изображение" в контексте процесса.
     *
     * @param processId      ИД процесса
     * @param index          Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param selectFragment (Bool) параметр "Выбирать фрагмент изображения при загрузке"
     */
    public void checkContextImageIsSelectFragment(String processId, int index, Boolean selectFragment) {
        JsonArray context = getContext(processId);
        Boolean propertySelectFragment = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("selectFragment").getAsBoolean();
        Assertions.assertEquals(propertySelectFragment, selectFragment,
                "Параметр 'Выбирать фрагмент изображения при загрузке' не совпадает");
    }

    public void checkContextVariableDeleted(String processId, int index) {
        JsonArray context = getContext(processId);
        Assertions.assertTrue(context.get(index).getAsJsonObject().get("deleted").getAsBoolean(),
                "Контекстная переменная не удалена");
    }
}
