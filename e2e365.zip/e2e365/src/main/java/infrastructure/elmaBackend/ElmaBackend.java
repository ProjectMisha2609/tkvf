package infrastructure.elmaBackend;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.elmaBackend.jsonTools.SubstitutionType;
import infrastructure.helpers.MicronautHttpClient;
import infrastructure.helpers.RandomString;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static infrastructure.elmaBackend.BackendUser.UnixTimeConverter.convertDateToUnix;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.*;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.JsonProcess.PROCESS_WITH_STATUS_FIELDS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_1;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;
import static infrastructure.utils.Loggers.CONSOLE;
import static java.lang.String.format;
import static java.time.format.DateTimeFormatter.ofPattern;

/**
 * Класс, содержащий основные методы работы с сервисом через API.
 */
@Singleton
public class ElmaBackend extends BackendUser {
    @Inject
    protected MicronautHttpClient micronautHttpClient;

    protected static final Configuration configuration = Configuration.builder()
            .jsonProvider(new JacksonJsonNodeJsonProvider())
            .mappingProvider(new JacksonMappingProvider())
            .build();

    /**
     * Получение пары ключ-значение из имени системной группы и её кода.
     *
     * @return Ключ:название; Значение:UUID;
     */
    public Map<String, String> getSystemGroupsMap() {
        Map<String, String> groups = new HashMap<>();
        String json = micronautHttpClient.authorizedJsonPost("/api/groups/list", QUERY_TO_GET_SYSTEM_GROUPS, getAuthTokenAdmin());
        JsonArray answer = JsonParser.parseString(json).getAsJsonObject().get("result").getAsJsonArray();
        for (JsonElement group : answer) {
            groups.put(group.getAsJsonObject().get("code").toString().replace("\"", ""),
                    group.getAsJsonObject().get("__id").toString().replace("\"", ""));
        }
        return groups;
    }

    /**
     * Получение пары ключ-значение из имени группы компании и её кода.
     *
     * @return Ключ:название; Значение:UUID;
     */
    public Map<String, String> getCompanyGroupsMap() {
        Map<String, String> groups = new HashMap<>();
        String json = micronautHttpClient.authorizedJsonPost("/api/groups/list", QUERY_TO_GET_COMPANY_GROUPS, getAuthTokenAdmin());
        JsonArray answer = JsonParser.parseString(json).getAsJsonObject().get("result").getAsJsonArray();
        for (JsonElement group : answer) {
            groups.put(group.getAsJsonObject().get("__name").toString().replace("\"", ""),
                    group.getAsJsonObject().get("__id").toString().replace("\"", ""));
        }
        return groups;
    }

    /**
     * Получение ID системной группы по её названию.
     */
    public String getSystemGroupId(String name) {
        if (getSystemGroupsMap().get(name) == null)
            CONSOLE.error("Не найдена группа пользователей с именем \"" + name + "\"");
        else return getSystemGroupsMap().get(name);
        return null;
    }

    /**
     * Получение пары ключ-значение из имени группы компании и её кода.
     *
     * @return Ключ:название; Значение:UUID;
     */
    public Map<String, String> getCodeCompanyGroupsMap() {
        Map<String, String> groups = new HashMap<>();
        String json = micronautHttpClient.authorizedJsonPost("/api/groups/list", QUERY_TO_GET_COMPANY_GROUPS, getAuthTokenAdmin());
        JsonArray answer = JsonParser.parseString(json).getAsJsonObject().get("result").getAsJsonArray();
        for (JsonElement group : answer) {
            groups.put(group.getAsJsonObject().get("__name").toString().replace("\"", ""),
                    group.getAsJsonObject().get("code").toString().replace("\"", ""));
        }
        return groups;
    }

    public String getCompanyGroupCode(String name) {
        if (getCodeCompanyGroupsMap().get(name) == null)
            CONSOLE.error("Не найдена группа пользователей с именем \"" + name + "\"");
        else return getCodeCompanyGroupsMap().get(name);
        return null;
    }

    /**
     * Получение ID группы компании по её названию.
     */
    public String getCompanyGroupId(String name) {
        if (getCompanyGroupsMap().get(name) == null)
            CONSOLE.error("Не найдена группа пользователей с именем \"" + name + "\"");
        else return getCompanyGroupsMap().get(name);
        return null;
    }

    public void createCompanyGroup(String name, String userId) {
        String json = String.format("""
                {
                   "__name": "%s",
                   "subOrgunitIds": [
                       "%s"
                   ],
                   "namespace": "global"
                }""", name, userId);
        micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
    }

    public String createCompanyGroup(String name, String userId1, String userId2) {
        String json = String.format("""
                {
                   "__name": "%s",
                   "subOrgunitIds": [
                       "%s",
                       "%s"
                   ],
                   "namespace": "global"
                }""", name, userId1, userId2);
        String response = micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }


    /**
     * Создает группу компании с заданным именем.
     *
     * @param name - Имя группы
     * @return ID новой роли группы
     */
    public String createCompanyGroup(String name) {
        String json = String.format("""
                {
                   "__name": "%s",
                    "isDefault": false,
                   "subOrgunitIds": [],
                   "namespace": "global"
                }""", name);
        String response = micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать новую группу с описанием и администратором
     *
     * @param groupName        - название группы
     * @param groupDescription - текст описания
     * @param adminId          - id администратора
     * @return ID новой группы
     */
    public String createNewGroup(String groupName, String groupDescription, String adminId) {
        String subOrgunitIds = "[]";
        if (adminId != null) {
            subOrgunitIds = String.format("[\"%s\"]", adminId);
        }

        String json = String.format("""
                {
                    "__name": "%s",
                    "description": "%s",
                    "subOrgunitIds": %s,
                    "namespace": "global"
                }""", groupName, groupDescription, subOrgunitIds);

        String response = micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать новую роль с описанием и пользователем
     *
     * @param roleName        - название роли
     * @param roleDescription - текст описания
     * @param idUser          - id пользователя
     * @return ID новой роли
     */
    public String createNewRole(String roleName, String roleDescription, String idUser) {
        String subOrgunitIds = "[]";
        if (idUser != null) {
            subOrgunitIds = String.format("[\"%s\"]", idUser);
        }

        String json = String.format("""
                {
                    "__name": "%s",
                    "description": "%s",
                    "isDefault": false,
                    "isRole": true,
                    "subOrgunitIds": %s,
                    "namespace": "global"
                }""", roleName, roleDescription, subOrgunitIds);

        String response = micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создает новую роль без описания и пользователя.
     *
     * @param roleName - - название роли
     * @return ID новой роли
     */
    public String createNewRole(String roleName) {
        return createNewRole(roleName, "", null);
    }

    /**
     * Изменить данные пользователя по его логину.
     *
     * @param login  email для входа
     * @param groups массив групп (администраторы, внешние пользователи и так далее)
     * @param fio    ФИО в соответствующем порядке
     * @return код ответа
     */
    public String setUserData(String login, String[] groups, String... fio) {
        String orig = micronautHttpClient.authorizedJsonGet("/api/users/" + getUserIdByEmail(login), getAuthTokenAdmin());
        String json = JsonPath.using(configuration).parse(orig)
                .set("$.fullname.firstname", fio[1])
                .set("$.fullname.lastname", fio[0])
                .set("$.fullname.middlename", fio[2])
                .set("$.groupIds", groups)
                .json().toString();
        return micronautHttpClient.authorizedJsonPutReturnCode("api/users/" + getUserIdByEmail(login), json, getAuthTokenAdmin());
    }

    /**
     * Изменить данные пользователя по его логину.
     *
     * @param login email для входа
     * @param fio   ФИО в соответствующем порядке
     * @return код ответа
     */
    public String setUserData(String login, String... fio) {
        String orig = micronautHttpClient.authorizedJsonGet("/api/users/" + getUserIdByEmail(login), getAuthTokenAdmin());
        String json = JsonPath.using(configuration).parse(orig)
                .set("$.fullname.firstname", fio[1])
                .set("$.fullname.lastname", fio[0])
                .set("$.fullname.middlename", fio[2])
                .json().toString();
        return micronautHttpClient.authorizedJsonPutReturnCode("api/users/" + getUserIdByEmail(login), json, getAuthTokenAdmin());
    }

    public void createApplication(String sectionName, String appName) {
        String json = JsonPath.using(configuration).parse(CREATE_APP_JSON_BODY)
                .set("$.name", appName)
                .set("$.elementName", appName)
                .set("$.code", appName.toLowerCase(Locale.ROOT))
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.pageData.widgets[0].data.namespaceCode", sectionName.toLowerCase(Locale.ROOT))
                .set("$.pageData.widgets[0].data.pageCode", appName.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/apps", json, getAuthTokenAdmin());
    }

    /**
     * Изменить поля приложения
     *
     * @param sectionName - имя раздела
     * @param appName     - имя приложения
     * @param body        - тело запроса
     */
    public void updateApplicationFields(String sectionName, String appName, String body) {
        micronautHttpClient.authorizedJsonPutReturnCode("/api/apps/" + sectionName.toLowerCase(Locale.ROOT) + "/"
                + appName.toLowerCase(Locale.ROOT) + "/fields", body, getAuthTokenAdmin());
    }

    public String createPage(String sectionName, String pageName) {
        String json = JsonPath.using(configuration).parse(CREATE_PAGE_JSON_BODY)
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.name", pageName)
                .set("$.code", pageName.toLowerCase(Locale.ROOT))
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/pages", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String lockWidget(String pageID) {
        String response = micronautHttpClient.authorizedJsonPost("/api/widgets/" + pageID + "/lock", EMPTY_JSON, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("hash").toString().replace("\"", "");
    }

    public void unlockWidget(String pageID, String lockHashHeader) {
        micronautHttpClient.authorizedLockHashJsonDeleteReturnCode("/api/widgets/" + pageID + "/lock", lockHashHeader, getAuthTokenAdmin());
    }

    public void createPreparedWidgetPage(String sectionName, String pageName) {
        String widgetPageID = createPageWidget(sectionName, pageName);
        String lockHash = lockWidget(widgetPageID);
        micronautHttpClient.authorizedLockHashJsonPut("/api/widgets/" + widgetPageID, lockHash, PREPARE_WIDGET_PAGE, getAuthTokenAdmin());
        unlockWidget(widgetPageID, lockHash);
    }

    public void createPreparedWidgetPageWithStringContext(String sectionName, String pageName, String serverScript) {
        String json = JsonPath.using(configuration).parse(PREPARE_WIDGET_PAGE_WITH_CONTEXT)
                .set("$.descriptor.serverScripts", serverScript)
                .json().toString();
        String widgetPageID = createPageWidget(sectionName, pageName);
        String lockHash = lockWidget(widgetPageID);
        micronautHttpClient.authorizedLockHashJsonPut("/api/widgets/" + widgetPageID, lockHash, json, getAuthTokenAdmin());
        unlockWidget(widgetPageID, lockHash);
    }

    public void createSection(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_SECTION_JSON_BODY)
                .set("$.name", name)
                .set("$.code", name.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/pages", json, getAuthTokenAdmin());
    }

    /**
     * Создаёт раздел только если нет раздела с таким именем
     *
     * @param name - имя раздела.
     */
    public void createSectionIfNotExists(String name) {
        String total = JsonPath.using(configuration)
                .parse(micronautHttpClient.authorizedJsonGet("api/pages?q="
                        + URLEncoder.encode(String.format("{\"eq\":[{\"field\":\"name\"},{\"const\":\"%s\"}]}", name),
                        StandardCharsets.UTF_8), getAuthTokenAdmin()))
                .read("$.total").toString();
        if (total.equals("0")) {
            String json = JsonPath.using(configuration).parse(CREATE_SECTION_JSON_BODY)
                    .set("$.name", name)
                    .set("$.code", name.toLowerCase(Locale.ROOT))
                    .json().toString();
            micronautHttpClient.authorizedJsonPost("/api/pages", json, getAuthTokenAdmin());
        }
    }

    public String createElement(String name, String sectionName, String appName) {
        String json = JsonPath.using(configuration).parse(CREATE_APP_ELEMENT_JSON_BODY)
                .set("$.payload.__name", name)
                .json().toString();
        String url = "/api/apps/" + sectionName.toLowerCase() + "/" + appName.toLowerCase() + "/items";
        String response = micronautHttpClient.authorizedJsonPost(url, json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createElementWithDirectory(String name, String sectionName, String appName, String directoryId) {
        String json = JsonPath.using(configuration).parse(CREATE_APP_ELEMENT_WITH_DIRECTORY_JSON_BODY)
                .set("$.payload.__directory", directoryId)
                .set("$.payload.__name", name)
                .json().toString();
        String url = "/api/apps/" + sectionName.toLowerCase() + "/" + appName.toLowerCase() + "/items";
        String response = micronautHttpClient.authorizedJsonPost(url, json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public void createPublicApiTokenForAdmin(String nameToken) {
        String json = String.format("""
                        {
                            "__name": "%s",
                            "userId": "%s"
                        }""",
                nameToken, getUserIdByEmail(adminLogin));
        micronautHttpClient.authorizedJsonPost("/api/token", json, getAuthTokenAdmin());
    }

    /**
     * Отправляет кучу полей при создании статусов, нужен в догонку к методу createAppStatuses
     *
     * @param section Секция приложения;
     * @param app     Название приложения;
     */
    private void setStatusFields(String section, String app) {
        String url = "/api/apps/" + section.toLowerCase(Locale.ROOT) +
                "/" + app.toLowerCase(Locale.ROOT) + "/fields";
        micronautHttpClient.authorizedJsonPut(url, PROCESS_WITH_STATUS_FIELDS, getAuthTokenAdmin());
    }

    /**
     * Получает id элемента приложения по его имени(имена должны быть уникальны)
     *
     * @param sectionName Секция приложения;
     * @param appName     Название приложения;
     * @param elementName Название элемента;
     */
    public String getElementIdByName(String sectionName, String appName, String elementName) {
        String url = "/api/apps/" + sectionName.toLowerCase(Locale.ROOT) + "/" + appName.toLowerCase(Locale.ROOT)
                + "/items?from=0&size=10&q=&withPerms=true&sortField=__createdAt&ascending=false&active=true";
        String responseBody = micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
        JsonObject allObject = JsonParser.parseString(responseBody).getAsJsonObject();
        JsonArray userArray = allObject.get("result").getAsJsonArray();
        for (int i = 0; i < userArray.size(); i++) {
            JsonObject getUser = userArray.get(i).getAsJsonObject();
            String userEmail = getUser.get("__name").toString().replace("\"", "");
            if (userEmail.equals(elementName)) {
                return getUser.get("__id").toString().replace("\"", "");
            }
        }
        return null;
    }

    /**
     * Получает текущее время и дату в формате yyyy-MM-dd'T'HH:mm:ss по гринвичу, округлённое до секунд вверх.
     */
    public String getDateAndTime() {
        return ZonedDateTime.now(ZoneId.of("UTC")).plusSeconds(1).format(ofPattern("yyyy-MM-dd'T'HH:mm:ss"));
    }

    /**
     * Отправляет текущие и будущие замещения в архив.
     */
    public void deleteComingAndActiveSubstitutions() {
        interruptActiveSubstitutions();
        deleteComingSubstitutions();
        sleep(SECONDS_5);
        if (getCurrentSubstitutionCount() != 0)
            CONSOLE.error("Не удалось удалить текущее замещение");
        if (getComingSubstitutionCount() != 0)
            CONSOLE.error("Не удалось удалить текущее замещение");
    }

    /**
     * Возвращает тело ответа на запрос получения текущих замещений.
     */
    public JsonObject getActiveSubstitutionsResponse() {
        String activeQuery = URLEncoder.encode(String.format(
                "{\"and\":[{\"lte\":[{\"field\":\"begin\"},{\"const\":\"%1$sZ\"}]},{\"gte\":[{\"field\":\"end\"},{\"const\":\"%1$sZ\"}]}]}",
                getDateAndTime()), StandardCharsets.UTF_8);
        return JsonParser.parseString(micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&q="
                + activeQuery + "&orderBy=deletedAt&asc=true", getAuthTokenAdmin())).getAsJsonObject();
    }

    /**
     * Прерывает текущие замещения.
     */
    public void interruptActiveSubstitutions() {
        int breakPoint = 0; // страховка от бесконечного цикла при баге.
        while (getActiveSubstitutionsResponse().get("total").getAsInt() != 0 && breakPoint < 10) {
            sleep(SECONDS_1);
            breakPoint++;
            JsonObject targetSubstitution = getActiveSubstitutionsResponse().get("result").getAsJsonArray()
                    .get(0).getAsJsonObject();
            String id = targetSubstitution.get("__id").toString().replace("\"", "");
            if (!targetSubstitution.has("deletedAt")) {
                micronautHttpClient.authorizedJsonPost("api/auth/substitutions/"
                        + id + "/interrupt", EMPTY_JSON, getAuthTokenAdmin());
            }
            if (breakPoint == 10) {
                CONSOLE.error("Цикл удаления текущих замещений прерван по достижению предела количества исполнений");
            }
        }
    }

    /**
     * Удаляет будущие замещения.
     * Будущими считаются лишь те замещения, которые начнутся не менее, чем через минуту.
     * Добавлено это ограничение из-за проблемы при запуске через CI:
     * Только что запущенное текущее замещение может попасть в список будущих,
     * что вызывает ошибку удаления замещения {"*":"Замещение вступило в действие и не может быть удалено"}
     */
    public void deleteComingSubstitutions() {
        String comingQuery = URLEncoder.encode(String.format(
                "{\"gt\":[{\"field\":\"begin\"},{\"const\":\"%sZ\"}]}", ZonedDateTime.now(ZoneId.of("GMT"))
                        .plusMinutes(1).format(ofPattern("yyyy-MM-dd'T'HH:mm:ss"))), StandardCharsets.UTF_8);
        String responseBodyComing = micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&orderBy=deletedAt&asc=true&q="
                + comingQuery, getAuthTokenAdmin());
        JsonParser.parseString(responseBodyComing).getAsJsonObject().get("result").getAsJsonArray()
                .iterator().forEachRemaining((obj) -> {
                    JsonObject object = obj.getAsJsonObject();
                    if (!object.has("__deletedAt")) {
                        micronautHttpClient.authorizedJsonDelete("api/auth/substitutions/"
                                + object.get("__id").toString().replace("\"", ""), getAuthTokenAdmin());
                    }
                });
        sleep(SECONDS_1);
        responseBodyComing = micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&q="
                + comingQuery + "&orderBy=deletedAt&asc=true", getAuthTokenAdmin());
        if (JsonParser.parseString(responseBodyComing).getAsJsonObject().get("total").getAsInt() != 0) {
            CONSOLE.info("При попытке удаления остались будущие замещения");
        }
    }

    /**
     * Создает замещение
     *
     * @param type  - тип замещения
     * @param begin - Дата начала замещения
     * @param end   - Дата конца замещения
     */
    public void createPublicApiSubstitutionEmployees(SubstitutionType type, LocalDateTime begin, LocalDateTime end) {
        DateTimeFormatter format = ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
        String json = format("""
                        {
                            "type": %s,
                            "absent": "%s",
                            "replacement": "%s",
                            "begin": "%sZ",
                            "end": "%sZ",
                            "reassignTasksOnStart": false,
                            "reassignTasksOnEnd": false
                        }""", type.toString(), getUserIdByEmail(userLogin),
                getUserIdByEmail(adminLogin), begin.format(format), end.format(format));

        micronautHttpClient.authorizedJsonPost("api/auth/substitutions", json, getAuthTokenAdmin());
    }

    /**
     * @return - Количество всех замещений
     */
    public int getAllSubstitutionCount() {
        String responseBody = micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&q&orderBy&asc=true", getAuthTokenAdmin());
        return Integer.parseInt(JsonParser.parseString(responseBody).getAsJsonObject().get("total").toString());
    }

    /**
     * @return - Количество текущих и будущих замещений
     */
    public int getCurrentAndComingSubstitutionCount() {
        String query = URLEncoder.encode(String.format("{\"or\":[{\"and\":[{\"lte\":[{\"field\":\"begin\"},{\"const\":\"%1$s\"}]},{\"gte\":[{\"field\":\"end\"}," +
                "{\"const\":\"%1$s\"}]}]},{\"gt\":[{\"field\":\"begin\"},{\"const\":\"%1$s\"}]}]}", getDateAndTime()), StandardCharsets.UTF_8);
        String responseBody = micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&q=" + query, getAuthTokenAdmin());
        return Integer.parseInt(JsonParser.parseString(responseBody).getAsJsonObject().get("total").toString());
    }

    /**
     * @return - Количество текущих замещений
     */
    public int getCurrentSubstitutionCount() {
        String query = URLEncoder.encode(String.format("{\"and\":[{\"lte\":[{\"field\":\"begin\"},{\"const\"" +
                        ":\"%1$sZ\"}]},{\"gte\":[{\"field\":\"end\"},{\"const\":\"%1$sZ\"}]}]}",
                getDateAndTime()), StandardCharsets.UTF_8);
        String responseBody = micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&q="
                + query + "&orderBy=deletedAt&asc=true", getAuthTokenAdmin());
        return Integer.parseInt(JsonParser.parseString(responseBody).getAsJsonObject().get("total").toString());
    }

    /**
     * @return - Количество будущих замещений
     */
    public int getComingSubstitutionCount() {
        String query = URLEncoder.encode(String.format("{\"gt\":[{\"field\":\"begin\"},{\"const\":\"%sZ\"}]}", ZonedDateTime.now(ZoneId.of("GMT"))
                .plusMinutes(1).format(ofPattern("yyyy-MM-dd'T'HH:mm:ss"))), StandardCharsets.UTF_8);
        String responseBody = micronautHttpClient.authorizedJsonGet("api/auth/substitutions?offset=0&limit=100&q="
                + query + "&orderBy=deletedAt&asc=true", getAuthTokenAdmin());
        return Integer.parseInt(JsonParser.parseString(responseBody).getAsJsonObject().get("total").toString());
    }


    public String getUserSurnameAndNameByEmail(String email) {
        JsonObject json = getUserJsonByEmail(email);
        Assertions.assertNotNull(json);
        JsonObject userFullName = json.getAsJsonObject("fullname");
        String name = userFullName.get("firstname").toString().replace("\"", "");
        String surname = userFullName.get("lastname").toString().replace("\"", "");
        if (name.length() == 0 && surname.length() == 0)
            return email;
        return surname + " " + name;
    }

    public String getUserIdByEmail(String email) {
        JsonObject json = getUserJsonByEmail(email);
        Assertions.assertNotNull(json);
        return json.get("__id").toString().replace("\"", "");
    }

    public String getUserFIOByEmail(String email) {
        JsonObject json = getUserJsonByEmail(email);
        Assertions.assertNotNull(json);
        return json.get("__name").toString().replace("\"", "");
    }

    public String getUserInfoById(String userId) {
        return micronautHttpClient.authorizedJsonGet("/api/users/" + userId, getAuthTokenAdmin());
    }

    public void setUserOnPositionByUserId(String userId, String positionId) {
        JsonObject jsonObject = JsonParser.parseString(getUserInfoById(userId)).getAsJsonObject();
        JsonElement positionString = jsonObject.get("osIds");
        JsonArray array = new JsonArray();
        if ((!positionString.isJsonNull()) && (array.size() != 0)) {
            array = positionString.getAsJsonArray();
            for (int i = 0; i <= array.size(); i++)
                array.remove(i);
        }
        array.add(positionId);
        jsonObject.add("osIds", array);
        micronautHttpClient.authorizedJsonPut("/api/users/" + userId, jsonObject.toString(), getAuthTokenAdmin());
    }

    /**
     * Метод проверки соответствия статуса пользователя
     *
     * @param email                - email пользователя
     * @param expectedStatusNumber - номер ожидаемого статуса (2 - 'Разблокированный', 3 - 'Блокированный'
     * @return true, если статус пользователя соответсвует ожидаемому, false - если иной
     */
    public boolean isUserWithStatusExists(String email, int expectedStatusNumber) {
        Set<String> coincidences = new HashSet<>();
        // получение только пользователей с ожидаемым статусом
        String query = URLEncoder.encode("{\"and\":[{\"tf\":{\"__status\":[" + expectedStatusNumber + ",0]}}]}", StandardCharsets.UTF_8);
        String response = micronautHttpClient.authorizedJsonGet("/api/auth/users?offset=0&limit=100&orderBy=__name&asc=true&q=" + query, getAuthTokenAdmin());
        JsonArray usersList = JsonParser.parseString(response).getAsJsonObject().get("result").getAsJsonArray();
        usersList.iterator().forEachRemaining((obj) -> {
            JsonObject object = obj.getAsJsonObject();
            if (object.get("email").toString().replace("\"", "").equals(email)) {
                coincidences.add(object.get("email").toString().replace("\"", ""));
            }
        });
        return coincidences.contains(email);
    }

    /**
     * Изменить статус пользователя
     *
     * @param email                - email пользователя
     * @param expectedStatusNumber - номер ожидаемого статуса (2 - 'Разблокированный', 3 - 'Блокированный'
     * @param statusUser           - Изменить статус пользователя ( 'block' - Заблокировать, 'unblock' - Разблокировать
     */
    public void changeUserStatus(String email, int expectedStatusNumber, String statusUser) {
        if (isUserWithStatusExists(email, expectedStatusNumber)) {
            micronautHttpClient.authorizedJsonPostReturnCode("/api/users/" + getUserIdByEmail(email)
                    + "/" + statusUser, "", getAuthTokenAdmin());
        }
    }

    /**
     * Метод создания трёх тестовых параметров на уровне компании для теста отображения параметров
     */
    public void createCompanyParametersTestData() {
        micronautHttpClient.authorizedJsonPutReturnCode("/api/settings/namespace/global", PUT_THREE_TEST_COMPANY_PARAMETERS, getAuthTokenAdmin());
    }

    public void createUserWidgetWithTab(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_USER_WIDGET_WITH_TABS)
                .set("$.code", name.toLowerCase(Locale.ROOT))
                .set("$.__name", name)
                .set("$.descriptor.code", "global@" + name.toLowerCase(Locale.ROOT))
                .set("$.descriptor.template.content.[''].[0].content.[''].[0].values.title", name)
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/widgets/create", json, getAuthTokenAdmin());
    }

    public void createEmptyUserWidget(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_EMPTY_USER_WIDGET)
                .set("$.code", name.toLowerCase(Locale.ROOT))
                .set("$.__name", name)
                .set("$.descriptor.code", "global@" + name.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/widgets/create", json, getAuthTokenAdmin());
    }

    public void createStringParameterInSection(String sectionName, String parameterName) {
        String json = JsonPath.using(configuration).parse(PUT_SECTION_PARAMETER_JSON_BODY)
                .set("$.fields[0].view.name", parameterName)
                .set("$.fields[0].code", parameterName.toLowerCase(Locale.ROOT))
                .set("$.fields[0].data.ns", sectionName.toLowerCase(Locale.ROOT))
                .set("$.values.test", sectionName + "." + parameterName)
                .json().toString();
        micronautHttpClient.authorizedJsonPutReturnCode("/api/settings/namespace/"
                + sectionName.toLowerCase(Locale.ROOT), json, getAuthTokenAdmin());
    }

    public String createPageWidget(String namespaceCode, String namePage) {
        String json = JsonPath.using(configuration).parse(CREATE_WIDGET_PAGE)
                .set("$.namespace", namespaceCode.toLowerCase(Locale.ROOT) + "." + namePage.toLowerCase(Locale.ROOT))
                .set("$.__name", namePage)
                .set("$.descriptor.code", namespaceCode.toLowerCase(Locale.ROOT) + "." + namePage.toLowerCase(Locale.ROOT) + "@_page")
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/widgets/create", json, getAuthTokenAdmin());
        JsonObject object = JsonParser.parseString(response).getAsJsonObject();
        return object.get("__id").getAsString().replace("\"", "");
    }

    public void createPlaceOfRegistration(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_PLACE_OF_REGISTRATION)
                .set("$.__name", name)
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("/api/docflow/nomenclature/dir/add", json, getAuthTokenAdmin());
    }

    public void createApplicationDocumentType(String sectionName, String appName) {
        String json = JsonPath.using(configuration).parse(CREATE_APP_DOCUMENT_TYPE_JSON_BODY)
                .set("$.name", appName)
                .set("$.elementName", appName)
                .set("$.code", appName.toLowerCase(Locale.ROOT))
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.pageData.widgets[0].data.namespaceCode", sectionName.toLowerCase(Locale.ROOT))
                .set("$.pageData.widgets[0].data.pageCode", appName.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/apps", json, getAuthTokenAdmin());
    }

    /**
     * Создания Исключение рабочего календаря
     *
     * @param exclusionDate - дата начала исключения
     */
    public void createExclusionWorkCalendar(LocalDate exclusionDate) {
        String json = format("""
                {
                    "specialDays": [
                        {
                            "date": %s,
                            "holiday": false,
                            "from": 32400,
                            "to": 64800
                        }
                    ]
                }  \s""", convertDateToUnix(exclusionDate));
        micronautHttpClient.authorizedJsonPut("/api/scheduler/specialDays", json, getAuthTokenAdmin());
    }

    /**
     * Убирает все дни исключения
     */
    public void deleteExclusionWorkCalendar() {
        micronautHttpClient.authorizedJsonPut("/api/scheduler/specialDays", "{\"specialDays\":[]}", getAuthTokenAdmin());
    }

    public String getExclusionWorkCalendar() {
        String response = micronautHttpClient.authorizedJsonGet("/api/scheduler/specialDays", getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("specialDays").toString().replace("\"", "");
    }

    /**
     * Получить данные 'Дня исключения'
     *
     * @param value - значения ('holiday' - выходной день, 'date' - дата, 'from' - время начала, 'to' - время окончания)
     * @return - указанное значение
     */
    public String getSpecialDaysData(String value) {
        String response = micronautHttpClient.authorizedJsonGet("/api/scheduler/specialDays", getAuthTokenAdmin());
        JsonObject allObject = JsonParser.parseString(response).getAsJsonObject();
        JsonArray userArray = allObject.get("specialDays").getAsJsonArray();
        JsonObject getDate = userArray.get(0).getAsJsonObject();
        return getDate.get(value).toString().replace("\"", "");
    }

    /**
     * @param dayOfWeek - день недели на англ языке ('friday' - пятница)
     * @return - значение указанного дня недели ('true' - выходной день, 'false' - рабочий день)
     */
    public String getWeekendsWorkCalendar(String dayOfWeek) {
        String response = micronautHttpClient.authorizedJsonGet("api/scheduler/general", getAuthTokenAdmin());
        JsonObject allObject = JsonParser.parseString(response).getAsJsonObject();
        JsonObject object = JsonParser.parseString(allObject.get("weekends").toString()).getAsJsonObject();
        return object.get(dayOfWeek).toString().replace("\"", "");
    }

    /**
     * @param daySchedule - Распорядок дня ('workingTime' - рабочее время, 'lunchTime' - обеденный перерыв)
     * @param fromOrTo    - Начало или конец('for'- начало, 'to'- конец)
     * @return - значение в формате unix epoch
     */
    public String getDayScheduleCalendarWorkTime(String daySchedule, String fromOrTo) {
        String response = micronautHttpClient.authorizedJsonGet("api/scheduler/general", getAuthTokenAdmin());
        JsonObject allObject = JsonParser.parseString(response).getAsJsonObject();
        JsonObject object = JsonParser.parseString(allObject.get("daySchedule").toString()).getAsJsonObject();
        JsonObject objectDatSchedule = JsonParser.parseString(object.get(daySchedule).toString()).getAsJsonObject();
        return objectDatSchedule.get(fromOrTo).toString();
    }

    /**
     * Распорядок дня по умолчанию
     */
    public void defaultWorkCalendar() {
        String json = "{\"daySchedule\":{\"workingTime\":{\"from\":32400,\"to\":64800},\"lunchTime\":{\"from\":43200,\"to\":46800}},\"weekends\":{\"friday\":false,\"monday\":false,\"saturday\":true,\"sunday\":true,\"thursday\":false,\"tuesday\":false,\"wednesday\":false}}";
        micronautHttpClient.authorizedJsonPut("api/scheduler/general", json, getAuthTokenAdmin());
    }

    /**
     * Создать роль пользователя в разделе бокового тулбара.
     */
    public void createRoleInSection(String groupName, String sectionName) {
        String UserId = getUserIdByEmail(userLogin);
        String json = JsonPath.using(configuration).parse(CREATE_ROLE_COMPANY_JSON_BODY)
                .set("$.__name", groupName)
                .set("$.subOrgunitIds[0]", UserId)
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
    }

    /**
     * Создать группу пользователей в разделе бокового тулбара.
     */
    public void createGroupInSection(String groupName, String sectionName) {
        String UserId = getUserIdByEmail(userLogin);
        String json = JsonPath.using(configuration).parse(CREATE_GROUP_COMPANY_JSON_BODY)
                .set("$.__name", groupName)
                .set("$.subOrgunitIds[0]", UserId)
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/groups", json, getAuthTokenAdmin());
    }

    /**
     * В разделе “Файлы” в папке “Мои файлы” создать новую папку
     *
     * @param nameFolder - Название новой папки
     * @param login      - Пользователь, которому будет создана папку
     * @return - Id созданной папки
     */
    public String createFolderInMyFilePageByUserLogin(String nameFolder, String login) {
        String userId = getUserIdByEmail(login);
        String json = String.format("{\"__name\":\"%s\",\"directory\":\"%s\"}", nameFolder, userId);
        String response = micronautHttpClient.authorizedJsonPut("api/disk/directories", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать папку в папке.
     *
     * @param nameFolder   - Название новой папки
     * @param parentFolder - Папка, в которой нужно создать папку
     * @return - Id созданной папки
     */
    public String createFolderInFolder(String nameFolder, String parentFolder) {
        String json = String.format("{\"__name\":\"%s\",\"directory\":\"%s\"}", nameFolder, parentFolder);
        String response = micronautHttpClient.authorizedJsonPut("api/disk/directories", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Включить иерархический справочник приложения
     *
     * @param sectionName - имя секции
     * @param appName     - имя приложения
     */
    public void enableHierarchicalDirectoryOfApplication(String sectionName, String appName) {
        micronautHttpClient.authorizedJsonPut(format("api/apps/%s/%s/settings", sectionName, appName).toLowerCase(Locale.ROOT),
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/EnableHierarchicalDirectoryOfApplication.json")
                        .buildAndGetAsString(), getAuthTokenAdmin());
    }

    /**
     * Создать папку в иерархическом справочнике
     *
     * @param sectionName - имя секции
     * @param appName     - имя приложения
     * @param id          - id директории
     * @param name        - имя директории
     */
    public void createFolderInHierarchicalDirectory(String sectionName, String appName, String id, String name) {
        micronautHttpClient.authorizedJsonPostReturnCode(format("api/apps/%s/%s/directories", sectionName, appName).toLowerCase(Locale.ROOT),
                JsonPath.using(configuration).parse(CREATE_FOLDER_IN_HIERARCHICAL_DIRECTORY)
                        .set("$.id", id)
                        .set("$.name", name)
                        .json().toString(),
                getAuthTokenAdmin());
    }

    /**
     * Создать элемент приложения в папке
     *
     * @param sectionName - имя секции
     * @param appName     - имя приложения
     * @param idAppItem   - id элемента приложения
     * @param nameAppItem - имя элемента приложения
     * @param idDirectory - id директории
     */
    public void createAppItemInFolder(String sectionName, String appName, String idAppItem, String nameAppItem, String idDirectory) {
        micronautHttpClient.authorizedJsonPostReturnCode(format("api/apps/%s/%s/items", sectionName, appName).toLowerCase(Locale.ROOT),
                JsonPath.using(configuration).parse(CREATE_APP_ITEM_IN_FOLDER)
                        .set("$.payload.__id", idAppItem)
                        .set("$.payload.__directory", idDirectory)
                        .set("$.payload.__name", nameAppItem)
                        .json().toString(),
                getAuthTokenAdmin());
    }

    public void createDirectoryApp(String sectionName, String appName, String uuid, String directoryName) {
        String json = JsonPath.using(configuration).parse(CREATE_DIRECTORY_APP)
                .set("$.id", uuid)
                .set("$.name", directoryName)
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("/api/apps/" + sectionName.toLowerCase(Locale.ROOT) + "/" + appName.toLowerCase(Locale.ROOT) + "/directories", json, getAuthTokenAdmin());
    }

    public void enableDigitalSign() {
        micronautHttpClient.authorizedJsonPutReturnCode("/api/picasso/provider/system.__digital_sign_provider/NUC", """
                {
                    "enabled": true
                }""", getAuthTokenAdmin());
    }

    public void createFolderInCompanyProcesses(String folderName) {
        String json = String.format("""
                {
                    "__name": "%s",
                    "category": "00000000-0000-0000-0000-000000000000",
                    "namespace": "global",
                    "page": false
                }""", folderName);
        micronautHttpClient.authorizedJsonPost("/api/bpm/categories", json, getAuthTokenAdmin());
    }

    public String getSectionIdByName(String sectionName) {
        String query = URLEncoder.encode(String.format("{\"and\":[{\"tf\":{\"name\":\"%s\"}}]}", sectionName), StandardCharsets.UTF_8);
        String url = "/api/pages?from=0&size=1000&q=" + query;
        String responseBody = micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
        JsonArray userArray = JsonParser.parseString(responseBody).getAsJsonObject().get("result").getAsJsonArray();
        for (int i = 0; i < userArray.size(); i++) {
            JsonObject getSection = userArray.get(i).getAsJsonObject();
            String getSectionName = getSection.get("name").toString().replace("\"", "");
            if (getSectionName.equals(sectionName)) {
                return getSection.get("__id").toString().replace("\"", "");
            }
        }
        return null;
    }

    public void setDefaultAccessForSection(String sectionId) {
        String json = "{\"values\":[{\"types\":[\"read\"],\"group\":{\"id\":\"fda5c295-230a-5025-9797-b8b4e99e08aa\",\"type\":\"group\"},\"inherited\":false}],\"timestamp\":0,\"inheritParent\":false}";
        micronautHttpClient.authorizedJsonPut("api/pages/" + sectionId + "/permissions", json, getAuthTokenAdmin());
    }

    public void createSerialNumForNomenclature(String serialID, String name) {
        String json = JsonPath.using(configuration).parse(CREATE_SERIAL_NUM_FOR_NOMENCLATURE)
                .set("$.code", serialID)
                .set("$.name", name)
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("/api/serial/nomenclature", json, getAuthTokenAdmin());
    }

    public void createDossierNomenclature(String dossierName, String placeRegID, String serialID, boolean reserveEnabled) {
        String json = JsonPath.using(configuration).parse(CREATE_DOSSIER_NOMENCLATURE)
                .set("$.__id", RandomString.getUUID())
                .set("$.__name", dossierName)
                .set("$.directory", placeRegID)
                .set("$.serialId", serialID)
                .set("$.registrationSettings.reserveEnabled", reserveEnabled)
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("/api/docflow/nomenclature/add", json, getAuthTokenAdmin());
    }

    public void createDossierNomenclature(String dossierName, String placeRegID, String serialID) {
        createDossierNomenclature(dossierName, placeRegID, serialID, false);
    }

    public String getPlaceRegistrationIdByName(String placeName) {
        String query = URLEncoder.encode(String.format("{\"eq\":[{\"field\":\"__name\"},{\"const\":\"%s\"}]}", placeName), StandardCharsets.UTF_8);
        String url = "/api/docflow/nomenclature/dir/list?permission=false&q=" + query;
        String responseBody = micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
        JsonArray userArray = JsonParser.parseString(responseBody).getAsJsonArray();
        for (int i = 0; i < userArray.size(); i++) {
            JsonObject getUser = userArray.get(i).getAsJsonObject();
            String userEmail = getUser.get("__name").toString().replace("\"", "");
            if (userEmail.equals(placeName)) {
                return getUser.get("__id").toString().replace("\"", "");
            }
        }
        return null;
    }

    public String getIdFolderFileCompany() {
        String url = "/api/disk/directories/00000000-0000-0000-0000-000000000000/directories";
        String responseBody = micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
        JsonArray userArray = JsonParser.parseString(responseBody).getAsJsonObject().get("result").getAsJsonArray();
        for (int i = 0; i < userArray.size(); i++) {
            JsonObject getFolder = userArray.get(i).getAsJsonObject();
            String folder = getFolder.get("__name").toString().replace("\"", "");
            if (folder.equals("shared")) {
                return getFolder.get("__id").toString().replace("\"", "");
            }
        }
        return null;
    }

    public void createFileInFolderCompany(String fileName) {
        String json = JsonPath.using(configuration).parse(CREATE_FILE_IN_FOLDER)
                .set("$.__name", fileName)
                .set("$.originalName", fileName)
                .set("$.directory", getIdFolderFileCompany())
                .json().toString();
        micronautHttpClient.authorizedJsonPut("/api/disk/files", json, getAuthTokenAdmin());
    }

    public void createFileInFolderById(String fileName, String folderId) {
        String json = JsonPath.using(configuration).parse(CREATE_FILE_IN_FOLDER)
                .set("$.__name", fileName)
                .set("$.originalName", fileName)
                .set("$.directory", folderId)
                .json().toString();
        micronautHttpClient.authorizedJsonPut("/api/disk/files", json, getAuthTokenAdmin());
    }

    public String createContract(String sectionName, String ContractName) {
        String json = JsonPath.using(configuration).parse(CREATE_CONTRACT_JSON_BODY)
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.name", ContractName)
                .set("$.code", ContractName.toLowerCase(Locale.ROOT))
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/pages", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String setDefaultSettingContract(String sectionName, String contractName) {
        String json = JsonPath.using(configuration).parse(SET_DEFAULT_SETTING_CONTRACT_JSON_BODY)
                .set("$.view.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.view.name", contractName)
                .set("$.view.code", contractName.toLowerCase(Locale.ROOT))
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/contractor", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String setAppSourceContract(String sectionName, String appName, String contractName) {
        String json = JsonPath.using(configuration).parse(SET_APP_SOURCE_CONTRACT_JSON_BODY)
                .set("$.sources[0].contractCode", contractName.toLowerCase(Locale.ROOT))
                .set("$.sources[0].contractNamespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.sources[0].sourceCode", appName.toLowerCase(Locale.ROOT))
                .set("$.sources[0].sourceNamespace", sectionName.toLowerCase(Locale.ROOT))
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/contractor/" + sectionName.toLowerCase(Locale.ROOT) + "/" + contractName.toLowerCase(Locale.ROOT) + "/sources", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonArray().get(0).getAsJsonObject();
        return jsonObject.get("id").toString().replace("\"", "");
    }

    /**
     * Настройки “Использование Office 365”
     *
     * @param value - true (Включить), false (Выключить)
     */
    public void settingUsingOffice365(boolean value) {
        String json = JsonPath.using(configuration).parse(SETTING_USING_OFFICE_365)
                .set("$.value", value)
                .json().toString();
        micronautHttpClient.authorizedJsonPutReturnCode("/api/settings/global", json, getAuthTokenAdmin());
    }

    /**
     * Добавить кнопку "Запуск процесса" на страницу приложения с привязкой к Бизнес Процессу
     *
     * @param sectionName - имя секции
     * @param appName     - имя приложения
     * @param processName - имя бизнес процесса
     */
    public void addProcessStartButtonToApplicationPage(String sectionName, String appName, String processName) {
        String json = JsonPath.using(configuration).parse(ADD_PROCESS_START_BUTTON_TO_APP)
                .set("$.listSettings.buttons[1].processNamespace", sectionName.toLowerCase(Locale.ROOT) + "." + appName.toLowerCase(Locale.ROOT))
                .set("$.listSettings.buttons[1].processCode", processName.toLowerCase(Locale.ROOT))
                .set("$.listSettings.buttons[1].processField", appName.toLowerCase(Locale.ROOT))
                .json().toString();
        micronautHttpClient.authorizedJsonPut(format("api/apps/%s/%s/settings", sectionName, appName).toLowerCase(Locale.ROOT), json, getAuthTokenAdmin());
    }

    /**
     * Отправить элемент приложения на согласование
     */
    public void sendApplicationElementForApproval(String sectionName, String appName, String idElementApp, String idRespondent) {
        String json = JsonPath.using(configuration).parse(SEND_APP_ELEMENT_FOR_APPROVAL)
                .set("$.approval_object.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.approval_object.code", appName.toLowerCase(Locale.ROOT))
                .set("$.approval_object.id", idElementApp)
                .set("$.respondents[0]", idRespondent)
                .set("$[\"system._process_approval.respondents\"][0]", idRespondent)
                .json().toString();
        micronautHttpClient.authorizedJsonPutReturnCode("/api/bpm/templates/public/" + idOfApprovalSystemProcess() + "/8/run", json, getAuthTokenAdmin());
    }

    /**
     * Отправить элемент приложения на ознакомления
     */
    public void sendApplicationElementForFamiliarization(String sectionName, String appName, String idElementApp, String idReceivers) {
        String json = JsonPath.using(configuration).parse(SEND_APP_ELEMENT_FOR_FAMILIARIZATION)
                .set("$.inform_object.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.inform_object.code", appName.toLowerCase(Locale.ROOT))
                .set("$.inform_object.id", idElementApp)
                .set("$.receivers[0]", idReceivers)
                .set("$[\"system._process_inform.receivers\"][0]", idReceivers)
                .json().toString();
        micronautHttpClient.authorizedJsonPutReturnCode("/api/bpm/templates/public/" + idOfFamiliarizationSystemProcess() + "/7/run", json, getAuthTokenAdmin());
    }

    /**
     * @return - id системного процесса Согласования
     */
    public String idOfApprovalSystemProcess() {
        String responseBody = micronautHttpClient.authorizedJsonGet("/api/bpm/templates/public/byCode/system/approval", getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(responseBody).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * @return - id системного процесса Ознакомления
     */
    public String idOfFamiliarizationSystemProcess() {
        String responseBody = micronautHttpClient.authorizedJsonGet("/api/bpm/templates/public/byCode/system/inform", getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(responseBody).getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }
}