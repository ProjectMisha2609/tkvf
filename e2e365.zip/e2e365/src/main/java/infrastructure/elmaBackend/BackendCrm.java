package infrastructure.elmaBackend;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;
import infrastructure.helpers.MicronautHttpClient;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.List;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.CREATE_PROJECT_JSON_BODY;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.CrmJsonBodies.*;

/**
 * Класс работы с разделом CRM через API.
 */
@Singleton
public class BackendCrm extends ElmaBackend {

    @Inject
    protected MicronautHttpClient micronautHttpClient;

    public static final Integer STATUS_PROCESSED = 2;

    public void createCompany(String name, String companyId) {
        String json = JsonPath.using(configuration).parse(CREATE_COMPANY_CRM_JSON_BODY)
                .set("$.payload.__id", companyId)
                .set("$.payload.__name", name)
                .json().toString();
        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_companies/items", json, getAuthTokenAdmin());
    }

    public String createContact(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_CONTACT_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_contacts/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createContact(String name, String skype) {
        String json = JsonPath.using(configuration).parse(CREATE_CONTACT_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._skype", skype)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_contacts/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createDeal(String name) {
        String adminId = getUserIdByEmail(adminLogin);
        String json = JsonPath.using(configuration).parse(CREATE_DEAL_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._owner[0]", adminId)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_leads/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createDeal(String name, String funnelId) {
        String adminId = getUserIdByEmail(adminLogin);
        String json = JsonPath.using(configuration).parse(CREATE_DEAL_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._owner[0]", adminId)
                .set("$.tempData.statusGroupId", funnelId)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_leads/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать сделку с бюджетом
     *
     * @param dealName  - название сделки
     * @param userEmail - email пользователя
     * @param budget    - бюджет (Пример : передаваемое значение 1000 = 10,00 (10 рублей)
     * @return id сделки
     */
    public String createDealWithBudget(String dealName, String userEmail, int budget) {
        String adminId = getUserIdByEmail(userEmail);
        String json = JsonPath.using(configuration).parse(CREATE_DEAL_WITH_BUDGET_CRM_JSON_BODY)
                .set("$.payload.__name", dealName)
                .set("$.payload._owner[0]", adminId)
                .set("$.payload._budget.cents", budget)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_leads/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать сделку с бюджетом
     *
     * @param dealName       - название сделки
     * @param userEmail      - email пользователя
     * @param budget         - бюджет (Пример : передаваемое значение 1000 = 10,00 (10 рублей)
     * @param idCompany      - id компании
     * @param plannedDueDate - запланированный срок сдачи
     * @return id сделки
     */
    public String createDealWithBudget(String dealName, String userEmail, int budget, String idCompany, String plannedDueDate) {
        String adminId = getUserIdByEmail(userEmail);
        String json = JsonPath.using(configuration).parse(CREATE_DEAL_WITH_BUDGET_CRM_JSON_BODY)
                .set("$.payload.__name", dealName)
                .set("$.payload._owner[0]", adminId)
                .set("$.payload._budget.cents", budget)
                .set("$.payload._companies", List.of(idCompany))
                .set("$.payload._plannedDueDate", plannedDueDate)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_leads/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать Статью дохода
     *
     * @param itemName  - имя статьи
     * @param userEmail - email пользователя
     * @return id статьи
     */
    public String createIncomeItem(String itemName, String userEmail) {
        String adminId = getUserIdByEmail(userEmail);
        String json = JsonPath.using(configuration).parse(CREATE_INCOME_ITEM_JSON_BODY)
                .set("$.payload.__name", itemName)
                .set("$.payload._responsible[0]", adminId)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_transactions/_income_items/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать ЦФО
     *
     * @param cfoName - имя ЦФО
     * @return id ЦФО
     */
    public String createCFO(String cfoName) {
        String json = JsonPath.using(configuration).parse(CREATE_CFO_JSON_BODY)
                .set("$.payload.__name", cfoName)
                .set("$.payload._description", cfoName)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_transactions/_frc/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать плановое поступление
     *
     * @param userEmail      - email пользователя
     * @param companyId      - id компании
     * @param itemOfIncomeId - id статьи дохода
     * @param cfoId          - id ЦФO
     * @param dealId         - id сделки
     * @param plannedDueDate - планируемая дата закрытия
     */
    public String createPlannedReceipt(String userEmail, String companyId, String itemOfIncomeId, String cfoId, String dealId, String plannedDueDate) {
        String userId = getUserIdByEmail(userEmail);
        String json = JsonPath.using(configuration).parse(CREATE_PLANNED_RECEIPT_JSON_BODY)
                .set("$.payload._responsible[0]", userId)
                .set("$.payload._contractor[0]", companyId)
                .set("$.payload._plannedPaymentDate", plannedDueDate)
                .set("$.payload._incomeDistribution.rows[0]._incomeItem[0]", itemOfIncomeId)
                .set("$.payload._incomeItemsUsed[0]", itemOfIncomeId)
                .set("$.payload._incomeDistribution.rows[0]._frc[0]", cfoId)
                .set("$.payload._frcUsed[0]", cfoId)
                .set("$.payload._basis[0]", dealId)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_transactions/_income/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    /**
     * Создать фактическое поступление
     *
     * @param userEmail        - email пользователя
     * @param companyId        - id компании
     * @param itemOfIncomeId   - id статьи дохода
     * @param cfoId            - id ЦФO
     * @param dealId           - id сделки
     * @param plannedReceiptId - id плановое поступление
     */
    public void createActualReceipt(String userEmail, String companyId, String itemOfIncomeId, String cfoId, String dealId, String plannedReceiptId, String actualPaymentDate) {
        String userId = getUserIdByEmail(userEmail);
        String json = JsonPath.using(configuration).parse(CREATE_ACTUAL_RECEIPT_JSON_BODY)
                .set("$.payload._responsible[0]", userId)
                .set("$.payload._contractor[0]", companyId)
                .set("$.payload._incomeDistribution.rows[0]._incomeItem[0]", itemOfIncomeId)
                .set("$.payload._incomeItemsUsed[0]", itemOfIncomeId)
                .set("$.payload._incomeDistribution.rows[0]._frc[0]", cfoId)
                .set("$.payload._frcUsed[0]", cfoId)
                .set("$.payload._basis[0]", dealId)
                .set("$.payload._plan[0]", plannedReceiptId)
                .set("$.payload._actualPaymentDate", actualPaymentDate)
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("/api/apps/_transactions/_income/items", json, getAuthTokenAdmin());
    }

    /**
     * Создать Цель
     *
     * @param name      - название цели
     * @param userEmail - email пользователя
     */
    public void createGoal(String name, String userEmail) {
        String userId = getUserIdByEmail(userEmail);
        String json = JsonPath.using(configuration).parse(CREATE_GOAL_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._responsible[0]", userId)
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("/api/apps/_transactions/_sales_goals/items", json, getAuthTokenAdmin());
    }

    public void updateDeal(String dealId, String name, String ownerId, int budget, String plannedDueDate) {
        String element = micronautHttpClient.authorizedJsonGet("/api/apps/_clients/_leads/items/" + dealId, getAuthTokenAdmin());
        JsonObject object = JsonParser.parseString(element).getAsJsonObject();
        JsonArray ownerArrId = new JsonArray();
        ownerArrId.add(ownerId);
        JsonObject budgetObj = new JsonObject();
        budgetObj.addProperty("cents", budget);
        budgetObj.addProperty("currency", "RUB");
        object.add("_owner", ownerArrId);
        object.add("_budget", budgetObj);
        object.addProperty("_plannedDueDate", plannedDueDate);
        micronautHttpClient.authorizedJsonPutReturnCode("/api/apps/_clients/_leads/items/" + dealId, object.toString(), getAuthTokenAdmin());
    }

    public String getFunnelId(String name) {
        String url = "/api/apps/_clients/_leads/settings";
        String responseBody = micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
        JsonArray userArray = JsonParser.parseString(responseBody).getAsJsonObject().get("status").getAsJsonObject().get("groups").getAsJsonArray();
        for (int i = 0; i < userArray.size(); i++) {
            JsonObject getSection = userArray.get(i).getAsJsonObject();
            String getSectionName = getSection.get("name").toString().replace("\"", "");
            if (getSectionName.equals(name)) {
                return getSection.get("id").toString().replace("\"", "");
            }
        }
        return null;
    }

    public String createLead(String name) {
        String adminId = getUserIdByEmail(adminLogin);
        String json = JsonPath.using(configuration).parse(CREATE_LEAD_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._owner[0]", adminId)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_opportunities/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createLead(String name, String contractId) {
        String adminId = getUserIdByEmail(adminLogin);
        String json = JsonPath.using(configuration).parse(CREATE_LEAD_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._owner[0]", adminId)
                .set("$.payload._contacts", List.of(contractId))
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_opportunities/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createLeadUser(String name, String userId) {
        String json = JsonPath.using(configuration).parse(CREATE_LEAD_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._owner[0]", userId)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_opportunities/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }


    public void deleteDeal(String dealId) {
        micronautHttpClient.authorizedJsonDelete("/api/apps/_clients/_leads/items/" + dealId, getAuthTokenAdmin());
    }

    /**
     * Переключает режим отображения задач по CRM.
     *
     * @param visible -  флаг, указывающий, нужно ли отображать задачи по CRM отдельно.
     */
    public void setCrmTasksVisibility(boolean visible) {
        String json = String.format("{\"key\":\"showCrmTasks\",\"value\":%s}", visible);
        micronautHttpClient.authorizedJsonPutReturnCode("api/settings/user", json, getAuthTokenAdmin());
    }

    public void initialStateOfDuplicateSettingsOriginalState() {
        String json = JsonPath.using(configuration).parse(DEFAULT_SETTING_DOUBLES)
                .set("$.settings[0].lastCheck.userId", getUserIdByEmail(adminLogin))
                .json().toString();
        micronautHttpClient.authorizedJsonPostReturnCode("api/dup-detector/settings/update", json, getAuthTokenAdmin());
    }

    public void setLeadStatusById(String id, int status) {
        String json = "{\"status\":" + status + ",\"order\":1,\"comment\":\"\",\"notify\":true}";
        micronautHttpClient.authorizedJsonPut("/api/apps/_clients/_opportunities/items/" + id + "/status", json, getAuthTokenAdmin());
    }

    public String createIndustry(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_INDUSTRY_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_industries/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createSegment(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_SEGMENT_CRM_JSON_BODY)
                .set("$.payload.__name", name)
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_clients/_segments/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }

    public String createProject(String name) {
        String json = JsonPath.using(configuration).parse(CREATE_PROJECT_JSON_BODY)
                .set("$.payload.__name", name)
                .set("$.payload._project_manager[0]", getUserIdByEmail(adminLogin))
                .json().toString();
        JsonObject jsonObject = JsonParser.parseString(
                        micronautHttpClient.authorizedJsonPost("/api/apps/_project_management/_project/items", json, getAuthTokenAdmin()))
                .getAsJsonObject();
        return jsonObject.get("__id").toString().replace("\"", "");
    }
}