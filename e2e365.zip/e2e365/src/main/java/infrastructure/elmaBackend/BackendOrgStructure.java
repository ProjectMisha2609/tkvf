package infrastructure.elmaBackend;

import infrastructure.helpers.MicronautHttpClient;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

/**
 * Класс для работы с оргструктурой компании через API.
 * TODO: возможно, стоит вложить его в ElmaBackend, ибо размерами наполнения не блещет,
 *  а единственный его метод не требует наследования от ElmaBackend.
 */
@Singleton
public class BackendOrgStructure extends ElmaBackend {
    @Inject
    protected MicronautHttpClient micronautHttpClient;

    /**
     * Изменить оргструктуру компании.
     *
     * @param structureJson - тело запроса.
     */
    public String createOrgStructure(String structureJson) {
        return micronautHttpClient.authorizedJsonPut("/api/orgstruct", structureJson, getAuthTokenAdmin());
    }
}
