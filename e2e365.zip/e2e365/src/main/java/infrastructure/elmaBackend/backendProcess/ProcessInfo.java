package infrastructure.elmaBackend.backendProcess;

import com.google.gson.JsonObject;

public class ProcessInfo {
    private final JsonObject jsonProcess;
    private final String processId;
    private final String processNamespace;
    private final String processCode;
    private final ProcessLevel level;

    public ProcessInfo(JsonObject jsonProcess, ProcessLevel level) {
        this.jsonProcess = jsonProcess;
        this.processCode = jsonProcess.get("code").getAsString();
        this.processNamespace = jsonProcess.get("namespace").getAsString();
        this.processId = jsonProcess.get("__id").getAsString();
        this.level = level;
    }

    /**
     * Получение JSON процесса при созданнии
     *
     * @return JSON процесса
     */
    public JsonObject getProcessJson() {
        return this.jsonProcess.deepCopy();
    }

    /**
     * Возвразает ID процесса
     *
     * @return ID процесса
     */
    public String getId() {
        return this.processId;
    }

    /**
     * Восвращяет размещение процесса
     *
     * @return окружение в котором находится процесс
     */
    public String getNamespace() {
        return this.processNamespace;
    }

    /**
     * Код процесса
     *
     * @return возвращяет поле "код процесса"
     */
    public String getCode() {
        return this.processCode;
    }

    public ProcessLevel getLevel() {
        return this.level;
    }

    enum ProcessLevel {
        GLOBAL,
        SECTION,
        APPLICATION
    }
}
