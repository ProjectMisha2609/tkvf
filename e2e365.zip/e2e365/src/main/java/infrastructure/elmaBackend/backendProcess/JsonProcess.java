package infrastructure.elmaBackend.backendProcess;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import infrastructure.utils.Constants;
import infrastructure.utils.Loggers;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.BackendBusinessProcessJsonBodies.DEFAULT_CONTEXT_ON_FORM;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.BackendBusinessProcessJsonBodies.DEFAULT_INSTANCE_CARD;

public class JsonProcess {
    private JsonObject jsonSchema;
    private JsonArray currentContext;
    private JsonObject currentProcess;
    private String script;
    private JsonObject buildJson = null;
    private ProcessInfo processInfo;

    public JsonProcess(String path, ProcessInfo processInfo) {
        try (FileReader reader = new FileReader(new File(Constants.PATH_TO_DEFAULT_DIR, path))) {
            JsonObject obj = JsonParser.parseReader(reader).getAsJsonObject();
            JsonArray objContext = obj.getAsJsonArray("context");
            this.jsonSchema = obj.get("process").getAsJsonObject();
            this.currentProcess = processInfo.getProcessJson();
            this.currentContext = this.currentProcess.getAsJsonArray("context");
            for (JsonElement context : objContext) {
                this.currentContext.add(context.getAsJsonObject());
            }
            this.script = this.currentProcess.get("scripts").getAsString();
            this.processInfo = processInfo;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Устанавливает временные значения для элемента таймер.
     *
     * @param timerElementUid UID элемента в процессе
     * @param parameter       Изменяемый параметр ("days" / "hours" / "minutes")
     * @param value           Значение для временного параметра
     */
    public JsonProcess setTimeInTimerSettings(String timerElementUid, String parameter, Integer value) {
        this.jsonSchema.getAsJsonObject("items").getAsJsonObject(timerElementUid)
                .getAsJsonObject("settings")
                .getAsJsonObject("timer")
                .addProperty(parameter, value);
        return this;
    }

    /**
     * Устанавливает зависимость от рабочего календаря (параметр "absolute") для элемента таймер.
     *
     * @param timerElementUid UID элемента в процессе
     * @param value           Значение (true - не зависит от рабочего календаря / false - зависит от рабочего календаря)
     */
    public JsonProcess setAbsoluteInTimerSettings(String timerElementUid, Boolean value) {
        this.jsonSchema.getAsJsonObject("items").getAsJsonObject(timerElementUid)
                .getAsJsonObject("settings")
                .getAsJsonObject("timer")
                .addProperty("absolute", value);
        return this;
    }

    public JsonProcess setGroupCode(String groupCode, String blockId) {
        this.jsonSchema.getAsJsonObject("lanes")
                .getAsJsonObject(blockId).getAsJsonObject("settings")
                .getAsJsonObject("group")
                .addProperty("code", groupCode);
        this.jsonSchema.getAsJsonObject("lanes")
                .getAsJsonObject(blockId).getAsJsonObject("settings")
                .getAsJsonArray("groups").get(0).getAsJsonObject()
                .addProperty("code", groupCode);
        return this;
    }

    public JsonProcess addContextVariable(JsonObject contextObj) {
        this.currentContext.add(contextObj);
        return this;
    }

    /**
     * Вынести переменную на форму стартового события бизнес-процесса
     *
     * @param contextName - название переменной
     * @param required    - обязательна ли для заполнения
     * @param readonly    - только для чтения
     */
    public JsonProcess addContextOnDefaultStartForm(String contextName, boolean required, boolean readonly) {
        return addContextOnDefaultForm("00000000-0000-0000-0000-000000000000", contextName, required, readonly);
    }


    /**
     * Вынести переменную на форму элемента бизнес-процесса
     *
     * @param contextName - название переменной
     * @param required    - обязательна ли для заполнения
     * @param readonly    - только для чтения
     */
    public JsonProcess addContextOnDefaultForm(String blockId, String contextName, boolean required, boolean readonly) {
        if (this.currentContext.size() == 0 ||
                this.jsonSchema.getAsJsonObject().get("items").getAsJsonObject().has(blockId)) {
            Loggers.CONSOLE.warn("Контекст процесса = 0, добавте сначала контекстную переменную");
            return this;
        }
        for (JsonElement element : this.currentContext) {
            JsonObject obj = element.getAsJsonObject();
            if (obj.get("code").getAsString().equals(contextName.toLowerCase().replace(" ", "_"))) {
                JsonObject contextOnForm = JsonParser.parseString(DEFAULT_CONTEXT_ON_FORM).getAsJsonObject();
                contextOnForm.addProperty("tooltip", "");
                contextOnForm.addProperty("code", contextName.toLowerCase().replace(" ", "_"));
                contextOnForm.addProperty("readonly", readonly);
                contextOnForm.addProperty("required", required);
                this.jsonSchema
                        .get("items").getAsJsonObject()
                        .get(blockId).getAsJsonObject()
                        .get("settings").getAsJsonObject()
                        .get("formFields").getAsJsonArray()
                        .add(contextOnForm);
                break;
            }
        }
        return this;
    }

    public JsonProcess setFunctionInScriptBlock(String blockId, String functionName) {
        this.jsonSchema.get("items").getAsJsonObject()
                .get(blockId).getAsJsonObject()
                .get("settings").getAsJsonObject()
                .addProperty("func", functionName);
        return this;
    }

    public JsonProcess addScript(String script) {
        this.script += "\n" + script;
        return this;
    }

    public JsonObject getObj() {
        if (this.buildJson == null) {
            build();
        }
        return this.buildJson;
    }

    public ProcessInfo getProcessInfo() {
        return this.processInfo;
    }

    public JsonObject getCurrentProcess() {
        return this.currentProcess;
    }

    private void build() {
        this.buildJson = new JsonObject();
        this.buildJson.add("process", this.jsonSchema);
        this.buildJson.add("context", this.currentContext);
        this.buildJson.addProperty("draft", true);
        this.buildJson.addProperty("scripts", this.script);
        this.buildJson.add("forms", this.currentProcess.get("forms").getAsJsonArray());
        this.buildJson.addProperty("manualRun", this.currentProcess.get("manualRun").getAsBoolean());
        this.buildJson.addProperty("hideInList", this.currentProcess.get("hideInList").getAsBoolean());
        JsonObject settings = this.currentProcess.getAsJsonObject("settings");
        settings.addProperty("allowNamespace", false);
        settings.add("fieldVisibilityConditions", new JsonObject());
        settings.add("instanceCard", JsonParser.parseString(DEFAULT_INSTANCE_CARD).getAsJsonObject());
        this.buildJson.add("settings", settings);
    }
}
