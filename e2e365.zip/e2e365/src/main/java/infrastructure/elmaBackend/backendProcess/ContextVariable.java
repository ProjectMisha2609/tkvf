package infrastructure.elmaBackend.backendProcess;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import infrastructure.elmaBackend.jsonTools.ContextType;

public class ContextVariable {
    private String contextName;
    private String contextCode;
    private String contextType;
    private boolean array;

    private boolean single;
    private final JsonObject object;

    {
        this.object = JsonParser.parseString("""
                {
                    "type": null,
                    "code": null,
                    "searchable": false,
                    "indexed": false,
                    "deleted": false,
                    "array": null,
                    "single": true,
                    "required": false,
                    "defaultValue": null,
                    "data": {},
                    "view": {
                        "name": null,
                        "data": {}
                    },
                    "calcByFormula": false,
                    "formula": "",
                    "sortable": false
                }""").getAsJsonObject();
    }

    private ContextVariable() {
    }

    public ContextVariable(String contextName, ContextType contextType) {
        this.contextName = contextName;
        this.contextCode = contextName.toLowerCase();
        this.contextType = contextType.name();
        this.array = true;
        this.single = true;
    }

    public ContextVariable(String contextName, ContextType contextType, boolean array) {
        this.contextName = contextName;
        this.contextCode = contextName.toLowerCase();
        this.contextType = contextType.name();
        this.array = array;
        this.single = true;
    }

    public ContextVariable(String contextName, ContextType contextType, boolean array, boolean single) {
        this.contextName = contextName;
        this.contextCode = contextName.toLowerCase();
        this.contextType = contextType.name();
        this.array = array;
        this.single = single;
    }

    public ContextVariable setDataField(String sectionCode, String appCode) {
        JsonObject obj = new JsonObject();
        obj.addProperty("code", appCode);
        obj.addProperty("namespace", sectionCode);
        this.object.add("data", obj);
        return this;
    }

    public ContextVariable setViewField(boolean timeOptional, String additionalType, String defaultTimeType, boolean setCurrentDatetime) {
        JsonObject obj = new JsonObject();
        obj.addProperty("timeOptional", timeOptional);
        obj.addProperty("additionalType", additionalType);
        obj.addProperty("defaultTimeType", defaultTimeType);
        obj.addProperty("setCurrentDatetime", setCurrentDatetime);
        JsonObject view = this.object.getAsJsonObject("view");
        view.add("data", obj);
        return this;
    }

    public JsonObject getJson() {
        this.object.addProperty("type", this.contextType);
        this.object.addProperty("code", this.contextCode);
        this.object.addProperty("array", this.array);
        this.object.addProperty("single", this.single);
        JsonObject view = this.object.getAsJsonObject("view");
        view.addProperty("name", this.contextName);
        this.object.add("view", view);
        return this.object;
    }
}
