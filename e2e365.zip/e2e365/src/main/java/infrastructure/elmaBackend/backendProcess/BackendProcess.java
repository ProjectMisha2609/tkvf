package infrastructure.elmaBackend.backendProcess;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.jsonpath.JsonPath;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.MicronautHttpClient;
import infrastructure.helpers.RandomString;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.junit.jupiter.api.Assertions;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.BackendBusinessProcessJsonBodies.*;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;

@Singleton
public class BackendProcess extends ElmaBackend {
    @Inject
    protected MicronautHttpClient micronautHttpClient;

    /**
     * Создать процесс на уровне приложения
     *
     * @param sectionName имя раздела (код)
     * @param appName     имя приложения (код)
     * @param processName имя процесса
     * @return ID созданного процесса
     */
    public ProcessInfo createInApplication(String sectionName, String appName, String processName) {
        if (!isAppCreated(sectionName, appName))
            throw new IllegalStateException("Нельзя создать процесс в несуществующем приложении");
        Object jsonContext = JsonPath.using(configuration).parse(JSON_APP_CONTEXT)
                .set("$.code", appName.toLowerCase(Locale.ROOT).replace(" ", "_"))
                .set("$.data.namespace", sectionName.toLowerCase(Locale.ROOT).replace(" ", "_"))
                .set("$.data.code", appName.toLowerCase(Locale.ROOT).replace(" ", "_"))
                .set("$.view.name", appName)
                .json();
        String json = JsonPath.using(configuration).parse(JSON_BASE)
                .set("$.__name", processName)
                .set("$.namespace", String.format("%s.%s",
                        sectionName.toLowerCase(Locale.ROOT).replace(" ", "_"),
                        appName.toLowerCase(Locale.ROOT).replace(" ", "_")))
                .set("$.code", processName.toLowerCase(Locale.ROOT))
                .set("$.manualRun", false)
                .set("$.settings.targetFeed.type", "object")
                .set("$.settings.targetFeed.variable", appName.toLowerCase(Locale.ROOT).replace(" ", "_"))
                .set("$.settings.allowGlobal", false)
                .set("$.context[0]", jsonContext)
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/bpm/templates", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return new ProcessInfo(jsonObject, ProcessInfo.ProcessLevel.APPLICATION);
    }

    /**
     * Создать процесс на уровне раздела
     *
     * @param sectionName имя раздела (код)
     * @param processName имя процесса
     * @return ID созданного процесса
     */
    public ProcessInfo createInSection(String sectionName, String processName) {
        if (!isSectionCreated(sectionName))
            throw new IllegalStateException("Нельзя создать процесс в несуществующем разделе");
        String json = JsonPath.using(configuration).parse(JSON_BASE)
                .set("$.__name", processName)
                .set("$.namespace", sectionName.toLowerCase(Locale.ROOT))
                .set("$.code", processName.toLowerCase(Locale.ROOT).replace(" ", "_"))
                .set("$.manualRun", true)
                .set("$.settings.targetFeed.type", "instance")
                .set("$.settings.targetFeed.variable", "")
                .set("$.settings.allowGlobal", false)
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/bpm/templates", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return new ProcessInfo(jsonObject, ProcessInfo.ProcessLevel.SECTION);
    }

    /**
     * Создать процесс на уровне компании
     *
     * @param processName имя процесса
     * @return ID созданного процесса
     */
    public ProcessInfo createInCompany(String processName) {
        String json = JsonPath.using(configuration).parse(JSON_BASE)
                .set("$.__name", processName)
                .set("$.namespace", "global")
                .set("$.code", processName.toLowerCase(Locale.ROOT).replace(" ", "_"))
                .set("$.manualRun", true)
                .set("$.settings.targetFeed.type", "instance")
                .set("$.settings.targetFeed.variable", "")
                .set("$.settings.allowGlobal", true)
                .json().toString();
        String response = micronautHttpClient.authorizedJsonPost("/api/bpm/templates", json, getAuthTokenAdmin());
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        return new ProcessInfo(jsonObject, ProcessInfo.ProcessLevel.GLOBAL);
    }

    /**
     * Действия с процессом (изменение, сохранение/публикация)
     *
     * @param jsonProcess жсон процесса
     * @return реализация интерфейса ActionProcess
     */
    public ActionsProcess action(JsonProcess jsonProcess) {
        return new ActionsProcess() {
            private final JsonProcess process = jsonProcess;
            private final ProcessInfo processInfo = jsonProcess.getProcessInfo();

            @Override
            public void publication() {
                validate();
                JsonObject buildProcess = process.getObj();
                buildProcess.addProperty("draft", false);
                String lockHash = lock(processInfo.getId());
                micronautHttpClient.authorizedLockHashJsonPut("/api/bpm/templates/" + processInfo.getId(), lockHash, buildProcess.toString(), getAuthTokenAdmin());
                unlock(lockHash, processInfo.getId());
                // Если процесс на уровне приложения то привязываем запуск к кнопке
                if (processInfo.getLevel().equals(ProcessInfo.ProcessLevel.APPLICATION)) {
                    JsonObject context = processInfo.getProcessJson().get("context").getAsJsonArray().get(0).getAsJsonObject();
                    String processField = context.get("code").getAsString();
                    String namespace = context.get("data").getAsJsonObject()
                            .get("namespace").getAsString();//это же и код раздела
                    String appCode = context.get("data").getAsJsonObject()
                            .get("code").getAsString();//это же и код приложения
                    String json = JsonPath.using(configuration).parse(CREATE_BUTTON_SETTINGS)
                            .set("$.buttons[0].id", RandomString.getUUID())
                            .set("$.buttons[0].label", "Сохранить")
                            .set("$.buttons[0].processNamespace", processInfo.getNamespace())
                            .set("$.buttons[0].processCode", processInfo.getCode())
                            .set("$.buttons[0].processField", processField)
                            .set("$.buttons[1].id", RandomString.getUUID())
                            .set("$.buttons[1].label", "Отмена")
                            .json().toString();
                    String currentSettings = micronautHttpClient.authorizedJsonGet(String.format("/api/apps/%s/%s/settings", namespace, appCode), getAuthTokenAdmin());
                    JsonObject object = JsonParser.parseString(currentSettings).getAsJsonObject();
                    object.add("createSettings", JsonParser.parseString(json).getAsJsonObject());
                    micronautHttpClient.authorizedJsonPut(String.format("/api/apps/%s/%s/settings", namespace, appCode),
                            object.toString(),
                            getAuthTokenAdmin());
                }
            }

            @Override
            public void save() {
                String lockHash = lock(processInfo.getId());
                JsonObject buildProcess = process.getObj();
                micronautHttpClient.authorizedLockHashJsonPut("/api/bpm/templates/" + processInfo.getId(), lockHash, buildProcess.toString(), getAuthTokenAdmin());
                unlock(lockHash, processInfo.getId());
            }

            private void validate() {
                JsonObject thisProcess = process.getCurrentProcess();
                JsonObject objValidate = process.getObj().deepCopy();
                objValidate.addProperty("namespace", thisProcess.get("namespace").getAsString());
                objValidate.addProperty("code", thisProcess.get("code").getAsString());
                objValidate.addProperty("type", thisProcess.get("type").getAsString());
                objValidate.addProperty("__name", thisProcess.get("__name").getAsString());
                objValidate.addProperty("category", thisProcess.get("category").getAsString());
                objValidate.addProperty("version", thisProcess.get("version").getAsInt());
                objValidate.addProperty("draft", thisProcess.get("draft").getAsBoolean());
                String responseValidate = micronautHttpClient.authorizedJsonPut("/api/bpm/templates/validate", objValidate.toString(), getAuthTokenAdmin());
                Assertions.assertEquals("{}", responseValidate, "Процесс содержит ошибки: " + responseValidate);
            }

            private String lock(String processId) {
                String response = micronautHttpClient.authorizedJsonPost("/api/bpm/templates/" + processId + "/lock", EMPTY_JSON, getAuthTokenAdmin());
                JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
                return jsonObject.get("hash").toString().replace("\"", "");
            }

            private void unlock(String lockHash, String processId) {
                micronautHttpClient.authorizedLockHashJsonDelete("/api/bpm/templates/" + processId + "/lock", lockHash, getAuthTokenAdmin());
            }
        };
    }

    /**
     * Запуск процесса с пусытм контекстом
     *
     * @param processID айди процесса
     * @return ID инстанса
     */
    public String run(String processID) {
        return run(processID, "{}");
    }

    /**
     * Запуск процесса
     *
     * @param processId         айди процесса
     * @param contextStartEvent контекст стартового события
     * @return ID инстанса процесса
     */
    public String run(String processId, String contextStartEvent) {
        // Узнаем текущую версию процесса
        String process = getProcess(processId);
        int processVersion;
        JsonObject jsonProcessObject = JsonParser.parseString(process).getAsJsonObject();
        if ((processVersion = jsonProcessObject.get("version").getAsInt()) <= 0) {
            throw new IllegalStateException("Процесс должен иметь версию 1 и выше");
        }
        // Запускаем процесс
        String json = micronautHttpClient.authorizedJsonPut("/api/bpm/templates/public/" + processId
                + "/" + processVersion + "/run", contextStartEvent, getAuthTokenAdmin());
        String instance = null;
        if (json != null) {
            JsonObject jsonObject = JsonParser.parseString(json).getAsJsonObject();
            instance = jsonObject.get("__id").getAsString();
        }
        return instance;
    }

    /**
     * Прервать процесс по его инстансу
     *
     * @param processInstanceId ID инстанса
     */
    public void interrupt(String processInstanceId) {
        String jsonBody = "{\"__updateComment\": \"INTERRUPT BY API COMMENT!\"}";
        micronautHttpClient.authorizedJsonPut("/api/bpm/instances/"
                + processInstanceId + "/interrupt", jsonBody, getAuthTokenAdmin());
    }

    /**
     * Получить все инстанс айди по айдишке процесса
     *
     * @param processId айди процесса
     * @return возвращает список айди инстансов
     */
    public List<String> getAllInstanceIDByProcessID(String processId) {
        List<String> list = new ArrayList<>();
        CustomDriver.waitMills(1000);
        String response = getAllInstanceByProcessID(processId);
        if (response != null) {
            JsonObject getAllJson = JsonParser.parseString(response).getAsJsonObject();
            JsonArray array = getAllJson.getAsJsonArray("result");
            for (int i = 0; i < array.size(); i++) {
                JsonObject getFromArray = array.get(i).getAsJsonObject();
                list.add(getFromArray.get("__id").toString().replace("\"", ""));
            }
        }
        return list;
    }

    private String getAllInstanceByProcessID(String processId) {
        String query = URLEncoder.encode(String.format("{\"eq\":[{\"field\":\"__templateId\"},{\"const\":\"%s\"}]}", processId), StandardCharsets.UTF_8);
        String url = "/api/processor/monitor/" + processId + "/instances" +
                "?from=0&size=1000&q=" + query + "&withPermissions=true&sortField=__createdAt&ascending=false";
        return micronautHttpClient.authorizedJsonGet(url, getAuthTokenAdmin());
    }

    private boolean isSectionCreated(String sectionName) {
        String query = URLEncoder.encode(
                String.format("{\"and\":[{\"tf\":{\"code\":\"%s\"}},{\"tf\":{\"type\":\"NAMESPACE\"}}]}",
                        sectionName.toLowerCase(Locale.ROOT).replace(" ", "_")), StandardCharsets.UTF_8);
        String response = micronautHttpClient.authorizedJsonGet("/api/pages?from=0&size=1000&q=" + query, getAuthTokenAdmin());
        return JsonParser.parseString(response).getAsJsonObject().get("total").getAsInt() == 1;
    }

    private boolean isAppCreated(String sectionName, String appName) {
        String query = URLEncoder.encode(
                String.format("{\"and\":[{\"tf\":{\"code\":\"%s\"}},{\"tf\":{\"namespace\":\"%s\"}},{\"tf\":{\"type\":\"APPLICATION\"}}]}",
                        appName.toLowerCase(Locale.ROOT).replace(" ", "_"),
                        sectionName.toLowerCase(Locale.ROOT).replace(" ", "_")), StandardCharsets.UTF_8);
        String response = micronautHttpClient.authorizedJsonGet("/api/pages?from=0&size=1000&q=" + query, getAuthTokenAdmin());
        return JsonParser.parseString(response).getAsJsonObject().get("total").getAsInt() == 1;
    }

    private String getProcess(String processId) {
        return micronautHttpClient.authorizedJsonGet("/api/bpm/templates/" + processId, getAuthTokenAdmin());
    }

    /* --- Check context process region --- */

    /**
     * Получает JsonArray с контекстом процесса.
     *
     * @param processId ИД процесса
     * @return JsonArray c контекстом процесса
     */
    public JsonArray getContext(String processId) {
        String response = micronautHttpClient.authorizedJsonGet("/api/bpm/templates/" + processId, getAuthTokenAdmin());
        JsonObject json = JsonParser.parseString(response).getAsJsonObject();
        return json.getAsJsonArray("context");
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам.
     *
     * @param processId      ИД процесса
     * @param index          Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName    Название контекстной переменной
     * @param type           Тип контекстной переменной
     * @param additionalType Подтип контекстной переменной
     */
    public void checkContext(String processId, int index, String contextName, String type, String additionalType) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        String propertySubType = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("additionalType").getAsString();
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals(propertyType, type,
                "Тип переменной не совпадает с выбранным");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        Assertions.assertEquals(propertySubType, additionalType,
                "Подтип не совпадает с выбранным");
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам.
     * Проверяет значения переменных через сравнение с переданным массивом.
     *
     * @param processId        ИД процесса
     * @param index            Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName      Название контекстной переменной
     * @param type             Тип контекстной переменной, "ENUM" или "BOOLEAN"
     * @param contextVariables Значения контекстной переменной
     */
    public void checkContextVariableValues(String processId, int index, String contextName, String type, String[] contextVariables) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        JsonArray jsonBodyWithVariables;
        Set<String> variableValuesSet = new HashSet<>();
        // блок сохранения значений переменных типа ENUM
        if (type.equals("ENUM")) {
            jsonBodyWithVariables = context.get(index).getAsJsonObject().getAsJsonObject("data").getAsJsonArray("enumItems");
            for (JsonElement variable : jsonBodyWithVariables) {
                // итеративное добавление имён переменных в список уникальных значений
                variableValuesSet.add(variable.getAsJsonObject().get("name").toString().replace("\"", ""));
            }
        }
        // блок сохранения значений переменных типа BOOLEAN
        else if (type.equals("BOOLEAN")) {
            variableValuesSet.add(context.get(index).getAsJsonObject().getAsJsonObject("view")
                    .get("data").getAsJsonObject()
                    .get("yesValue").toString().replace("\"", ""));
            variableValuesSet.add(context.get(index).getAsJsonObject().getAsJsonObject("view")
                    .get("data").getAsJsonObject()
                    .get("noValue").toString().replace("\"", ""));
        } else {
            Assertions.fail("Неизвестный тип переменной");
        }
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals(propertyType, type,
                "Тип переменной не совпадает с выбранным");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        for (String contextVariable : contextVariables) {
            Assertions.assertTrue(variableValuesSet.contains(contextVariable),
                    String.format("В значениях переменных не найдено: %s", contextVariable));
        }
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам.
     *
     * @param processId   ИД процесса
     * @param index       Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName Название контекстной переменной
     * @param type        Тип контекстной переменной
     * @param single      параметр Одиночное(true)/Множественное(false)
     */
    public void checkContext(String processId, int index, String contextName, String type, Boolean single) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        Boolean isPropertySingle = context.get(index).getAsJsonObject().get("single").getAsBoolean();
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals(propertyType, type,
                "Тип переменной не совпадает с выбранным. Ожидался %s, а не %s");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        Assertions.assertEquals(isPropertySingle, single,
                "Отображаемое значение одиночное/множественное не совпадает с указанным");
    }

    /**
     * Проверяет контекст процесса на соответствие указанным характеристикам (Для типа "Деньги").
     *
     * @param processId   ИД процесса
     * @param index       Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param contextName Название контекстной переменной
     * @param currency    Выбранная валюта для типа деньги
     */
    public void checkContext(String processId, int index, String contextName, String currency) {
        JsonArray context = getContext(processId);
        String propertyName = context.get(index).getAsJsonObject().get("code").getAsString();
        String propertyType = context.get(index).getAsJsonObject().get("type").getAsString();
        String viewName = context.get(index).getAsJsonObject().getAsJsonObject("view").get("name").getAsString();
        String propertyCurrency = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("currency").getAsString();
        Assertions.assertEquals(propertyName, contextName.toLowerCase(Locale.ROOT),
                "Имя свойства не совпадает с указанным");
        Assertions.assertEquals("MONEY", propertyType,
                "Тип переменной не совпадает с выбранным");
        Assertions.assertEquals(viewName, contextName,
                "Отображаемое имя не совпадает с указанным");
        Assertions.assertEquals(propertyCurrency, currency,
                "Валюта не совпадает с выбранной");
    }

    /**
     * Проверяет значение по умолчанию в контексте процесса.
     *
     * @param processId    ИД процесса
     * @param index        Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param defaultValue Значение по умолчанию для контекстной переменной
     */
    public void checkContextDefaultValue(String processId, int index, String defaultValue) {
        JsonArray context = getContext(processId);
        String propertyDefaultValue = context.get(index).getAsJsonObject().get("defaultValue").getAsString();
        Assertions.assertEquals(propertyDefaultValue, defaultValue,
                "Значение по умолчанию не совпадает с указанным");
    }

    /**
     * Проверяет формулу для свойства в контексте процесса.
     *
     * @param processId ИД процесса
     * @param index     Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param formula   Значение по умолчанию для контекстной переменной
     */
    public void checkContextFormula(String processId, int index, String formula) {
        JsonArray context = getContext(processId);
        String propertyFormula = context.get(index).getAsJsonObject().get("formula").getAsString();
        Assertions.assertEquals(propertyFormula, formula,
                "Значение по умолчанию не совпадает с указанным");
    }

    /**
     * Проверяет подсказку для свойства в контексте процесса.
     *
     * @param processId ИД процесса
     * @param index     Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param tooltip   Значение по умолчанию для контекстной переменной
     */
    public void checkContextTooltip(String processId, int index, String tooltip) {
        JsonArray context = getContext(processId);
        String propertyTooltip = context.get(index).getAsJsonObject().getAsJsonObject("view").get("tooltip").getAsString();
        Assertions.assertEquals(propertyTooltip, tooltip,
                "Подсказка не совпадает с указанной");
    }

    /**
     * Проверяет параметр "Указывать текущее время" для свойства типа Дата/Время в контексте процесса.
     *
     * @param processId       ИД процесса
     * @param index           Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param currentDateTime (Bool) параметр "Указывать текущее время"
     */
    public void checkContextDateTimeCurrent(String processId, int index, Boolean currentDateTime) {
        JsonArray context = getContext(processId);
        Boolean propertyCurrentDatetime = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("setCurrentDatetime").getAsBoolean();
        Assertions.assertEquals(propertyCurrentDatetime, currentDateTime,
                "Параметр Указывать текущее время не совпадает");
    }

    /**
     * Проверяет параметр "Указывать текущее время" для свойства типа Дата/Время в контексте процесса.
     *
     * @param processId       ИД процесса
     * @param index           Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param timeOptional    (Bool) параметр "Время опционально"
     * @param defaultTimeType Тип опционального времени startOfDay/endOfDay
     */
    public void checkContextDateTimeOptional(String processId, int index, Boolean timeOptional, String defaultTimeType) {
        JsonArray context = getContext(processId);
        Boolean propertyTimeOptional = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("timeOptional").getAsBoolean();
        String propertyDefaultTimeType = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("defaultTimeType").getAsString();
        Assertions.assertEquals(propertyTimeOptional, timeOptional,
                "Параметр Время опционально не совпадает");
        Assertions.assertEquals(propertyDefaultTimeType, defaultTimeType,
                "Тип опционального времени не совпадает");
    }

    /**
     * Проверяет параметр "Показывать заблокированных" для свойства типа "Пользователь" в контексте процесса.
     *
     * @param processId   ИД процесса
     * @param index       Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param showBlocked (Bool) параметр "Показывать заблокированных"
     */
    public void checkContextUserShowBlocked(String processId, int index, Boolean showBlocked) {
        JsonArray context = getContext(processId);
        Boolean propertyShowBlocked = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("showBlocked").getAsBoolean();
        Assertions.assertEquals(propertyShowBlocked, showBlocked,
                "Параметр 'Показывать заблокированных' не совпадает");
    }

    /**
     * Проверяет параметр "Выбирать фрагмент изображения при загрузке" для свойства типа "Изображение" в контексте процесса.
     *
     * @param processId      ИД процесса
     * @param index          Индекс в массиве контекстных переменных ("context": [] - в JSON бизнес-процесса)
     * @param selectFragment (Bool) параметр "Выбирать фрагмент изображения при загрузке"
     */
    public void checkContextImageIsSelectFragment(String processId, int index, Boolean selectFragment) {
        JsonArray context = getContext(processId);
        Boolean propertySelectFragment = context.get(index).getAsJsonObject().getAsJsonObject("view")
                .getAsJsonObject("data").get("selectFragment").getAsBoolean();
        Assertions.assertEquals(propertySelectFragment, selectFragment,
                "Параметр 'Выбирать фрагмент изображения при загрузке' не совпадает");
    }

    public void checkContextVariableDeleted(String processId, int index) {
        JsonArray context = getContext(processId);
        Assertions.assertTrue(context.get(index).getAsJsonObject().get("deleted").getAsBoolean(),
                "Контекстная переменная не удалена");
    }
    /* --- End check context process region --- */
}
