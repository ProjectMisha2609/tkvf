package infrastructure.elmaBackend.unusedMethods;

import java.util.Locale;

/**
 * Неиспользованные методы класса ElmaBackend и его наследников.
 * Удалять жалко, держать в классе мусор - неправильно.
 * Некоторые действия методов пришлось закомментировать, что бы не тащить импорты.
 * TODO: разобраться какие из них всё-таки нужны.
 */
class UnusedMethods {
    /**
     * Создает статусы в приложении
     *
     * @param section     Секция приложения;
     * @param app         Название приложения;
     * @param statusesNum Нужное количество статусов у приложения;
     */
    public void createAppStatuses(String section, String app, int statusesNum) {
        StringBuilder statusObjects = new StringBuilder();
        //цикл для создания json объекта для статуса, они будут вставлены в массив items
        for (int i = 1; i <= statusesNum; i++) {
            String statusObject = String.format("{\n" +
                    "      \"id\": %s,\n" +
                    "      \"code\": \"%s\",\n" +
                    "      \"name\": \"%s\",\n" +
                    "      \"isFinished\": false,\n" +
                    "      \"jumpMethod\": \"NEXT\",\n" +
                    "      \"jumpToStatuses\": [],\n" +
                    "      \"hideFromBoard\": false,\n" +
                    "      \"isNegative\": false,\n" +
                    "      \"readonly\": false,\n" +
                    "      \"groupId\": \"00000000-0000-0000-0000-000000000000\",\n" +
                    "      \"backgroundColor\": \"\"\n" +
                    "    },", i, ("status" + i), ("status" + i));
            //если последняя итерация то обрезаем запятую чтобы json был правильный
            if (i == statusesNum)
                statusObject = statusObject.substring(0, statusObject.length() - 1);
            statusObjects.append(statusObject);
        }
        //в items подставляется statusObjects строка
        String json = String.format("{\n" +
                "    \"enabled\": true,\n" +
                "    \"manualChange\": false,\n" +
                "    \"nextId\": %s,\n" +
                "    \"items\": [%s],\n" +
                "    \"groups\": [\n" +
                "      {\n" +
                "        \"id\": \"00000000-0000-0000-0000-000000000000\",\n" +
                "        \"name\": \"\",\n" +
                "        \"code\": \"__default\",\n" +
                "        \"flow\": {\n" +
                "          \"type\": \"manual\",\n" +
                "          \"forwardOnly\": false\n" +
                "        }\n" +
                "      }\n" +
                "    ],\n" +
                "    \"transitionLog\": false\n" +
                "  }", (statusesNum + 1), statusObjects);

        String url = "/api/apps/" + section.toLowerCase(Locale.ROOT) +
                "/" + app.toLowerCase(Locale.ROOT) + "/settings/status";

        //micronautHttpClient.authorizedJsonPut(url, json, getAuthTokenAdmin());
        //setStatusFields(section, app);
    }

    /**
     * Создание формы в приложении, находящемся внутри секции, по имени секции и приложения.
     *
     * @param sectionName - имя секции
     * @param appName     - имя приложения
     * @param formName    - имя для создаваемой формы
     * @return поле __name из ответа сервера.
     */
    public String createFormInApplicationByName(String sectionName, String appName, String formName) {
        String json = String.format("{\n" +
                "    \"namespace\": \"%1$s.%2$s\",\n" +
                "    \"code\": \"%3$s\",\n" +
                "    \"__name\": \"%4$s\",\n" +
                "    \"hidden\": false,\n" +
                "    \"draft\": false,\n" +
                "    \"version\": 1,\n" +
                "    \"dataNamespace\": \"%1$s\",\n" +
                "    \"dataCode\": \"%2$s\",\n" +
                "    \"descriptor\": {\n" +
                "        \"code\": \"%1$s.%2$s@%3$s\",\n" +
                "        \"template\": {\n" +
                "            \"descriptor\": \"item-form-complex-popup\",\n" +
                "            \"values\": {\n" +
                "                \"formGroup\": {\n" +
                "                    \"path\": [\n" +
                "                        \"item\"\n" +
                "                    ]\n" +
                "                }\n" +
                "            },\n" +
                "            \"content\": {\n" +
                "                \"[content]\": [\n" +
                "                    {\n" +
                "                        \"id\": \"c18e9118-cda2-49f4-ae50-5414c9b970b2\",\n" +
                "                        \"descriptor\": \"modal-body\",\n" +
                "                        \"values\": {\n" +
                "                            \"shadow\": true\n" +
                "                        },\n" +
                "                        \"content\": {\n" +
                "                            \"\": [\n" +
                "                                {\n" +
                "                                    \"id\": \"b9dbfcad-d5e2-49d0-bfc9-0e817c7a30e6\",\n" +
                "                                    \"descriptor\": \"dynamic-form\",\n" +
                "                                    \"values\": {\n" +
                "                                        \"form\": {\n" +
                "                                            \"path\": [\n" +
                "                                                \"item\"\n" +
                "                                            ]\n" +
                "                                        },\n" +
                "                                        \"fields\": {\n" +
                "                                            \"path\": [\n" +
                "                                                \"fields\"\n" +
                "                                            ]\n" +
                "                                        }\n" +
                "                                    },\n" +
                "                                    \"content\": {},\n" +
                "                                    \"fixed\": false\n" +
                "                                }\n" +
                "                            ]\n" +
                "                        },\n" +
                "                        \"fixed\": false\n" +
                "                    }\n" +
                "                ],\n" +
                "                \"[footer]\": [\n" +
                "                    {\n" +
                "                        \"descriptor\": \"appview-process-buttons\",\n" +
                "                        \"values\": {\n" +
                "                            \"application\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"application\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"isLocked\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"isLocked\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"item\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"itemModel\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"settings\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"buttonSettings\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"runProcessAction\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"runProcessAction\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"permissions\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"permissions\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"useDefaultButtons\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"useDefaultButtons\"\n" +
                "                                ]\n" +
                "                            },\n" +
                "                            \"bpTemplateBuilder\": {\n" +
                "                                \"path\": [\n" +
                "                                    \"bpTemplateBuilder\"\n" +
                "                                ]\n" +
                "                            }\n" +
                "                        },\n" +
                "                        \"content\": {},\n" +
                "                        \"fixed\": false\n" +
                "                    }\n" +
                "                ],\n" +
                "                \"[sidebar]\": [\n" +
                "                    {\n" +
                "                        \"id\": \"662f08da-59da-4112-9ae1-763785ab8bf2\",\n" +
                "                        \"descriptor\": \"sidebar-widget\",\n" +
                "                        \"values\": {},\n" +
                "                        \"content\": {\n" +
                "                            \"\": [\n" +
                "                                {\n" +
                "                                    \"id\": \"1556d7a7-eaa5-41a2-b262-82ec3b86e64d\",\n" +
                "                                    \"descriptor\": \"user-guide\",\n" +
                "                                    \"values\": {},\n" +
                "                                    \"content\": {},\n" +
                "                                    \"fixed\": false\n" +
                "                                }\n" +
                "                            ]\n" +
                "                        },\n" +
                "                        \"fixed\": false\n" +
                "                    }\n" +
                "                ],\n" +
                "                \"[headerControls]\": [],\n" +
                "                \"[headerCustomization]\": []\n" +
                "            },\n" +
                "            \"fixed\": false,\n" +
                "            \"descriptorVersion\": 2\n" +
                "        },\n" +
                "        \"fields\": [],\n" +
                "        \"types\": [\n" +
                "            \"form\"\n" +
                "        ],\n" +
                "        \"dataFieldCode\": \"item\"\n" +
                "    }\n" +
                "}", sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT), formName.toLowerCase(Locale.ROOT), formName);
        //String response = micronautHttpClient.authorizedJsonPost("api/widgets/create", json, getAuthTokenAdmin());
        //JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        //return jsonObject.get("__id").toString().replace("\"", "");
        return json;
    }


}