package infrastructure.helpers.configs;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Stream;

import static infrastructure.utils.Loggers.CONSOLE;

/**
 * Basic test configuration params.
 * Warning: SSH secret key must contain prefix! See readme or {@link infrastructure.utils.SshStateRestorerService}
 */
public class E2eTestConfig {
    private static final ThreadLocal<E2eTestConfig> tlInstanceContainer = new ThreadLocal<>();
    private final Properties properties;
    public final String standUrl;
    public final String adminLogin;
    public final String adminPassword;
    public final String userLogin;
    public final String userPassword;
    public final String sshSecretKey;
    public final boolean isCleaningRequired;
    public final String sshHost;
    public final int sshPort;
    public final String sshUser;
    public final String sshKnownHosts;
    public final String backupPath;
    public final String sshPassword;

    { // fill fields
        properties = loadProperties();
        standUrl = getOrDefault(ConfigEntity.ELMA_STAND_URL, true);
        adminLogin = getOrDefault(ConfigEntity.ADMIN_LOGIN, true, "admin@example.com");
        adminPassword = getOrDefault(ConfigEntity.ADMIN_PASSWORD, true, "admin@example.com");
        userLogin = getOrDefault(ConfigEntity.USER_LOGIN, true, "saratova@example.com");
        userPassword = getOrDefault(ConfigEntity.USER_PASSWORD, true, "saratova@example.com");
        isCleaningRequired = Optional.ofNullable(getOrDefault(ConfigEntity.IS_CLEANING_REQUIRED, false))
                .map(v -> v.equals("true")).orElse(false);
        sshSecretKey = getOrDefault(ConfigEntity.SSH_SECRET_KEY, isCleaningRequired);
        sshHost = getOrDefault(ConfigEntity.SSH_HOST, isCleaningRequired);
        sshUser = getOrDefault(ConfigEntity.SSH_USER, isCleaningRequired);
        sshPort = Optional.ofNullable(getOrDefault(ConfigEntity.SSH_PORT, isCleaningRequired))
                .map(Integer::parseInt).orElse(22);
        sshKnownHosts = getOrDefault(ConfigEntity.SSH_KNOWN_HOSTS, isCleaningRequired);
        backupPath = getOrDefault(ConfigEntity.PATH_TO_BACKUP, isCleaningRequired);
        sshPassword = getOrDefault(ConfigEntity.SSH_PASSWORD, isCleaningRequired);
    }

    /**
     * Get thread-safe instance of this class.
     *
     * @return new or existing instance
     */
    public static E2eTestConfig getInstance() {
        if (tlInstanceContainer.get() == null) tlInstanceContainer.set(new E2eTestConfig());
        return tlInstanceContainer.get();
    }

    private String getOrDefault(ConfigEntity configEntity, boolean required) {
        String value = Optional.ofNullable(System.getenv(configEntity.envName)).orElse(properties.getProperty(configEntity.propName));
        if (value == null && required) throw new RuntimeException(
                String.format("Параметр конфигурации \"%s\" или переменная окружения \"%s\" обязательны, но не найдены", configEntity.propName, configEntity.envName));
        return value;
    }

    private String getOrDefault(ConfigEntity configEntity, boolean required, String placeholder) {
        String value = Optional.ofNullable(System.getenv(configEntity.envName)).orElse(properties.getProperty(configEntity.propName));
        if (value == null && required) {
            value = placeholder;
            CONSOLE.info(String.format("Параметр конфигурации \"%s\" и переменная окружения \"%s\" не найдены, " +
                    "установлено дефолтное значение \"%s\"", configEntity.propName, configEntity.envName, placeholder));
        }
        return value;
    }

    private static Properties loadProperties() {
        Properties properties = new Properties();
        try (InputStream inputStream = E2eTestConfig.class.getClassLoader().getResourceAsStream("application.properties")) {
            properties.load(inputStream);
        } catch (IOException | NullPointerException ignored) {
        }
        return Stream.of(properties, System.getProperties())
                .collect(Properties::new, Map::putAll, Map::putAll);
    }

    /**
     * All available configuration entities as pair with environment variable and java property name.
     */
    private enum ConfigEntity {
        ELMA_STAND_URL("ELMA_STAND_URL", "stand-url"),
        ADMIN_LOGIN("ADMIN_LOGIN", "admin-login"),
        ADMIN_PASSWORD("ADMIN_PASSWORD", "admin-password"),
        USER_LOGIN("USER_LOGIN", "user-login"),
        USER_PASSWORD("USER_PASSWORD", "user-password"),
        IS_CLEANING_REQUIRED("IS_CLEANING_REQUIRED", "is-cleaning-required"),
        SSH_SECRET_KEY("SSH_SECRET_KEY", "ssh-secret-key"),
        SSH_HOST("SSH_HOST", "ssh-host"),
        SSH_USER("SSH_USER", "ssh-user"),
        SSH_PORT("SSH_PORT", "ssh-port"),
        SSH_KNOWN_HOSTS("SSH_KNOWN_HOSTS", "ssh-known-hosts"),
        PATH_TO_BACKUP("PATH_TO_BACKUP", "backup-path"),
        SSH_PASSWORD("SSH_PASSWORD", "ssh-password");
        private static final String PROPS_PREFIX = "elma.";
        public final String envName;
        public final String propName;

        ConfigEntity(String envName, String propName) {
            this.envName = envName;
            this.propName = PROPS_PREFIX + propName;
        }
    }
}
