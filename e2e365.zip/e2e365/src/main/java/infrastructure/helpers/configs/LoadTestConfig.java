package infrastructure.helpers.configs;

import java.security.InvalidParameterException;

/**
 * Все параметры для запуска будут забиты внутри контейнера, который будет управлять выполнением теста
 * ПАРАМТЕРЫ ПОЛОЖИТЬ В ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ КОНТЕЙНЕРА ЖЕЛЕЗНО.
 * Параметры:
 * SSH_STAND_VM_HOST - адрес ВМки на которой будем разворачивать стенд
 * SSH_STAND_VM_USER - пользователя для входа на ВМку
 * SSH_STAND_VM_PASSWORD - пароль ВМки
 * ON_PREMISE_VERSION - ссылка для скачивания установочника нужной версии
 * SSH_JMETER_VM_HOST - адрес ВМки с которой запускаются тесты
 * SSH_JMETER_VM_USER - пользователь ВМки
 * SSH_JMETER_VM_PASSWORD - пароль ВМки
 */
public class LoadTestConfig {
    private static VmStandCredentials credentials;
    private static VmJmeterCredentials jmeterVmCredentials;

    public static String getVmStandHost() {
        return getVmStandCredentials().SSH_STAND_VM_HOST;
    }

    public static String getVmStandUser() {
        return getVmStandCredentials().SSH_STAND_VM_USER;
    }

    public static String getVmStandPassword() {
        return getVmStandCredentials().SSH_STAND_VM_PASSWORD;
    }

    public static String getDownloadLink() {
        return getVmStandCredentials().ON_PREMISE_VERSION;
    }

    public static String getStandUrl() {
        return getVmStandCredentials().STAND_URL;
    }

    public static String getVmJmeterHost() {
        return getVmJmeterCredentials().SSH_JMETER_VM_HOST;
    }

    public static String getVmJmeterUser() {
        return getVmJmeterCredentials().SSH_JMETER_VM_USER;
    }

    public static String getVmJmeterPassword() {
        return getVmJmeterCredentials().SSH_JMETER_VM_PASSWORD;
    }

    private static VmStandCredentials getVmStandCredentials() {
        if (credentials != null) {
            return credentials;
        }
        credentials = new VmStandCredentials();
        credentials.SSH_STAND_VM_HOST = System.getenv("SSH_STAND_VM_HOST");
        if (credentials.SSH_STAND_VM_HOST == null) {
            throw new InvalidParameterException("could not extract SSH_STAND_VM_HOST from ENV");
        }
        credentials.SSH_STAND_VM_USER = System.getenv("SSH_STAND_VM_USER");
        if (credentials.SSH_STAND_VM_USER == null) {
            throw new InvalidParameterException("could not extract SSH_STAND_VM_USER from ENV");
        }
        credentials.SSH_STAND_VM_PASSWORD = System.getenv("SSH_STAND_VM_PASSWORD");
        if (credentials.SSH_STAND_VM_PASSWORD == null) {
            throw new InvalidParameterException("could not extract SSH_STAND_VM_PASSWORD from ENV");
        }
        credentials.ON_PREMISE_VERSION = System.getenv("ON_PREMISE_VERSION");
        if (credentials.ON_PREMISE_VERSION == null) {
            throw new InvalidParameterException("could not extract ON_PREMISE_VERSION from ENV");
        }
        credentials.STAND_URL = "http://" + credentials.SSH_STAND_VM_HOST;
        return credentials;
    }

    public static VmJmeterCredentials getVmJmeterCredentials() {
        if (jmeterVmCredentials != null) {
            return jmeterVmCredentials;
        }
        jmeterVmCredentials = new VmJmeterCredentials();
        jmeterVmCredentials.SSH_JMETER_VM_HOST = System.getenv("SSH_JMETER_VM_HOST");
        if (jmeterVmCredentials.SSH_JMETER_VM_HOST == null) {
            throw new InvalidParameterException("could not extract SSH_JMETER_VM_HOST from ENV");
        }
        jmeterVmCredentials.SSH_JMETER_VM_USER = System.getenv("SSH_JMETER_VM_USER");
        if (jmeterVmCredentials.SSH_JMETER_VM_USER == null) {
            throw new InvalidParameterException("could not extract SSH_JMETER_VM_USER from ENV");
        }
        jmeterVmCredentials.SSH_JMETER_VM_PASSWORD = System.getenv("SSH_JMETER_VM_PASSWORD");
        if (jmeterVmCredentials.SSH_JMETER_VM_PASSWORD == null) {
            throw new InvalidParameterException("could not extract SSH_JMETER_VM_PASSWORD from ENV");
        }
        return jmeterVmCredentials;
    }

    private static class VmStandCredentials {
        public String SSH_STAND_VM_HOST;
        public String SSH_STAND_VM_USER;
        public String SSH_STAND_VM_PASSWORD;
        public String ON_PREMISE_VERSION;
        public String STAND_URL;
    }

    private static class VmJmeterCredentials {
        public String SSH_JMETER_VM_HOST;
        public String SSH_JMETER_VM_USER;
        public String SSH_JMETER_VM_PASSWORD;
    }
}
