package infrastructure.helpers.configs;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidParameterException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class InstallTestConfig {
    private static OnPremCredentials credentials;

    public static String getHost() {
        return getCredentials().host;
    }

    public static String getUser() {
        return getCredentials().user;
    }

    public static String getPassword() {
        return getCredentials().password;
    }

    public static String getLink() {
        return getCredentials().downloadLink;
    }

    public static String getUrlStand() {
        return getCredentials().onPremStandUrl;
    }

    private static OnPremCredentials getCredentials() {
        if (credentials != null) {
            return credentials;
        }
        credentials = new InstallTestConfig.OnPremCredentials();
        boolean isGitlab = System.getenv("CI") != null;
        if (isGitlab) {
            credentials.host = System.getenv("SSH_HOST");
            if (credentials.host == null) {
                throw new InvalidParameterException("could not extract SSH_HOST from ENV");
            }
            credentials.user = System.getenv("SSH_USER");
            if (credentials.user == null) {
                throw new InvalidParameterException("could not extract SSH_USER from ENV");
            }
            credentials.password = System.getenv("SSH_PASSWORD");
            if (credentials.password == null) {
                throw new InvalidParameterException("could not extract SSH_PASSWORD from ENV");
            }
            credentials.downloadLink = System.getenv("URL_ONPREMISE");
            if (credentials.downloadLink == null) {
                throw new InvalidParameterException("could not extract URL_ONPREMISE from ENV");
            }
            credentials.onPremStandUrl = "http://" + credentials.host;
            return credentials;
        }
        String[] onPremConfigFileLines = getTestConfigFileLines();
        credentials.host = getConfigValueByRegex("SSH_HOST:(.*)", onPremConfigFileLines[0]);
        if (credentials.host == null) {
            throw new InvalidParameterException("could not SSH_HOST from onPremConfig");
        }
        credentials.user = getConfigValueByRegex("SSH_USER:(.*)", onPremConfigFileLines[1]);
        if (credentials.user == null) {
            throw new InvalidParameterException("could not extract SSH_USER from onPremConfig");
        }
        credentials.password = getConfigValueByRegex("SSH_PASSWORD:(.*)", onPremConfigFileLines[2]);
        if (credentials.password == null) {
            throw new InvalidParameterException("could not extract SSH_PASSWORD from onPremConfig");
        }
        credentials.downloadLink = getConfigValueByRegex("URL_ONPREMISE:(.*)", onPremConfigFileLines[3]);
        if (credentials.downloadLink == null) {
            throw new InvalidParameterException("could not extract URL_ONPREMISE from onPremConfig");
        }
        credentials.onPremStandUrl = "http://" + credentials.host;
        return credentials;
    }

    private static String[] getTestConfigFileLines() {
        try (Stream<String> stream = Files.lines(Paths.get("configStandFiles", "onPremConfig"))) {
            return stream.toArray(String[]::new);
        } catch (IOException e) {
            e.printStackTrace();
            throw new InvalidParameterException("could not extract values from onPremConfig");
        }
    }

    private static String getConfigValueByRegex(String regexString, String OnPremConfig) {
        Pattern pattern = Pattern.compile(regexString);
        Matcher matcher = pattern.matcher(OnPremConfig);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private static class OnPremCredentials {
        public String host;
        public String user;
        public String password;
        public String downloadLink;
        public String onPremStandUrl;
    }
}
