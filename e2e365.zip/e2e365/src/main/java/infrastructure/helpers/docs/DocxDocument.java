package infrastructure.helpers.docs;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import static infrastructure.utils.Loggers.CONSOLE;

/**
 * Фасад документа формата docx.
 * <p>
 * todo: Должен уметь читать параграфы, строки, изображения.
 * Можно написать методы создания, редактирования и сохранения документа в файл.
 * Можно для лучшей читаемости обойти индексы, начинающиеся на 0
 */
public class DocxDocument {
    private XWPFDocument document;

    public DocxDocument(File file) {
        try {
            this.document = new XWPFDocument(new FileInputStream(file));
        } catch (IOException e) {
            CONSOLE.error(e.getMessage(), e);
        }
    }

    public DocxDocument(String... paragraphs) {
        this.document = new XWPFDocument();
        for (String par : paragraphs) {
            this.document.createParagraph().createRun().setText(par);
        }
    }

    public DocxDocument addParagraphWithText(String text) {
        document.createParagraph().createRun().setText(text);
        return this;
    }

    public String getParagraphTextByNumber(int paragraphNumber) {
        List<XWPFParagraph> paragraphs = document.getParagraphs();
        return paragraphs.get(--paragraphNumber).getParagraphText();
    }

    public String getLineInParagraphByNumber(int paragraphNumber, int lineNumber) {
        return getParagraphTextByNumber(--paragraphNumber)
                .split("\n")[--lineNumber];
    }
}

class usage {
    /**
     * Пример предполагаемого использования, должен создать документ с двумя абзацами.
     * Впоследствии файл можно будет отредактировать и сохранить на диск.
     */
    public static void usage1() {
        // создали документ и уже можно читать/писать, затем можно сохранить в файл
        DocxDocument doc = new DocxDocument("Lorem ipsum dolor sit amet," +
                "consectetur adipiscing elit," +
                "sed do eiusmod tempor incididunt" +
                "ut labore et dolore magna aliqua.",
                "Ut enim ad minim veniam, \n" +
                        "quis nostrud exercitation ullamco laboris nisi \n" +
                        "ut aliquip ex ea commodo consequat.");
        System.out.println(doc.getLineInParagraphByNumber(1, 1) + "\n----");
        System.out.println(doc.getLineInParagraphByNumber(1, 3) + "\n----");
        doc.addParagraphWithText("text3")
                .addParagraphWithText("text4")
                .addParagraphWithText("text5\ntext5_2");
        System.out.println(doc.getParagraphTextByNumber(3) + "\n----");
        System.out.println(doc.getParagraphTextByNumber(4) + "\n----");
        System.out.println(doc.getParagraphTextByNumber(5) + "\n----");
        System.out.println(doc.getLineInParagraphByNumber(5, 2));
    }

    /**
     * Пример предполагаемого использования, должен создать документ с двумя абзацами.
     */
    public static void usage2() {
        File file = new File("testData/template_docx_modified.docx");
        // передали какой-то файл и уже можно читать/писать
        System.out.println(new DocxDocument(file)
                .getParagraphTextByNumber(1));
    }

//    public static void main(String[] args) {
//        usage1();
//        usage2();
//    }
}
