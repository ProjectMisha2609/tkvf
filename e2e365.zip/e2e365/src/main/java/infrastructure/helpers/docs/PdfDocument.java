package infrastructure.helpers.docs;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Фасад документа формата pdf.
 * <p>
 * Считывает текст документа полностью, разделяя по страницам.
 * todo: заполнить методы получения строк, абзацев.
 */
public class PdfDocument {

    private final List<String> pages = new ArrayList<>();

    public PdfDocument(File file) {
        try {
            // библиотека оказалась со своим ридером файлов,
            // так что приходится ради единообразности с docx получить из файла путь к нему.
            PdfReader reader = new PdfReader(file.getAbsolutePath());
            int pageCount = reader.getNumberOfPages();
            for (int i = 1; i <= pageCount; i++) {
                pages.add(PdfTextExtractor.getTextFromPage(reader, i));
            }
            reader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String getTextFromPage(int pageNumber) {
        return pages.get(--pageNumber);
    }
}

class pdfUsage {
    /**
     * Пример предполагаемого использования, читаем файл, получаем текст страницы
     */
    public static void usage1() {

        PdfDocument doc = new PdfDocument(new File("target/build/68091f8d-d632-4e07-8801-93173249ef40/variableString9765.pdf"));
        System.out.println(doc.getTextFromPage(1));
    }

//    public static void main(String[] args) {
//        usage1();
//    }
}
