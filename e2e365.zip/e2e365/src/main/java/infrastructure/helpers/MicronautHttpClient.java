package infrastructure.helpers;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.client.BlockingHttpClient;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.annotation.Client;
import jakarta.inject.Singleton;

import static infrastructure.elmaBackend.BackendUser.standAndCompanyUrl;

/**
 * Обёртка клиента micronaut для отправки API запросов в процессе тестирования сервиса.
 * Имеет обратную совместимость с legacy синтаксисом запросов,
 * а так же более удобные методы отправки авторизованного запроса одной строкой кода.
 */
@Singleton
public class MicronautHttpClient {

    /**
     * Используемый клиент micronaut.
     */
    private final BlockingHttpClient blockingHttpClient;

    /**
     * Конструктор для инъекции обёртки клиента в классы с методами API.
     *
     * @param httpClient - api-клиент, автоматически передаётся при инъекции.
     */
    public MicronautHttpClient(@Client(id = "elma") HttpClient httpClient) {
        this.blockingHttpClient = httpClient.toBlocking();
    }

    /**
     * Новый метод отправки авторизованного запроса GET
     *
     * @param url   - путь url после адреса стенда.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedJsonGet(String url, String token) {
        HttpRequest<?> req = HttpRequest.GET(standAndCompanyUrl + url)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    /**
     * Новый метод отправки авторизованного запроса POST
     *
     * @param url   - путь url после адреса стенда.
     * @param body  - тело запроса.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedJsonPost(String url, String body, String token) {
        HttpRequest<?> req = HttpRequest.POST(standAndCompanyUrl + url, body)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    /**
     * Новый метод отправки авторизованного запроса POST, возвращает статус-код.
     * Нужен для случаев, когда API отдаёт пустое тело ответа. (bug workaround)
     *
     * @param url   - путь url после адреса стенда.
     * @param body  - тело запроса.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String статус-код.
     */
    public String authorizedJsonPostReturnCode(String url, String body, String token) {
        HttpRequest<?> req = HttpRequest.POST(standAndCompanyUrl + url, body)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return String.valueOf(blockingHttpClient.exchange(req).code());
    }


    /**
     * Новый метод отправки авторизованного запроса PUT
     *
     * @param url   - путь url после адреса стенда.
     * @param body  - тело запроса.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedJsonPut(String url, String body, String token) {
        HttpRequest<?> req = HttpRequest.PUT(standAndCompanyUrl + url, body)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    /**
     * Новый метод отправки авторизованного запроса PUT, возвращает статус-код.
     * Нужен для случаев, когда API отдаёт пустое тело ответа. (bug workaround)
     *
     * @param url   - путь url после адреса стенда.
     * @param body  - тело запроса.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedJsonPutReturnCode(String url, String body, String token) {
        HttpRequest<?> req = HttpRequest.PUT(standAndCompanyUrl + url, body)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return String.valueOf(blockingHttpClient.exchange(req).code());
    }

    /**
     * Новый метод отправки авторизованного запроса DELETE
     *
     * @param url   - путь url после адреса стенда.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedJsonDelete(String url, String token) {
        HttpRequest<?> req = HttpRequest.DELETE(standAndCompanyUrl + url)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    /**
     * Новый метод отправки авторизованного запроса DELETE с телом
     *
     * @param url   - путь url после адреса стенда.
     * @param token - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedJsonDelete(String url, String body, String token) {
        HttpRequest<?> req = HttpRequest.DELETE(standAndCompanyUrl + url, body)
                .header("Cookie", "vtoken=" + token)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    /**
     * Новый метод отправки авторизованного запроса PUT c lock hash хэдером
     *
     * @param url            - путь url после адреса стенда.
     * @param body           - тело запроса.
     * @param lockHashHeader - хэш-сумма для встраивания в хэдер.
     * @param token          - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedLockHashJsonPut(String url, String lockHashHeader, String body, String token) {
        HttpRequest<?> req = HttpRequest.PUT(standAndCompanyUrl + url, body)
                .header("Cookie", "vtoken=" + token)
                .header("Lock-Hash", lockHashHeader)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    /**
     * Новый метод отправки авторизованного запроса DELETE c lock hash хэдером
     *
     * @param url            - путь url после адреса стенда.
     * @param lockHashHeader - хэш-сумма для встраивания в хэдер.
     * @param token          - токен пользователя для встраивания в хэдер.
     * @return String тело ответа.
     */
    public String authorizedLockHashJsonDelete(String url, String lockHashHeader, String token) {
        HttpRequest<?> req = HttpRequest.DELETE(standAndCompanyUrl + url)
                .header("Cookie", "vtoken=" + token)
                .header("Lock-Hash", lockHashHeader)
                .header("Content-Type", "application/json");
        return blockingHttpClient.retrieve(req);
    }

    public String authorizedLockHashJsonDeleteReturnCode(String url, String lockHashHeader, String token) {
        HttpRequest<?> req = HttpRequest.DELETE(standAndCompanyUrl + url)
                .header("Cookie", "vtoken=" + token)
                .header("Lock-Hash", lockHashHeader)
                .header("Content-Type", "application/json");
        return String.valueOf(blockingHttpClient.exchange(req).code());
    }
}
