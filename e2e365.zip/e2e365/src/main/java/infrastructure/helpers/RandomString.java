package infrastructure.helpers;

import infrastructure.utils.Loggers;

import java.math.BigInteger;
import java.util.UUID;

public class RandomString {
    private static final int maxLength = 32;

    public static String get(int length) {
        String tempString = UUID.randomUUID().toString().replace("-", "");
        if (length > maxLength) {
            Loggers.CONSOLE.warn("32 symbols max length string");
            return tempString;
        }
        if (length <= 0) {
            Loggers.CONSOLE.warn("length string must be over 0");
            return "";
        }
        return tempString.substring(0, length);
    }

    public static String getUUID() {
        return UUID.randomUUID().toString();
    }

    public static String getNum(int length) {
        String tempString = String.format("%040d", new BigInteger(UUID.randomUUID().
                toString().replace("-", ""), 16));
        if (length > maxLength) {
            Loggers.CONSOLE.warn("32 symbols max length string");
            return tempString;
        }
        if (length <= 0) {
            Loggers.CONSOLE.warn("length string must be over 0");
            return "";
        }
        return tempString.substring(1, length + 1);
    }
}
