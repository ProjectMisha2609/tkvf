package infrastructure.helpers;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;

public class CommandSsh {
    private Session session;
    private Channel channel;
    private InputStream inputStream;
    private OutputStream outputStream;
    private final String user;
    private final String password;
    private final String host;

    public CommandSsh(String user, String password, String host) {
        this.user = user;
        this.password = password;
        this.host = host;
    }

    /**
     * Подключиться к удаленной машине по SSH
     *
     * @param port            порт
     * @param waitTimeInMills время ожидания подключения
     */
    public boolean connect(int port, int waitTimeInMills) throws JSchException {
        JSch jSch = new JSch();
        session = jSch.getSession(user, host, port);
        session.setPassword(password);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setTimeout(60000);
        session.connect();
        channel = session.openChannel("shell");
        channel.connect(waitTimeInMills);
        try {
            inputStream = channel.getInputStream();
            outputStream = channel.getOutputStream();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Рассчитывает разницу во времени и делает задержку в 500мс
     *
     * @param timeStart - время старта
     * @return вернет разницу между текущем временем и временем начала
     */
    public long calkDeltaTime(long timeStart) {
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        long timeNow = new Date().getTime();
        return timeNow - timeStart;
    }

    /**
     * Отправить команду в терминал
     *
     * @param command команда
     * @param timeout время ожидания выполнения команды
     * @return String вернет вывод терминала
     */
    public String sendCommand(String command, long timeout) {
        byte[] tmp = new byte[1024];
        StringBuilder outputBuffer = new StringBuilder();
        long timeStart = new Date().getTime();
        try {
            if (command != null) {
                outputStream.write(command.getBytes());
                outputStream.flush();
            }
            while (calkDeltaTime(timeStart) <= timeout) {
                while (inputStream.available() > 0) {
                    int i = inputStream.read(tmp, 0, 1024);
                    if (i < 0) break;
                    String outTerminal = new String(tmp, 0, i);
                    outputBuffer.append(outTerminal);
                }
                if (channel.isClosed()) {
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return outputBuffer.toString();
    }

    /**
     * Отправить команду и ждать пока не получим pattern
     *
     * @param command команда отправляемая по SSH
     * @param pattern ожидаемый результат выполнения команды
     * @param timeout время выполнения
     * @return Expected
     */
    public Expected sendCommandAndExpect(String command, String pattern, long timeout) {
        byte[] tmp = new byte[1024];
        StringBuilder outputBuffer = new StringBuilder();
        Expected expected = new Expected();
        long timeStart = new Date().getTime();
        try {
            if (command != null) {
                outputStream.write(command.getBytes());
                outputStream.flush();
            }
            while (calkDeltaTime(timeStart) <= timeout) {
                while (inputStream.available() > 0) {
                    int i = inputStream.read(tmp, 0, 1024);
                    if (i < 0) break;
                    String outTerminal = new String(tmp, 0, i);
                    outputBuffer.append(outTerminal);
                }
                if (channel.isClosed()) {
                    break;
                }
                if (pattern != null && outputBuffer.toString().contains(pattern)) {
                    expected.result = true;
                    expected.commandLineOut = outputBuffer.toString();
                    return expected;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        expected.result = false;
        expected.commandLineOut = outputBuffer.toString();
        return expected;
    }

    /**
     * Ждать пока не будет получен вывод подходящий под паттерн
     *
     * @param pattern ожидаемый вывод
     * @param timeout время ожидания
     * @return Expected
     */
    public Expected expect(String pattern, long timeout) {
        byte[] tmp = new byte[1024];
        StringBuilder outputBuffer = new StringBuilder();
        Expected expected = new Expected();
        long timeStart = new Date().getTime();
        try {
            while (calkDeltaTime(timeStart) <= timeout) {
                while (inputStream.available() > 0) {
                    int i = inputStream.read(tmp, 0, 1024);
                    if (i < 0) break;
                    String outTerminal = new String(tmp, 0, i);
                    outputBuffer.append(outTerminal);
                }
                if (channel.isClosed()) {
                    break;
                }
                if (pattern != null && outputBuffer.toString().contains(pattern)) {
                    expected.result = true;
                    expected.commandLineOut = outputBuffer.toString();
                    return expected;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        expected.result = false;
        expected.commandLineOut = outputBuffer.toString();
        return expected;
    }

    /**
     * Результат работы команды
     * <p>
     * boolean result - результат выполнениня команды
     * String commandLineOut - вывод терминала
     */
    public class Expected {
        public boolean result;
        public String commandLineOut;
    }

    /**
     * Закрыть SSH сессию
     */
    public void disconnect() {
        channel.disconnect();
        session.disconnect();
    }
}