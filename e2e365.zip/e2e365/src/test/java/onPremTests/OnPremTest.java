package onPremTests;

import com.jcraft.jsch.JSchException;
import infrastructure.helpers.CommandSsh;
import infrastructure.helpers.configs.InstallTestConfig;
import org.junit.jupiter.api.*;

import static infrastructure.utils.Constants.TimeWait.*;
import static infrastructure.utils.Loggers.CONSOLE;
import static infrastructure.utils.Loggers.FILE_LOGGER;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class OnPremTest {
    @Test
    @DisplayName("Установка онпремиса")
    @Tags({@Tag("install"), @Tag("install_test")})
    @Order(1)
    public void installOnPremiseTest() {
        CommandSsh commandSsh = new CommandSsh(InstallTestConfig.getUser(), InstallTestConfig.getPassword(), InstallTestConfig.getHost());
        boolean resultTest = false;
        CommandSsh.Expected result;
        try {
            commandSsh.connect(22, (int) MINUTES_1);
            result = commandSsh.sendCommandAndExpect("sudo su\r", "password", SECONDS_5);
            FILE_LOGGER.debug(result.commandLineOut);
            FILE_LOGGER.debug(commandSsh.sendCommand(InstallTestConfig.getPassword() + "\r", SECONDS_5));
            result = commandSsh.sendCommandAndExpect("whoami\r", "root", SECONDS_5);
            FILE_LOGGER.debug(result.commandLineOut);
            if (!result.result) {
                CONSOLE.error("CAN NOT LOGIN ROOT!!!");
                commandSsh.disconnect();
                assert result.result;
                return;
            }
            result = commandSsh.sendCommandAndExpect("curl -fsSL -o elma365-installer.sh " + InstallTestConfig.getLink() + " && chmod +x elma365-installer.sh && ./elma365-installer.sh\r",
                    "ELMA365 will work slowly. Press [ENTER] to continue...", SECONDS_10);
            FILE_LOGGER.debug(result.commandLineOut);
            if (result.result) {
                result = commandSsh.sendCommandAndExpect("\r", "Notice: We recommend disabling SWAP for the application to work correctly!!!", SECONDS_10);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("\r", "Do you want to specify your proxy settings (/etc/environment)?(y/N)", SECONDS_10);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("N\r", "Do you want to enable the ufw firewall?(y/N)", SECONDS_40);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("N\r", "Do you want to specify your private DNS? (y/N)", MINUTES_5);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("N\r", "Select language for ELMA365", MINUTES_5);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("\r", "Administrator login (email)", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("\r", "Administrator password", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                FILE_LOGGER.debug(commandSsh.sendCommand("\033[1;1R", SECONDS_5));
                result = commandSsh.sendCommandAndExpect("test\r\033[1;5R", "Confirm password", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                FILE_LOGGER.debug(commandSsh.sendCommand("\033[1;1R", SECONDS_5));
                result = commandSsh.sendCommandAndExpect("test\r\033[1;5R", "SMTP server (type '<empty>' to leave blank)", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("\r", "Do you have external Databases?", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                FILE_LOGGER.debug(commandSsh.sendCommand("\033[1;1R\r", SECONDS_5));
                result = commandSsh.sendCommandAndExpect("N\r\033[1;5R", "Enter host", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("\r", "Refresh Hardware ID?", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                FILE_LOGGER.debug(commandSsh.sendCommand("\033[1;1R\r", SECONDS_5));
                result = commandSsh.sendCommandAndExpect("N\r\033[1;5R", "configuration complete. ELMA365 app will be deployed in a few minutes", SECONDS_5);
                FILE_LOGGER.debug(result.commandLineOut);
                if (result.commandLineOut.contains("Enable platform debug mode?")) {
                    FILE_LOGGER.debug(commandSsh.sendCommand("\033[1;1R\r", SECONDS_5));
                    result = commandSsh.sendCommandAndExpect("N\r\033[1;5R", "configuration complete. ELMA365 app will be deployed in a few minutes", SECONDS_10);
                    FILE_LOGGER.debug(result.commandLineOut);
                }
                if (result.result) {
                    result = commandSsh.expect("Installation complete", MINUTES_30);
                    FILE_LOGGER.debug(result.commandLineOut);
                    if (result.result) {
                        FILE_LOGGER.debug(commandSsh.sendCommand(" microk8s kubectl get pods -o wide\r", SECONDS_10));
                    }
                }
            }
            resultTest = result.result;
        } catch (JSchException e) {
            e.printStackTrace();
            FILE_LOGGER.error(e.getMessage(), e);
        }
        commandSsh.disconnect();
        assert resultTest;
    }

    @Test
    @DisplayName("Удаление онпремиса")
    @Tags({@Tag("delete"), @Tag("install_test")})
    @Order(2)
    public void deleteOnPremiseTest() {
        CommandSsh commandSsh = new CommandSsh(InstallTestConfig.getUser(), InstallTestConfig.getPassword(), InstallTestConfig.getHost());
        boolean resultTest = false;
        try {
            resultTest = commandSsh.connect(22, (int) MINUTES_2);
            CommandSsh.Expected result;
            FILE_LOGGER.debug(commandSsh.sendCommandAndExpect("sudo su\r", "password", SECONDS_5).commandLineOut);
            FILE_LOGGER.debug(commandSsh.sendCommand(InstallTestConfig.getPassword() + "\r", SECONDS_5));
            result = commandSsh.sendCommandAndExpect("whoami\r", "root", SECONDS_5);
            if (!result.result) {
                CONSOLE.error("CAN NOT LOGIN ROOT!!!");
                commandSsh.disconnect();
                assert result.result;
                return;
            }
            FILE_LOGGER.debug(result.commandLineOut);
            String commandResult = commandSsh.sendCommand(" snap remove --purge microk8s\r", SECONDS_5);
            FILE_LOGGER.debug(commandResult);
            if (!commandResult.contains("snap \"microk8s\" is not installed")) {
                FILE_LOGGER.debug(commandSsh.expect("microk8s removed", MINUTES_3).commandLineOut);
            }
            FILE_LOGGER.debug(commandSsh.sendCommand("rm -f /usr/local/bin/elma365ctl\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -P INPUT ACCEPT\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -P FORWARD ACCEPT\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -P OUTPUT ACCEPT\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -t nat -F\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -t mangle -F\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -F\r", SECONDS_5));
            FILE_LOGGER.debug(commandSsh.sendCommand("iptables -X\r", SECONDS_5));
        } catch (JSchException e) {
            e.printStackTrace();
            FILE_LOGGER.error(e.getMessage(), e);
        }
        commandSsh.disconnect();

        assert resultTest;
    }
}
