package onPremTests;

import com.jcraft.jsch.JSchException;
import infrastructure.helpers.CommandSsh;
import infrastructure.helpers.RandomString;
import infrastructure.helpers.configs.LoadTestConfig;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static infrastructure.utils.Constants.TimeWait.*;
import static infrastructure.utils.Loggers.CONSOLE;
import static infrastructure.utils.Loggers.FILE_LOGGER;

public class OnPremLoadTest {
    @Test
    @DisplayName("Запуск нагрузочного тестирования")
    @Tag("load_test")
    public void runLoadTests() {
        String logfile = "logfile" + RandomString.get(8) + ".log";
        CommandSsh commandSsh = new CommandSsh(LoadTestConfig.getVmJmeterUser(), LoadTestConfig.getVmJmeterPassword(), LoadTestConfig.getVmJmeterHost());
        CommandSsh.Expected result;
        try {
            commandSsh.connect(22, (int) MINUTES_2);
            CONSOLE.info(commandSsh.sendCommand("nohup ./run.sh > " + logfile + " &\r", SECONDS_10));
            commandSsh.disconnect();//Отключаемся от текущей сессии
            commandSsh.connect(22, (int) MINUTES_2);//Подклчюаемся к новой
            result = commandSsh.sendCommandAndExpect("cat " + logfile + "\r", "LOAD TEST RUN", SECONDS_10);
            CONSOLE.info(result.commandLineOut);
            if (!result.result) {
                CONSOLE.info("Во время запуска произошли ошибки провертье данные на машине " + LoadTestConfig.getVmJmeterHost());
                assert false;
                return;
            }
            CONSOLE.info("Нагрузочный тест запущен, примерно через час результаты будут на " + LoadTestConfig.getVmJmeterHost());
            commandSsh.disconnect();
            assert result.result;
        } catch (JSchException e) {
            CONSOLE.error(e.getMessage(), e);
            assert false;
        }
    }

    @Test
    @DisplayName("Обновление версии")
    @Tag("prepare")
    public void updateVersion() {
        CommandSsh commandSsh = new CommandSsh(LoadTestConfig.getVmStandUser(), LoadTestConfig.getVmStandPassword(), LoadTestConfig.getVmStandHost());
        CommandSsh.Expected result;
        try {
            commandSsh.connect(22, (int) MINUTES_2);
            result = commandSsh.sendCommandAndExpect("sudo su\r", "password", SECONDS_5);
            FILE_LOGGER.debug(result.commandLineOut);
            FILE_LOGGER.debug(commandSsh.sendCommand(LoadTestConfig.getVmStandPassword() + "\r", SECONDS_5));
            result = commandSsh.sendCommandAndExpect("whoami\r", "root", SECONDS_5);
            FILE_LOGGER.debug(result.commandLineOut);
            if (!result.result) {
                CONSOLE.error("CAN NOT LOGIN ROOT!!!");
                commandSsh.disconnect();
                assert result.result;
                return;
            }
            result = commandSsh.sendCommandAndExpect("curl -fsSL -o elma365-installer.sh " + LoadTestConfig.getDownloadLink() + " && chmod +x elma365-installer.sh && ./elma365-installer.sh -e enterprise\r",
                    "Found ELMA365 version", SECONDS_10);
            CONSOLE.info(result.commandLineOut);
            if (result.result) {
                result = commandSsh.sendCommandAndExpect("y", "Be sure you have made data backup before update. Choose", MINUTES_2);
                CONSOLE.info(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("C\r", "We recommend disabling SWAP for the application to work correctly!!!", MINUTES_2);
                CONSOLE.info(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("\r", "Do you want to specify your proxy settings", MINUTES_2);
                CONSOLE.info(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("N\r", "Do you want to enable the ufw firewall?", MINUTES_2);
                CONSOLE.info(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("N\r", "Enable IPv6?", MINUTES_2);
                CONSOLE.info(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("N\r", "Enable Autoscaling and Linkerd?", MINUTES_40);
                CONSOLE.info(result.commandLineOut);
                result = commandSsh.sendCommandAndExpect("n", "Skipped", MINUTES_1);
                CONSOLE.info(result.commandLineOut);
            }
            if (result.result) {
                CONSOLE.info(commandSsh.sendCommand(" microk8s kubectl get pods -o wide\r", SECONDS_5));
                CONSOLE.info("ELMA365 UPDATED");
                CONSOLE.info(commandSsh.sendCommand(" elma365ctl version\r", SECONDS_5));
            }
            commandSsh.disconnect();
            assert result.result;
        } catch (JSchException e) {
            e.printStackTrace();
            CONSOLE.error(e.getMessage(), e);
            assert false;
        }
    }
}