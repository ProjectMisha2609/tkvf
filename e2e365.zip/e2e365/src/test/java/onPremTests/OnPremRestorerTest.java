package onPremTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.utils.SshStateRestorerService;
import infrastructure.utils.StateRestorerService;
import io.qameta.allure.Allure;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

import static infrastructure.utils.Constants.TimeWait.MINUTES_5;
import static io.qameta.allure.Allure.addAttachment;

/**
 * Данный класс исключён из тестов, запускаемых по mvn clean через pom.
 * Исключение происходит через exclude в конфиге surefire.
 * Вызвать тест можно через команду mvn -Dtest=OnPremRestorerTest test которая обойдёт это ограничение,
 * или же просто запуском теста кнопкой из Idea.
 * Таким образом, производить вызов отката стенда можно и через CI, и вручную кнопкой, не боясь его случайного запуска.
 * Ввиду выполнения только одного класса и одного метода,
 * текущий конфиг выполнит тест единожды и в одном потоке.
 */
class OnPremRestorerTest {
    private final StateRestorerService stateRestorerService = new SshStateRestorerService();

    @Test
    @Tag("stand_restore")
    @DisplayName("Произвести восстановление состояния onpremise стенда")
    public void restore() {
        Allure.step("Вызов отката стенда", () -> {
            addAttachment("TimeStamp", new SimpleDateFormat("MM/dd/yyyy h:mm:ss a").format(new Date()));
            stateRestorerService.restoreBackup();
            CustomDriver.waitMills(MINUTES_5);
        });
    }
}
