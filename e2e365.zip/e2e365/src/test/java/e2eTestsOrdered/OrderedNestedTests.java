package e2eTestsOrdered;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendOrgStructure;
import infrastructure.elmaBackend.BackendUser;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.elmaBackend.jsonTools.JsonOrgStructure;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.ProcessInstanceModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaModals.TaskModal;
import pages.elmaModals.UserSettingsModal;
import pages.elmaPages.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.DEFAULT_ORG_STRUCTURE;
import static infrastructure.elmaBackend.jsonTools.SubstitutionType.REASSIGN;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.UserStatus.ACTIVE;
import static infrastructure.utils.Constants.UserStatus.BLOCKED;
import static java.lang.String.format;
import static java.time.LocalDateTime.now;
import static java.time.format.DateTimeFormatter.ofPattern;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Класс с зависимыми тестами, которые могут повлиять на процесс выполнения других тестов.
 * В многопоточном режиме выполняются одним потоком во избежание нежелательного взаимодействия.
 */
@MicronautTest
@TestClassOrder(ClassOrderer.OrderAnnotation.class)
public class OrderedNestedTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BackendOrgStructure backendOrgStructure;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected ProcessInstanceModal processInstanceModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected ProcessMonitorPage processMonitorPage;
    @Inject
    protected OrgStructurePage orgStructurePage;
    @Inject
    protected SubstitutionPage substitutionPage;
    @Inject
    protected CompanyPage companyPage;
    @Inject
    protected UserPageInAdminSectionPage userPageInAdminSectionPage;
    @Inject
    protected AdminSectionPage adminSectionPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected UserSettingsModal userSettingsModal;

    @Nested
    @Order(1)
    @Tags({@Tag("ordered"), @Tag("ordered_process")})
    @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
    public class BusinessProcessOrgStructureTests {

        @AfterEach
        public void setDefaultOrgStructure() {
            backendOrgStructure.createOrgStructure(DEFAULT_ORG_STRUCTURE);
        }

        @Test
        @Order(1)
        @Link(value = "9633381f-c83c-4ab0-aca1-6c4aec10bf9d", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9633381f-c83c-4ab0-aca1-6c4aec10bf9d)")
        @DisplayName("Проверить выполнение задач исполнителями из разных ЗО")
        public void taskInDifferentZoneTest() {
            String processName = "TestingProcess" + RandomString.get(16);
            String processId = backendBusinessProcess.createBusinessProcess("global", processName);
            String positionName = "TestTaskFromDifferentZone" + RandomString.get(4);
            String positionId = RandomString.getUUID();
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(positionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(userLogin), positionId);

            businessProcessPage.open("admin/process", processId);
            businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
            businessProcessPage.addZoneResponsibility();
            businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(2)");
            businessProcessPage.moveArrow("", "Задача");
            businessProcessPage.moveArrow("Задача 1", "Задача 2");
            businessProcessPage.moveArrowFinish("Задача 2");
            businessProcessPage.clickSave();
            businessProcessPage.clickPublish();
            backendBusinessProcess.run(processId);

            sectionPage.open("/tasks/income");
            sectionPage.clickTask("Задача 1", processName);
            taskModal.clickNext();
            sectionPage.checkToastAppeared();
            CustomDriver.setCookieUser();
            sectionPage.open("/tasks/income");
            sectionPage.clickTask("Задача 2", processName);
            taskModal.clickNext();

            sectionPage.checkToastAppeared();
        }

        @Test
        @Order(2)
        @Link(value = "36bc4faf-fa86-4751-a272-f83b5161fc35", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/36bc4faf-fa86-4751-a272-f83b5161fc35)")
        @DisplayName("Проверить отображение информации по исполнителям на карточке процесса")
        public void checkProcessInfoByExecutorTest() {
            //TODO надо разобраться что не так в этом тесте
            String processName = "TestingProcess" + RandomString.get(16);
            String processId = backendBusinessProcess.createBusinessProcess("global", processName);
            String positionName = "TestTaskFromDifferentZone" + RandomString.get(4);
            String positionId = RandomString.getUUID();
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(positionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(userLogin), positionId);
            String lockHash = backendBusinessProcess.lock(processId);
            backendBusinessProcess.saveChanges(processId, lockHash,
                    new JsonBusinessProcess.Builder()
                            .setJsonFile("testData/JsonProcess/TaskInDifferentZone.json")
                            .setDraft(true)
                            .buildAndGetAsString());
            backendBusinessProcess.unlock(processId, lockHash);

            businessProcessPage.open("admin/process", processId);

            businessProcessPage.clickSettingsZoneResponsibility("Зона ответственности 2");
            settingsBlockModal.fillNameBlock(positionName);
            settingsBlockModal.selectExecutorInZoneResponsibility();
            settingsBlockModal.dialogWindowPressButton("Сохранить");
            businessProcessPage.clickSave();
            businessProcessPage.clickPublish();
            backendBusinessProcess.run(processId);
            backendBusinessProcess.run(processId);

            sectionPage.open("/tasks/income");
            sectionPage.clickTask("Задача 1", processName);
            taskModal.clickNext();

            processMonitorPage.open("admin/monitor/");
            processMonitorPage.selectProcess(processName);
            String adminName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);
            String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
            processMonitorPage.selectConditionInInstanceCountersPanel(adminName, 1);

            processMonitorPage.checkOnlyOneExecutorInInstanceResultTable(adminName);

            processMonitorPage.selectConditionInInstanceCountersPanel(userName, 1);

            processMonitorPage.checkOnlyOneExecutorInInstanceResultTable(userName);
        }

        @Test
        @Order(3)
        @Link(value = "f44bca7d-49d9-48b7-9e0f-986abba5e8f8", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f44bca7d-49d9-48b7-9e0f-986abba5e8f8)")
        @DisplayName("Проверить корректность отображения информации на вкладке История карточки экземпляра процесса")
        public void checkHistoryTabOnProcessInstanceCardTest() {
            String processName = "TestingProcess" + RandomString.get(16);
            String processId = backendBusinessProcess.createBusinessProcess("global", processName);
            String positionName = "TestTaskFromDifferentZone" + RandomString.get(4);
            String positionId = RandomString.getUUID();
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(positionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(userLogin), positionId);
            String lockHash = backendBusinessProcess.lock(processId);
            backendBusinessProcess.saveChanges(processId, lockHash,
                    new JsonBusinessProcess.Builder()
                            .setJsonFile("testData/JsonProcess/TaskInDifferentZone.json")
                            .setDraft(true)
                            .buildAndGetAsString());
            backendBusinessProcess.unlock(processId, lockHash);

            businessProcessPage.open("admin/process", processId);
            businessProcessPage.clickSettingsZoneResponsibility("Зона ответственности 2");

            settingsBlockModal.selectExecutorInZoneResponsibility();
            settingsBlockModal.dialogWindowPressButton("Сохранить");
            businessProcessPage.clickSave();
            businessProcessPage.clickPublish();
            backendBusinessProcess.run(processId);

            sectionPage.open("/tasks/income");
            sectionPage.clickTask("Задача 1", processName);
            taskModal.clickNext();

            processMonitorPage.open("admin/monitor/");
            processMonitorPage.selectProcess(processName);
            processMonitorPage.openHistory();
            String datePattern = "\\d{1,2}.{5,}\\d{4}.{3},.\\d{1,2}:\\d{2}";
            String admin = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);
            String user = elmaBackend.getUserSurnameAndNameByEmail(userLogin);

            processInstanceModal.checkCountOfValuesByPatternInHistoryTable(datePattern, 2);
            processInstanceModal.checkCountOfValuesInHistoryTable(admin, 1);
            processInstanceModal.checkCountOfValuesInHistoryTable(user, 1);
            processInstanceModal.checkCountOfValuesInHistoryTable("Задача 2", 1);
        }

        @Test
        @Order(4)
        @Tag("Author=Hushvahtov")
        @Link(value = "be1ffef6-3e56-4bb2-b992-cc332fb1443d", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/be1ffef6-3e56-4bb2-b992-cc332fb1443d)")
        @DisplayName("Проверить верное вычисление руководителя после выполнения операции Получить руководителя")
        public void checkCorrectSupervisorAfterPerformingOperationGetSupervisorTest() {
            String positionName = "StructureForGetSupervisorPositionName" + RandomString.get(4);
            String processName = "StructureForGetSupervisorProcessName" + RandomString.get(8);
            String positionId = RandomString.getUUID();

            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(positionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(userLogin), positionId);

            String processId = backendBusinessProcess.createBusinessProcess("global", processName);
            String lockHash = backendBusinessProcess.lock(processId);
            backendBusinessProcess.saveChanges(processId, lockHash,
                    new JsonBusinessProcess.Builder()
                            .setJsonFile("testData/JsonProcess/ProcessOperationsGetSupervisor.json")
                            .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                            .buildAndGetAsString());
            backendBusinessProcess.unlock(processId, lockHash);

            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();

            sectionPage.open("tasks/income");
            sectionPage.startCompanyProcessWithName(processName);
            sectionPage.clickNextStageOrExit();
            sectionPage.open("tasks/income");
            sectionPage.clickTask(processName, "Задача 1");

            String fio = elmaBackend.getUserFIOByEmail(adminLogin);
            taskModal.checkInputFormRowValue("user_supervisor", fio);
        }
    }

    @Nested
    @Order(2)
    @Tags({@Tag("ordered"), @Tag("ordered_org_struct")})
    @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
    public class OrgStructureTests {

        @AfterEach
        public void setDefaultOrgStructure() {
            backendOrgStructure.createOrgStructure(DEFAULT_ORG_STRUCTURE);
        }

        @Test
        @Order(1)
        @Link(value = "b5012be0-7d9a-418b-91e2-76daa35a143b", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b5012be0-7d9a-418b-91e2-76daa35a143b)")
        @DisplayName("Добавить новую должность")
        public void addNewPositionInOrgStructureTest() {
            backendOrgStructure.createOrgStructure(new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .buildAndGetAsString());

            orgStructurePage.open();
            orgStructurePage.clickAddPosition();
            String structName = "TestStructure" + RandomString.get(8);
            orgStructurePage.fillName(structName);
            orgStructurePage.clickSaveButton();

            orgStructurePage.checkElementNameExists(structName);
        }

        @Test
        @Order(2)
        @Link(value = "af08c1cb-31c5-4871-a870-7b4e6963cdc6", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/af08c1cb-31c5-4871-a870-7b4e6963cdc6)")
        @DisplayName("Добавить новую группу сотрудников")
        public void addNewGroupInOrgStructureTest() {
            backendOrgStructure.createOrgStructure(new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .buildAndGetAsString());

            orgStructurePage.open();
            orgStructurePage.clickAddGroup();
            String structName = "TestStructure" + RandomString.get(8);
            orgStructurePage.fillName(structName);
            orgStructurePage.clickSaveButton();

            orgStructurePage.checkElementNameExists(structName);
        }

        @Test
        @Order(3)
        @Link(value = "62068bfc-1e4a-44a1-a714-629677c7618e", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/62068bfc-1e4a-44a1-a714-629677c7618e)")
        @DisplayName("Добавить новый отдел")
        public void addNewDepartmentInOrgStructureTest() {
            backendOrgStructure.createOrgStructure(new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .buildAndGetAsString());

            orgStructurePage.open();
            orgStructurePage.clickAddDepartment();
            String structName = "TestStructure" + RandomString.get(8);
            orgStructurePage.fillName(structName);
            orgStructurePage.clickSaveButton();

            orgStructurePage.checkElementNameExists(structName);
        }

        @Test
        @Order(4)
        @Link(value = "ae48cd93-07b5-44e4-8a3d-f919bb030e6c", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ae48cd93-07b5-44e4-8a3d-f919bb030e6c)")
        @DisplayName("Проверить сохранение орг структуры")
        public void saveOrgStructureTest() {
            backendOrgStructure.createOrgStructure(new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .buildAndGetAsString());

            orgStructurePage.open();
            orgStructurePage.clickAddPosition();
            String structName = "TestStructure" + RandomString.get(8);
            orgStructurePage.fillName(structName);
            orgStructurePage.clickSaveButton();

            orgStructurePage.checkElementNameExists(structName);
        }

        @Test
        @Order(5)
        @Tag("Author=Hushvahtov")
        @Link(value = "5173f466-1351-4394-8ae1-4c34dc63c874", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5173f466-1351-4394-8ae1-4c34dc63c874)")
        @DisplayName("Добавить в права доступа Элемент орг структуры")
        public void addToAccessRightsOrgStructureTest() {
            String sectionName = "addToAccessRightsOrgStructureSectionName" + RandomString.get(8);
            String appName = "addToAccessRightsOrgStructureAppName" + RandomString.get(8);
            String idFolder = RandomString.getUUID();
            String nameFolder = "nameFolder" + RandomString.get(4);
            String nameAppItem = "nameAppItem" + RandomString.get(4);
            String idAppItem = RandomString.getUUID();
            String positionName = "AddToAccessRightsOrgStructure" + RandomString.get(4);
            String positionId = RandomString.getUUID();

            elmaBackend.createSection(sectionName);
            elmaBackend.createApplication(sectionName, appName);
            elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
            elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
            elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);

            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(positionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(userLogin), positionId);

            sectionPage.open(sectionName, appName);
            sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
            sectionPage.clickLimitAccess("Ограничить доступ к данным");
            sectionPage.clickLimitAccess("На уровне папок Приложения");
            sectionPage.clickSaveAccess();

            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();
            sectionPage.open(sectionName, appName);

            sectionPage.checkAppNotVisible(nameFolder);

            CustomDriver.clearStoredData();
            CustomDriver.setCookieAdmin();
            sectionPage.open(sectionName, appName);
            sectionPage.clickPencilButton();
            sectionPage.clickButtonSettingByFolder(nameFolder);
            sectionPage.selectSettingFolder("Права доступа");

            sectionPage.clickButtonAddInAccessRights();
            sectionPage.addRightToOrgStructure(positionName);
            sectionPage.clickButtonSelect();
            sectionPage.clickButtonSave();


            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();
            sectionPage.open(sectionName, appName);

            sectionPage.checkAppVisible(nameFolder);
            sectionPage.checkAppElementExist(nameAppItem);
        }
    }

    @Nested
    @Order(3)
    @Tags({@Tag("ordered"), @Tag("ordered_users")})
    @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
    public class BlockAndUnblockUserTests {

        private final String SECTION_CODE = "admin";
        private final String ADMIN_MAIN = "main";
        private final String USERS_CODE = "users";

        @AfterEach
        void userUnblock() {
            elmaBackend.changeUserStatus(userLogin, 3, "unblock");
            backendOrgStructure.createOrgStructure(DEFAULT_ORG_STRUCTURE);
            backendOrgStructure.setUserData(userLogin, new String[]{"f25906e4-41c3-5a89-8ec2-06648dd1f614"}, "Фамилия", "Имя", "");
            elmaBackend.setUserData(adminLogin, adminLogin, "", "");
            BackendUser.setTimeZoneLocalMachine(BackendUser.getAuthTokenUser(), userLogin);
        }

        @Test
        @Order(1)
        @Tag("Author=Hushvahtov")
        @Link(value = "c2d77213-b13f-4cca-97c1-f4c965b15fe6", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c2d77213-b13f-4cca-97c1-f4c965b15fe6)")
        @DisplayName("Разблокировать пользователя")
        public void checkUnblockUserTest() {
            elmaBackend.changeUserStatus(userLogin, 2, "block");

            adminSectionPage.open(SECTION_CODE, ADMIN_MAIN);
            adminSectionPage.clickLinkUsers();
            sectionPage.clickSearchInParametersTasks();
            userPageInAdminSectionPage.clickButtonFilterStatus();
            userPageInAdminSectionPage.clickButtonStatusBlock();
            userPageInAdminSectionPage.clickButtonSearch();
            userPageInAdminSectionPage.cLickUserProfile(userLogin);
            userPageInAdminSectionPage.clickButtonUnblockAndOk();
            adminSectionPage.refreshPage();

            Assertions.assertTrue(elmaBackend.isUserWithStatusExists(userLogin, ACTIVE),
                    "Пользователь с запрошенным логином и статусом не найден");
        }

        @Test
        @Order(2)
        @Tag("Author=Hushvahtov")
        @Link(value = "ad5e3e7d-115c-4efb-b7f0-c5f35ebd13fc", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ad5e3e7d-115c-4efb-b7f0-c5f35ebd13fc)")
        @DisplayName("Блокировать пользователя")
        public void checkBlockUserTest() {
            adminSectionPage.open(SECTION_CODE, ADMIN_MAIN);
            adminSectionPage.clickLinkUsers();
            userPageInAdminSectionPage.cLickUserProfile(userLogin);
            userPageInAdminSectionPage.clickButtonBlockAndOk();
            adminSectionPage.refreshPage();

            Assertions.assertTrue(elmaBackend.isUserWithStatusExists(userLogin, BLOCKED),
                    "Пользователь с запрошенным логином и статусом не найден");
        }

        @Test
        @Order(3)
        @Tag("Author=Hushvahtov")
        @Link(value = "4e8f1178-51b6-45f1-b61b-19504505067a", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4e8f1178-51b6-45f1-b61b-19504505067a)")
        @DisplayName("Редактировать пользователя")
        public void checkEditUserTest() {
            DateTimeFormatter formatAssert = ofPattern("d MMMM yyyy г.");
            String firstName = "FirstName";
            String lastName = "User";
            String middleName = "MiddleName";
            String workPhone = "+79887757144";
            String mobilePhone = "+79887756666";
            String group = "Администраторы";
            String namePhoto = "cats.jpg";
            String position = "TestStructure" + RandomString.get(8);
            LocalDate birthday = LocalDate.of(1999, 1, 2);
            LocalDate employmentDate = LocalDate.of(2021, 10, 2);
            String localMachineCurrentTimezone = ZonedDateTime.now().getZone().getId();
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(position)
                    .setId(RandomString.getUUID())
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();

            // Опасное действие с оргструктурой: заменить текущую на созданную в тесте.
            backendOrgStructure.createOrgStructure(jsonOrgStructure);

            userPageInAdminSectionPage.open(SECTION_CODE, USERS_CODE);
            userPageInAdminSectionPage.cLickUserProfile(userLogin);
            userPageInAdminSectionPage.clickEditButton();
            userPageInAdminSectionPage.inputFirstName(firstName);
            userPageInAdminSectionPage.inputLastName(lastName);
            userPageInAdminSectionPage.inputMiddleName(middleName);
            userPageInAdminSectionPage.inputWorkPhone(workPhone);
            userPageInAdminSectionPage.inputMobilePhone(mobilePhone);
            userPageInAdminSectionPage.inputDataBirthday(birthday.format(ofPattern("dd.MM.yyyy")));
            userPageInAdminSectionPage.inputEmploymentDate(employmentDate.format(ofPattern("dd.MM.yyyy")));
            userPageInAdminSectionPage.choosePosition();
            userPageInAdminSectionPage.chooseTimeZone(localMachineCurrentTimezone);
            userPageInAdminSectionPage.chooseGroup(group);
            userPageInAdminSectionPage.changePhoto("/testData/" + namePhoto);
            userPageInAdminSectionPage.clickButtonSave();

            Assertions.assertAll(
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditFIO(String.format("%s %s %s", lastName, firstName, middleName))),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditEmail(userLogin)),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditWorkPhone(workPhone)),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditMobilePhone(mobilePhone)),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditBirthday(birthday.format(formatAssert))),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditDateEmployment(employmentDate.format(formatAssert))),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditTimeZone(localMachineCurrentTimezone)),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditPosition(position)),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.checkEditGroups(group)),
                    () -> Assertions.assertTrue(userPageInAdminSectionPage.isImg(namePhoto)));
        }

        @Test
        @Order(4)
        @Tag("Author=Hushvahtov")
        @Link(value = "5b22c48c-531c-4b27-baf2-2dd6c3644185", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5b22c48c-531c-4b27-baf2-2dd6c3644185)")
        @DisplayName("Изменить данные в профиле пользователя - поменять ФИО")
        public void checkChangeFullName() {
            String firstName = "FirstName";
            String lastName = "Admin";
            String middleName = "MiddleName";

            mainPage.open();
            mainPage.clickUserWidget();
            mainPage.clickSettingProfUser();
            userSettingsModal.inputFirstName(firstName);
            userSettingsModal.inputLastName(lastName);
            userSettingsModal.inputMiddleName(middleName);
            userSettingsModal.clickButtonSave();
            mainPage.refreshPage();

            assertTrue(elmaBackend.getUserInfoById(elmaBackend.getUserIdByEmail(adminLogin))
                            .contains(format("%s %s %s", lastName, firstName, middleName)),
                    "ФИО не соответствует ожидаемому");
        }
    }

    @Nested
    @Order(4)
    @Tags({@Tag("ordered"), @Tag("ordered_substitution")})
    @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
    public class SubstitutionTests {

        @BeforeEach
        public void deleteSubstitutions() {
            elmaBackend.deleteComingAndActiveSubstitutions();
        }

        @Test
        @Order(1)
        @Tag("Author=Hushvahtov")
        @Link(value = "ae796842-e09b-406b-a6ad-d6c399b6c27d", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ae796842-e09b-406b-a6ad-d6c399b6c27d)")
        @DisplayName("Удалить будущее замещение")
        public void checkDeleteSubstitution() {
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().plusDays(20),
                    now().plusDays(21));

            substitutionPage.open("/admin/substitution/coming");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickComingSubstitution();
            substitutionPage.clickSubstitution();
            substitutionPage.clickEditButton();
            substitutionPage.clickDeleteButton();

            assertEquals(--countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(2)
        @Tag("Author=Hushvahtov")
        @Link(value = "9a1cacaf-094a-432e-8690-ecd846b8104a", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9a1cacaf-094a-432e-8690-ecd846b8104a)")
        @DisplayName("Прервать текущее замещение")
        public void checkAbortCurrentSubstitution() {
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().minusDays(1),
                    now().plusDays(1));

            substitutionPage.open("/admin/substitution/current");

            int countBefore = elmaBackend.getCurrentSubstitutionCount();

            substitutionPage.clickCurrentSubstitution();
            substitutionPage.clickSubstitution();
            substitutionPage.clickEditButton();
            substitutionPage.clickDeleteButton();
            substitutionPage.refreshPage();
            int countAfter = elmaBackend.getCurrentSubstitutionCount();

            assertEquals(--countBefore, countAfter,
                    "Количество замещений в архиве не соответствует ожидаемым");
        }

        @Test
        @Order(3)
        @Tag("Author=Hushvahtov")
        @Link(value = "bc06bf28-45e1-424f-ab70-38a1083b0ceb", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bc06bf28-45e1-424f-ab70-38a1083b0ceb)")
        @DisplayName("Редактировать текущее замещение")
        public void checkEditCurrentSubstitution() {
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().minusDays(1), now().plusDays(1));

            substitutionPage.open("admin/substitution/current");
            substitutionPage.clickCurrentSubstitution();
            substitutionPage.clickSubstitution();
            substitutionPage.clickEditButton();
            substitutionPage.inputChangeEndDateCss(now().plusWeeks(5).format(ofPattern("dd.MM.yyyy")));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            substitutionPage.checkEditFinishData(now().plusWeeks(5).format(ofPattern("d MMMM yyyy г.")));
        }

        @Test
        @Order(4)
        @Tag("Author=Hushvahtov")
        @Link(value = "a21c66fd-94b8-4ae2-bcf4-c8f3de342f05", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a21c66fd-94b8-4ae2-bcf4-c8f3de342f05)")
        @DisplayName("Редактировать будущее замещение")
        public void checkEditFutureSubstitution() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            DateTimeFormatter formatAssert = ofPattern("d MMMM yyyy г.");
            LocalDateTime startData = now().plusWeeks(4);
            LocalDateTime endData = now().plusWeeks(5);
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().plusDays(20), now().plusDays(22));

            substitutionPage.open("admin/substitution/current");
            substitutionPage.clickComingSubstitution();
            substitutionPage.clickSubstitution();
            substitutionPage.clickEditButton();
            substitutionPage.chooseTypeInformation();
            substitutionPage.inputChangeStartDateCss(startData.format(format));
            substitutionPage.inputChangeEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            substitutionPage.checkEditType("Информирование");
            substitutionPage.checkEditStartData(startData.format(formatAssert));
            substitutionPage.checkEditFinishData(endData.format(formatAssert));
        }

        @Test
        @Order(5)
        @Tag("Author=Hushvahtov")
        @Link(value = "62a23b00-4262-4cc1-a76e-0266470a013e", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/62a23b00-4262-4cc1-a76e-0266470a013e)")
        @DisplayName("Добавить замещение с типом Полная передача прав на будущую дату")
        public void checkAddSubstitutionFullTransferOnFutureDate() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            LocalDateTime startData = now().plusDays(20);
            LocalDateTime endData = now().plusDays(25);

            substitutionPage.open("admin/substitution/current");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickCreateSubstitution();
            substitutionPage.chooseTypeFullTransfer();
            substitutionPage.clickButtonSearchMissing();
            substitutionPage.chooseUserByEmail(adminLogin);
            substitutionPage.clickButtonSearchSubstitute();
            substitutionPage.chooseUserByEmail(userLogin);
            substitutionPage.inputStartDateCss(startData.format(format));
            substitutionPage.inputEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            assertEquals(++countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(6)
        @Tag("Author=Hushvahtov")
        @Link(value = "8ab85d7a-e734-44b4-aee4-75768f87b7e6", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8ab85d7a-e734-44b4-aee4-75768f87b7e6)")
        @DisplayName("Добавить замещение с типом Переназначение задач на будущую дату")
        public void checkAddSubstitutionAssignTasksOnFutureDate() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            LocalDateTime startData = now().plusDays(15);
            LocalDateTime endData = now().plusDays(16);

            substitutionPage.open("admin/substitution/current");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickCreateSubstitution();
            substitutionPage.chooseTypeAssignTasks();
            substitutionPage.clickButtonSearchMissing();
            substitutionPage.chooseUserByEmail(adminLogin);
            substitutionPage.clickButtonSearchSubstitute();
            substitutionPage.chooseUserByEmail(userLogin);
            substitutionPage.inputStartDateCss(startData.format(format));
            substitutionPage.inputEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            assertEquals(++countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(7)
        @Tag("Author=Hushvahtov")
        @Link(value = "a162cd20-9f69-4a47-bcf7-4de9a94bd731", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a162cd20-9f69-4a47-bcf7-4de9a94bd731)")
        @DisplayName("Добавить замещение с типом Информирование на будущую дату")
        public void checkAddSubstitutionInformationOnFutureDate() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            LocalDateTime startData = now().plusDays(10);
            LocalDateTime endData = now().plusDays(11);

            substitutionPage.open("admin/substitution/current");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickCreateSubstitution();
            substitutionPage.chooseTypeInformation();
            substitutionPage.clickButtonSearchMissing();
            substitutionPage.chooseUserByEmail(adminLogin);
            substitutionPage.clickButtonSearchSubstitute();
            substitutionPage.chooseUserByEmail(userLogin);
            substitutionPage.inputStartDateCss(startData.format(format));
            substitutionPage.inputEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            assertEquals(++countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(8)
        @Tag("Author=Hushvahtov")
        @Link(value = "99746ac3-4d0f-4f27-b049-fcf0cbe4b285", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/99746ac3-4d0f-4f27-b049-fcf0cbe4b285)")
        @DisplayName("Добавить замещение с типом Полная передача прав на текущую дату")
        public void checkAddSubstitutionFullTransferOnCurrentDate() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            LocalDateTime startData = now();
            LocalDateTime endData = now().plusDays(5);

            substitutionPage.open("admin/substitution/current");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickCreateSubstitution();
            substitutionPage.chooseTypeFullTransfer();
            substitutionPage.clickButtonSearchMissing();
            substitutionPage.chooseUserByEmail(adminLogin);
            substitutionPage.clickButtonSearchSubstitute();
            substitutionPage.chooseUserByEmail(userLogin);
            substitutionPage.inputStartDateCss(startData.format(format));
            substitutionPage.inputEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            companyPage.open("/company/birthdays");
            companyPage.clickUsersPage();
            companyPage.refreshPage();

            companyPage.checkSubstitutionUser(format("Отсутствует с %s по %s", startData.format(format), endData.format(format)));
            assertEquals(++countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(9)
        @Tag("Author=Hushvahtov")
        @Link(value = "b72a1ed6-e9e9-4261-b813-5cc12ab16131", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b72a1ed6-e9e9-4261-b813-5cc12ab16131)")
        @DisplayName("Добавить замещение с типом Переназначение задач на текущую дату")
        public void checkAddSubstitutionAssignTasksOnCurrentDate() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            LocalDateTime startData = now();
            LocalDateTime endData = now().plusDays(5);

            substitutionPage.open("admin/substitution/current");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickCreateSubstitution();
            substitutionPage.chooseTypeAssignTasks();
            substitutionPage.clickButtonSearchMissing();
            substitutionPage.chooseUserByEmail(adminLogin);
            substitutionPage.clickButtonSearchSubstitute();
            substitutionPage.chooseUserByEmail(userLogin);
            substitutionPage.inputStartDateCss(startData.format(format));
            substitutionPage.inputEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            companyPage.open("/company/birthdays");
            companyPage.clickUsersPage();
            companyPage.refreshPage();

            companyPage.checkSubstitutionUser(format("Отсутствует с %s по %s", startData.format(format), endData.format(format)));
            assertEquals(++countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(10)
        @Tag("Author=Hushvahtov")
        @Link(value = "c882011e-1044-4144-a9ad-1fb95ed7c498", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c882011e-1044-4144-a9ad-1fb95ed7c498)")
        @DisplayName("Добавить замещение с типом Информирование на текущую дату")
        public void checkAddSubstitutionInformationOnCurrentDate() {
            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            LocalDateTime startData = now();
            LocalDateTime endData = now().plusDays(5);

            substitutionPage.open("admin/substitution/current");

            int countSubstitution = elmaBackend.getAllSubstitutionCount();

            substitutionPage.clickCreateSubstitution();
            substitutionPage.chooseTypeInformation();
            substitutionPage.clickButtonSearchMissing();
            substitutionPage.chooseUserByEmail(adminLogin);
            substitutionPage.clickButtonSearchSubstitute();
            substitutionPage.chooseUserByEmail(userLogin);
            substitutionPage.inputStartDateCss(startData.format(format));
            substitutionPage.inputEndDateCss(endData.format(format));
            substitutionPage.clickEditButton();
            substitutionPage.refreshPage();

            companyPage.open("/company/birthdays");
            companyPage.clickUsersPage();
            companyPage.refreshPage();

            companyPage.checkSubstitutionUser(format("Отсутствует с %s по %s", startData.format(format), endData.format(format)));
            assertEquals(++countSubstitution, elmaBackend.getAllSubstitutionCount(),
                    "Количество замещений не соответствует ожидаемым");
        }

        @Test
        @Order(11)
        @Tag("Author=Hushvahtov")
        @Link(value = "107ab1d5-2759-4031-a0f9-d7562f5fee7f", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/107ab1d5-2759-4031-a0f9-d7562f5fee7f)")
        @DisplayName("Проверить отображение замещений в разделе В плане")
        public void checkDisplaySubstitutionsInSectionPlan() {
            // дата для api по гринвичу.
            LocalDateTime startDate = now(ZoneId.of("UTC")).plusDays(20);
            LocalDateTime endDate = now(ZoneId.of("UTC")).plusDays(21);
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    startDate,
                    endDate);
            // дата для веба с учётом пояса.
            startDate = now().plusDays(20);
            substitutionPage.open("admin/substitution/coming");

            substitutionPage.checkListSubstitutionDisplay();
            substitutionPage.checkStartDate(startDate.format(ofPattern("d MMMM yyyy г.")));
        }

        @Test
        @Order(12)
        @Tag("Author=Hushvahtov")
        @Link(value = "a59420bd-b963-4ea6-80ab-bdc03e6091fa", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a59420bd-b963-4ea6-80ab-bdc03e6091fa)")
        @DisplayName("Проверить отображение замещений в разделе Текущие")
        public void checkDisplaySubstitutionsInSectionCurrent() {
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().minusDays(1),
                    now().plusDays(1));

            substitutionPage.open("admin/substitution/current");

            substitutionPage.checkListSubstitutionDisplay();
            substitutionPage.checkStartDate(now().format(ofPattern("d MMMM yyyy г.")));
        }

        @Test
        @Order(13)
        @Tag("Author=Hushvahtov")
        @Link(value = "09401cab-249e-42b7-ae3f-a81eb52e5c7c", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/09401cab-249e-42b7-ae3f-a81eb52e5c7c)")
        @DisplayName("Проверить отображение замещений в разделе Все")
        public void checkDisplaySubstitutionsInSectionAll() {
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().plusDays(20),
                    now().plusDays(21));

            substitutionPage.open("admin/substitution/all");

            substitutionPage.checkListSubstitutionDisplay();
        }

        @Test
        @Order(14)
        @Tag("Author=Hushvahtov")
        @Link(value = "e901e328-a1ec-46ff-9a9c-7d1eb91b11fa", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e901e328-a1ec-46ff-9a9c-7d1eb91b11fa)")
        @DisplayName("Проверить отображение замещений в разделе Архив")
        public void checkDisplaySubstitutionsInSectionArchive() {
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN,
                    now().minusDays(1),
                    now().plusDays(1));
            elmaBackend.deleteComingAndActiveSubstitutions();

            substitutionPage.open("admin/substitution/archive");

            substitutionPage.checkListSubstitutionDisplay();
        }

        @Test
        @Order(15)
        @Tag("Author=Hushvahtov")
        @Link(value = "312decb1-8f92-4d1b-8f05-728beaa06828", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/312decb1-8f92-4d1b-8f05-728beaa06828)")
        @DisplayName("Проверить отображение информации об отсутствии за указанное в настройках число дней")
        public void checkDisplayInformationInSettingSubstitution() {
            // дата для api по гринвичу.
            LocalDateTime startDate = now(ZoneId.of("UTC")).plusDays(9);
            LocalDateTime endDate = now(ZoneId.of("UTC")).plusDays(11);

            DateTimeFormatter format = ofPattern("dd.MM.yyyy");
            elmaBackend.createPublicApiSubstitutionEmployees(REASSIGN, startDate, endDate);
            // дата для веба с учётом пояса.
            startDate = now().plusDays(9);
            endDate = now().plusDays(11);

            substitutionPage.open("admin/substitution/coming");
            substitutionPage.clickSettingButton();
            substitutionPage.inputAdvanceNotification("10");
            substitutionPage.clickEditButton();

            companyPage.open("/company/birthdays");
            companyPage.clickUsersPage();
            companyPage.refreshPage();

            companyPage.checkSubstitutionUser(format("Отсутствует с %s по %s", startDate.format(format), endDate.format(format)));

            elmaBackend.deleteComingAndActiveSubstitutions();
        }
    }

    @Nested
    @Order(5)
    @Tags({@Tag("ordered"), @Tag("org_structure")})
    @TestMethodOrder(MethodOrderer.OrderAnnotation.class)
    public class EditOrgStructureTests {

        @AfterEach
        public void setDefaultOrgStructure() {
            backendOrgStructure.createOrgStructure(DEFAULT_ORG_STRUCTURE);
        }

        @Test
        @Order(1)
        @Tag("Author=Hushvahtov")
        @Link(value = "296f2ae1-0857-4b82-aedc-c64939d93015", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/296f2ae1-0857-4b82-aedc-c64939d93015)")
        @DisplayName("Проверить возможность перехода со страницы отдела обратно в орг структуру")
        public void checkSwitchedFromDepartmentPageBackToOrgStructureTest() {
            String positionId = RandomString.getUUID();
            String departmentId = RandomString.getUUID();
            String departmentName = "DEPARTMENTName" + RandomString.get(8);
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(departmentName)
                    .setId(departmentId)
                    .setType("DEPARTMENT")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName("Начальник отдела\r\n\"Генеральный директор\"")
                    .setId(positionId)
                    .setType("POSITION")
                    .setParentId(departmentId)
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.clickButtonCollapseArrowUp(departmentName);
            orgStructurePage.clickDepartment(departmentName);
            orgStructurePage.clickButtonReturn();

            orgStructurePage.checkDepartment(departmentName);
        }

        @Test
        @Order(2)
        @Tag("Author=Hushvahtov")
        @Link(value = "41979993-d02f-4a42-b07a-03dc1951713e", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/41979993-d02f-4a42-b07a-03dc1951713e)")
        @DisplayName("Удалить элемент орг структуры, из которого есть исходящие элементы")
        public void deleteElementOrgStructureOutgoingElementsTest() {
            String positionIdOne = RandomString.getUUID();
            String positionIdTwo = RandomString.getUUID();
            String positionName = "PositionName" + RandomString.get(4);
            String positionNameTwo = "PositionNameTwo" + RandomString.get(4);
            String groupName = "GroupName" + RandomString.get(4);
            String groupNameTwo = "GroupNameTwo" + RandomString.get(4);
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setId(positionIdOne)
                    .setType("POSITION")
                    .setName(positionName)
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setId(RandomString.getUUID())
                    .setType("GROUP")
                    .setName(groupName)
                    .setParentId(positionIdOne)
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setId(positionIdTwo)
                    .setType("POSITION")
                    .setName(positionNameTwo)
                    .setSort(1)
                    .setParentId(positionIdOne)
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setId(RandomString.getUUID())
                    .setType("GROUP")
                    .setName(groupNameTwo)
                    .setParentId(positionIdTwo)
                    .addStructureInJsonArray()
                    .buildAndGetAsString();

            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.clickDeleteButtonPosition(positionName);
            orgStructurePage.clickDeleteButtonModalWindow();

            orgStructurePage.checkAbsenceOfPosition(positionName);
        }

        @Test
        @Order(3)
        @Tag("Author=Hushvahtov")
        @Link(value = "72cc1719-3754-4536-b1ca-e6b057b927be", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/72cc1719-3754-4536-b1ca-e6b057b927be)")
        @DisplayName("Переименовать элемент орг структуры с помощью двойного клика на элемент")
        public void renameOrgStructureByDoubleClickOnElementTest() {
            String departmentId = RandomString.getUUID();
            String departmentName = "DepartmentName" + RandomString.get(4);
            String newDepartmentName = "NewDepartmentName";
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(departmentName)
                    .setId(departmentId)
                    .setType("DEPARTMENT")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName("Начальник отдела\r\n\"Генеральный директор\"")
                    .setId(RandomString.getUUID())
                    .setType("POSITION")
                    .setParentId(departmentId)
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.repositionName(departmentName, newDepartmentName);
            orgStructurePage.checkDepartment(newDepartmentName);
        }

        @Test
        @Order(4)
        @Tag("Author=Hushvahtov")
        @Link(value = "76b54d13-3f54-47dc-9995-a24dfd466487", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/76b54d13-3f54-47dc-9995-a24dfd466487)")
        @DisplayName("Проверить возможность перехода в отдел")
        public void checkPossibilityMoveToDepartmentTest() {
            String departmentId = RandomString.getUUID();
            String departmentName = "DepartmentName" + RandomString.get(8);
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(departmentName)
                    .setId(departmentId)
                    .setType("DEPARTMENT")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName("Начальник отдела\r\n\"Генеральный директор\"")
                    .setId(RandomString.getUUID())
                    .setType("POSITION")
                    .setParentId(departmentId)
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.clickButtonCollapseArrowUp(departmentName);
            orgStructurePage.clickDepartment(departmentName);
            orgStructurePage.checkButtonReturn();
        }

        @Test
        @Order(5)
        @Tag("Author=Hushvahtov")
        @Link(value = "bd63ab96-84df-4310-84ed-9d560bad926e", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bd63ab96-84df-4310-84ed-9d560bad926e)")
        @DisplayName("Переместить элемент орг структуры при добавлении")
        public void checkMoveElementOfOrgStructureWhenAddTest() {
            String positionName = "PositionName" + RandomString.get(4);
            String newPositionName = "NewPositionName" + RandomString.get(4);
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(RandomString.getUUID())
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.addPosition("Генеральный директор");
            orgStructurePage.fillName(newPositionName);
            orgStructurePage.clickSaveButton();
            orgStructurePage.movePosition(newPositionName);

            orgStructurePage.checkFirstPosition(newPositionName);
        }

        @Test
        @Order(6)
        @Tag("Author=Hushvahtov")
        @Link(value = "d72b2068-353e-4cae-b1f5-692bc2098b42", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d72b2068-353e-4cae-b1f5-692bc2098b42)")
        @DisplayName("Переименовать элемент орг структуры с помощью кнопки редактировать")
        public void renameOrgStructureElementUseEditButtonTest() {
            String positionName = "positionName" + RandomString.get(4);
            String positionNewName = "positionNewName" + RandomString.get(4);
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(positionName)
                    .setId(RandomString.getUUID())
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.repositionNameWithButtonEdit(positionName, positionNewName);
            orgStructurePage.clickSaveButton();

            orgStructurePage.checkExistPosition(positionNewName);
        }

        @Test
        @Order(7)
        @Tag("Author=Hushvahtov")
        @Link(value = "dc1049bf-3677-4c54-b929-d05d81116358", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/dc1049bf-3677-4c54-b929-d05d81116358)")
        @DisplayName("Удалить элемент орг структуры при добавлении")
        public void deleteOrgStructureElementWhenAddTest() {
            String positionName = "positionName" + RandomString.get(4);
            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);
            orgStructurePage.open();
            orgStructurePage.addPosition("Генеральный директор");
            orgStructurePage.fillName(positionName);
            orgStructurePage.clickSaveButton();
            orgStructurePage.clickDeleteButtonPosition(positionName);

            orgStructurePage.checkAbsenceOfPosition(positionName);
        }

        @Test
        @Order(8)
        @Tag("Author=Krasilnikov")
        @Link(value = "e218c6d7-fece-4852-9377-a38c28cfcc7e", type = ELMA_TMS)
        @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e218c6d7-fece-4852-9377-a38c28cfcc7e)")
        @DisplayName("Проверить перемещение элемента оргструктуры с помощью стрелок")
        public void moveOrgStructureElementTest() {
            String firstPositionName = "firstPositionName" + RandomString.get(4);
            String firstPositionId = RandomString.getUUID();
            String secondPositionName = "secondPositionName" + RandomString.get(4);
            String secondPositionId = RandomString.getUUID();

            String jsonOrgStructure = new JsonOrgStructure.Builder()
                    .addNewPositionInJson(new JsonOrgStructure.Builder()
                            .setJsonFile("testData/OrgStructure/PositionCreation.json")
                            .createDefault())
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(firstPositionName)
                    .setId(firstPositionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .setJsonFile("testData/OrgStructure/PositionCreation.json")
                    .setName(secondPositionName)
                    .setSort(1)
                    .setId(secondPositionId)
                    .setType("POSITION")
                    .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                    .addStructureInJsonArray()
                    .buildAndGetAsString();
            backendOrgStructure.createOrgStructure(jsonOrgStructure);

            orgStructurePage.open();
            orgStructurePage.movePosition(secondPositionName);

            orgStructurePage.checkFirstPosition(secondPositionName);
        }
    }
}
