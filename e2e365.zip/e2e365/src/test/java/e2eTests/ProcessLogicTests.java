package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.LogicGatewaySettingsModal;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.InterfaceDesignerPage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;

@MicronautTest
@Tags({@Tag("express"), @Tag("process_logic")})
public class ProcessLogicTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected LogicGatewaySettingsModal logicGatewaySettingsModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "0e7445c0-b9bf-4f15-82c5-3b5c6cf0e9ec", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0e7445c0-b9bf-4f15-82c5-3b5c6cf0e9ec)")
    @DisplayName("Проверить работу перехода по умолчанию")
    public void checkDefaultTransitionTest() {
        String businessProcessName = "checkDefaultTransitionProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskOrOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Переходы");
        logicGatewaySettingsModal.selectDefaultTransition("Задача 1");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "20333f64-9abc-4ef4-bb57-ae0bad89d173", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/20333f64-9abc-4ef4-bb57-ae0bad89d173)")
    @DisplayName("Изменить порядок проверки условий")
    public void checkTransitionOrderTest() {
        String businessProcessName = "checkTransitionOrderProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskOrOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Переходы");
        logicGatewaySettingsModal.moveTransitionSlightlyBelowTransition("Задача 1", "Задача 2");
        logicGatewaySettingsModal.selectDefaultTransition("Задача 1");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "2089e220-343d-404d-a642-a09acfb79026", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2089e220-343d-404d-a642-a09acfb79026)")
    @DisplayName("Задать условие перехода для перехода из шлюза")
    public void checkTransitionByConditionTest() {
        String businessProcessName = "checkTransitionByConditionProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskOrOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Переходы");
        logicGatewaySettingsModal.selectDefaultTransition("Задача 2");
        logicGatewaySettingsModal.openTransitionSettings("Задача 1");
        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addBooleanCondition("Выбор", "Да");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        interfaceDesignerPage.selectProcessStartCondition("Да");
        sectionPage.processStartConfirmation();

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "2b5ae03f-e378-4ad1-af8d-fb8ee6239692", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2b5ae03f-e378-4ad1-af8d-fb8ee6239692)")
    @DisplayName("Проверить использование служебной переменной типа да нет в ИЛИ-шлюзе")
    public void checkBooleanVariableUsageTest() {
        String businessProcessName = "checkBooleanVariableUsageProcessName" + RandomString.get(8);
        String scenarioName = "checkBooleanVariableUsageScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskOrOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Выбор");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return true");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Переходы");
        logicGatewaySettingsModal.selectDefaultTransition("Задача 2");
        logicGatewaySettingsModal.openTransitionSettings("Задача 1");
        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addBooleanCondition("Служебная переменная шлюза", "Да");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b5af4fe5-e475-4ecd-bac8-3e683dd083e3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b5af4fe5-e475-4ecd-bac8-3e683dd083e3)")
    @DisplayName("Проверить использование служебной переменной типа число в ИЛИ-Шлюзе")
    public void checkNumericVariableUsageTest() {
        String businessProcessName = "checkNumericVariableUsageProcessName" + RandomString.get(8);
        String scenarioName = "checkNumericVariableUsageScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskOrOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Число");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return 1");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Переходы");
        logicGatewaySettingsModal.selectDefaultTransition("Задача 2");
        logicGatewaySettingsModal.openTransitionSettings("Задача 1");
        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addConditionWithNonNullCheck("Служебная переменная шлюза", "Не пустое значение");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d3dae0d1-a27d-4e84-b29f-b4f49c324da1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d3dae0d1-a27d-4e84-b29f-b4f49c324da1)")
    @DisplayName("Проверить использование служебной переменной типа строка в ИЛИ-Шлюзе")
    public void checkStringVariableUsageTest() {
        String businessProcessName = "checkStringVariableUsageProcessName" + RandomString.get(8);
        String scenarioName = "checkStringVariableUsageScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskOrOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Строка");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return \"string\"");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Переходы");
        logicGatewaySettingsModal.selectDefaultTransition("Задача 2");
        logicGatewaySettingsModal.openTransitionSettings("Задача 1");
        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addConditionWithNonNullCheck("Служебная переменная шлюза", "Не пустое значение");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "0d6b14a3-620c-47ac-b78e-3a56cbae06c6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0d6b14a3-620c-47ac-b78e-3a56cbae06c6)")
    @DisplayName("Проверить использование служебной переменной типа строка")
    public void checkStringVariableUsageInAndORGatewayTest() {
        String businessProcessName = "checkStringVariableUsageInAndORGatewayProcessName" + RandomString.get(8);
        String scenarioName = "checkStringVariableUsageInAndORGatewayScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskAndOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Строка");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return \"string\"");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLeftArrowFromGateway();

        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addConditionWithNonNullCheck("Служебная переменная шлюза", "Не пустое значение");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "13d382da-6a4f-4985-afad-d91a64c26113", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/13d382da-6a4f-4985-afad-d91a64c26113)")
    @DisplayName("Проверить использование служебной переменной типа число")
    public void checkNumericVariableUsageInAndORGatewayTest() {
        String businessProcessName = "checkNumericVariableUsageInAndORGatewayProcessName" + RandomString.get(8);
        String scenarioName = "checkNumericVariableUsageInAndORGatewayScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskAndOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Число");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return 1");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLeftArrowFromGateway();

        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addConditionWithNonNullCheck("Служебная переменная шлюза", "Не пустое значение");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "5e112588-bedc-4ea7-93d9-81e9b7de0d63", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5e112588-bedc-4ea7-93d9-81e9b7de0d63)")
    @DisplayName("Проверить использование служебной переменной типа да нет")
    public void checkBooleanVariableUsageInAndORGatewayTest() {
        String businessProcessName = "checkBooleanVariableUsageInAndORGatewayProcessName" + RandomString.get(8);
        String scenarioName = "checkBooleanVariableUsageInAndORGatewayScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskAndOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Выбор");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return true");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLeftArrowFromGateway();

        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addBooleanCondition("Служебная переменная шлюза", "Да");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "41c3b7a6-84b0-4f46-b2a7-b609b486d3b5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/41c3b7a6-84b0-4f46-b2a7-b609b486d3b5)")
    @DisplayName("Проверить использование служебной переменной, вычисляемой в сценарии")
    public void checkNumericVariableCalculatingInAndORGatewayTest() {
        String businessProcessName = "checkNumericVariableCalculatingInAndORGatewayProcessName" + RandomString.get(8);
        String scenarioName = "checkNumericVariableCalculatingInAndORGatewayScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskAndOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Число");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return 1 + 1");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLeftArrowFromGateway();

        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addConditionIntCheck("Служебная переменная шлюза", ">", 1);
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "f9a40830-e4eb-452c-a182-1235d7cf9447", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f9a40830-e4eb-452c-a182-1235d7cf9447)")
    @DisplayName("Задать условие перехода для перехода из шлюза")
    public void checkRedirectFromGatewayInAndORGatewayTest() {
        String businessProcessName = "checkRedirectFromGatewayInAndORGatewayProcessName" + RandomString.get(8);
        String scenarioName = "checkRedirectFromGatewayInAndORGatewayScenarioName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskAndOrGatewayAndTwoEndpoints.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickLogicGateway("Шлюз 1");

        logicGatewaySettingsModal.selectModalWindowTab("Служебная переменная");
        logicGatewaySettingsModal.clickServiceVariableUsage();
        logicGatewaySettingsModal.setServiceVariable("Выбор");
        logicGatewaySettingsModal.createAndOpenScenario(scenarioName);
        logicGatewaySettingsModal.fillFunction("return true");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickLeftArrowFromGateway();

        logicGatewaySettingsModal.selectModalWindowTab("Условия перехода");
        logicGatewaySettingsModal.addBooleanCondition("Служебная переменная шлюза", "Да");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        interfaceDesignerPage.selectProcessStartCondition("Да");
        sectionPage.processStartConfirmation();

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "c7401764-fded-4cfc-ad9a-7672ec1f38ca", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c7401764-fded-4cfc-ad9a-7672ec1f38ca)")
    @DisplayName("Проверить, что процесс не публикуется без указания завершающего шлюза")
    public void checkProcessNotPublishingWithoutEndGatewayTest() {
        String businessProcessName = "checkProcessNotPublishingWithoutEndGatewayProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskAndOrGatewayWithoutEndGateway.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        // открыть и закрыть, для полной загрузки страницы
        businessProcessPage.clickLogicGateway("Шлюз 1");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.checkCantPublish("Собирающий шлюз без парного разделяющего");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "040a4eae-d7da-4acb-b9ca-d0201e79c854", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/040a4eae-d7da-4acb-b9ca-d0201e79c854)")
    @DisplayName("Проверить, что процесс не публикуется без указания завершающего шлюза")
    // В тесте есть задача перетащить параллельный шлюз, а потом соединить его с другими элементами.
    // Данные действия крайне сложно автоматизировать, потому тест выполнен в общем стиле: через бэк.
    public void checkProcessWithParallelGatewayNotPublishingWithoutEndGatewayTest() {
        String businessProcessName = "checkProcessNotPublishingWithoutEndGatewayProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartConditionTaskParallelGatewayWithoutEndGateway.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        // открыть и закрыть, для полной загрузки страницы
        businessProcessPage.clickLogicGateway("Шлюз 1");
        logicGatewaySettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.checkCantPublish("Собирающий шлюз без парного разделяющего");
    }
}
