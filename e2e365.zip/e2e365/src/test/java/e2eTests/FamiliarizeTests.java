package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.DocumentTemplateCreatingModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaModals.WidgetSettingsModal;
import pages.elmaPages.*;

import java.time.LocalDate;
import java.util.Locale;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;
import static java.time.LocalDate.now;

@MicronautTest
@Tags({@Tag("express"), @Tag("familiarization")})
public class FamiliarizeTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected FilePage filePage;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected MessagePage messagePage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "45dce8fe-2b19-4c06-bc0b-2db3236d2a60", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/45dce8fe-2b19-4c06-bc0b-2db3236d2a60)")
    @DisplayName("Проверить прерывание выполнения задачи ознакомления при просрочке")
    public void checkInterruptionOfFamiliarizationTaskInCaseOfDelayTest() {
        int differenceOfTime = 1;
        String namePhoto = "cats.png";
        String nameFolder = "checkInterruptionOfFamiliarizationTaskInCaseOfDelayFolder" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);

        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String processName = "checkInterruptionOfFamiliarizationTaskInCaseOfDelayProcess" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeWithTaskProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.inputTimeMinuteLimitDeadline(differenceOfTime);
        settingsBlockModal.removeCheckMarkFromTakeIntoAccountWorkCalendar();
        settingsBlockModal.clickCheckboxAbortAndSelectNextStep();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Ознакомление", processName);

        // Ожидаем 1 минуту для проверки по истечению срока действия созданной задачи
        CustomDriver.waitMills(60000);
        // ссылка другая для того, что бы страница гарантированно обновилась
        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4afbb4f1-0968-42f3-848f-ff5fb01d5d21", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4afbb4f1-0968-42f3-848f-ff5fb01d5d21)")
    @DisplayName("Проверить ознакомление с элементом приложения")
    public void checkFamiliarizationWithAppElementTest() {
        String sectionName = "checkFamiliarizationWithAppElementSectionName" + RandomString.get(8);
        String appName = "checkFamiliarizationWithAppElementAppName" + RandomString.get(8);
        String elementName = "checkFamiliarizationWithAppElementElementName" + RandomString.get(8);
        String businessProcessName = "checkFamiliarizationWithAppElementBusinessProcessName" + RandomString.get(8);
        String variableName = "application" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, businessProcessName);
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.selectAppInModalWindow(elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName);
        sectionPage.clickFamiliarizationButton("Ознакомиться");
        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(elementName);

        widgetSettingsModal.checkVisibleListApproval("Ознакомились");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9321161e-9405-4d55-8001-b591386d71c8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9321161e-9405-4d55-8001-b591386d71c8)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи ознакомления с типом - контекстная переменная")
    public void checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariableTest() {
        LocalDate date = now().plusDays(5);

        String sectionName = "checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariableSectionName" + RandomString.get(8);
        String appName = "checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariableAppName" + RandomString.get(8);
        String elementName = "checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariableElementName" + RandomString.get(8);
        String processName = "checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariableProcess" + RandomString.get(8);
        String placeRegName = "checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariablePlaceReg" + RandomString.get(4);
        String dossierName = "checkTimeLimitSettingForTaskOfFamiliarizationWithTypeContextVariableDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(4);
        String variableTimerName = "timer" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.clickRadioButtonVariable();
        settingsBlockModal.expandDueDateMenuAndSelect(variableTimerName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "00:00");

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkDateFinishTask(processName, date);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "865927f3-c4c3-4130-8cf0-0c2c8e4b6034", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/865927f3-c4c3-4130-8cf0-0c2c8e4b6034)")
    @DisplayName("Изменить название задачи ознакомления, используя контекстные переменные")
    public void changeNameOfFamiliarizationTaskUsingContextVariablesTest() {
        String namePhoto = "cats.png";
        String nameFolder = "changeNameOfFamiliarizationTaskUsingContextVariablesFolder" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String variableName = "file" + RandomString.get(8);

        String processName = "checkInterruptionOfFamiliarizationTaskInCaseOfDelayProcess" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkTaskWithNameAppearFromProcess("Ознакомление", processName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b1184eaf-a250-4f82-8d8f-cffe8eb95543", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b1184eaf-a250-4f82-8d8f-cffe8eb95543)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи ознакомления с типом - точное время")
    public void checkTimeLimitSettingForCompletingTypeFamiliarizationTaskExactTimeTest() {
        int differenceOfDays = 5;
        String namePhoto = "cats.png";
        String nameFolder = "checkTimeLimitSettingForCompletingTypeFamiliarizationTaskExactTimeFolder" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String variableName = "file" + RandomString.get(8);

        String processName = "checkTimeLimitSettingForCompletingTypeFamiliarizationTaskExactTimeProcess" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.inputDateLimitDeadline(differenceOfDays);
        settingsBlockModal.removeCheckMarkFromTakeIntoAccountWorkCalendar();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkDifferentDateStartAndFinishDate(processName, differenceOfDays);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "dd2757f0-926b-4361-9ddd-632d4a3cd9df", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/dd2757f0-926b-4361-9ddd-632d4a3cd9df)")
    @DisplayName("Проверить ознакомление с файлом")
    public void checkFamiliarizationWithFileTest() {
        String namePhoto = "cats.png";
        String nameFolder = "checkFamiliarizationWithFileFolder" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String variableName = "file" + RandomString.get(8);

        String processName = "checkFamiliarizationWithFileProcess" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(namePhoto, processName);
        sectionPage.clickFamiliarizationButtonAndInputComment();
        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo("Листы ознакомления");

        widgetSettingsModal.checkVisibleCheckMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "11595931-da62-4d12-9261-fc5c8abbb5ac", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/11595931-da62-4d12-9261-fc5c8abbb5ac)")
    @DisplayName("Изменить название операции ознакомление")
    public void changeNotificationNameTest() {
        String processName = "changeFamiliarizeNameProcessName" + RandomString.get(4);
        String formName = "newFormName" + RandomString.get(4);
        String variableName = "file" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.setTextInputByFormRowName("Название", formName);
        settingsBlockModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Ознакомление 1", "Что посылаем на ознакомление", "", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.checkElementByName(formName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "9e04f448-aaa6-402a-bcfe-aefc7ceddcd3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9e04f448-aaa6-402a-bcfe-aefc7ceddcd3)")
    @DisplayName("Проверить отображение введенного текста сообщения при ознакомлении")
    public void checkViewTextMessageFamiliarizeTest() {
        String processName = "checkViewTextMessageFamiliarizeProcessName" + RandomString.get(4);
        String formName = "newFormName" + RandomString.get(4);
        String variableName = "file" + RandomString.get(4);
        String comment = "text for message" + RandomString.get(4);
        String namePhoto = "cats.png";
        String nameFolder = "checkFamiliarizationWithFileFolder" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.setTextInputByFormRowName("Название", formName);
        settingsBlockModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Ознакомление 1", "Что посылаем на ознакомление", "", variableName);
        settingsBlockModal.setTextBlockByFormRowName("Текст сообщения", comment);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(comment);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9ce23596-2165-400c-849f-446d66e5e1f7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9ce23596-2165-400c-849f-446d66e5e1f7)")
    @DisplayName("Проверить настройку \"Использовать пользовательский статус\" в Ознакомлении с элементом приложения")
    public void checkUserStatusSettingInFamiliarizeToAppElementTest() {
        String sectionName = "checkUserStatusSettingInFamiliarizeToAppElementSectionName" + RandomString.get(8);
        String appName = "checkUserStatusSettingInFamiliarizeToAppElementAppName" + RandomString.get(8);
        String elementName = "checkUserStatusSettingInFamiliarizeToAppElementElementName" + RandomString.get(8);
        String businessProcessName = "checkUserStatusSettingInFamiliarizeToAppElementBusinessProcessName" + RandomString.get(8);
        String variableName = "application" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.chooseTab("Пользовательские статусы");
        settingsBlockModal.setCheckboxConditionByLabel("Использовать пользовательский статус", true);
        settingsBlockModal.setTextInputByFormRowName("Текст кнопки в задаче", "Ознакомиться условно");
        settingsBlockModal.setTextInputByFormRowName("Текст статуса", "Ознакомлен с условием");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.selectAppInModalWindow(elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName);
        sectionPage.clickFamiliarizationButton(" Ознакомиться условно");

        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(elementName);

        widgetSettingsModal.checkTooltipTextByButtonName("approved", "Ознакомлен с условием");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3b553df3-4af7-4c8a-8760-f989e7c9d2dc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3b553df3-4af7-4c8a-8760-f989e7c9d2dc)")
    @DisplayName("Проверить пакетное ознакомление")
    public void checkBatchFamiliarizationTest() {
        String sectionName = "checkBatchFamiliarizationSectionName" + RandomString.get(8);
        String appNameOne = "checkBatchFamiliarizationAppNameOne" + RandomString.get(8);
        String appNameTwo = "checkBatchFamiliarizationAppNameTwo" + RandomString.get(8);
        String elementNameOne = "checkBatchFamiliarizationElementNameOne" + RandomString.get(8);
        String elementNameTwo = "checkBatchFamiliarizationElementNameTwo" + RandomString.get(8);
        String businessProcessName = "checkBatchFamiliarizationProcessName" + RandomString.get(8);
        String variableNameOne = "applicationOne" + RandomString.get(8);
        String variableNameTwo = "applicationTwo" + RandomString.get(8);
        String packageName = "package" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appNameOne);
        elmaBackend.createApplication(sectionName, appNameTwo);
        elmaBackend.createElement(elementNameOne, sectionName, appNameOne);
        elmaBackend.createElement(elementNameTwo, sectionName, appNameTwo);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessPackageFormationWithFamiliarize.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableNameOne, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appNameOne.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableNameOne, "", false, false, false)

                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableNameTwo, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appNameTwo.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableNameTwo, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(packageName, ContextType.REF_ITEM, false))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Формирование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документы для объединения", variableNameOne);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Пакет документов", packageName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документы для объединения", 2, variableNameTwo);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", packageName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);

        settingsBlockModal.clickButtonZoomAllWithRowName(variableNameOne);
        sectionPage.selectAppInModalWindow(elementNameOne);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableNameTwo);
        sectionPage.selectAppInModalWindow(elementNameTwo);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(packageName + ": Ознакомление", packageName);
        sectionPage.clickButtonInItemBoxByItemName(elementNameOne, "Оставить комментарий");
        sectionPage.inputComment("ок1");
        settingsBlockModal.clickConfirmDialogButton("Отправить");
        sectionPage.clickButtonInItemBoxByItemName(elementNameTwo, "Оставить комментарий");
        sectionPage.inputComment("ок2");
        sectionPage.clickConfirmDialogButton("Отправить");
        sectionPage.clickFamiliarizationButton("Ознакомиться");

        sectionPage.open(sectionName, appNameOne);
        sectionPage.clickOnCardApp(elementNameOne)
        ;
        widgetSettingsModal.checkVisibleListApproval("Ознакомились с пакетом");
        widgetSettingsModal.checkTooltipTextByButtonName("file", "Посмотреть пакет");

        sectionPage.open(sectionName, appNameTwo);
        sectionPage.clickOnCardApp(elementNameTwo);

        widgetSettingsModal.checkVisibleListApproval("Ознакомились с пакетом");
        widgetSettingsModal.checkTooltipTextByButtonName("file", "Посмотреть пакет");
    }

    //TODO: тест с багом, проходит только на t-elma365
    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a7f68d31-5956-46b2-a74a-646f3a5f64b5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a7f68d31-5956-46b2-a74a-646f3a5f64b5)")
    @DisplayName("Проверить настройку \"Использовать пользовательский статус\" в Ознакомлении с файлом")
    public void checkUserStatusSettingInFamiliarizeWithFileTest() {
        String businessProcessName = "checkUserStatusSettingInFamiliarizeWithFileBusinessProcessName" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);
        String namePhoto = "cats.png";
        String nameFolder = "checkUserStatusSettingInFamiliarizeWithFile" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Ознакомление");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что посылаем на ознакомление", variableName);
        settingsBlockModal.chooseTab("Пользовательские статусы");
        settingsBlockModal.setCheckboxConditionByLabel("Использовать пользовательский статус", true);
        settingsBlockModal.setTextInputByFormRowName("Текст кнопки в задаче", "Ознакомиться условно");
        settingsBlockModal.setTextInputByFormRowName("Текст статуса", "Ознакомлен с условием");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        //TODO: на t-elma365 не появляется alert с текст "Запущен процесс"
//        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(namePhoto, businessProcessName);
        sectionPage.clickModalHeaderButton(" Ознакомиться условно");
        settingsBlockModal.clickConfirmDialogButton("Ознакомиться");

        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo("Листы ознакомления");

        widgetSettingsModal.checkTooltipTextByButtonName("approved", "Ознакомлен с условием");
    }
}