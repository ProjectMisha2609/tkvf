package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.MessageModal;
import pages.elmaPages.MessagePage;

import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("message")})
public class MessagesTests {
    private final String SECTION_CODE = "messages";
    private final String FEED_CODE = "feed";

    @Inject
    protected MessagePage messagePage;
    @Inject
    protected MessageModal messageModal;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Link(value = "257517af-3647-4aa3-bc67-b9cc97ea0d69", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/257517af-3647-4aa3-bc67-b9cc97ea0d69)")
    @DisplayName("[Послать сообщение] Послать сообщение в \"Канал\"")
    public void sendMessageInChannelTest() {
        String channelName = "testMessage" + RandomString.get(4);
        String messageHeader = "sendMessageInChannelTestHeader" + RandomString.get(5);
        String messageText = "sendMessageInChannelTestMessage" + RandomString.get(5);

        messagePage.open(SECTION_CODE, FEED_CODE);
        messagePage.chooseSettingsOption("Добавить канал");
        messagePage.enterChannelNameModal(channelName);
        messageModal.dialogWindowPressButton("Добавить канал");
        messagePage.appToolbar().selectAppByName(channelName);
        messagePage.appHeaderToolbar().clickActionButton("Написать");
        messagePage.writeMessageHeader(messageHeader);
        messagePage.writeMessageText(messageText);
        messageModal.dialogWindowPressButton("Отправить");

        messagePage.checkHeaderAndTextEqual(messageHeader, messageText);
    }

    @Test
    @Link(value = "0a73648c-35e5-40e0-8fad-122cd970b705", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0a73648c-35e5-40e0-8fad-122cd970b705)")
    @DisplayName("[Послать сообщение] Послать сообщение \"Кому\"")
    public void sendMessageMentionTest() {
        String channelName = "testMention" + RandomString.get(4);
        String messageHeader = "sendMessageMentionTestHeader" + RandomString.get(5);
        String mentionUserEmail = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        String[] mentionUser = mentionUserEmail.split("@");
        String messageText = "sendMessageMentionTestMessage" + RandomString.get(5) + " @" + mentionUser[0];

        messagePage.open(SECTION_CODE, FEED_CODE);
        messagePage.chooseSettingsOption("Добавить канал");
        messagePage.enterChannelNameModal(channelName);
        messageModal.dialogWindowPressButton("Добавить канал");
        messagePage.appToolbar().selectAppByName(channelName);
        messagePage.chooseSettingsOption("Управление пользователями");
        messagePage.clickAddMentionUserInUsersControlModal(mentionUserEmail);
        messagePage.appHeaderToolbar().clickActionButton("Написать");
        messagePage.writeMessageHeader(messageHeader);
        messagePage.writeMessageText(messageText);
        messagePage.clickFirstUserInSendMessage();
        messageModal.dialogWindowPressButton("Отправить");
        CustomDriver.setCookieUser();
        messagePage.open(SECTION_CODE, FEED_CODE);
        messagePage.appToolbar().selectAppByName(channelName);

        messagePage.checkMentionExist(mentionUserEmail);
    }

    @Test
    @Link(value = "b8ff870f-8037-43d9-b008-db909482e8e5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b8ff870f-8037-43d9-b008-db909482e8e5)")
    @DisplayName("[Работа с сообщениями] Оставить комментарий")
    public void sendCommentaryTest() {
        String channelName = "testCommentary" + RandomString.get(4);
        String messageHeader = "sendCommentaryTestHeader" + RandomString.get(5);
        String messageText = "sendCommentaryTestMessage" + RandomString.get(5);
        String commentaryText = "sendCommentaryTestText" + RandomString.get(5);

        messagePage.open(SECTION_CODE, FEED_CODE);
        messagePage.chooseSettingsOption("Добавить канал");
        messagePage.enterChannelNameModal(channelName);
        messageModal.dialogWindowPressButton("Добавить канал");
        messagePage.appToolbar().selectAppByName(channelName);
        messagePage.appHeaderToolbar().clickActionButton("Написать");
        messagePage.writeMessageHeader(messageHeader);
        messagePage.writeMessageText(messageText);
        messageModal.dialogWindowPressButton("Отправить");
        messagePage.sendCommentary(commentaryText);

        messagePage.checkCommentaryExistAndEqual(commentaryText);
    }
}
