package e2eTests;

import infrastructure.drivers.CustomDriver;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaPages.LoginPage;
import pages.elmaPages.MainPage;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.adminPassword;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("login")})
public class LoginTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected LoginPage loginPage;

    @Test
    @Link(value = "951c2ae3-6ac2-45aa-99c2-5577760c7f0e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/951c2ae3-6ac2-45aa-99c2-5577760c7f0e)")
    @DisplayName("Вход в систему с существующей электронной почтой и верным паролем")
    public void authTest() {
        loginPage.open("_login");
        loginPage.fillEmail(adminLogin);
        loginPage.fillPassword(adminPassword);
        loginPage.clickLogin();

        mainPage.isAddSectionButtonExists();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "0ca3d250-e2d6-44b4-b9b0-fb21c2dfcc9f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0ca3d250-e2d6-44b4-b9b0-fb21c2dfcc9f)")
    @DisplayName("Проверить выход из системы")
    public void logoutTest() {
        mainPage.open();
        mainPage.logout();
        CustomDriver.clearStoredData();

        loginPage.isEmailVisible();
    }
}
