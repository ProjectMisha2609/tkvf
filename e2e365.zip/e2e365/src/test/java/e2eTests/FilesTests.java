package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.FileModal;
import pages.elmaModals.TaskModal;
import pages.elmaModals.WidgetSettingsModal;
import pages.elmaPages.FilePage;
import pages.elmaPages.FilePageInAdminSectionPage;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("files")})
public class FilesTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected FilePage filePage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected FilePageInAdminSectionPage filePageInAdminSectionPage;
    @Inject
    protected FileModal fileModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;


    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "067b7742-ae7a-414a-b163-7d8bb55ad9d3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/067b7742-ae7a-414a-b163-7d8bb55ad9d3)")
    @DisplayName("Проверить создание документа формата pptx")
    public void checkCreationOfPPTXDocumentTest() {
        String nameFile = "checkCreationOfPPTXDocument" + RandomString.get(8);
        filePageInAdminSectionPage.open("admin", "disk");
        filePageInAdminSectionPage.clickCheckmark();
        filePageInAdminSectionPage.clickButtonSave();
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.clickButtonPlusFile();
        filePage.selectTypeFile("PowerPoint");
        filePage.inputNameFile(nameFile);
        filePage.clickButtonCreate();
        filePage.clickButtonSystemClose();

        filePage.checkFileVisible(nameFile);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9b85de9c-850b-404f-a77c-0474967035fb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9b85de9c-850b-404f-a77c-0474967035fb)")
    @DisplayName("Проверить создание документа формата xlsx")
    public void checkCreationOfXLSXDocumentTest() {
        String nameFile = "checkCreationOfXLSXDocument" + RandomString.get(8);
        filePageInAdminSectionPage.open("admin", "disk");
        filePageInAdminSectionPage.clickCheckmark();
        filePageInAdminSectionPage.clickButtonSave();
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.clickButtonPlusFile();
        filePage.selectTypeFile("Excel");
        filePage.inputNameFile(nameFile);
        filePage.clickButtonCreate();
        filePage.clickButtonSystemClose();

        filePage.checkFileVisible(nameFile);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "6ec301d7-e10f-4fc7-b232-655fb22383d3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6ec301d7-e10f-4fc7-b232-655fb22383d3)")
    @DisplayName("Проверить создание документа формата docx")
    public void checkCreationOfDOCXDocumentTest() {
        String nameFile = "checkCreationOfDOCXDocument" + RandomString.get(8);
        filePageInAdminSectionPage.open("admin", "disk");
        filePageInAdminSectionPage.clickCheckmark();
        filePageInAdminSectionPage.clickButtonSave();
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.clickButtonPlusFile();
        filePage.selectTypeFile("Word");
        filePage.inputNameFile(nameFile);
        filePage.clickButtonCreate();
        filePage.clickButtonSystemClose();

        filePage.checkFileVisible(nameFile);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2a944396-e8ad-4b62-bdd7-b5be7cbc2184", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2a944396-e8ad-4b62-bdd7-b5be7cbc2184)")
    @DisplayName("Проверить работу настройки Использовать Office365 для работы с файлами")
    public void checkOperationOfSettingsWithFileTest() {
        filePageInAdminSectionPage.open("admin", "disk");
        filePageInAdminSectionPage.clickCheckmark();
        filePageInAdminSectionPage.clickButtonSave();
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.clickButtonPlusFile();

        filePage.checkTypeFileVisible("PowerPoint");
        filePage.checkTypeFileVisible("Excel");
        filePage.checkTypeFileVisible("Word");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3607019f-4b28-486e-9ef6-2ec5a9f0d50a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3607019f-4b28-486e-9ef6-2ec5a9f0d50a)")
    @DisplayName("Переместить")
    public void checkMoveFileTest() {
        String namePhoto = "cats.png";
        String nameFolder = "checkMoveFileNameFolder" + RandomString.get(8);
        elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        if (filePage.isFileNotExists(namePhoto))
            filePage.uploadingPhotos("/testData/images/" + namePhoto);
        filePage.clickCheckBoxByPhoto(namePhoto);
        filePage.clickButtonMoveAndSelectFolderPhoto(nameFolder);
        filePage.clickByFolderOrPhoto(nameFolder);

        filePage.checkFileVisible(namePhoto);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "8069adf0-788f-4b9d-a868-5402fe659e53", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8069adf0-788f-4b9d-a868-5402fe659e53)")
    @DisplayName("Добавить в избранное")
    public void checkAddToFavoritesFileTest() {
        String namePhoto = "cats.png";
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        if (filePage.isFileNotExists(namePhoto))
            filePage.uploadingPhotos("/testData/images/" + namePhoto);
        filePage.clickCheckBoxByPhoto(namePhoto);
        filePage.clickButtonFavoritesPhoto();
        mainPage.open("files", "favorite");

        filePage.checkFileVisible(namePhoto);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "88dfd874-d01d-420f-9998-5156d6af3309", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/88dfd874-d01d-420f-9998-5156d6af3309)")
    @DisplayName("Удалить")
    public void checkDeleteFileTest() {
        //в начале удаляю все файлы из корзины
        mainPage.open("files", "trash");
        filePage.clickButtonDeletePhoto();

        String namePhoto = "cats.png";
        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        if (filePage.isFileNotExists(namePhoto))
            filePage.uploadingPhotos("/testData/images/" + namePhoto);
        filePage.clickCheckBoxByPhoto(namePhoto);
        filePage.clickButtonDeletePhoto();
        mainPage.open("files", "trash");

        filePage.checkFileVisible(namePhoto);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e6ef7f65-a557-431e-85ca-854f1cab2bbc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e6ef7f65-a557-431e-85ca-854f1cab2bbc)")
    @DisplayName("Поиск с установленным в чекбоксе флагом \\В этой папке\\")
    public void checkSearchWithSetCheckBoxInThisFolderTest() {
        String fileName = "checkSearchWithSetCheckBoxInThisFolderFileName" + RandomString.get(4);

        elmaBackend.settingUsingOffice365(true);
        elmaBackend.createFileInFolderCompany(fileName);

        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.checkboxSearchInThisFolder();
        filePage.inputSearchByNameFileAndClickEnter(fileName);
        filePage.checkFileNotExistInSearchResults(fileName);

        mainPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.inputSearchByNameFileAndClickEnter(fileName);
        filePage.checkFileExistInSearchResults(fileName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f5a8659f-9e04-40ee-aa1b-fb3d199ddd6e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f5a8659f-9e04-40ee-aa1b-fb3d199ddd6e)")
    @DisplayName("Быстрый поиск по названию файла или его части")
    public void checkQuickSearchByFilenameOrPartOfItTest() {
        String fileName = "checkQuickSearchByFilenameOrPartOfItFileName" + RandomString.get(4);

        elmaBackend.settingUsingOffice365(true);
        elmaBackend.createFileInFolderCompany(fileName);

        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.inputSearchByNameFileAndClickEnter(fileName);
        filePage.checkFileExistInSearchResults(fileName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "84860564-4026-4085-b93e-5555a45843a1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/84860564-4026-4085-b93e-5555a45843a1)")
    @DisplayName("Свойства")
    public void checkFilePropertiesTest() {
        String fileName = "checkFilePropertiesFileName" + RandomString.get(4);
        String taskName = "checkFilePropertiesTaskName" + RandomString.get(4);
        String namePhoto = "cats.png";

        elmaBackend.settingUsingOffice365(true);
        elmaBackend.createFileInFolderCompany(fileName);

        mainPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        filePage.clickMenuSystemInfo("Задача");
        fileModal.clickPlusTaskButton();
        fileModal.inputNameNewTask(taskName);
        fileModal.inputTaskPerformerAndSelectFromList(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        fileModal.clickSaveButton();

        mainPage.open("tasks/income");
        sectionPage.clickTask(taskName);
        taskModal.clickInputFieldMessage();
        taskModal.clickButtonAtSignAndSelectUser(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        taskModal.uploadFile("/testData/images/" + namePhoto);
        taskModal.clickButtonDownload();
        taskModal.checkNameOfUploadedFile(namePhoto);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "1bcb87ef-6823-49ae-af99-0f5d241b8d78", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1bcb87ef-6823-49ae-af99-0f5d241b8d78)")
    @DisplayName("Отправить на согласование группе пользователей. Тип согласования: Последовательное")
    public void sendToGroupUsersForApprovalTypeOfAgreementSequentialTest() {
        String fileName = "typeOfAgreementSequentialFileName" + RandomString.get(4);

        elmaBackend.settingUsingOffice365(true);
        elmaBackend.createFileInFolderCompany(fileName);

        mainPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        fileModal.clickButtonToSendIconDown();
        fileModal.clickButtonToSendAgreement();
        fileModal.clickButtonAdvancedSearchAndSelectUser(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        fileModal.clickButtonAdvancedSearchAndSelectUser(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
        fileModal.clickButtonSequential();
        fileModal.clickButtonContinuation();
        fileModal.clickNextStageOrExit();
        filePage.checkAlertWithTextFragmentExists("Отправлено на согласование");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        mainPage.open("tasks/income");
        sectionPage.checkTaskNameNotExists(fileName);

        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        mainPage.open("tasks/income");
        sectionPage.clickTask(fileName);
        sectionPage.clickRefuseButtonAndInputComment("Файл не согласован");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        mainPage.open("tasks/income");
        sectionPage.clickTask(fileName);
        sectionPage.clickAgreeButtonAndInputComment("Файл согласован");

        sectionPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        filePage.clickMenuSystemInfo();

        widgetSettingsModal.checkVisibleListApproval("ОТКАЗАНО");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "6a7e24bd-179c-44db-94ed-ede96d5afecd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6a7e24bd-179c-44db-94ed-ede96d5afecd)")
    @DisplayName("Отправить на согласование группе пользователей. Тип согласования: Параллельное")
    public void sendToGroupUsersForApprovalTypeOfAgreementParallelTest() {
        String fileName = "typeOfAgreementParallelFileName" + RandomString.get(4);

        elmaBackend.settingUsingOffice365(true);
        elmaBackend.createFileInFolderCompany(fileName);

        mainPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        fileModal.clickButtonToSendIconDown();
        fileModal.clickButtonToSendAgreement();
        fileModal.clickButtonAdvancedSearchAndSelectUser(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        fileModal.clickButtonAdvancedSearchAndSelectUser(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
        fileModal.clickButtonParallel();
        fileModal.clickButtonInterrupt();
        fileModal.clickNextStageOrExit();
        filePage.checkAlertWithTextFragmentExists("Отправлено на согласование");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        mainPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess(fileName, "Согласование");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        mainPage.open("tasks/income");
        sectionPage.clickTask(fileName);
        sectionPage.clickRefuseButtonAndInputComment("Файл не согласован");

        sectionPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        filePage.clickMenuSystemInfo();

        widgetSettingsModal.checkVisibleListApproval("ОТКАЗАНО");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "73b961f0-de70-48b0-8e84-de5c5c5ae3b7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/73b961f0-de70-48b0-8e84-de5c5c5ae3b7)")
    @DisplayName("Отправить на ознакомление одному пользователю")
    public void sendToOneUserForReviewTest() {
        String fileName = "sendToOneUserForReviewFileName" + RandomString.get(4);

        elmaBackend.settingUsingOffice365(true);
        elmaBackend.createFileInFolderCompany(fileName);

        mainPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        fileModal.clickButtonToSend();
        fileModal.clickButtonAdvancedSearchAndSelectUser(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
        fileModal.clickNextStageOrExit();
        filePage.checkAlertWithTextFragmentExists("Отправлено на ознакомление");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        mainPage.open("tasks/income");
        sectionPage.clickTask(fileName);
        sectionPage.clickFamiliarizationButtonAndInputComment();

        sectionPage.open("files", elmaBackend.getIdFolderFileCompany());
        filePage.clickByFolderOrPhoto(fileName);
        filePage.clickMenuSystemInfo("Листы ознакомления");

        widgetSettingsModal.checkVisibleListApproval("Ознакомились");
    }
}
