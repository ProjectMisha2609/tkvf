package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.UserSettingsModal;
import pages.elmaPages.FilePage;
import pages.elmaPages.MainPage;

import java.time.LocalDate;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.utils.Constants.ELMA_TMS;
import static java.lang.String.format;
import static java.time.format.DateTimeFormatter.ofPattern;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertTrue;

@MicronautTest
@Tags({@Tag("express"), @Tag("user_settings")})
public class UserSettingsTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected UserSettingsModal userSettingsModal;
    @Inject
    protected FilePage filePage;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a5a2c608-757b-430b-83d1-59c72b294776", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a5a2c608-757b-430b-83d1-59c72b294776)")
    @DisplayName("Изменить данные в профиле пользователя - поменять номера телефонов")
    public void checkChangePhoneNumbers() {
        String workPhone = "+79887757144";
        String mobilePhone = "+79887756666";
        mainPage.open();

        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();
        userSettingsModal.inputWorkPhone(workPhone);
        userSettingsModal.inputMobilePhone(mobilePhone);
        userSettingsModal.clickButtonSave();
        mainPage.refreshPage();

        assertAll(
                () -> assertTrue(elmaBackend.getUserInfoById(elmaBackend.getUserIdByEmail(adminLogin))
                                .contains(format("\"mobilePhone\":[{\"tel\":\"%s\",\"type\":\"mobile\"}]", mobilePhone)),
                        "MobilePhone не соответствует ожидаемому"),
                () -> assertTrue(elmaBackend.getUserInfoById(elmaBackend.getUserIdByEmail(adminLogin))
                                .contains(format("\"workPhone\":[{\"tel\":\"%s\",\"type\":\"work\"}]", workPhone)),
                        "WorkPhone не соответствует ожидаемому"));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ef209f16-a130-4197-ae70-c473cc03e138", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ef209f16-a130-4197-ae70-c473cc03e138)")
    @DisplayName("Изменить данные в профиле пользователя - поменять дату рождения")
    public void checkChangeDateOfBirth() {

        LocalDate birthday = LocalDate.of(1999, 1, 2);

        mainPage.open();
        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();
        userSettingsModal.inputDataBirthday(birthday.format(ofPattern("dd.MM.yyyy")));
        userSettingsModal.clickButtonSave();
        mainPage.refreshPage();

        assertTrue(elmaBackend.getUserInfoById(elmaBackend.getUserIdByEmail(adminLogin))
                        .contains(format("birthDate\":\"%s", birthday.format(ofPattern("yyyy-MM-dd")))),
                "Дата рождения не соответствует ожидаемому");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "882bc9fb-8fe5-4c7b-8e5f-99755137201a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/882bc9fb-8fe5-4c7b-8e5f-99755137201a)")
    @DisplayName("Изменить данные в профиле пользователя - поменять фото с выбором из локального компьютера")
    public void checkChangeLocalPhoto() {

        String namePhoto = "cats.jpg";

        mainPage.open();
        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();
        userSettingsModal.clickRemovePhoto();
        userSettingsModal.uploadingPhotos("/testData/" + namePhoto);
        userSettingsModal.clickButtonSave();
        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();

        assertTrue(userSettingsModal.isImg(namePhoto), "Новое фото не отобразилось");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2075a4c7-25d8-40f8-b4a8-13dc4db7f0c2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2075a4c7-25d8-40f8-b4a8-13dc4db7f0c2)")
    @DisplayName("Изменить данные в профиле пользователя - поменять фото с выбором из раздела Файлы")
    public void checkChangePhoto() {

        String namePhoto = "cats.jpg";

        //Предусловие - Предварительно загрузить изображение в раздел Файлы - Мои Файлы
        mainPage.open();
        mainPage.sectionToolbar().selectSectionByCode("files");
        filePage.clickButtonMyFile();
        filePage.uploadingPhotos("/testData/" + namePhoto);

        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();
        userSettingsModal.clickRemovePhoto();
        userSettingsModal.clickButtonThreeDots();
        userSettingsModal.clickMyFile();
        userSettingsModal.choosePhoto(namePhoto);
        userSettingsModal.clickButtonSave();

        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();
        assertTrue(userSettingsModal.isImg(namePhoto), "Новое фото не отобразилось");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5d01c62b-fe2d-46a3-a858-29b072aff864", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5d01c62b-fe2d-46a3-a858-29b072aff864)")
    @DisplayName("Проверить работу кнопки справка в настройках профиля пользователя")
    public void checkHelpButtons() {
        String expectedUrl = "https://elma365.com/ru/help/360016398552.html";

        mainPage.open();
        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();
        assertTrue(mainPage.checkHelpButton(expectedUrl));
    }
}
