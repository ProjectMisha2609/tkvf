package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.ParameterSettingsModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.FilePage;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("issuing_rights")})
public class IssuingRightsToElementBlockTest {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected FilePage filePage;
    @Inject
    protected CreateAppElementModal createAppElementModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "30b8dc8d-c4b4-4587-8b01-729d2915bdf3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/30b8dc8d-c4b4-4587-8b01-729d2915bdf3)")
    @DisplayName("Проверить выдачу прав на Удаление к файлу")
    public void checkIssuingRightsDeleteToFileTest() {
        String processName = "checkIssuingRightsDeleteToFile" + RandomString.get(16);
        String variableName1 = "contextFile" + RandomString.get(4);
        String variableName2 = "contextUser" + RandomString.get(4);
        String fileName = "FileDelete" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.FILE))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createFileInFolderCompany(fileName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав"); // TODO "Выдача прав на элемент 1" разбита на 2 части. поиск будет по первой
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Удаление");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        parameterSettingsModal.hoverFileUploader("Файл");
        businessProcessPage.clickButtonMenuHorizontal();
        parameterSettingsModal.clickItemContextMenu("Выбрать из Раздела \"Файлы\"");
        filePage.clickButtonCompanyFiles();
        filePage.selectFile(fileName);

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("/files/" + elmaBackend.getIdFolderFileCompany());
        filePage.clickMenuHorizontal(fileName);
        parameterSettingsModal.clickItemContextMenu("Управление доступом");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "delete");
        filePage.checkIssuingRightsToFile(userName, false, "read", "update", "assign", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c9cf51d3-9517-4d0c-b830-aead2ca52927", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c9cf51d3-9517-4d0c-b830-aead2ca52927)")
    @DisplayName("Проверить выдачу прав на Выдачу прав к файлу")
    public void checkIssuingRightsAssignRightToFileTest() {
        String processName = "checkIssuingRightsAssignRightToFile" + RandomString.get(16);
        String variableName1 = "contextFile" + RandomString.get(4);
        String variableName2 = "contextUser" + RandomString.get(4);
        String fileName = "FileAssignRight" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.FILE))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createFileInFolderCompany(fileName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Выдача прав");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        parameterSettingsModal.hoverFileUploader("Файл");
        businessProcessPage.clickButtonMenuHorizontal();
        parameterSettingsModal.clickItemContextMenu("Выбрать из Раздела \"Файлы\"");
        filePage.clickButtonCompanyFiles();
        filePage.selectFile(fileName);

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("/files/" + elmaBackend.getIdFolderFileCompany());
        filePage.clickMenuHorizontal(fileName);
        parameterSettingsModal.clickItemContextMenu("Управление доступом");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "assign");
        filePage.checkIssuingRightsToFile(userName, false, "read", "update", "delete", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "cb8df079-d18f-44a3-a316-7640c4847c29", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cb8df079-d18f-44a3-a316-7640c4847c29)")
    @DisplayName("Проверить выдачу прав на Чтение к файлу")
    public void checkIssuingRightsReadToFileTest() {
        String processName = "checkIssuingRightsReadToFile" + RandomString.get(16);
        String variableName1 = "contextFile" + RandomString.get(4);
        String variableName2 = "contextUser" + RandomString.get(4);
        String fileName = "FileRead" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.FILE))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createFileInFolderCompany(fileName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Чтение");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        parameterSettingsModal.hoverFileUploader("Файл");
        businessProcessPage.clickButtonMenuHorizontal();
        parameterSettingsModal.clickItemContextMenu("Выбрать из Раздела \"Файлы\"");
        filePage.clickButtonCompanyFiles();
        filePage.selectFile(fileName);
        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("/files/" + elmaBackend.getIdFolderFileCompany());
        filePage.clickMenuHorizontal(fileName);
        parameterSettingsModal.clickItemContextMenu("Управление доступом");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "read");
        filePage.checkIssuingRightsToFile(userName, false, "delete", "update", "assign", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "51ea07f9-9e11-43ac-b6b8-751ff845e100", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/51ea07f9-9e11-43ac-b6b8-751ff845e100)")
    @DisplayName("Проверить выдачу прав на Изменение к файлу")
    public void checkIssuingRightsUpdateToFileTest() {
        String processName = "checkIssuingRightsUpdateToFile" + RandomString.get(16);
        String variableName1 = "contextFile" + RandomString.get(4);
        String variableName2 = "contextUser" + RandomString.get(4);
        String fileName = "FileUpdate" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.FILE))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createFileInFolderCompany(fileName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Изменение");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");

        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        parameterSettingsModal.hoverFileUploader("Файл");
        businessProcessPage.clickButtonMenuHorizontal();
        parameterSettingsModal.clickItemContextMenu("Выбрать из Раздела \"Файлы\"");
        filePage.clickButtonCompanyFiles();
        filePage.selectFile(fileName);

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("/files/" + elmaBackend.getIdFolderFileCompany());
        filePage.clickMenuHorizontal(fileName);
        parameterSettingsModal.clickItemContextMenu("Управление доступом");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "update");
        filePage.checkIssuingRightsToFile(userName, false, "read", "delete", "assign", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5e5a9f00-8a3d-4563-a466-73fafb326556", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5e5a9f00-8a3d-4563-a466-73fafb326556)")
    @DisplayName("Проверить выдачу прав на Удаление к элементу приложения")
    public void checkIssuingRightsDeleteToAppTest() {
        String processName = "checkIssuingRightsDeleteToApp" + RandomString.get(16);
        String sectionName = "checkIssuingRightsDeleteToApp" + RandomString.get(4);
        String appName = "appIssuingRightsDelete" + RandomString.get(3);
        String elementAppName = "appElement" + RandomString.get(4);
        String variableName1 = appName;
        String variableName2 = "contextUser" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        settingsBlockModal.clickRadioButton("Ограничить доступ к данным");
        settingsBlockModal.clickRadioButton("На уровне элементов Приложения");
        businessProcessPage.clickButtonDeleteUserFromAssignRightList("Все пользователи");
        mainPage.clickButtonOnAppContent("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Удаление");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");

        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        businessProcessPage.clickButtonAddNewAppOnStartForm();
        createAppElementModal.fillName(elementAppName);
        createContextModal.clickModalFooterButton("Сохранить");

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementAppName);
        parameterSettingsModal.clickModalHeaderButton("lock");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "delete");
        filePage.checkIssuingRightsToFile(userName, false, "read", "update", "assign", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c9cf51d3-9517-4d0c-b830-aead2ca52927", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c9cf51d3-9517-4d0c-b830-aead2ca52927)")
    @DisplayName("Проверить выдачу прав на Чтение к элементу приложения")
    public void checkIssuingRightsReadToAppTest() {
        String processName = "checkIssuingRightsReadToApp" + RandomString.get(16);
        String sectionName = "checkIssuingRightsReadToApp" + RandomString.get(4);
        String appName = "appIssuingRightsRead" + RandomString.get(3);
        String elementAppName = "appElement" + RandomString.get(4);
        String variableName1 = appName;
        String variableName2 = "contextUser" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        settingsBlockModal.clickRadioButton("Ограничить доступ к данным");
        settingsBlockModal.clickRadioButton("На уровне элементов Приложения");
        businessProcessPage.clickButtonDeleteUserFromAssignRightList("Все пользователи");
        mainPage.clickButtonOnAppContent("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");

        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Чтение");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");

        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        businessProcessPage.clickButtonAddNewAppOnStartForm();
        createAppElementModal.fillName(elementAppName);
        createContextModal.clickModalFooterButton("Сохранить");

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementAppName);
        parameterSettingsModal.clickModalHeaderButton("lock");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "read");
        filePage.checkIssuingRightsToFile(userName, false, "delete", "update", "assign", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "718bc435-d162-47ed-a464-59b9e04a8dff", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/718bc435-d162-47ed-a464-59b9e04a8dff)")
    @DisplayName("Проверить выдачу прав на Изменение к элементу приложения")
    public void checkIssuingRightsUpdateToAppTest() {
        String processName = "checkIssuingRightsUpdateToApp" + RandomString.get(16);
        String sectionName = "checkIssuingRightsUpdateToApp" + RandomString.get(4);
        String appName = "appIssuingRightsUpdate" + RandomString.get(3);
        String elementAppName = "appElement" + RandomString.get(4);
        String variableName1 = appName;
        String variableName2 = "contextUser" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        settingsBlockModal.clickRadioButton("Ограничить доступ к данным");
        settingsBlockModal.clickRadioButton("На уровне элементов Приложения");
        businessProcessPage.clickButtonDeleteUserFromAssignRightList("Все пользователи");
        mainPage.clickButtonOnAppContent("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Изменение");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");

        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        businessProcessPage.clickButtonAddNewAppOnStartForm();
        createAppElementModal.fillName(elementAppName);
        createContextModal.clickModalFooterButton("Сохранить");

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementAppName);
        parameterSettingsModal.clickModalHeaderButton("lock");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "update");
        filePage.checkIssuingRightsToFile(userName, false, "read", "delete", "assign", "bpmanage", "import", "full");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "4784019c-163a-481a-bbfc-1a13e887f828", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4784019c-163a-481a-bbfc-1a13e887f828)")
    @DisplayName("Проверить выдачу прав на Выдачу прав к элементу приложения")
    public void checkIssuingRightsAssignRightToAppTest() {
        String processName = "checkIssuingRightsAssignRightToApp" + RandomString.get(16);
        String sectionName = "checkIssuingRightsAssignRightToApp" + RandomString.get(4);
        String appName = "appIssuingRightsAssignRight" + RandomString.get(3);
        String elementAppName = "appElement" + RandomString.get(4);
        String variableName1 = appName;
        String variableName2 = "contextUser" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithIssuingRightsToElementBlock.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName1, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName2, ContextType.SYS_USER))
                        .addContextOnDefaultStartForm(variableName1, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName2, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        settingsBlockModal.clickRadioButton("Ограничить доступ к данным");
        settingsBlockModal.clickRadioButton("На уровне элементов Приложения");
        businessProcessPage.clickButtonDeleteUserFromAssignRightList("Все пользователи");
        mainPage.clickButtonOnAppContent("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Выдача прав");
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Объект", variableName1);
        parameterSettingsModal.clickDropDownOnFieldAndChooseItem("Пользователь", variableName2);
        createContextModal.setCheckboxByName("Выдача прав");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");

        sectionPage.startCompanyProcess(processName);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableName2);
        mainPage.clickSelectUser(userLogin);
        businessProcessPage.clickButtonAddNewAppOnStartForm();
        createAppElementModal.fillName(elementAppName);
        createContextModal.clickModalFooterButton("Сохранить");

        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementAppName);
        parameterSettingsModal.clickModalHeaderButton("lock");
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        filePage.checkIssuingRightsToFile(userName, true, "assign");
        filePage.checkIssuingRightsToFile(userName, false, "read", "delete", "update", "bpmanage", "import", "full");
    }
}
