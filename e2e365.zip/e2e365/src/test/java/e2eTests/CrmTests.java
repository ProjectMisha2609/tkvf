package e2eTests;

import infrastructure.elmaBackend.BackendCrm;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.util.Map;

import static infrastructure.elmaBackend.BackendCrm.STATUS_PROCESSED;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("crm")})
public class CrmTests {
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected CrmSectionPage crmSectionPage;
    @Inject
    protected CreateAppElementModal createApplicationElementModal;
    @Inject
    protected CompanyCardPage companyCardPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CrmDoublesModal crmDoublesModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected MessagePage messagePage;
    @Inject
    protected CreateTaskModal createTaskModal;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;

    @Inject
    protected SettingFolderFilterModal settingFolderFilterModal;
    @Inject
    protected SettingsBlockModal settingsBlockModal;

    @Test
    @Link(value = "17ba4816-9a54-4826-a7b1-8a2b549edd58", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/17ba4816-9a54-4826-a7b1-8a2b549edd58)")
    @DisplayName("Добавить компанию")
    public void addNewCompanyInCrmSectionTest() {
        String sectionName = "_clients";
        String appName = "_companies";
        String nameCompany = "Company" + RandomString.get(10);

        crmSectionPage.open(sectionName, appName);
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Компания");
        createApplicationElementModal.fillName(nameCompany);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        crmSectionPage.checkCompanyCreated(nameCompany);
    }

    @Test
    @Link(value = "2c745177-1228-4340-92e6-29409aabf5f9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2c745177-1228-4340-92e6-29409aabf5f9)")
    @DisplayName("Создать сделку с заполнением только обязательных полей")
    public void createDealWithOnlyRequiredFieldsTest() {
        String sectionName = "_clients";
        String appName = "_leads";
        String dealName = "Deal" + RandomString.get(10);

        crmSectionPage.open(sectionName, appName);
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Сделка");
        createApplicationElementModal.fillName(dealName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        crmSectionPage.checkCardVisible(dealName, 1);
    }

    @Test
    @Link(value = "89837c24-722f-4659-8dce-a540380a5107", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/89837c24-722f-4659-8dce-a540380a5107)")
    @DisplayName("Компания. Добавить контакт")
    public void addContactOnCompanyCardTest() {
        String companyName = "addContactOnCompanyCardTest" + RandomString.get(8);
        String contactName = "Contact" + RandomString.get(8);
        String companyId = RandomString.getUUID();
        backendCrm.createCompany(companyName, companyId);

        companyCardPage.open(companyId);
        companyCardPage.clickAddContact();
        createApplicationElementModal.fillName(contactName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        companyCardPage.checkContactName(contactName);
    }

    @Test
    @Link(value = "dc49e674-6955-4979-a04e-fd35a93f0545", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/dc49e674-6955-4979-a04e-fd35a93f0545)")
    @DisplayName("Компания. Добавить сделку")
    public void addDealOnCompanyCardTest() {
        String companyName = "addDealOnCompanyCardTest" + RandomString.get(8);
        String dealName = "DealName" + RandomString.get(8);
        String companyId = RandomString.getUUID();
        backendCrm.createCompany(companyName, companyId);

        companyCardPage.open(companyId);
        companyCardPage.clickAddDeal();
        createApplicationElementModal.fillName(dealName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        companyCardPage.checkDealName(dealName);
    }

    @Test
    @Link(value = "370e5e6a-516d-403d-b642-e9248ada5c1e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/370e5e6a-516d-403d-b642-e9248ada5c1e)")
    @DisplayName("Добавить новую Воронку продаж")
    public void addSalesFunnelTest() {
        String sectionName = "_clients";
        String appName = "_leads";
        String funnelName = "funnelName" + RandomString.get(8);

        crmSectionPage.open(sectionName, appName);
        crmSectionPage.addNewFunnel(funnelName);

        crmSectionPage.checkPageContainsNewFunnel(funnelName);
    }

    @Test
    @Link(value = "f4321e38-16a1-4c86-93b6-c114b4cb4b18", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f4321e38-16a1-4c86-93b6-c114b4cb4b18)")
    @DisplayName("Создать задачу")
    public void createTaskTest() {
        backendCrm.setCrmTasksVisibility(false);
        String companyName = "createTaskCompany" + RandomString.get(8);
        String taskName = "taskName" + RandomString.get(8);
        backendCrm.createCompany(companyName, RandomString.getUUID());

        crmSectionPage.open("_clients/_companies");
        crmSectionPage.openCompany(companyName);
        crmSectionPage.fillTask(taskName);

        sectionPage.open("tasks/income");
        sectionPage.clickTask(taskName);

        interfaceDesignerPage.checkTaskNameVisible(companyName);
    }

    @Test
    @Link(value = "b3a8109f-47c9-41f4-8dc1-02f723d035fe", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b3a8109f-47c9-41f4-8dc1-02f723d035fe)")
    @DisplayName("Проверить редактирование")
    public void checkEditTest() {
        Map<String, String> dataForCompany = crmSectionPage.generateData();

        crmSectionPage.open("_clients/_companies");
        crmSectionPage.openCompany(dataForCompany.get("companyName"));
        createAppElementModal.clickModalFooterButton("Редактировать");
        //todo: редактирование отраслей и сегментов доступно без включения редактирования, удаление невозможно.
        // происходит наложение модальных окон с одинаковыми локаторами.
        crmSectionPage.fillRedactFields(dataForCompany);

        crmSectionPage.checkCompanyDataCorrect(dataForCompany);
    }

    @Test
    @Link(value = "7427a0f7-dfb3-4bbc-a2a8-1f8aaf73a503", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7427a0f7-dfb3-4bbc-a2a8-1f8aaf73a503)")
    @DisplayName("Написать сообщение в ленту")
    public void sendMessageInDealCardTest() {
        String dealName = "sendMessageInDealCardTest" + RandomString.get(8);
        String feedMessage = "feedMessage" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.sendMessageInFeed(feedMessage);

        crmSectionPage.checkMessageSent(feedMessage);
    }

    @Test
    @Link(value = "0e5fa000-5cd4-4c46-bb5a-f1d20e1cca24", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0e5fa000-5cd4-4c46-bb5a-f1d20e1cca24)")
    @DisplayName("Создать встречу")
    public void createMeetingInDealCardTest() {
        String dealName = "createMeetingTest" + RandomString.get(8);
        String taskName = "createMeetingTaskName" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients", "_leads", "_funnels");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Встреча");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.selectAdminInSearch();
        crmSectionPage.saveTask();

        crmSectionPage.isNewTaskInFeedAppeared(taskName);
    }

    @Test
    @Link(value = "5d5a191f-47f4-41cd-9a9f-d2b4b5822d37", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5d5a191f-47f4-41cd-9a9f-d2b4b5822d37)")
    @DisplayName("Создать задачу")
    public void createTaskInDealCardTest() {
        String dealName = "createTaskInDealCardTest" + RandomString.get(8);
        String taskName = "createTaskInDealCard" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Задача");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.selectAdminInSearch();
        crmSectionPage.fillCalendarData();
        crmSectionPage.saveTask();

        crmSectionPage.isNewTaskCreated(taskName);
    }

    @Test
    @Link(value = "142d9a67-680b-4287-9708-25d88527cf39", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/142d9a67-680b-4287-9708-25d88527cf39)")
    @DisplayName("Письмо. Перенести")
    public void changeLetterDateTest() {
        String dealName = "changeLetterDateTest" + RandomString.get(8);
        String taskName = "changeLetterDate" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Письмо");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();

        String creationDate = crmSectionPage.getTaskCreationDate();
        crmSectionPage.clickTaskButton("Изменить");
        crmSectionPage.setTomorrowDateInCalendar();
        crmSectionPage.confirmWindowClickButton("Сохранить");
        crmSectionPage.confirmChangeLetterTime();

        crmSectionPage.checkTaskTimeChanged(creationDate);
    }

    @Test
    @Link(value = "190524ed-a935-4996-a06c-921c91d0dad1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/190524ed-a935-4996-a06c-921c91d0dad1)")
    @DisplayName("Встреча. Сделано")
    public void meetingDoneInDealCardTest() {
        String dealName = "meetingDoneInDealCardTest" + RandomString.get(8);
        String taskName = "meetingDoneInDealCard" + RandomString.get(8);
        String commentary = "meetingDoneInDealCardCommentary" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Встреча");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.selectAdminInSearch();
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Сделано");
        crmSectionPage.confirmWindowClickButton("Сделано", commentary);

        crmSectionPage.isTaskInDealCardDone(taskName, commentary);
    }

    @Test
    @Link(value = "1d7ee197-4f59-4799-b7e7-34d54a244e53", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/1d7ee197-4f59-4799-b7e7-34d54a244e53)")
    @DisplayName("Вебинар. Сделано")
    public void webinarDoneInDealCardTest() {
        String dealName = "webinarDoneInDealCardTest" + RandomString.get(8);
        String taskName = "webinarDoneInDealCard" + RandomString.get(8);
        String commentary = "webinarDoneInDealCardCommentary" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Вебинар");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Сделано");
        crmSectionPage.confirmWindowClickButton("Сделано", commentary);

        crmSectionPage.isTaskInDealCardDone(taskName, commentary);
    }

    @Test
    @Link(value = "263d0b4f-228a-45d9-95dc-0bad54cfc5c9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/263d0b4f-228a-45d9-95dc-0bad54cfc5c9)")
    @DisplayName("Добавить контакт")
    public void addContactInDealCardTest() {
        String dealName = "addContactInDealCardTest" + RandomString.get(8);
        String contactName = "contactInDealCard" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.clickAddContactInDealCard();
        createApplicationElementModal.fillName(contactName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        crmSectionPage.isContactAdded(contactName);
    }

    @Test
    @Link(value = "26db2e66-1e87-471f-9c1d-a0eae69d626e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/26db2e66-1e87-471f-9c1d-a0eae69d626e)")
    @DisplayName("Проверить смену статуса Сделки")
    public void statusChangeInDealCardTest() {
        String dealName = "statusChangeInDealCardTest" + RandomString.get(8);
        String status = "Первичный контакт";
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.changeStatusInDealCard(status);

        crmSectionPage.checkStatusChanged(status);
    }

    @Test
    @Link(value = "4ade53e8-01f9-4330-ab7c-01cc0baca281", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4ade53e8-01f9-4330-ab7c-01cc0baca281)")
    @DisplayName("Звонок. Перенести")
    public void changeCallDateTest() {
        String dealName = "changeCallDateTest" + RandomString.get(8);
        String taskName = "changeCallDate" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Звонок");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();

        String creationDate = crmSectionPage.getTaskCreationDate();
        crmSectionPage.clickTaskButton("Изменить");
        crmSectionPage.setTomorrowDateInCalendar();
        crmSectionPage.confirmWindowClickButton("Сохранить");
        crmSectionPage.confirmChangeLetterTime();

        crmSectionPage.checkTaskTimeChanged(creationDate);
    }

    @Test
    @Link(value = "5dd0566b-11b4-4cc7-abfc-24b39039fd8b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5dd0566b-11b4-4cc7-abfc-24b39039fd8b)")
    @DisplayName("Проверить историю звонков в Календаре")
    public void checkCallHistoryTest() {
        String dealName = "checkCallHistoryTest" + RandomString.get(8);
        String taskName = "checkCallHistory" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Звонок");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Недозвон");
        crmSectionPage.chooseCallResult("Занято");
        crmSectionPage.open("schedule");

        crmSectionPage.checkHistoryAppearedInFeed(taskName, "Занято");
    }

    @Test
    @Link(value = "638b94cb-c870-4d26-8e36-ecb2ab3b78e2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/638b94cb-c870-4d26-8e36-ecb2ab3b78e2)")
    @DisplayName("Выполнить задачу")
    public void completeTaskInDealCardTest() {
        String dealName = "completeTaskInDealCardTest" + RandomString.get(8);
        String taskName = "completeTaskInDealCard" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients", "_leads", "_funnels");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Задача");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.selectAdminInSearch();
        crmSectionPage.fillCalendarData();
        crmSectionPage.saveTask();
        crmSectionPage.open("tasks", "income");
        sectionPage.clickTask(taskName);
        taskModal.clickModalFooterButton("Сделано");
        taskModal.confirmCompleteTask();
        // на версии 2023.1.4 задача стала закрываться сама
        // taskModal.clickModalFooterButton("Закрыть задачу");
        crmSectionPage.isControlTaskCompleted();
    }

    @Test
    @Link(value = "6df991ca-bd09-44e6-8fbc-072cf9c8d607", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6df991ca-bd09-44e6-8fbc-072cf9c8d607)")
    @DisplayName("Создать звонок")
    public void makeCallDateTest() {
        String dealName = "makeCallDateTest" + RandomString.get(8);
        String taskName = "makeCallDate" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Звонок");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();

        crmSectionPage.isNewTaskCreated(taskName);
    }

    @Test
    @Link(value = "7186d23e-c6d5-41a1-a719-e22063527713", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7186d23e-c6d5-41a1-a719-e22063527713)")
    @DisplayName("Письмо. Сделано")
    public void letterDoneTest() {
        String dealName = "letterDoneTest" + RandomString.get(8);
        String taskName = "letterDone" + RandomString.get(8);
        String commentary = "letterDoneCommentary" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Письмо");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Сделано");
        crmSectionPage.confirmWindowClickButton("Сделано", commentary);

        crmSectionPage.isTaskInDealCardDone(taskName, commentary);
    }

    @Test
    @Link(value = "82dd9c50-2ae4-4b8c-9a24-ce97c9aaceb0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/82dd9c50-2ae4-4b8c-9a24-ce97c9aaceb0)")
    @DisplayName("Звонок. Закрыть сделку")
    public void closeDealCallTest() {
        String dealName = "closeDealCallTest" + RandomString.get(8);
        String taskName = "closeDealCall" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients", "_leads", "_funnels");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Звонок");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Закрыть сделку");
        crmSectionPage.confirmWindowClickButton("Закрыть сделку");
        /* В использованном методе isDealCallClosed присутствует лишняя проверка на наличие сообщения
        "Сделка \"" + taskName + "\" закрыта.", которая отсутствует в тест-кейсе.
        Кейс блокировался тем, что в данном случае не проверяемое по тк сообщение содержит другой статус:
        "Процесс " + taskName + " был прерван".
        Так же обнаружено, что элемент div[class*='message__title'] не обладает вложенным элементом текста,
        а содержит текст, используемый для поиска. */

        crmSectionPage.isDealCallAborted(taskName);
    }

    @Test
    @Link(value = "9fcdd24d-d2e3-45ad-b036-ff46e61f23f4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9fcdd24d-d2e3-45ad-b036-ff46e61f23f4)")
    @DisplayName("Вебинар. Перенести")
    public void changeWebinarTimeInDealCardTest() {
        String dealName = "changeWebinarTimeInDealCardTest" + RandomString.get(8);
        String taskName = "changeWebinarTimeInDealCard" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Вебинар");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        String creationDate = crmSectionPage.getTaskCreationDate();
        crmSectionPage.clickTaskButton("Изменить");
        crmSectionPage.setTomorrowDateInCalendar();
        crmSectionPage.confirmWindowClickButton("Сохранить");
        crmSectionPage.confirmChangeLetterTime();

        crmSectionPage.checkTaskTimeChanged(creationDate);
    }

    @Test
    @Link(value = "a11d68a3-8f96-4890-a125-bfb3b55733a4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a11d68a3-8f96-4890-a125-bfb3b55733a4)")
    @DisplayName("Звонок. Недозвон. Закрыть задачу")
    public void closeCallTaskTest() {
        String dealName = "closeCallTaskTest" + RandomString.get(8);
        String taskName = "closeCallTask" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Звонок");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Недозвон");
        crmSectionPage.chooseCallResult("Закрыть задачу");

        crmSectionPage.isCallTaskClosed();
    }

    @Test
    @Link(value = "a9e80d22-15ad-488a-942b-eb4edddce099", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a9e80d22-15ad-488a-942b-eb4edddce099)")
    @DisplayName("Проверить историю писем в Календаре")
    public void checkLettersHistoryTest() {
        String dealName = "checkLettersHistoryTest" + RandomString.get(8);
        String taskName = "checkLettersHistory" + RandomString.get(8);
        String commentary = "checkLettersHistoryCommentary" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Письмо");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Сделано");
        crmSectionPage.confirmWindowClickButton("Сделано", commentary);
        crmSectionPage.open("schedule");

        crmSectionPage.isLetterHaveHistory(taskName);
    }

    @Test
    @Tag("bugged")
    @Link(value = "cd136637-9365-4f26-9bd0-4284f9919ea0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cd136637-9365-4f26-9bd0-4284f9919ea0)")
    @DisplayName("Звонок. Недозвон")
    public void callStatusesTaskTest() {
        String dealName = "callStatusesTaskTest" + RandomString.get(8);
        String taskName = "callStatusesTask" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Звонок");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Недозвон");
        crmSectionPage.chooseCallResult("Занято");

        crmSectionPage.isStatusAppearedInFeed("Занято");
        /*
         В версии 2023.1.4 нельзя добавить новые статусы звонка.
         Дефект: после обновления статуса не работают все четыре кнопки панели:
         "Сделано", "Недозвон", "Изменить", "Закрыть сделку".
         Как следствие - не открывается поповер, вызываемый кнопкой "Недозвон".
         Кнопку поповера, тем не менее, можно нажать когда она скрыта, через консоль браузера.
        */
        crmSectionPage.clickTaskButton("Недозвон");
        crmSectionPage.chooseCallResult("Недоступен");

        crmSectionPage.isStatusAppearedInFeed("Недоступен");
        crmSectionPage.clickTaskButton("Недозвон");
        crmSectionPage.chooseCallResult("Нет ответа");

        crmSectionPage.isStatusAppearedInFeed("Нет ответа");
    }

    @Test
    @Link(value = "d620de0c-9eed-4dda-a03e-e0a58940f9e5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d620de0c-9eed-4dda-a03e-e0a58940f9e5)")
    @DisplayName("Звонок. Сделано")
    public void callDoneTest() {
        String dealName = "callDoneTest" + RandomString.get(8);
        String taskName = "callDone" + RandomString.get(8);
        String commentary = "callDoneCommentary" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Письмо");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Сделано");
        crmSectionPage.confirmWindowClickButton("Сделано", commentary);

        crmSectionPage.isTaskInDealCardDone(taskName, commentary);
    }

    @Test
    @Link(value = "d7b16da8-687b-481f-a659-e1d55d3b8618", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d7b16da8-687b-481f-a659-e1d55d3b8618)")
    @DisplayName("Встреча. Перенести")
    public void changeMeetingDateTest() {
        String dealName = "changeMeetingDateTest" + RandomString.get(8);
        String taskName = "changeMeetingDate" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Встреча");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();

        String creationDate = crmSectionPage.getTaskCreationDate();
        crmSectionPage.clickTaskButton("Изменить");
        crmSectionPage.setTomorrowDateInCalendar();
        crmSectionPage.confirmWindowClickButton("Сохранить");
        crmSectionPage.confirmChangeLetterTime();

        crmSectionPage.checkTaskTimeChanged(creationDate);
    }

    @Test
    @Link(value = "f83c1d65-3ee0-40ad-bc3b-6359c3912657", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f83c1d65-3ee0-40ad-bc3b-6359c3912657)")
    @DisplayName("Проверить историю встреч в Календаре")
    public void checkMeetingHistoryTest() {
        String dealName = "checkMeetingHistoryTest" + RandomString.get(8);
        String taskName = "checkMeetingHistory" + RandomString.get(8);
        String commentary = "checkMeetingHistoryCommentary" + RandomString.get(8);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.pressNewTaskButton("Встреча");
        crmSectionPage.enterTaskName(taskName);
        crmSectionPage.saveTask();
        crmSectionPage.clickTaskButton("Сделано");
        crmSectionPage.confirmWindowClickButton("Сделано", commentary);
        crmSectionPage.open("schedule");

        crmSectionPage.checkHistoryAppearedInFeed(taskName, commentary);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "420a5ba2-4470-4247-adc2-80573b432261", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/420a5ba2-4470-4247-adc2-80573b432261)")
    @DisplayName("Проверка отображения подраздела Задачи CRM в разделе Задачи")
    public void displayOfCRMTaskSubsectionInTasksSectionTest() {
        backendCrm.setCrmTasksVisibility(false);
        mainPage.open();
        mainPage.clickUserWidget();
        mainPage.clickSettingProfUser();

        createApplicationElementModal.selectModalWindowTab("Задачи");
        createApplicationElementModal.setCheckboxConditionByLabel("Показывать задачи по CRM отдельно от прочих входящих задач", true);
        createApplicationElementModal.clickButtonOnModalWindowByName("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Настройки успешно сохранены");

        mainPage.open("tasks/income");
        sectionPage.checkCreatedAppsAvailable("Задачи CRM");

        backendCrm.setCrmTasksVisibility(false);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "74dd1079-aef0-4898-a6c7-e42cb4ec51f8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/74dd1079-aef0-4898-a6c7-e42cb4ec51f8)")
    @DisplayName("Проверка сохранения правила дублей при общем весе более 100%")
    public void duplicateRuleSavingWithTotalWeightMoreThan100PercentTest() {
        mainPage.open("_clients/__duplicates");
        crmSectionPage.clickButtonOnConfigPage("Лид-Лид");
        crmDoublesModal.setWeightByFirstColumnValue("Название", 41);
        crmSectionPage.dialogWindowPressButton("Сохранить");

        mainPage.checkAlertWithTextFragmentExists("Общий процент совпадения для правила Лид-Лид не может превышать 100%");
    }

    @Test
    @Tag("bugged") // todo: не успевает учитывать данные из приложения контакт, на облаке падает практически всегда.
    @Tag("Author=Hushvahtov")
    @Link(value = "4aa38007-5fdf-4c9d-9f54-e349634f2fb1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4aa38007-5fdf-4c9d-9f54-e349634f2fb1)")
    @DisplayName("Проверка поиска дублей с введением дополнительных условий")
    public void duplicateSearchWithAdditionalConditionsTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String contactName = "duplicateSearchWithAdditionalConditionsContactName" + RandomString.get(8);
        String skype = "duplicateSearchWithAdditionalConditionsSkype" + RandomString.get(8);
        String leadName = "duplicateSearchWithAdditionalConditionsLeadName" + RandomString.get(8);
        String contractId = backendCrm.createContact(contactName, skype);
        backendCrm.createLead(leadName, contractId);
        backendCrm.createLead(leadName, contractId);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.clickButtonOnConfigPage("Лид-Лид");
        crmDoublesModal.setWeightByFirstColumnValue("Контакты.Имя", 10);
        crmDoublesModal.clickButtonOnModalWindowByName("+ Условие");
        crmDoublesModal.clickButtonOnModalWindowByName("<Не определен>");
        crmDoublesModal.selectPopoverOptionByName("Контакты");
        crmDoublesModal.selectPopoverOptionByName("Skype");
        crmSectionPage.dialogWindowPressButton("ОК");
        crmDoublesModal.setWeightByFirstColumnValue("Skype", 10);
        crmDoublesModal.clickButtonOnModalWindowByName("<Не определен>");
        crmDoublesModal.selectPopoverOptionByName("Контакты");
        crmDoublesModal.selectPopoverOptionByName("Skype");
        crmSectionPage.dialogWindowPressButton("Сохранить");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName);

        crmSectionPage.checkTextInRightBlock("Дубли", "Это дубль: 60%. Совпадений:");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "c1893d22-ed9d-4b86-9fc7-8ac0bbe4241f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c1893d22-ed9d-4b86-9fc7-8ac0bbe4241f)")
    @DisplayName("Проверка поиска дублей среди элементов с определенным статусом")
    public void duplicateSearchWithSpecificStatusTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "duplicateSearchWithSpecificStatusLeadName" + RandomString.get(8);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.dragLeadAndDropBetweenColumns(leadName, 1, 2);
        crmSectionPage.dragLeadAndDropBetweenColumns(leadName, 1, 2);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");

        mainPage.refreshPage();
        crmSectionPage.chooseTabOnConfigPage("Дополнительные настройки");
        crmSectionPage.clickButtonOnConfigPage("Выберите статусы");
        crmSectionPage.setCheckboxConditionByLabel("Обработка", true);
        crmSectionPage.clickButton("Сохранить");
        crmSectionPage.changeStatusByValueOfFieldName("Перевести отмеченный дублем элемент в статус", "Неквалифицирован");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 2);
        crmSectionPage.checkTextInRightBlock("Дубли", "Это дубль: 40%. Совпадений: 1.");
        crmSectionPage.clickTextInRightBlock("Дубли", "Подробнее");
        crmDoublesModal.clickCheckboxInModalLearnMoreDuplicates(leadName);
        crmDoublesModal.clickButtonOnModalWindowByName("Объединить (1)");
        crmDoublesModal.clickButtonInModalWindowCombineLeads("Объединить");

        mainPage.refreshPage();
        crmSectionPage.clickTextInRightBlock("Дубли", leadName);

        crmSectionPage.checkTextInRightBlock("Дубли", "Данный элемент объединен в элемент");
        crmSectionPage.checkTextInRightBlock("Статус", "Неквалифицирован");
        crmSectionPage.checkTextInRightBlock("Дубли", leadName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2acfc705-4dc3-40cd-8ed2-3801eea76a5a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2acfc705-4dc3-40cd-8ed2-3801eea76a5a)")
    @DisplayName("Проверка работы красного коридора при поиске дублей")
    public void redCorridorDuplicateSearchTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "duplicateSearchAmongItemsWithSpecificStatusLeadName" + RandomString.get(8);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");

        mainPage.refreshPage();
        crmSectionPage.chooseTabOnConfigPage("Дополнительные настройки");
        crmSectionPage.setThresholdsForResultsOfDuplicates("Красный коридор — наиболее вероятное совпадение", 40);
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");

        crmSectionPage.openCard(leadName, 1);

        crmSectionPage.checkTextInRightBlock("Дубли", "Это дубль: 40%. Совпадений: 1.");
        crmSectionPage.checkCorrectBlockColor("Дубли", false);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d1d1b707-e53b-4923-97df-37b6fac7e084", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d1d1b707-e53b-4923-97df-37b6fac7e084)")
    @DisplayName("Проверка работы желтого коридора при поиске дублей")
    public void yellowCorridorDuplicateSearchTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "duplicateSearchAmongItemsWithSpecificStatusLeadName" + RandomString.get(8);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");

        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");

        crmSectionPage.openCard(leadName, 1);

        crmSectionPage.checkTextInRightBlock("Дубли", "Это дубль: 40%. Совпадений: 1.");
        crmSectionPage.checkCorrectBlockColor("Дубли", true);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ad2774c9-cb57-4fbe-9c2b-d8e05a7f0fee", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ad2774c9-cb57-4fbe-9c2b-d8e05a7f0fee)")
    @DisplayName("Поиск дублей среди элементов, содержащих определенное количество символов в названии")
    public void duplicateSearchAmongItemsWithCertainTitleLengthTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();

        String leadName = "duplicateSearchAmongItemsWithCertainTitleLength" + RandomString.get(4);
        String leadShotName = RandomString.get(2);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");

        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");

        mainPage.clickButtonOnAppContent("+ Лид");
        createAppElementModal.fillName(leadName);
        sectionPage.clickSaveButton();
        mainPage.checkAlertWithTextFragmentExists("Лид успешно создан");

        mainPage.clickButtonOnAppContent("+ Лид");
        createAppElementModal.fillName(leadName);
        sectionPage.clickSaveButton();
        crmDoublesModal.checkModalWindowWithNameVisible("Подробнее о дублях");
        crmDoublesModal.clickButtonOnModalWindowByName("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Лид успешно создан");

        mainPage.clickButtonOnAppContent("+ Лид");
        createAppElementModal.fillName(leadShotName);
        sectionPage.clickSaveButton();
        mainPage.checkAlertWithTextFragmentExists("Лид успешно создан");

        mainPage.clickButtonOnAppContent("+ Лид");
        createAppElementModal.fillName(leadShotName);
        sectionPage.clickSaveButton();
        crmDoublesModal.checkModalWindowWithNameNotVisible("Подробнее о дублях");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5b6bebbe-fb03-41a8-ab3e-2807e2c3d964", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5b6bebbe-fb03-41a8-ab3e-2807e2c3d964)")
    @DisplayName("Поиск дублей среди элементов разных приложений")
    public void duplicateSearchAcrossMultipleApplicationsTest() {
        String dealAndLeadName = "duplicateSearchAcrossMultipleApplications" + RandomString.get(8);

        backendCrm.createDeal(dealAndLeadName);
        backendCrm.createLead(dealAndLeadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Сделка", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealAndLeadName, 1);
        crmSectionPage.clickTextInRightBlock("Дубли", "Подробнее");
        crmDoublesModal.clickCheckboxInModalLearnMoreDuplicates(dealAndLeadName);
        crmDoublesModal.clickButtonOnModalWindowByName("Связать (1)");

        crmSectionPage.checkTextInRightBlock("Дубли", "Данный элемент отмечен дублем для элемента");
        crmSectionPage.checkTextInRightBlock("Дубли", dealAndLeadName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "09d6c7e8-cf74-4805-a3ca-75b3b7a1bce4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/09d6c7e8-cf74-4805-a3ca-75b3b7a1bce4)")
    @DisplayName("Пагинация элементов-дублей")
    public void paginationOfDuplicateElementTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();

        String leadName = "paginationOfDuplicateElement" + RandomString.get(4);
        int countLead = 12;
        for (int i = 0; i < countLead; i++) {
            backendCrm.createLead(leadName);
        }

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 1);

        crmSectionPage.checkTextInRightBlock("Дубли", "Это дубль: 40%. Совпадений: 10.");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f91a4fa0-4b11-4a0e-a190-27160b9a1df0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f91a4fa0-4b11-4a0e-a190-27160b9a1df0)")
    @DisplayName("Функционал \"Не дубль\"")
    public void functionNotDoubleTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "functionNotDouble" + RandomString.get(4);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 1);
        crmSectionPage.clickTextInRightBlock("Дубли", "Подробнее");
        crmDoublesModal.clickCheckboxInModalLearnMoreDuplicates(leadName);
        crmDoublesModal.clickButtonOnModalWindowByName("Не дубль (1)");
        crmDoublesModal.clickButtonOnModalWindowByName("Отмена");
        mainPage.refreshPage();

        crmSectionPage.checkTextInRightBlock("Дубли", "Совпадений не найдено");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2f298e36-5e3c-43bd-90f3-2248515bb5f2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2f298e36-5e3c-43bd-90f3-2248515bb5f2)")
    @DisplayName("Объединение элементов-дублей")
    public void combiningDuplicateElementsTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "combiningDuplicateElements" + RandomString.get(4);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 1);
        crmSectionPage.clickTextInRightBlock("Дубли", "Подробнее");
        crmDoublesModal.clickCheckboxInModalLearnMoreDuplicates(leadName);
        crmDoublesModal.clickButtonOnModalWindowByName("Объединить (1)");
        crmDoublesModal.clickButtonInModalWindowCombineLeads("Объединить");
        mainPage.refreshPage();

        crmSectionPage.checkTextInRightBlock("Дубли", "Объединены в текущий элемент (1)");
        crmSectionPage.checkTextInRightBlock("Дубли", "Это дубль: 0%. Совпадений: 0.");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a2830d5a-99ca-4949-b7ee-338286687005", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a2830d5a-99ca-4949-b7ee-338286687005)")
    @DisplayName("Поиск дублей")
    public void searchDoubleTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "searchDouble" + RandomString.get(4);
        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 1);
        crmSectionPage.clickTextInRightBlock("Дубли", "Подробнее");
        crmDoublesModal.checkModalWindowWithNameVisible("Подробнее о дублях");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d3854f72-674e-405f-9ded-4d504e74b3a2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d3854f72-674e-405f-9ded-4d504e74b3a2)")
    @DisplayName("Проверить закрытие активностей CRM после перемещения лида в статус Неквалифицирован")
    public void closeActiveCRMAfterMovedLeadInStatusUnqualifiedTest() {
        String leadName = "closeActiveCRMAfterMovedLeadInStatusUnqualified" + RandomString.get(4);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 1);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();
        crmSectionPage.changeStatusInDealCard("Неквалифицирован");
        crmDoublesModal.clickButtonOnModalWindowByName("Сменить статус");
        mainPage.checkAlertWithTextFragmentExists("Статус успешно изменен");
        mainPage.refreshPage();

        crmSectionPage.checkDisplayedOnCardCrossedOut("Позвонить " + leadName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9f8c677f-5c7e-4b8f-a6b1-d90029c0afa1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9f8c677f-5c7e-4b8f-a6b1-d90029c0afa1)")
    @DisplayName("Проверить закрытие активностей CRM после перемещения сделки в статус Закрыта неуспешно")
    public void closeActiveCRMAfterMovedDealInStatusCloseTest() {
        String dealName = "closeActiveCRMAfterMovedDealInStatusClose" + RandomString.get(4);
        backendCrm.createDeal(dealName);

        mainPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName, 1);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();
        crmSectionPage.changeStatusInDealCard("Закрыта неуспешно");
        crmDoublesModal.clickButtonOnModalWindowByName("Сменить статус");
        mainPage.checkAlertWithTextFragmentExists("Статус успешно изменен");
        mainPage.refreshPage();

        crmSectionPage.checkDisplayedOnCardCrossedOut("Позвонить " + dealName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2ab2047c-c52b-4ef4-a3c9-224ead35fd98", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2ab2047c-c52b-4ef4-a3c9-224ead35fd98)")
    @DisplayName("Проверить поиск по Названию")
    public void searchByNameTest() {
        String leadNameOne = "searchByNameLeadOne" + RandomString.get(4);
        String leadNameTwo = "searchByNameLeadTwo" + RandomString.get(4);
        backendCrm.createLead(leadNameOne);
        backendCrm.createLead(leadNameTwo);

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.inputSearchByNameAndClickEnter(leadNameOne);
        mainPage.checkButtonOnAppContentExist("+ Лид");

        crmSectionPage.checkCardVisible(leadNameOne, 1);
        crmSectionPage.checkCardNotVisible(leadNameTwo, 1);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5a1a3191-7579-4bc7-b9da-bca719cb5dc4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5a1a3191-7579-4bc7-b9da-bca719cb5dc4)")
    @DisplayName("Поиск дублей при создании элемента приложения")
    public void searchDuplicatesCreatingAppElementTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "searchDuplicatesCreatingAppElement" + RandomString.get(8);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.chooseTabOnConfigPage("Результат поиска дублей");
        crmSectionPage.clickStartSearchByAppName("Приложение \"Лиды\"");
        crmDoublesModal.clickButtonOnModalWindowByName("Запустить проверку");

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");

        mainPage.clickButtonOnAppContent("+ Лид");
        createAppElementModal.fillName(leadName);
        sectionPage.clickSaveButton();
        mainPage.checkAlertWithTextFragmentExists("Лид успешно создан");

        mainPage.clickButtonOnAppContent("+ Лид");
        createAppElementModal.fillName(leadName);
        sectionPage.clickSaveButton();

        crmDoublesModal.checkModalWindowWithNameVisible("Подробнее о дублях");
        crmDoublesModal.checkContentModalBodyInModalWindow("Вероятно, данная запись является дублирующей. Найдены совпадения.");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5fea9d4a-b17e-42bf-bed1-8dd21252d43c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5fea9d4a-b17e-42bf-bed1-8dd21252d43c)")
    @DisplayName("Проверка поиска дублей среди элементов, процент совпадения которых ниже значения жёлтого коридора")
    public void checkSearchDuplicatesAmongElementsPercentLowerYellowCorridorTest() {
        backendCrm.initialStateOfDuplicateSettingsOriginalState();
        String leadName = "checkSearchDuplicatesAmongElementsPercentLowerYellowCorridor" + RandomString.get(8);

        backendCrm.createLead(leadName);
        backendCrm.createLead(leadName);

        mainPage.open("_clients/__duplicates");
        crmSectionPage.clickButtonOnConfigPage("Лид-Лид");
        crmDoublesModal.setWeightByFirstColumnValue("Название", 20);
        crmSectionPage.dialogWindowPressButton("Сохранить");
        crmSectionPage.changeStatusByFirstColumnValue("Лид-Лид", "Активен");
        crmSectionPage.clickButtonOnConfigPage("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Изменения успешно сохранены");
        crmSectionPage.clickButtonOnConfigPage("Запустить поиск");
        crmSectionPage.dialogWindowPressButton("Запустить проверку");

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Проверка на дубли завершена");

        crmSectionPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName, 1);


        crmSectionPage.checkTextInRightBlock("Дубли", "Совпадений не найдено");
        crmSectionPage.clickTextInRightBlock("Дубли", "Отметить дублем?");

        crmSectionPage.checkModalWindowWithNameVisible("Подробнее о дублях");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "32506e96-5fa4-47cc-9a66-a05b13dfcd3f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/32506e96-5fa4-47cc-9a66-a05b13dfcd3f)")
    @DisplayName("Проверить поиск по полю \\Ответственный\\")
    public void checkSearchByFieldResponsibleTest() {
        String leadNameAdmin = "checkSearchByFieldResponsibleAdmin" + RandomString.get(8);
        String leadNameUser = "checkSearchByFieldResponsibleUser" + RandomString.get(8);

        backendCrm.createLead(leadNameAdmin);
        backendCrm.createLeadUser(leadNameUser, backendCrm.getUserIdByEmail(userLogin));

        crmSectionPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkCardVisible(leadNameAdmin, 1);

        sectionPage.clickSearchInParametersTasks();
        sectionPage.setCheckboxConditionByLabel("Текущий пользователь", true);
        sectionPage.clickSearchByParameters();

        crmSectionPage.checkCardVisible(leadNameAdmin, 1);
        crmSectionPage.checkCardNotVisible(leadNameUser, 1);

        sectionPage.clickSearchInParametersTasks();
        sectionPage.setCheckboxConditionByLabel("Текущий пользователь", false);
        createTaskModal.clickExtendSearch();
        createTaskModal.fillReassignExecutor();
        createTaskModal.clickFoundedExecutor();
        sectionPage.clickSearchByParameters();

        crmSectionPage.checkCardNotVisible(leadNameAdmin, 1);
        crmSectionPage.checkCardVisible(leadNameUser, 1);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a4bd0602-385c-445a-bea3-5a5cf9cfe38c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a4bd0602-385c-445a-bea3-5a5cf9cfe38c)")
    @DisplayName("Быстрый поиск по названию или его части")
    public void quickSearchByNameOrPartOfItTest() {
        String leadName = "quickSearchByNameOrPartOfIt" + RandomString.get(8);

        backendCrm.createLead(leadName);
        crmSectionPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkCardVisible(leadName, 1);
        sectionPage.clickSearchInParametersTasks();
        changeElementBlockModal.setManualTextInput(leadName.substring(0, 5));
        sectionPage.clickSearchByParameters();

        crmSectionPage.checkCardVisible(leadName, 1);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a5925f9a-70ac-4ba0-b36e-6df12b83d4b7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a5925f9a-70ac-4ba0-b36e-6df12b83d4b7)")
    @DisplayName("Проверить функцию поиска \\Сохранить как фильтр\\")
    public void checkSearchFunctionSaveAsFilterTest() {
        String leadName = "checkSearchFunctionSaveAsFilter" + RandomString.get(8);
        String filterName = "checkSearchFunctionSaveAsFilterName" + RandomString.get(8);

        backendCrm.createLead(leadName);

        crmSectionPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkCardVisible(leadName, 1);
        sectionPage.clickSearchInParametersTasks();
        changeElementBlockModal.setManualTextInput(leadName);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр");
        settingFolderFilterModal.setNameNewFilter(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        mainPage.checkAlertWithTextFragmentExists("Фильтр успешно сохранен");
        settingFolderFilterModal.chooseSearchFilterFromList(filterName);

        crmSectionPage.checkCardVisible(leadName, 1);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b36b5ecf-120e-4985-bc17-27960c5cc5c0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b36b5ecf-120e-4985-bc17-27960c5cc5c0)")
    @DisplayName("Проверить поиск по системным фильтрам")
    public void checkSystemFilterSearchTest() {
        String leadName = "checkSystemFilterSearch" + RandomString.get(8);

        String leadId = backendCrm.createLead(leadName);
        backendCrm.setLeadStatusById(leadId, STATUS_PROCESSED);

        crmSectionPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkCardVisible(leadName, 2);
        sectionPage.clickSearchInParametersTasks();
        settingFolderFilterModal.chooseSearchFilterFromList("В работе");
        // todo: в тест-кейсе ошибка, при включении фильтра "в работе"
        //  отображается не kanban, а вертикальный список содержимого колонки
        crmSectionPage.checkListFieldVisible(leadName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "040bfe8b-9837-4df1-b232-7f38478211bf", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/040bfe8b-9837-4df1-b232-7f38478211bf)")
    @DisplayName("Добавить компанию")
    public void addNewCompanyTest() {
        String companyName = "Company" + RandomString.get(10);
        String contactName = "contactName" + RandomString.get(4);
        String dealName = "dealName" + RandomString.get(4);
        String industryName = "industriesName" + RandomString.get(4);
        String segmentName = "segmentName" + RandomString.get(4);
        String address = "address" + RandomString.get(4);
        String email = RandomString.get(8) + "@" + RandomString.get(4) + ".com";
        String web = RandomString.get(4) + ".com";
        String inn = "2324234233432";
        String kpp = "789789789078";
        String urName = "urName" + RandomString.get(4);
        String ogrn = "3433455534";
        String urAddress = "address" + RandomString.get(4);
        String PostAddress = "address" + RandomString.get(4);
        String Bank = "bank" + RandomString.get(4);
        String bik = "9203423934";
        String rs = "40000000440";
        String kors = "50000000441";
        String name = "name" + RandomString.get(4);
        String surname = "surname" + RandomString.get(4);
        String secondname = "secondname" + RandomString.get(4);
        String leadName = "leadName" + RandomString.get(4);

        backendCrm.createContact(contactName);
        backendCrm.createDeal(dealName);
        backendCrm.createIndustry(industryName);
        backendCrm.createSegment(segmentName);

        crmSectionPage.open("/_clients/_companies");
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Компания");
        crmSectionPage.setTextInputByFormRowName("Название", companyName);
        crmSectionPage.setTextInputByPlaceholder("Фамилия", surname);
        crmSectionPage.setTextInputByPlaceholder("Имя", name);
        crmSectionPage.setTextInputByPlaceholder("Отчество", secondname);
        crmSectionPage.setTextInputByFormRowName("Рабочий телефон", "+79090554433");
        crmSectionPage.setTextInputByFormRowName("Адрес", address);
        crmSectionPage.setTextInputByFormRowName("Рабочая почта", email);
        crmSectionPage.setTextInputByFormRowName("Web", web);
        crmSectionPage.setTextInputByFormRowName("ИНН", inn);
        crmSectionPage.setTextInputByFormRowName("КПП", kpp);
        crmSectionPage.setTextInputByFormRowName("Юридическое название", urName);
        crmSectionPage.setTextInputByFormRowName("ОГРН", ogrn);
        crmSectionPage.setTextInputByFormRowName("Юридический адрес", urAddress);
        crmSectionPage.setTextInputByFormRowName("Почтовый адрес", PostAddress);
        crmSectionPage.setTextInputByFormRowName("Банк", Bank);
        crmSectionPage.setTextInputByFormRowName("БИК", bik);
        crmSectionPage.setTextInputByFormRowName("Расчетный счет", rs);
        crmSectionPage.setTextInputByFormRowName("Корреспондентский счет", kors);

        settingsBlockModal.clickButtonZoomAllWithRowName("Контакты");
        mainPage.clickSelectName(contactName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Сделка");
        mainPage.clickSelectName(dealName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Отрасли");
        mainPage.clickSelectName(industryName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Сегмент");
        mainPage.clickSelectName(segmentName);
        settingsBlockModal.clickButtonOnFormRow("Лиды", "plus");
        settingsBlockModal.setTextInputByModalNameAndFormRowName("Добавить Лид", "Название", leadName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Лид успешно создан");
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        crmSectionPage.openCompany(companyName);
        crmSectionPage.checkTextForRowValue("Рабочий телефон", "+79090554433");
        crmSectionPage.checkTextForRowValue("Адрес", address);
        crmSectionPage.checkTextForRowValue("Рабочая почта", email);
        crmSectionPage.checkTextForRowValue("Web", web);
        crmSectionPage.checkTextForRowValue("ИНН", inn);
        crmSectionPage.checkTextForRowValue("КПП", kpp);
        crmSectionPage.checkTextForRowValue("Юридическое название", urName);
        crmSectionPage.checkTextForRowValue("ОГРН", ogrn);
        crmSectionPage.checkTextForRowValue("Юридический адрес", urAddress);
        crmSectionPage.checkTextForRowValue("Почтовый адрес", PostAddress);
        crmSectionPage.checkTextForRowValue("Банк", Bank);
        crmSectionPage.checkTextForRowValue("БИК", bik);
        crmSectionPage.checkTextForRowValue("Расчетный счет", rs);
        crmSectionPage.checkTextForRowValue("Корреспондентский счет", kors);
        crmSectionPage.checkTextForRowValue("ФИО руководителя", surname);
        crmSectionPage.checkTextForRowValue("ФИО руководителя", name);
        crmSectionPage.checkTextForRowValue("ФИО руководителя", secondname);
        crmSectionPage.checkTextForRowValue("Контакты", contactName);
        crmSectionPage.checkTextForRowValue("Сделка", dealName);
        crmSectionPage.checkTextForRowValue("Отрасли", industryName);
        crmSectionPage.checkTextForRowValue("Сегмент", segmentName);
        crmSectionPage.checkTextForRowValue("Лиды", leadName);
    }
}
