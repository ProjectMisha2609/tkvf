package e2eTests;

import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaPages.CompanyPage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("my_company")})
public class MyCompanyTests {
    @Inject
    protected CompanyPage companyPage;

    @Test
    @Link(value = "77699877-94d9-4d62-ac1e-f20886045b85", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/77699877-94d9-4d62-ac1e-f20886045b85)")
    @DisplayName("Проверить корректность отображения пользователей на вкладке \"Сотрудники\"")
    public void employeesAlphabeticalOrderTest() {
        companyPage.open("company", "birthdays");
        // TODO: на сайте в слове "сотрудники" английская C в начале.
        companyPage.appToolbar().selectAppByName("Cотрудники");

        companyPage.checkEmployeeListSorted();
    }
}
