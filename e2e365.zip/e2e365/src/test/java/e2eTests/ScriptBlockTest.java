package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.ParameterSettingsModal;
import pages.elmaModals.SelectAppModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.*;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("scriptblock")})
public class ScriptBlockTest {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected MessagePage messagePage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected SelectAppModal selectAppModal;
    @Inject
    MainPage mainPage;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f3c3ed54-66b4-4236-ab0f-641e1b598161", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f3c3ed54-66b4-4236-ab0f-641e1b598161)")
    @DisplayName("Вынести операцию Сценарий на схему бизнес-процесса")
    public void addScriptBlockOnSchemeTest() {
        String processName = "addScriptBlock" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.dragAndDropScriptBlockOnScheme("Сценарий");
        businessProcessPage.clickSave();

        businessProcessPage.checkElementByName("Сценарий 1");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "92de82c6-f89e-4790-9d7b-9c7e735515f9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/92de82c6-f89e-4790-9d7b-9c7e735515f9)")
    @DisplayName("Оповестить об ошибке текущего пользователя")
    public void notifyCurrentUserAboutErrorTest() {
        String processName = "addScriptBlock" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptBPWithMessageError.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Сценарий 1");
        parameterSettingsModal.clickAndSelectDropDownItem(" ", "testFunction");
        settingsBlockModal.chooseTab("Обработка ошибок");
        createContextModal.setCheckboxByName("Оповещать об ошибке пользователей:");
        parameterSettingsModal.clickButtonOnField("");
        settingsBlockModal.clickRadioButton("Текущий пользователь");
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        backendBusinessProcess.run(processId, EMPTY_JSON);

        businessProcessPage.checkSurfaceMessage("Сценарий завершился с ошибкой");
        messagePage.open("messages", "feed");
        messagePage.checkExistsMessage("taskWithErrorScript");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7d480c66-edcb-4f04-89b7-06bf52a62001", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7d480c66-edcb-4f04-89b7-06bf52a62001)")
    @DisplayName("Оповестить об ошибке пользователя из контекстной переменной")
    public void notifyCurrentUserAboutErrorFromContextVariableTest() {
        String processName = "addScriptBlock" + RandomString.get(16);
        String contextName = "UserVariable" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptBPWithMessageError.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(contextName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextUser();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(contextName, false);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Сценарий 1");
        parameterSettingsModal.clickAndSelectDropDownItem(" ", "testFunction");
        settingsBlockModal.chooseTab("Обработка ошибок");
        createContextModal.setCheckboxByName("Оповещать об ошибке пользователей:");
        parameterSettingsModal.clickButtonOnField("");
        settingsBlockModal.clickRadioButton("Контекстная переменная");
        parameterSettingsModal.clickAndSelectDropDownItem("Выберите переменную", contextName);
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");

        sectionPage.startCompanyProcess(processName);
        mainPage.clickLoupeButtonByFormRowName("");
        mainPage.clickSelectUser(adminLogin);
        sectionPage.processStartConfirmation();


        businessProcessPage.checkSurfaceMessage("Сценарий завершился с ошибкой");
        messagePage.open("messages", "feed");
        messagePage.checkExistsMessage("taskWithErrorScript");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "761903be-69e3-4f8b-be4c-5d0f6d5919e1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/761903be-69e3-4f8b-be4c-5d0f6d5919e1)")
    @DisplayName("Оповестить об ошибке пользователя из группы")
    public void notifyCurrentUserAboutErrorFromGroupTest() {
        String processName = "addScriptBlock" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptBPWithMessageError.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Сценарий 1");
        parameterSettingsModal.clickAndSelectDropDownItem(" ", "testFunction");
        settingsBlockModal.chooseTab("Обработка ошибок");
        createContextModal.setCheckboxByName("Оповещать об ошибке пользователей:");
        parameterSettingsModal.clickButtonOnField("");
        settingsBlockModal.clickRadioButton("Группа");
        parameterSettingsModal.clickAndSelectDropDownItem("Выберите группу", "Супервизор системы");
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        backendBusinessProcess.run(processId, EMPTY_JSON);
        businessProcessPage.checkSurfaceMessage("Сценарий завершился с ошибкой");
        messagePage.open("messages", "feed");
        messagePage.checkExistsMessage("taskWithErrorScript");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "cc96045e-0215-4384-8d4d-9535fe378e5c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cc96045e-0215-4384-8d4d-9535fe378e5c)")
    @DisplayName("Оповестить об ошибке пользователя из орг структуры")
    public void notifyCurrentUserAboutErrorFromOrgStructureTest() {
        String processName = "addScriptBlock" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptBPWithMessageError.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Сценарий 1");
        parameterSettingsModal.clickAndSelectDropDownItem(" ", "testFunction");
        settingsBlockModal.chooseTab("Обработка ошибок");
        createContextModal.setCheckboxByName("Оповещать об ошибке пользователей:");
        parameterSettingsModal.clickButtonOnField("");
        settingsBlockModal.clickRadioButton("Элемент оргструктуры");
        parameterSettingsModal.clickAndSelectBoxItem(" ", "Генеральный директор");
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        backendBusinessProcess.run(processId, EMPTY_JSON);
        businessProcessPage.checkSurfaceMessage("Сценарий завершился с ошибкой");
        messagePage.open("messages", "feed");
        messagePage.checkExistsMessage("taskWithErrorScript");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "23cb4329-f91f-4ed6-828f-007a484ff467", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/23cb4329-f91f-4ed6-828f-007a484ff467)")
    @DisplayName("Проверить прерывание процесса при ошибке в сценарии с переходом к другой операции")
    public void notifyCurrentUserAboutErrorAndSwitchTaskTest() {
        String processName = "addScriptBlock" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptBPWithMessageErrorAndSwitchTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Сценарий 1");
        parameterSettingsModal.clickAndSelectDropDownItem(" ", "testFunction");
        settingsBlockModal.chooseTab("Обработка ошибок");
        parameterSettingsModal.clickCheckBoxOnField("Прервать");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        backendBusinessProcess.run(processId, EMPTY_JSON);
        businessProcessPage.checkSurfaceMessage("Поставлена задача: TaskBeforeError");
    }
}
