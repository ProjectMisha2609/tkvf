package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.ProcessInstanceModal;
import pages.elmaPages.ProcessMonitorPage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("process_monitor")})
public class ProcessMonitorTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected ProcessMonitorPage processMonitorPage;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected ProcessInstanceModal processInstanceModal;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e1fa262a-1ac3-4cb7-8959-939a624f22dc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e1fa262a-1ac3-4cb7-8959-939a624f22dc)")
    @DisplayName("Проверить отображение информации по статусам на карточке процесса")
    public void checkDisplayTableInstancesAndTasksProcessTest() {
        String businessProcessName = "checkDisplayTableInstancesAndTasksProcessProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String processInstanceIdOne = backendBusinessProcess.run(processId, EMPTY_JSON);
        String processInstanceIdTwo = backendBusinessProcess.run(processId, EMPTY_JSON);
        String processInstanceIdThree = backendBusinessProcess.run(processId, EMPTY_JSON);

        backendBusinessProcess.interrupt(processInstanceIdOne);
        String taskId = backendTasks.getTaskByInstanceId(processInstanceIdTwo, 5000);
        sectionPage.openTask(taskId);
        sectionPage.clickNextStageOrExit();
        processMonitorPage.open("admin/monitor", processId);

        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
        processMonitorPage.selectConditionInInstanceCountersPanel("Прерван", 1);
        processMonitorPage.selectConditionInInstanceCountersPanel("Текущий", 1);
        // прерывание текущего процесса после проверки.
        backendBusinessProcess.interrupt(processInstanceIdThree);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "94dd71be-ca29-44ac-bb6b-2fd1dad14501", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/94dd71be-ca29-44ac-bb6b-2fd1dad14501)")
    @DisplayName("Открыть карточку экземпляра процесса из таблицы процессов")
    public void checkOpenProcessInstanceCardFromProcessTableTest() {
        String businessProcessName = "checkOpenProcessInstanceCardFromProcessTableProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId, EMPTY_JSON);
        processMonitorPage.open("admin/monitor", processId);
        processMonitorPage.openProcessInstanceInInstanceResultTable();

        processMonitorPage.checkTabList("История");
        processMonitorPage.checkTabList("Контекст");
        processMonitorPage.checkTabList("Карта процесса");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9b8d798e-a9fc-46e3-a061-7d9dec038e64", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9b8d798e-a9fc-46e3-a061-7d9dec038e64)")
    @DisplayName("Проверить отображение экземпляров процесса по конкретному исполнителю")
    public void checkDisplayOfProcessInstancesSpecificExecutorTest() {
        String businessProcessName = "checkDisplayOfProcessInstancesSpecificExecutorProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId, EMPTY_JSON);
        processMonitorPage.open("admin/monitor", processId);
        String assignee = processMonitorPage.clickByNumberInstancesProcess(adminLogin);

        processMonitorPage.checkPerformerSelectedUser(assignee);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "54ebf0a9-ed54-4159-a8a6-1c310f0d30a2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/54ebf0a9-ed54-4159-a8a6-1c310f0d30a2)")
    @DisplayName("Проверить отображение таблицы экземпляров и задач процесса")
    public void checkDisplayStatusInfoProcessCardTest() {
        String businessProcessName = "checkDisplayStatusInfoProcessCardProcessName" + RandomString.get(8);
        // TODO: одинаковые кейсы с checkDisplayTableInstancesAndTasksProcessTest
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String processInstanceIdOne = backendBusinessProcess.run(processId, EMPTY_JSON);
        String processInstanceIdTwo = backendBusinessProcess.run(processId, EMPTY_JSON);
        String processInstanceIdThree = backendBusinessProcess.run(processId, EMPTY_JSON);

        backendBusinessProcess.interrupt(processInstanceIdOne);
        String taskId = backendTasks.getTaskByInstanceId(processInstanceIdTwo, 5000);
        sectionPage.openTask(taskId);
        sectionPage.clickNextStageOrExit();
        processMonitorPage.open("admin/monitor", processId);

        processMonitorPage.selectConditionInInstanceCountersPanel("Текущий", 1);
        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
        processMonitorPage.selectConditionInInstanceCountersPanel("Прерван", 1);
        // прерывание текущего процесса после проверки.
        backendBusinessProcess.interrupt(processInstanceIdThree);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "bf0bfb1b-c62f-4c8d-90bb-dbc8c9d6c0a0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bf0bfb1b-c62f-4c8d-90bb-dbc8c9d6c0a0)")
    @DisplayName("Проверить переход на карточку процесса")
    public void checkTransitionProcessCardTest() {
        String businessProcessName = "checkDisplayStatusInfoProcessCardProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId, EMPTY_JSON);
        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(businessProcessName);
        processMonitorPage.clickAllProcessButton();

        processMonitorPage.checkHeaderPage("Информация о процессе");
        processMonitorPage.checkHeaderPage("По статусам и исполнителям");
        processMonitorPage.checkSizeOfResultTable(1);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b03ed0b6-5f9a-4e56-8dfd-1249203a3713", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b03ed0b6-5f9a-4e56-8dfd-1249203a3713)")
    @DisplayName("Проверить работу кнопки Все")
    public void checkAllProcessTasksButtonTest() {
        String processName = "checkAllProcessButtonProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTwoTasks.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.clickNextStageOrExit();
        sectionPage.checkNextStageNameEquals("Выход");

        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.clickAllProcessButton();
        processMonitorPage.openProcessInstance("TestStartSubProces");

        processInstanceModal.clickAllTasksButton();

        processInstanceModal.checkCountOfValuesByPatternInHistoryTable("Задача 1", 1);
        processInstanceModal.checkCountOfValuesByPatternInHistoryTable("Задача 2", 1);
        processInstanceModal.checkValueStateByPatternInHistoryTable("Задача 1", true);
        processInstanceModal.checkValueStateByPatternInHistoryTable("Задача 2", false);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "7c1c3549-6cf5-403c-b097-3665297bb3d4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7c1c3549-6cf5-403c-b097-3665297bb3d4)")
    @DisplayName("Проверить работу кнопки Текущие")
    public void checkActiveProcessTasksButtonTest() {
        String processName = "checkAllProcessButtonProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTwoTasks.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.clickNextStageOrExit();
        sectionPage.checkNextStageNameEquals("Выход");

        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.clickAllProcessButton();
        processMonitorPage.openProcessInstance("TestStartSubProces");

        processInstanceModal.clickAllTasksButton();
        processInstanceModal.clickActiveTasksButton();

        processInstanceModal.checkCountOfValuesByPatternInHistoryTable("Задача 1", 0);
        processInstanceModal.checkCountOfValuesByPatternInHistoryTable("Задача 2", 1);
        processInstanceModal.checkValueStateByPatternInHistoryTable("Задача 2", false);
    }

    @Test
    @Tag("bugged")
    @Tag("Author=Krasilnikov")
    @Link(value = "a1845e7e-11fb-45db-9387-eb07c55074c4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a1845e7e-11fb-45db-9387-eb07c55074c4)")
    @DisplayName("Проверить работу кнопки Обновление версии")
    public void checkVersionUpdateButtonTest() {
        String processName = "checkVersionUpdateButtonProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();
        sectionPage.checkNextStageNameEquals("Выход");

        lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTwoTasks.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.clickAllProcessButton();
        processMonitorPage.openProcessInstance("TestStartSubProces");

        processInstanceModal.selectTab("Карта");
        processInstanceModal.checkMapElementVisibility("Задача 1", true);
        processInstanceModal.checkMapElementVisibility("Задача 2", false);

        processInstanceModal.updateVersion();
        // TODO: баг, нужно открывать модальное окно заново, иначе изменений нет.
        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.clickAllProcessButton();
        processMonitorPage.openProcessInstance("TestStartSubProces");

        processInstanceModal.selectTab("Карта");
        processInstanceModal.checkMapElementVisibility("Задача 1", true);
        processInstanceModal.checkMapElementVisibility("Задача 2", true);
        processInstanceModal.checkProcessVersion(2);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "123be16c-0227-4e26-84c7-57f9f42a03a8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/123be16c-0227-4e26-84c7-57f9f42a03a8)")
    @DisplayName("Проверить работу кнопки Пропустить шаг")
    public void checkSkipStepButtonTest() {
        String processName = "checkSkipStepButtonProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithErrorScenario.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.clickAllProcessButton();
        processMonitorPage.openProcessInstance("TestStartSubProces");

        processInstanceModal.checkProcessInstanceHistory("Ошибка");
        processInstanceModal.skipTaskWithError();
        processInstanceModal.checkProcessInstanceHistory("Конец");
        processInstanceModal.close();
        processMonitorPage.refreshPage();
        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
    }
}
