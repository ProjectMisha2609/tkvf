package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.backendProcess.BackendProcess;
import infrastructure.elmaBackend.backendProcess.JsonProcess;
import infrastructure.elmaBackend.backendProcess.ProcessInfo;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.util.Locale;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;

@MicronautTest
@Tags({@Tag("express"), @Tag("ts_sdk")})
public class TsSdkTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected FilePage filePage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected SettingsActionsButtonModal settingsActionsButtonModal;
    @Inject
    protected SelectProcessModal selectProcessModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected AddNewAppModal addNewAppModal;
    @Inject
    protected CreateAppModal createAppModal;
    @Inject
    protected NomenclaturePage nomenclaturePage;
    @Inject
    protected CreateBpModal createBpModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendProcess backendProcess;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "02fb198b-e115-4df0-93e8-8132d86728d0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/02fb198b-e115-4df0-93e8-8132d86728d0)")
    @DisplayName("Проверить получение активных листов согласования в сценарии - getApprovalLists()")
    public void getApprovalListsInScriptTest() {
        String sectionName = "getApprovalListsInScriptSectionName" + RandomString.get(8);
        String appName = "getApprovalListsInScriptAppName" + RandomString.get(8);
        String elementName = "getApprovalListsInScriptElementName" + RandomString.get(8);
        String processName = "getApprovalListsInScriptProcessName" + RandomString.get(8);
        String idUser = elmaBackend.getUserIdByEmail(adminLogin);
        String stringName = "String" + RandomString.get(4);
        String comment = "comment" + RandomString.get(8);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    const approvalLists = await item!.docflow().getApprovalLists();
                    Context.data.%s= JSON.stringify(approvalLists);
                }""", appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String idElement = elmaBackend.createElement(elementName, sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(stringName, ContextType.STRING, false))
                        .addContextToActionFormByActionId("59d97370-88e2-40cd-a50c-7ce1ebb6cd3d", stringName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        elmaBackend.addProcessStartButtonToApplicationPage(sectionName, appName, processName);
        elmaBackend.sendApplicationElementForApproval(sectionName, appName, idElement, idUser);

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName + ": Согласовать", "Согласование");
        sectionPage.agreeWithComment(comment);

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("Запуск процесса");
        createAppElementModal.setTextInputWithSearchByFormRowName(appName, elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        taskModal.checkInputFormRowValue(stringName, comment);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "7aa032ca-ece2-4b0f-bbf9-670159b3b14c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7aa032ca-ece2-4b0f-bbf9-670159b3b14c)")
    @DisplayName("Проверить получение активных листов ознакомления в сценарии - getInformLists()")
    public void getInformListsInScriptTest() {
        String sectionName = "getInformListsInScriptSectionName" + RandomString.get(8);
        String appName = "getInformListsInScriptAppName" + RandomString.get(8);
        String elementName = "getInformListsInScriptElementName" + RandomString.get(8);
        String processName = "getInformListsInScriptProcessName" + RandomString.get(8);
        String idUser = elmaBackend.getUserIdByEmail(adminLogin);
        String stringName = "String" + RandomString.get(4);
        String comment = "comment" + RandomString.get(8);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    const approvalLists = await item!.docflow().getInformLists();
                    Context.data.%s= JSON.stringify(approvalLists);
                }""", appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String idElement = elmaBackend.createElement(elementName, sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(stringName, ContextType.STRING, false))
                        .addContextToActionFormByActionId("59d97370-88e2-40cd-a50c-7ce1ebb6cd3d", stringName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        elmaBackend.addProcessStartButtonToApplicationPage(sectionName, appName, processName);
        elmaBackend.sendApplicationElementForFamiliarization(sectionName, appName, idElement, idUser);

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName, "Ознакомление");
        sectionPage.familiarizationWithComment(comment);

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("Запуск процесса");
        createAppElementModal.setTextInputWithSearchByFormRowName(appName, elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        taskModal.checkInputFormRowValue(stringName, comment);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "152edae1-b64c-4645-a39c-5a021f6e2c73", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/152edae1-b64c-4645-a39c-5a021f6e2c73)")
    @DisplayName("Проверить возвращение листа согласования из архива в сценарии - unarchiveApprovalList(listId)")
    public void unarchiveApprovalListsInScriptTest() {
        String sectionName = "unarchiveApprovalListsInScriptSectionName" + RandomString.get(8);
        String appName = "unarchiveApprovalListsInScriptAppName" + RandomString.get(8);
        String elementName = "unarchiveApprovalListsInScriptElementName" + RandomString.get(8);
        String processName = "unarchiveApprovalListsInScriptProcessName" + RandomString.get(8);
        String idUser = elmaBackend.getUserIdByEmail(adminLogin);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    const approvalLists = await item!.docflow().getApprovalArchivedLists();
                    approvalLists.forEach(list => item.docflow().unarchiveApprovalList(list.__id))
                }""", appName.toLowerCase(Locale.ROOT));

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String idElement = elmaBackend.createElement(elementName, sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        elmaBackend.addProcessStartButtonToApplicationPage(sectionName, appName, processName);
        elmaBackend.sendApplicationElementForApproval(sectionName, appName, idElement, idUser);

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName + ": Согласовать", "Согласование");
        sectionPage.agreeWithoutComment();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки согласования");
        createAppElementModal.clickRadioButtonByLabel("Исключить системные поля по умолчанию");
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.openAppElement(sectionName, appName, elementName);
        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Листы согласования");
        widgetSettingsModal.checkContentInBlockApprovalList("Архив (1)");

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("Запуск процесса");
        createAppElementModal.setTextInputWithSearchByFormRowName(appName, elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.checkInscriptionAgreed("Согласовано");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e1b47302-1f1a-4ee0-8135-60134831d4fa", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e1b47302-1f1a-4ee0-8135-60134831d4fa)")
    @DisplayName("Проверить получение архивных листов согласования в сценарии - getApprovalArchivedLists()")
    public void getApprovalArchivedListsInScriptTest() {
        String sectionName = "getApprovalArchivedListsInScriptSectionName" + RandomString.get(8);
        String appName = "getApprovalArchivedListsInScriptAppName" + RandomString.get(8);
        String elementName = "getApprovalArchivedListsInScriptElementName" + RandomString.get(8);
        String processName = "getApprovalArchivedListsInScriptProcessName" + RandomString.get(8);
        String idUser = elmaBackend.getUserIdByEmail(adminLogin);
        String stringName = "String" + RandomString.get(4);
        String comment = "comment" + RandomString.get(8);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    const approvalLists = await item!.docflow().getApprovalArchivedLists();
                    Context.data.%s= JSON.stringify(approvalLists);
                }""", appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String idElement = elmaBackend.createElement(elementName, sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(stringName, ContextType.STRING, false))
                        .addContextToActionFormByActionId("59d97370-88e2-40cd-a50c-7ce1ebb6cd3d", stringName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        elmaBackend.addProcessStartButtonToApplicationPage(sectionName, appName, processName);
        elmaBackend.sendApplicationElementForApproval(sectionName, appName, idElement, idUser);

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName + ": Согласовать", "Согласование");
        sectionPage.agreeWithComment(comment);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки согласования");
        createAppElementModal.clickRadioButtonByLabel("Исключить системные поля по умолчанию");
        createAppElementModal.clickModalFooterButton("Сохранить");

        mainPage.clickButtonOnAppContent("Запуск процесса");
        createAppElementModal.setTextInputWithSearchByFormRowName(appName, elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        taskModal.checkInputFormRowValue(stringName, comment);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ac4887a7-d7db-40de-ad61-62e6131150cd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ac4887a7-d7db-40de-ad61-62e6131150cd)")
    @DisplayName("Проверить получение архивных листов ознакомления в сценарии - getInformArchivedLists()")
    public void getInformArchivedListsInScriptTest() {
        String sectionName = "getInformArchivedListsInScriptSectionName" + RandomString.get(8);
        String appName = "getInformArchivedListsInScriptAppName" + RandomString.get(8);
        String elementName = "getInformArchivedListsInScriptElementName" + RandomString.get(8);
        String processName = "getInformArchivedListsInScriptProcessName" + RandomString.get(8);
        String idUser = elmaBackend.getUserIdByEmail(adminLogin);
        String stringName = "String" + RandomString.get(4);
        String comment = "comment" + RandomString.get(8);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    const approvalLists = await item!.docflow().getInformArchivedLists();
                    Context.data.%s= JSON.stringify(approvalLists);
                }""", appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String idElement = elmaBackend.createElement(elementName, sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(stringName, ContextType.STRING, false))
                        .addContextToActionFormByActionId("59d97370-88e2-40cd-a50c-7ce1ebb6cd3d", stringName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        elmaBackend.addProcessStartButtonToApplicationPage(sectionName, appName, processName);
        elmaBackend.sendApplicationElementForFamiliarization(sectionName, appName, idElement, idUser);

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName, "Ознакомление");
        sectionPage.familiarizationWithComment(comment);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки согласования");
        createAppElementModal.clickRadioButtonByLabel("Исключить системные поля по умолчанию");
        createAppElementModal.clickModalFooterButton("Сохранить");

        mainPage.clickButtonOnAppContent("Запуск процесса");
        createAppElementModal.setTextInputWithSearchByFormRowName(appName, elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        taskModal.checkInputFormRowValue(stringName, comment);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "64d3236a-b7df-4a55-ba8f-49482451b43e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/64d3236a-b7df-4a55-ba8f-49482451b43e)")
    @DisplayName("Проверить получение папки элемента иерархического справочника в сценарии getFolder()")
    public void getFolderHierarchicalDirectoryInScriptTest() {
        String sectionName = "getFolderHierarchicalDirectoryInScriptSectionName" + RandomString.get(8);
        String appName = "getFolderHierarchicalDirectoryInScriptAppName" + RandomString.get(8);
        String processName = "getFolderHierarchicalDirectoryInScriptProcessName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String stringName = "String" + RandomString.get(4);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    const folder = await item!.getFolder();
                    Context.data.%s = folder!.name;
                }""", appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(stringName, ContextType.STRING, false))
                        .addContextToActionFormByActionId("59d97370-88e2-40cd-a50c-7ce1ebb6cd3d", stringName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.clickNameFolder(nameFolder);
        mainPage.clickButtonOnAppContent("+ Приложение");
        createAppElementModal.fillName(appName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
        sectionPage.clickTask(processName, "Задача 1");

        taskModal.checkInputFormRowValue(stringName, nameFolder);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f3b4b966-fc85-4436-b6fd-d21324c90e56", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f3b4b966-fc85-4436-b6fd-d21324c90e56)")
    @DisplayName("Проверить изменение папки для элемента иерархического справочника в сценарии setFolder()")
    public void setFolderHierarchicalDirectoryInScriptTest() {
        String sectionName = "setFolderHierarchicalDirectoryInScriptSectionName" + RandomString.get(8);
        String appName = "setFolderHierarchicalDirectoryInScriptAppName" + RandomString.get(8);
        String processName = "setFolderHierarchicalDirectoryInScriptProcessName" + RandomString.get(8);
        String nameFolderOne = "nameFolderOne" + RandomString.get(4);
        String nameFolderTwo = "nameFolderTwo" + RandomString.get(4);
        String nameAppItemOne = "nameAppItemOne" + RandomString.get(4);
        String idFolderOne = RandomString.getUUID();
        String idFolderTwo = RandomString.getUUID();
        String idAppItemOne = RandomString.getUUID();
        String stringName = "String" + RandomString.get(4);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = await Context.data.%s!.fetch();
                    await item!.setFolder('%s');
                }""", appName.toLowerCase(Locale.ROOT), idFolderTwo);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolderOne, nameFolderOne);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolderTwo, nameFolderTwo);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItemOne, nameAppItemOne, idFolderOne);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(stringName, ContextType.STRING, false))
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        // Шаг добавление кнопки сделан через веб, чтобы не повредить бэковый метод вкл иерархии
        sectionPage.open(sectionName, appName);
        sectionPage.checkAppElementExist(nameAppItemOne);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку запуска процесса");
        settingsActionsButtonModal.fillName("Запуск процесса");
        settingsActionsButtonModal.clickSelectProcess();
        selectProcessModal.selectDoubleFoldedTreeNodeElementByName(sectionName, appName, processName);
        selectProcessModal.checkProcessAddedInButtonRun(processName);
        settingsActionsButtonModal.clickSave();
        sectionPage.checkAppElementExist(nameAppItemOne);

        sectionPage.clickNameFolder(nameFolderOne);
        mainPage.clickButtonOnAppContent("Запуск процесса");
        createAppElementModal.setTextInputWithSearchByFormRowName(appName, nameAppItemOne);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open(sectionName, appName);
        sectionPage.clickNameFolder(nameFolderTwo);

        sectionPage.checkAppElementExist(nameAppItemOne);
    }

    /* ---- Start region: folders tests  ---- */

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3ae06158-cc40-4de4-bd1f-74906167041f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3ae06158-cc40-4de4-bd1f-74906167041f)")
    @DisplayName("Проверить создание новой папки в сценарии - create(name,parentId)")
    public void createFolderInScriptTest() {
        String processName = "createFolderInScriptProcessName" + RandomString.get(8);
        String folderName = "createFolderInScriptFolderName" + RandomString.get(8);
        String myFileFolder = backendBusinessProcess.getUserIdByEmail(adminLogin);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const name = "%s";
                    const parentId = "%s";
                    await System.directories.create(name,parentId);
                }""", folderName, myFileFolder);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        backendBusinessProcess.run(processId, EMPTY_JSON);

        filePage.open("files", myFileFolder);
        filePage.checkFileVisible(folderName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "ca066b80-9c40-4cab-8872-8b04bdb6066a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ca066b80-9c40-4cab-8872-8b04bdb6066a)")
    @DisplayName("Проверить создание новой папки в сценарии - createChildren(name)")
    public void createChildrenFolderInScriptTest() {
        String processName = "createChildrenFolderInScriptProcessName" + RandomString.get(8);
        String folderName = "createChildrenFolderInScriptFolder" + RandomString.get(8);
        String childFolderName = "folderName" + RandomString.get(8);

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const searchDir = await System.directories.search().where(di =>di.__id.eq('%s')).first();
                    await searchDir!.createChildren("%s");
                }""", folderId, childFolderName);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId, EMPTY_JSON);

        filePage.open("files", folderId);
        filePage.checkFileVisible(childFolderName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "a587961c-3a1a-405d-865f-345c83bed0b5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a587961c-3a1a-405d-865f-345c83bed0b5)")
    @DisplayName("Проверить поиск по папкам в сценарии - search()")
    public void searchFolderInScriptTest() {
        String processName = "searchFolderInScriptProcessName" + RandomString.get(8);
        String folderName = "searchFolderInScriptFolder" + RandomString.get(8);
        String variableName = "variable" + RandomString.get(8);

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const searchDir = await System.directories.search().where(di =>di.__id.eq('%s')).first();
                    Context.data.%s = searchDir!.data.__name;
                }""", folderId, variableName);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcessWithTask.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING))
                        .addContextToActionFormByActionId("59d97370-88e2-40cd-a50c-7ce1ebb6cd3d", variableName, "", false, false, false)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);

        sectionPage.openTask(taskId);
        taskModal.checkInputFormRowValue(variableName, folderName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "01e491a1-1954-4319-b15b-7695d95b76c4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/01e491a1-1954-4319-b15b-7695d95b76c4)")
    @DisplayName("Проверить получение родительских папок в сценарии - getParents(directoryId)")
    public void getParentFolderTest() {
        String sectionName = "getParentFolderSectionName" + RandomString.get(8);
        String pageName = "getParentFolderPageName" + RandomString.get(8);
        String folderName = "getParentFolderFolderName" + RandomString.get(8);

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);

        String tsFunction = String.format("""
                async function test(): Promise<void> {
                const parents = await System.directories.getParents("%s");
                Context.data.stroka = parents[0].data.__name;
                }""", folderId);

        backendBusinessProcess.createSection(sectionName);
        backendBusinessProcess.createPage(sectionName, pageName);
        backendBusinessProcess.createPreparedWidgetPageWithStringContext(sectionName, pageName, tsFunction);

        sectionPage.open(sectionName, pageName);
        // Даже с draft:false страница считается нетронутой, пока не побывали в конструкторе.
        // Решил посылать draft:true, а потом в конструкторе публиковать
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        mainPage.clickButtonOnAppContent("Тест");
        taskModal.checkInputFormRowValue("Строка", "home:" + backendBusinessProcess.getUserIdByEmail(adminLogin));
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "e24d2e2e-57f8-4902-a17d-eb0353ef986f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e24d2e2e-57f8-4902-a17d-eb0353ef986f)")
    @DisplayName("Проверить получение дочерних папок в сценарии - getChildren(directoryId)")
    public void getChildFolderTest() {
        String sectionName = "getChildFolderSectionName" + RandomString.get(8);
        String pageName = "getChildFolderPageName" + RandomString.get(8);
        String folderName = "getChildFolderFolderName" + RandomString.get(8);
        String childFolderName = "getChildFolderFolderName" + RandomString.get(8);

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);
        backendBusinessProcess.createFolderInFolder(childFolderName, folderId);

        // написано System.directories.getChildren("{{Айди вложенной папки}}"); но айди то нужен родителя.
        String tsFunction = String.format("""
                async function test(): Promise<void> {
                    const childsDir = await System.directories.getChildren("%s");
                    Context.data.stroka = childsDir[0].data.__name;
                    }""", folderId);

        backendBusinessProcess.createSection(sectionName);
        backendBusinessProcess.createPage(sectionName, pageName);
        backendBusinessProcess.createPreparedWidgetPageWithStringContext(sectionName, pageName, tsFunction);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        mainPage.clickButtonOnAppContent("Тест");
        taskModal.checkInputFormRowValue("Строка", childFolderName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d074114b-f9fc-476e-9262-ffb98b9d20aa", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d074114b-f9fc-476e-9262-ffb98b9d20aa)")
    @DisplayName("Проверить получение подпапок первого уровня вложенности в сценарии - getDirs(directoryId)")
    public void getSubChildFolderTest() {
        String sectionName = "getSubChildFolderSectionName" + RandomString.get(8);
        String pageName = "getSubChildFolderPageName" + RandomString.get(8);
        String folderName = "getSubChildFolderFolderName" + RandomString.get(8);
        String childFolderName = "getSubChildFolderFolderName" + RandomString.get(8);
        String anotherChildFolderName = "getSubChildFolderFolderName" + RandomString.get(8);

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);
        backendBusinessProcess.createFolderInFolder(childFolderName, folderId);
        backendBusinessProcess.createFolderInFolder(anotherChildFolderName, folderId);

        String tsFunction = String.format("""
                async function test(): Promise<void> {
                    const dirsInDir = await System.directories.getDirs("%s");
                    Context.data.stroka = '';
                    dirsInDir.forEach(async dir => await dir.getDirs());
                    dirsInDir!.forEach(f => Context.data.stroka += f.data.__name + "/");
                    }""", folderId);

        backendBusinessProcess.createSection(sectionName);
        backendBusinessProcess.createPage(sectionName, pageName);
        backendBusinessProcess.createPreparedWidgetPageWithStringContext(sectionName, pageName, tsFunction);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        mainPage.clickButtonOnAppContent("Тест");
        // Скрипт выдаёт вложенные папки итеративно, разделяя их слешами. Порядок не регламентируется.
        taskModal.checkInputFormRowValue("Строка", childFolderName);
        taskModal.checkInputFormRowValue("Строка", anotherChildFolderName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "058c5a9e-28ff-4936-b264-76a0fa33693a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/058c5a9e-28ff-4936-b264-76a0fa33693a)")
    @DisplayName("Проверить получение списка файлов в папке в сценарии - getFiles(directoryId)")
    public void getFilesInFolderTest() {
        String sectionName = "getFilesInFolderSectionName" + RandomString.get(8);
        String pageName = "getFilesInFolderPageName" + RandomString.get(8);
        String folderName = "getFilesInFolderFolderName" + RandomString.get(8);
        // в тесте почему-то был только один файл, делаю на два, так как в названии фигурирует список.
        String firstFileName = "file" + RandomString.get(8) + ".docx";
        String secondFileName = "file" + RandomString.get(8) + ".docx";

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);
        // пришлось добавить += и разделитель, а так же инициализировать строку, что бы обойти undefined в начале
        String tsFunction = String.format("""
                async function test(): Promise<void> {
                    const filesInDir = await System.directories.getFiles("%s");
                    Context.data.stroka = '';
                    filesInDir.forEach(file => Context.data.stroka += file.data.__name + "/");
                    }""", folderId);

        // Не знаю, зачем нужен офис, чтения файла в кейсе нет.
        // backendBusinessProcess.settingUsingOffice365(true);
        backendBusinessProcess.createFileInFolderById(firstFileName, folderId);
        backendBusinessProcess.createFileInFolderById(secondFileName, folderId);
        backendBusinessProcess.createSection(sectionName);
        backendBusinessProcess.createPage(sectionName, pageName);
        backendBusinessProcess.createPreparedWidgetPageWithStringContext(sectionName, pageName, tsFunction);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        mainPage.clickButtonOnAppContent("Тест");
        // Скрипт выдаёт вложенные папки итеративно, разделяя их слешами. Порядок не регламентируется.
        taskModal.checkInputFormRowValue("Строка", firstFileName);
        taskModal.checkInputFormRowValue("Строка", secondFileName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "136f7d52-3bfc-41af-a42d-1668f7f7fdca", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/136f7d52-3bfc-41af-a42d-1668f7f7fdca)")
    @DisplayName("Проверить удаление папки в сценарии - delete(directoryId)")
    public void deleteFolderInScriptTest() {
        String processName = "deleteFolderInScriptProcessName" + RandomString.get(8);
        String folderName = "deleteFolderInScriptFolderName" + RandomString.get(8);
        String myFileFolder = backendBusinessProcess.getUserIdByEmail(adminLogin);

        String folderId = backendBusinessProcess.createFolderInMyFilePageByUserLogin(folderName, adminLogin);

        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    await System.directories.delete("%s");
                }""", folderId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/TsProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .putFunction(tsFunction)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        filePage.open("files", myFileFolder);
        filePage.checkFileVisible(folderName);

        backendBusinessProcess.run(processId, EMPTY_JSON);

        filePage.open("files", myFileFolder);
        filePage.checkFileNotExists(folderName);
    }

    /* ---- End region: folders tests  ---- */
    /* ---- Start region: nomenclature tests  ---- */

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "50a3f1f1-8968-4395-8f9f-d963a7d504e6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/50a3f1f1-8968-4395-8f9f-d963a7d504e6)")
    @DisplayName("Проверить регистрацию элемента приложения в сценарии - register(nomenclatureId)")
    public void checkRegisterElementTest() {
        String sectionName = "checkRegisterElementSectionName" + RandomString.get(8);
        String appName = "checkRegisterElementAppName" + RandomString.get(8);
        String registrationPlaceName = "checkRegisterElementRegistrationPlaceName" + RandomString.get(8);
        String processName = "checkRegisterElementProcessName" + RandomString.get(8);
        String dossierName = "dossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    if(Context.data.%s != undefined){
                        const settings = await Application.getSettings();
                        settings.registrationSettings.nomenclatureIds.forEach(nom => Context.data.%s!.docflow().register(nom))
                    } else {
                        throw new Error("Not Found element App")
                    }
                }
                """, appName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT));

        backendProcess.createPlaceOfRegistration(registrationPlaceName);
        String placeRegId = backendProcess.getPlaceRegistrationIdByName(registrationPlaceName);

        backendProcess.createSerialNumForNomenclature(serialId, dossierName);
        backendProcess.createDossierNomenclature(dossierName, placeRegId, serialId);
        backendProcess.createSection(sectionName);
        backendProcess.createApplicationDocumentType(sectionName, appName);
        ProcessInfo processInfo = backendProcess.createInApplication(sectionName, appName, processName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/SimpleScript.json", processInfo)
                        .addScript(tsFunction)
                        .setFunctionInScriptBlock("5ac7b1ff-8ff1-406c-ad8d-d1ccd1247415", "functionName"))
                .publication();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(registrationPlaceName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();// TODO у этого метода несколько реплик
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.checkNumerationRegDocument("1");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "82b10179-de36-4f0e-87a3-283de314911a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/82b10179-de36-4f0e-87a3-283de314911a)")
    @DisplayName("Проверить отмену регистрации элемента приложения в сценарии - deleteRegistration(nomenclatureId)")
    public void checkDeleteElementRegistrationTest() {
        String sectionName = "checkDeleteElementRegistrationSectionName" + RandomString.get(8);
        String appName = "checkDeleteElementRegistrationAppName" + RandomString.get(8);
        String registrationPlaceName = "checkDeleteElementRegistrationPlaceName" + RandomString.get(8);
        String processName = "checkDeleteElementRegistrationProcessName" + RandomString.get(8);
        String dossierName = "dossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    if(Context.data.%s != undefined){
                    const settings = await Application.getSettings();
                    settings.registrationSettings.nomenclatureIds.forEach(nomenclatureId =>
                    Context.data.%s!.docflow().deleteRegistration(nomenclatureId))
                } else {
                    throw new Error("Not Found element App")
                """, appName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT));

        backendBusinessProcess.createPlaceOfRegistration(registrationPlaceName);
        String placeRegId = backendBusinessProcess.getPlaceRegistrationIdByName(registrationPlaceName);

        backendBusinessProcess.createSerialNumForNomenclature(serialId, dossierName);
        backendBusinessProcess.createDossierNomenclature(dossierName, placeRegId, serialId);

        backendBusinessProcess.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();
        createAppModal.chooseTypeOfApp("Документ");
        createAppModal.fillName(appName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");
        sectionPage.checkAppCreated(appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(registrationPlaceName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(dossierName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(processName);
        createBpModal.dialogWindowPressButton("Создать");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Сценарий");
        businessProcessPage.moveArrow("", "Сценарий");
        businessProcessPage.moveArrowFinish("Сценарий");

        businessProcessPage.clickSettingsBlock("");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(appName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.clickAddNewFunction();
        settingsBlockModal.fillFunctionName("functionName");
        settingsBlockModal.clickCreateFunction();
        settingsBlockModal.clickOpenFunction();
        businessProcessPage.fillSimpleScript(tsFunction);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку запуска процесса");
        settingsActionsButtonModal.fillName("Запуск процесса");
        settingsActionsButtonModal.clickSelectProcess();
        selectProcessModal.selectDoubleFoldedTreeNodeElementByName(sectionName, appName, processName);
        selectProcessModal.checkProcessAddedInButtonRun(processName);
        settingsActionsButtonModal.clickSave();
        sectionPage.appHeaderToolbar().clickCloseActionButton();
        sectionPage.appHeaderToolbar().clickActionButton("Запуск процесса");

        settingsBlockModal.setTextInputWithSearchByFormRowName(appName, "starfish.png");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open(sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.checkDocumentNotRegistered();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "efa08355-7097-4859-a0a2-3556d20cbde6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/efa08355-7097-4859-a0a2-3556d20cbde6)")
    @DisplayName("Проверить получение списка регистраций элемента приложения в сценарии - getRegistrations()")
    public void checkGetRegistrationTest() {
        String sectionName = "checkGetRegistrationSectionName" + RandomString.get(8);
        String appName = "checkGetRegistrationAppName" + RandomString.get(8);
        String registrationPlaceName = "checkGetRegistrationPlaceName" + RandomString.get(8);
        String processName = "checkGetRegistrationProcessName" + RandomString.get(8);
        String dossierName = "dossier" + RandomString.get(4);
        String stringName = "stringVar" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    if(Context.data.%s != undefined) {
                    const item = Context.data.%s!;
                    const registrations = await item.docflow().getRegistrations();
                    registrations.forEach(registry =>
                    Context.data.%s = registry.__name)
                } else {
                    throw new Error("Not Found element App")
                """, appName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        backendBusinessProcess.createPlaceOfRegistration(registrationPlaceName);
        String placeRegId = backendBusinessProcess.getPlaceRegistrationIdByName(registrationPlaceName);

        backendBusinessProcess.createSerialNumForNomenclature(serialId, dossierName);
        backendBusinessProcess.createDossierNomenclature(dossierName, placeRegId, serialId);

        backendBusinessProcess.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();
        createAppModal.chooseTypeOfApp("Документ");
        createAppModal.fillName(appName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");
        sectionPage.checkAppCreated(appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(registrationPlaceName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(dossierName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(processName);
        createBpModal.dialogWindowPressButton("Создать");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Сценарий");
        businessProcessPage.moveArrow("", "Сценарий");
        businessProcessPage.simpleDragAndDropBelowBlock("Задача", "Сценарий 1");
        businessProcessPage.moveArrow("Сценарий 1", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");

        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(stringName);
        createContextModal.selectContextType("Строка");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(stringName, "Строка");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickSettingsBlock("");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(appName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(stringName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(stringName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.clickAddNewFunction();
        settingsBlockModal.fillFunctionName("functionName");
        settingsBlockModal.clickCreateFunction();
        settingsBlockModal.clickOpenFunction();
        businessProcessPage.fillSimpleScript(tsFunction);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку запуска процесса");
        settingsActionsButtonModal.fillName("Запуск процесса");
        settingsActionsButtonModal.clickSelectProcess();
        selectProcessModal.selectDoubleFoldedTreeNodeElementByName(sectionName, appName, processName);
        selectProcessModal.checkProcessAddedInButtonRun(processName);
        settingsActionsButtonModal.clickSave();
        sectionPage.appHeaderToolbar().clickCloseActionButton();
        sectionPage.appHeaderToolbar().clickActionButton("Запуск процесса");

        settingsBlockModal.setTextInputWithSearchByFormRowName(appName, "starfish.png");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
        sectionPage.clickTask(processName, "Задача 1");
        taskModal.checkInputFormRowValue(stringName, "1");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "9dd79456-5370-46b4-9d2d-af1e06e12a44", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9dd79456-5370-46b4-9d2d-af1e06e12a44)")
    @DisplayName("Проверить получение дела по номеру в сценарии - getNomenclature(nomenclatureId)")
    public void checkGetNomenclatureIdTest() {
        String sectionName = "checkGetNomenclatureIdSectionName" + RandomString.get(8);
        String appName = "checkGetNomenclatureIdAppName" + RandomString.get(8);
        String registrationPlaceName = "checkGetNomenclatureIdPlaceName" + RandomString.get(8);
        String processName = "checkGetNomenclatureIdProcessName" + RandomString.get(8);
        String dossierName = "dossier" + RandomString.get(4);
        String stringName = "stringVar" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    const item = Context.data.%s!;
                    const settings = await Application.getSettings();
                    if (settings.registrationSettings.nomenclatureIds) {
                        for(const firstNomId of settings.registrationSettings.nomenclatureIds) {
                            const firstNom = await item.docflow().getNomenclature(firstNomId);
                            if (firstNom!== undefined && !firstNom.__deletedAt) {
                                Context.data.%s = firstNom.__name
                            }
                        }""", appName.toLowerCase(Locale.ROOT), stringName.toLowerCase(Locale.ROOT));

        backendBusinessProcess.createPlaceOfRegistration(registrationPlaceName);
        String placeRegId = backendBusinessProcess.getPlaceRegistrationIdByName(registrationPlaceName);

        backendBusinessProcess.createSerialNumForNomenclature(serialId, dossierName);
        backendBusinessProcess.createDossierNomenclature(dossierName, placeRegId, serialId);

        backendBusinessProcess.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();
        createAppModal.chooseTypeOfApp("Документ");
        createAppModal.fillName(appName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");
        sectionPage.checkAppCreated(appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(registrationPlaceName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(processName);
        createBpModal.dialogWindowPressButton("Создать");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Сценарий");
        businessProcessPage.moveArrow("", "Сценарий");
        businessProcessPage.simpleDragAndDropBelowBlock("Задача", "Сценарий 1");
        businessProcessPage.moveArrow("Сценарий 1", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");

        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(stringName);
        createContextModal.selectContextType("Строка");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(stringName, "Строка");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickSettingsBlock("");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(appName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(stringName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(stringName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.clickAddNewFunction();
        settingsBlockModal.fillFunctionName("functionName");
        settingsBlockModal.clickCreateFunction();
        settingsBlockModal.clickOpenFunction();
        businessProcessPage.fillSimpleScript(tsFunction);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.clickModalFooterButton("Сохранить");

        taskModal.checkInputFormRowValue(appName, "starfish");
        sectionPage.clickNextStageOrExit();
        taskModal.checkInputFormRowValue(stringName, dossierName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d64d51cf-769b-40b8-b5a6-2d6e0eefbecc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d64d51cf-769b-40b8-b5a6-2d6e0eefbecc)")
    @DisplayName("Проверить резервирование номера для регистрации в сценарии - reserve(nomenclatureId)")
    public void checkReserveNomenclatureIdTest() {
        String sectionName = "checkReserveNomenclatureIdSectionName" + RandomString.get(8);
        String appName = "checkReserveNomenclatureIdAppName" + RandomString.get(8);
        String registrationPlaceName = "checkReserveNomenclatureIdRegistrationPlaceName" + RandomString.get(8);
        String processName = "checkReserveNomenclatureIdProcessName" + RandomString.get(8);
        String dossierName = "dossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    if(Context.data.%s != undefined) {
                    const item = Context.data.%s!;
                    const settings = await Application.getSettings();
                    settings.registrationSettings.nomenclatureIds.forEach(nomenclatureId =>
                           item.docflow().reserve(nomenclatureId))
                } else {
                    throw new Error("Not Found element App")
                """, appName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT));

        backendBusinessProcess.createPlaceOfRegistration(registrationPlaceName);
        String placeRegId = backendBusinessProcess.getPlaceRegistrationIdByName(registrationPlaceName);

        backendBusinessProcess.createSerialNumForNomenclature(serialId, dossierName);
        backendBusinessProcess.createDossierNomenclature(dossierName, placeRegId, serialId, true);

        backendBusinessProcess.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();
        createAppModal.chooseTypeOfApp("Документ");
        createAppModal.fillName(appName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");
        sectionPage.checkAppCreated(appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(registrationPlaceName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(processName);
        createBpModal.dialogWindowPressButton("Создать");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Сценарий");
        businessProcessPage.moveArrow("", "Сценарий");
        businessProcessPage.moveArrowFinish("Сценарий 1");

        businessProcessPage.clickSettingsBlock("");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(appName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.clickAddNewFunction();
        settingsBlockModal.fillFunctionName("functionName");
        settingsBlockModal.clickCreateFunction();
        settingsBlockModal.clickOpenFunction();
        businessProcessPage.fillSimpleScript(tsFunction);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку запуска процесса");
        settingsActionsButtonModal.fillName("Запуск процесса");
        settingsActionsButtonModal.clickSelectProcess();
        selectProcessModal.selectDoubleFoldedTreeNodeElementByName(sectionName, appName, processName);
        selectProcessModal.checkProcessAddedInButtonRun(processName);
        settingsActionsButtonModal.clickSave();
        sectionPage.appHeaderToolbar().clickCloseActionButton();
        sectionPage.appHeaderToolbar().clickActionButton("Запуск процесса");

        settingsBlockModal.setTextInputWithSearchByFormRowName(appName, "starfish.png");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.checkRegistrationNumberReserved(dossierName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b40cde8a-afeb-472b-b4ed-dee6d741b18b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b40cde8a-afeb-472b-b4ed-dee6d741b18b)")
    @DisplayName("Проверить отмену резервирования номера для регистрации в сценарии - deleteReservation(nomenclatureId)")
    public void checkRemoveReserveNomenclatureIdTest() {
        String sectionName = "checkRemoveReserveNomenclatureIdSectionName" + RandomString.get(8);
        String appName = "checkRemoveReserveNomenclatureIdAppName" + RandomString.get(8);
        String registrationPlaceName = "checkRemoveReserveNomenclatureIdRegistrationPlaceName" + RandomString.get(8);
        String processName = "checkRemoveReserveNomenclatureIdProcessName" + RandomString.get(8);
        String dossierName = "dossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String tsFunction = String.format("""
                async function functionName(): Promise<void> {
                    if(Context.data.%s != undefined) {
                    const item = Context.data.%s!;
                    const settings = await Application.getSettings();
                    settings.registrationSettings.nomenclatureIds.forEach(nomenclatureId =>
                           item.docflow().deleteReservation(nomenclatureId))
                } else {
                    throw new Error("Not Found element App")
                """, appName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT));

        backendBusinessProcess.createPlaceOfRegistration(registrationPlaceName);
        String placeRegId = backendBusinessProcess.getPlaceRegistrationIdByName(registrationPlaceName);

        backendBusinessProcess.createSerialNumForNomenclature(serialId, dossierName);
        backendBusinessProcess.createDossierNomenclature(dossierName, placeRegId, serialId, true);

        backendBusinessProcess.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();
        createAppModal.chooseTypeOfApp("Документ");
        createAppModal.fillName(appName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");
        sectionPage.checkAppCreated(appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(registrationPlaceName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocumentWithReserveNumber(dossierName);
        nomenclaturePage.checkReserveNumerationRegDocument("1");

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(processName);
        createBpModal.dialogWindowPressButton("Создать");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Сценарий");
        businessProcessPage.moveArrow("", "Сценарий");
        businessProcessPage.moveArrowFinish("Сценарий 1");

        businessProcessPage.clickSettingsBlock("");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(appName, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.clickAddNewFunction();
        settingsBlockModal.fillFunctionName("functionName");
        settingsBlockModal.clickCreateFunction();
        settingsBlockModal.clickOpenFunction();
        businessProcessPage.fillSimpleScript(tsFunction);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку запуска процесса");
        settingsActionsButtonModal.fillName("Запуск процесса");
        settingsActionsButtonModal.clickSelectProcess();
        selectProcessModal.selectDoubleFoldedTreeNodeElementByName(sectionName, appName, processName);
        selectProcessModal.checkProcessAddedInButtonRun(processName);
        settingsActionsButtonModal.clickSave();
        sectionPage.appHeaderToolbar().clickCloseActionButton();
        sectionPage.appHeaderToolbar().clickActionButton("Запуск процесса");

        settingsBlockModal.setTextInputWithSearchByFormRowName(appName, "starfish.png");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.checkRegistrationNumberNotReserved(dossierName);
    }
}
