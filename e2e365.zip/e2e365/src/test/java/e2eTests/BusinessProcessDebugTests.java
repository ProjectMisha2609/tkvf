package e2eTests;


import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import infrastructure.utils.Constants;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.ParameterSettingsModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.BusinessProcessDebugPage;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.PageConstructorPage;
import pages.elmaPages.SectionPage;

import java.time.Duration;
import java.time.LocalTime;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.utils.Constants.ELMA_TMS;
import static org.junit.jupiter.api.Assertions.assertTrue;

@MicronautTest
@Tags({@Tag("express"), @Tag("process_debug")})
public class BusinessProcessDebugTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BusinessProcessDebugPage businessProcessDebugPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "133b2571-f30c-4ae4-8894-51fb118f2958", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/133b2571-f30c-4ae4-8894-51fb118f2958)")
    @DisplayName("Отображение ленты по процессу при отладке")
    public void viewTapeOfProcessAtDebugTest() {
        String processName = "viewTapeOfProcessAtDebugProcessName" + RandomString.get(8);
        String sectionName = "viewTapeOfProcessAtDebugSectionName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickDebug();

        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkTapeMessage("На шаге \"Задача 1\" создана задача Задача 1");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d48ed08a-14fe-4569-9999-8496de91a7c9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d48ed08a-14fe-4569-9999-8496de91a7c9)")
    @DisplayName("Отображение истории по процессу")
    public void viewHistoryProcessAtDebugTest() {
        String processName = "viewHistoryProcessProcessName" + RandomString.get(8);
        String sectionName = "viewHistoryProcessSectionName" + RandomString.get(8);
        String adminName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickDebug();

        String startTime = LocalTime.now().format(Constants.DateAndTimeFormatters.FORMATTER_HH_MM);
        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkActionComponentOnDiagramExists("Задача 1");
        String createTime = businessProcessDebugPage.getCreateTimeFromHistory("Задача 1", adminName);
        assertTrue(Duration.between(LocalTime.parse(createTime), LocalTime.parse(startTime)).abs().toMinutes() <= 5, "Время запуска отладки БП не совпало с текущим временем");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "641fed45-aaa7-49e5-8c76-3cf93fb47bf3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/641fed45-aaa7-49e5-8c76-3cf93fb47bf3)")
    @DisplayName("Проверить, что задачи, созданные при отладке, не появились в списках задач")
    public void checkNotCreateTaskAtStartDebugTest() {
        String processName = "viewHistoryProcessProcessName" + RandomString.get(8);
        String sectionName = "viewHistoryProcessSectionName" + RandomString.get(8);
        String adminName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickDebug();

        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkHistoryRecordExists("Задача 1", adminName);
        businessProcessPage.open("/tasks/income");
        sectionPage.checkLoadTaskListPage();
        sectionPage.checkTaskOnListNotExists(processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7d1907db-4bb7-45f2-a4f2-b5095c9efa75", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7d1907db-4bb7-45f2-a4f2-b5095c9efa75)")
    @DisplayName("Отображение контекста процесса при отладке")
    public void viewContextAtStartDebugTest() {
        String processName = "viewHistoryProcessProcessName" + RandomString.get(8);
        String sectionName = "viewHistoryProcessSectionName" + RandomString.get(8);
        String variableName = "String" + RandomString.get(4);
        String checkText = "checkText" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        pageConstructorPage.selectMainTab("Контекст");
        sectionPage.refreshPage();
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextString();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickDebug();

        parameterSettingsModal.fillFieldSetting(variableName, checkText);
        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkContextExists(variableName, checkText);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0e3d2f21-23b8-482c-8e04-8f385537a531", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0e3d2f21-23b8-482c-8e04-8f385537a531)")
    @DisplayName("Отображение карты процесса при отладке")
    public void viewMapProcessAtStartDebugTest() {
        String processName = "viewMapProcessAtStartDebugProcessName" + RandomString.get(8);
        String sectionName = "viewMapProcessAtStartDebugSectionName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickDebug();
        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkViewMapSimpleProcessAtStartDebug();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "da7c9642-e0eb-4a77-8c6f-f32301c060ec", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/da7c9642-e0eb-4a77-8c6f-f32301c060ec)")
    @DisplayName("Проверить отладку процесса")
    public void checkMainsFormsAtStartDebugTest() {
        String processName = "checkMainsFormsAtStartDebugProcessName" + RandomString.get(8);
        String sectionName = "checkMainsFormsAtStartDebugSectionName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickDebug();
        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkMainsFormsExists("История", "Карта", "Лента", "Контекст");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5f0687b4-eab5-4bdc-b05b-1dd3c77aae73", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5f0687b4-eab5-4bdc-b05b-1dd3c77aae73)")
    @DisplayName("Проверить отладку процесса с подпроцессом")
    public void checkProcessWithSubprocessAtStartDebugTest() {
        String processName = "checkProcessWithSubprocessAtStartProcessName" + RandomString.get(8);
        String sectionName = "checkProcessWithSubprocessAtStartSectionName" + RandomString.get(8);
        String adminName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        String subprocessName = "subprocessAtStartProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithSubprocess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String subprocessId = backendBusinessProcess.createBusinessProcess(sectionName, subprocessName);
        lockHash = backendBusinessProcess.lock(subprocessId);
        backendBusinessProcess.saveChanges(subprocessId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(subprocessId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Запуск");
        parameterSettingsModal.selectProcessParameter(sectionName, subprocessName);
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.clickDebug();
        sectionPage.processStartConfirmation();

        businessProcessDebugPage.checkActionComponentOnDiagramExists("Задача 1");
        businessProcessDebugPage.clickTaskOnHistoryForm("Задача 1");
        parameterSettingsModal.clickModalFooterButton("-> Запуск процесса 1");
        businessProcessDebugPage.clickHeaderTabs("TestStartSubProces");
        businessProcessDebugPage.clickTaskOnHistoryForm("Задача 1");
        parameterSettingsModal.clickModalFooterButton("-> Выход");
        businessProcessDebugPage.clickHeaderTabs("BaseProcess");
        businessProcessDebugPage.clickTaskOnHistoryForm("Задача 2");
        parameterSettingsModal.clickModalFooterButton("-> Выход");

        businessProcessDebugPage.checkHistoryRecordExists("Конец", adminName);
    }
}
