package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.APPLICATION_WITH_TABLE;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("table")})
public class TableSettingsTests {

    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected TableSettingsModal tableSettingsModal;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3b87c215-4270-4797-9dfd-f00fecb9ffba", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3b87c215-4270-4797-9dfd-f00fecb9ffba)")
    @DisplayName("Добавить Надпись в футере колонки")
    public void addTextOnTableFooterTest() {
        String sectionName = "addTextOnTableFooterSectionName" + RandomString.get(8);
        String applicationName = "addTextOnTableFooterApplicationName" + RandomString.get(8);
        String columnName = "addTextOnTableFooterColumnName" + RandomString.get(8);
        String footerText = "footerText" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.setFooterText(footerText);
        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);
        tableSettingsModal.checkTextExistsOnTableFooter(footerText);
    }

    @Test
    @Tag("bugged")
    @Tag("Author=Krasilnikov")
    @Link(value = "1e6a6c35-50c4-4a33-9250-abc08e8892a4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1e6a6c35-50c4-4a33-9250-abc08e8892a4)")
    @DisplayName("Проверить работу кнопки \\Создать и новое\\ при добавлении колонки")
    public void checkCreateAndNewButtonOnTableColumnTest() {
        String sectionName = "checkCreateAndNewButtonOnTableColumnSectionName" + RandomString.get(8);
        String applicationName = "checkCreateAndNewButtonOnTableColumnApplicationName" + RandomString.get(8);
        String columnName = "checkCreateAndNewButtonOnTableColumnColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        // todo: известный баг, не открывается окно создания новой колонки.
        parameterSettingsModal.dialogWindowPressButton("Создать и новое");

        parameterSettingsModal.dialogWindowCheckButton("Создать и новое");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "651271e3-4db4-4e2f-a61a-096790c7a3d5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/651271e3-4db4-4e2f-a61a-096790c7a3d5)")
    @DisplayName("Отображение таблицы произвольно")
    public void setTableViewInPixelTest() {
        String sectionName = "setTableViewInPixelSectionName" + RandomString.get(8);
        String applicationName = "setTableViewInPixelApplicationName" + RandomString.get(8);
        // из-за длины названия браузер считает, что колонка длиннее.
        String columnName = RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.changeTableSize(1);
        tableSettingsModal.checkTableSizeInTextIndicator("176px");

        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);
        tableSettingsModal.checkTableSizeInPixels(176);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "4b583103-a87e-4c2b-a5fa-6ed2d9a09e31", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4b583103-a87e-4c2b-a5fa-6ed2d9a09e31)")
    @DisplayName("Отображение таблицы по всей ширине окна")
    public void setTableViewFullWindowTest() {
        String sectionName = "setTableViewFullWindowSectionName" + RandomString.get(8);
        String applicationName = "setTableViewFullWindowApplicationName" + RandomString.get(8);
        String columnNameFirst = "setTableViewFullWindowColumnName" + RandomString.get(8);
        String columnNameSecond = "setTableViewFullWindowColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnNameFirst);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.setTableViewFullSize();
        tableSettingsModal.checkTableSizeInTextIndicator("100.0%");

        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnNameSecond);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.checkTableSizeInTextIndicator("50.0%", "50.0%");
        tableSettingsModal.changeTableSize(1);
        tableSettingsModal.checkTableSizeInTextIndicator("50.1%", "49.9%");

        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);

        tableSettingsModal.checkTableSizeInPercents("50.1%", "49.9%");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "606392ee-fdf8-4c0f-b53f-a6e7764ce155", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/606392ee-fdf8-4c0f-b53f-a6e7764ce155)")
    @DisplayName("Проверить настройку ширины колонок")
    public void setTableColumnWidthTest() {
        String sectionName = "setTableColumnWidthSectionName" + RandomString.get(8);
        String applicationName = "setTableColumnWidthApplicationName" + RandomString.get(8);
        String columnNameFirst = "setTableColumnWidthColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnNameFirst);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.changeTableSize(-1);
        tableSettingsModal.checkTableSizeInTextIndicator("174px");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "a5bcbc11-b377-4bd0-a19d-f52b450549fc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a5bcbc11-b377-4bd0-a19d-f52b450549fc)")
    @DisplayName("Скрыть заголовок таблицы")
    public void hideTableHeaderTest() {
        String sectionName = "hideTableHeaderSectionName" + RandomString.get(8);
        String applicationName = "hideTableHeaderApplicationName" + RandomString.get(8);
        String columnName = "hideTableHeaderColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.hideHeader();
        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);
        tableSettingsModal.checkTableLinesCount(2);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b761af41-7688-4a5c-8408-fbbdc8793932", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b761af41-7688-4a5c-8408-fbbdc8793932)")
    @DisplayName("Проверить изменение цвета текста в колонке таблицы")
    public void setColumnTextColorTest() {
        String sectionName = "setColumnTextColorSectionName" + RandomString.get(8);
        String applicationName = "setColumnTextColorApplicationName" + RandomString.get(8);
        String columnName = "setColumnTextColorColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.openColumnSettings();
        tableSettingsModal.openTextColorSettings();
        tableSettingsModal.selectGreenColor();
        tableSettingsModal.saveStyleSettings();

        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);

        tableSettingsModal.checkTextColorIsGreen();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b76ec50c-27ad-489d-8c7a-723a5faffd41", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b76ec50c-27ad-489d-8c7a-723a5faffd41)")
    @DisplayName("Проверить заливку колонок таблицы")
    public void secColumnBackgroundColorTest() {
        String sectionName = "setColumnTextColorSectionName" + RandomString.get(8);
        String applicationName = "setColumnTextColorApplicationName" + RandomString.get(8);
        String columnName = "setColumnTextColorColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.openColumnSettings();
        tableSettingsModal.openBackgroundColorSettings();
        tableSettingsModal.selectGreenColor();
        tableSettingsModal.saveStyleSettings();

        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);

        tableSettingsModal.checkBackgroundColorIsGreen();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d4f8136b-b5b0-45fb-8a2c-1db4d98738d5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d4f8136b-b5b0-45fb-8a2c-1db4d98738d5)")
    @DisplayName("Добавить в таблицу данные из другого приложения")
    public void addDataFromApplicationTest() {
        String sectionName = "addDataFromApplicationSectionName" + RandomString.get(8);
        String applicationNameFirst = "addDataFromApplicationApplicationName" + RandomString.get(8);
        String applicationNameSecond = "addDataFromApplicationApplicationName" + RandomString.get(8);
        String elementName = "elementName" + RandomString.get(8);
        String columnName = "hideTableFooterColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationNameFirst);
        elmaBackend.createApplication(sectionName, applicationNameSecond);
        elmaBackend.updateApplicationFields(sectionName, applicationNameSecond, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationNameFirst);
        mainPage.clickButtonOnAppContent("+ " + applicationNameFirst);

        createAppElementModal.fillName(elementName);
        createAppElementModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists(applicationNameFirst + " успешно создан");

        sectionPage.open(sectionName, applicationNameSecond);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectExactParameterType("Приложение");
        parameterSettingsModal.selectApplicationParameter(sectionName, applicationNameFirst);
        parameterSettingsModal.dialogWindowPressButton("Создать");

        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationNameSecond);
        tableSettingsModal.selectAppElementInTableField(elementName);

        tableSettingsModal.checkAppElementNameInTable(elementName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "ebbec98d-30c6-43f8-abb5-bb66de60895f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ebbec98d-30c6-43f8-abb5-bb66de60895f)")
    @DisplayName("Скрыть футер таблицы")
    public void hideTableFooterTest() {
        String sectionName = "hideTableFooterSectionName" + RandomString.get(8);
        String applicationName = "hideTableFooterApplicationName" + RandomString.get(8);
        String columnName = "hideTableFooterColumnName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.updateApplicationFields(sectionName, applicationName, APPLICATION_WITH_TABLE);

        sectionPage.open(sectionName, applicationName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.openTransitionSettings("table");
        parameterSettingsModal.clickTableParameters();
        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(columnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.hideFooter();
        tableSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        mainPage.clickButtonOnAppContent("+ " + applicationName);
        tableSettingsModal.checkTableLinesCount(2);
    }
}


