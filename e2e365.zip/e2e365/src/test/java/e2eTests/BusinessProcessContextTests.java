package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.ParameterSettingsModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;

import static infrastructure.utils.Constants.ELMA_TMS;

/**
 * Тесты бизнес-процессов, связанные с контекстами.
 * Выделены в отдельный класс, так как класс с бизнес-процессами выполнялся очень долго.
 */

@MicronautTest
@Tags({@Tag("express"), @Tag("process")})
public class BusinessProcessContextTests {
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;

    @Test
    @Link(value = "4a7fbe60-4890-428f-9b3f-00d376093656", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4a7fbe60-4890-428f-9b3f-00d376093656)")
    @DisplayName("Добавить контекст типа Строка")
    public void addContextTypeStringTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextString" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Строка");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Строка");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "STRING", "string");
    }

    @Test
    @Link(value = "c79d9db7-9a19-42b3-a62b-84c0c049b315", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c79d9db7-9a19-42b3-a62b-84c0c049b315)")
    @DisplayName("Добавить поле типа Строка в формате Текст")
    public void addContextTypeStringAsTextTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextText" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Строка");
        createContextModal.selectContextSubType("Текст");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Строка");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "STRING", "text");
    }

    @Test
    @Link(value = "6ede39d6-de49-480a-9226-a77b630788b7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6ede39d6-de49-480a-9226-a77b630788b7)")
    @DisplayName("Добавить контекст типа Целое число")
    public void addContextTypeIntegerTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextInteger" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Число");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Число");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "FLOAT", "integer");
    }

    @Test
    @Link(value = "96f3b8d6-0579-4f28-8e4f-8c04eeb5d47a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/96f3b8d6-0579-4f28-8e4f-8c04eeb5d47a)")
    @DisplayName("Добавить контекст типа Дробное число")
    public void addContextTypeDoubleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextDouble" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);


        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Число");
        createContextModal.selectContextSubType("Дробное");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Число");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "FLOAT", "float");
    }

    @Test
    @Link(value = "da87303d-7113-4997-af6e-c473869192d8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/da87303d-7113-4997-af6e-c473869192d8)")
    @DisplayName("Добавить контекст типа Выбор \\да/нет\\ - в виде переключателя")
    public void addContextTypeBooleanSwitchTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextBooleanSwitch" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Выбор «да/нет»");
        createContextModal.selectContextSubType("Переключатель");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Выбор «да/нет»");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "BOOLEAN", "radio");
    }

    @Test
    @Link(value = "d7147993-5219-4210-85b4-9d13369fb356", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d7147993-5219-4210-85b4-9d13369fb356)")
    @DisplayName("Добавить контекст типа Выбор \\да/нет\\ - в виде флажка")
    public void addContextTypeBooleanCheckboxTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextBooleanCheckbox" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Выбор «да/нет»");
        createContextModal.selectContextSubType("Флажок");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Выбор «да/нет»");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "BOOLEAN", "checkbox");
    }

    @Test
    @Link(value = "63455cdf-fd3c-41dc-96f6-f0b301c3c2a3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/63455cdf-fd3c-41dc-96f6-f0b301c3c2a3)")
    @DisplayName("Добавить контекст типа Дата/время в виде Дата/время")
    public void addContextTypeDateTimeTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextDateTime" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Дата/время");
        createContextModal.selectContextSubType("Дата/Время");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Дата/время");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "DATETIME", "datetime");
    }

    @Test
    @Link(value = "29819e02-4745-42fb-abac-b3e4ab0096d6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/29819e02-4745-42fb-abac-b3e4ab0096d6)")
    @DisplayName("Добавить контекст типа Дата/время в виде Дата")
    public void addContextTypeDateTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextDate" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Дата/время");
        createContextModal.selectContextSubType("Дата");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Дата/время");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "DATETIME", "date");
    }

    @Test
    @Link(value = "caf15804-e3c4-47bd-bc64-407744539c12", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/caf15804-e3c4-47bd-bc64-407744539c12)")
    @DisplayName("Добавить контекст типа Дата/время в виде Время")
    public void addContextTypeTimeTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextTime" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Дата/время");
        createContextModal.selectContextSubType("Время");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Дата/время");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "DATETIME", "time");
    }

    @Test
    @Link(value = "4d4a47f8-4018-4002-a519-28897af80df2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4d4a47f8-4018-4002-a519-28897af80df2)")
    @DisplayName("Добавить контекст типа Категория - одиночная")
    public void addContextTypeCategoryTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextCategory" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Категория");
        createContextModal.selectContextSubType("Одиночный");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Категория");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "ENUM", true);
    }

    @Test
    @Link(value = "77510922-8f36-4716-a158-5cd71c516e34", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/77510922-8f36-4716-a158-5cd71c516e34)")
    @DisplayName("Добавить контекст типа Категория - множественная")
    public void addContextTypeCategoryMultipleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextCategoryMultiple" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Категория");
        createContextModal.selectContextSubType("Множественный");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Категория");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "ENUM", false);
    }

    @Test
    @Link(value = "2ab496b0-83cb-4b7e-8581-47522e36e61b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2ab496b0-83cb-4b7e-8581-47522e36e61b)")
    @DisplayName("Добавить контекст типа Деньги")
    public void addContextTypeMoneyTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextMoney" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Деньги");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Деньги");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "RUB");
    }

    @Test
    @Link(value = "2b633a71-b164-4fcd-8626-c44d739ef1d9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2b633a71-b164-4fcd-8626-c44d739ef1d9)")
    @DisplayName("Добавить контекст типа Номер телефона")
    public void addContextTypePhoneTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextPhone" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Номер телефона");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Номер телефона");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "PHONE", false);
    }

    @Test
    @Link(value = "ac74eae7-531d-40f6-9ec2-f71a2ee88e21", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ac74eae7-531d-40f6-9ec2-f71a2ee88e21)")
    @DisplayName("Добавить контекст типа Электронная почта")
    public void addContextTypeEmailTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextEmail" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Электронная почта");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Электронная почта");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "EMAIL", false);
    }

    @Test
    @Link(value = "bd2161d5-1f07-4195-bcd3-07e1e988900d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/bd2161d5-1f07-4195-bcd3-07e1e988900d)")
    @DisplayName("Добавить контекст типа Изображение - одно")
    public void addContextTypeImageSingleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextImageSingle" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Изображение");
        createContextModal.selectContextSubType("Одно");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Изображение");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "IMAGE", true);
    }

    @Test
    @Link(value = "93fb590f-acba-4667-a4a3-fac353631e9b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/93fb590f-acba-4667-a4a3-fac353631e9b)")
    @DisplayName("Добавить контекст типа Изображение - несколько")
    public void addContextTypeImageMultipleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextImageMultiple" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Изображение");
        createContextModal.selectContextSubType("Несколько");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Изображение");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "IMAGE", false);
    }

    @Test
    @Link(value = "4023df1a-7884-44da-84ac-4331ab18de9e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4023df1a-7884-44da-84ac-4331ab18de9e)")
    @DisplayName("Добавить контекст типа Файлы - один")
    public void addContextTypeFileSingleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextFileSingle" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Файлы");
        createContextModal.selectContextSubType("Один");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Файлы");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "FILE", true);
    }

    @Test
    @Link(value = "5efa7d72-6c34-489c-87c9-6ac3468dabe6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5efa7d72-6c34-489c-87c9-6ac3468dabe6)")
    @DisplayName("Добавить контекст типа Файлы - несколько")
    public void addContextTypeFileMultipleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextFileMultiple" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Файлы");
        createContextModal.selectContextSubType("Несколько");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Файлы");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "FILE", false);
    }

    @Test
    @Link(value = "f7b61fc2-802f-4570-9e4e-386bda87b2a2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f7b61fc2-802f-4570-9e4e-386bda87b2a2)")
    @DisplayName("Добавить контекст типа Ф.И.О.")
    public void addContextTypeFullNameTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextFullName" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Ф.И.О.");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Ф.И.О.");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "FULL_NAME", true);
    }

    @Test
    @Link(value = "3de03390-a9b4-4b42-b9db-e9f03a05a0f5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3de03390-a9b4-4b42-b9db-e9f03a05a0f5)")
    @DisplayName("Добавить контекст типа Ссылка")
    public void addContextTypeLinkTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextLink" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Ссылка");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Ссылка");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "LINK", true);
    }

    @Test
    @Link(value = "227f8682-e362-45a6-aa49-82b1b4e29d6a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/227f8682-e362-45a6-aa49-82b1b4e29d6a)")
    @DisplayName("Добавить контекст типа Таблица с вариантом отображения Таблица")
    public void addContextTypeTableTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextTable" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Таблица");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Таблица");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "TABLE", true);
    }

    @Test
    @Link(value = "14fa8781-0e12-4aed-994f-4334eba8d732", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/14fa8781-0e12-4aed-994f-4334eba8d732)")
    @DisplayName("Добавить контекст типа Пользователи - один пользователь")
    public void addContextTypeUserSingleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextUserSingle" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Пользователи");
        createContextModal.selectContextSubType("Один");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Пользователи");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "SYS_USER", true);
    }

    @Test
    @Link(value = "15720161-f611-49a0-9135-398af53adfde", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/15720161-f611-49a0-9135-398af53adfde)")
    @DisplayName("Добавить контекст типа Пользователь - Несколько пользователей")
    public void addContextTypeUserMultipleTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextUserMultiple" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Пользователи");
        createContextModal.selectContextSubType("Несколько");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Пользователи");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "SYS_USER", false);
    }

    @Test
    @Link(value = "94a2a9af-b7b7-4d17-9e99-8c9006a5d353", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/94a2a9af-b7b7-4d17-9e99-8c9006a5d353)")
    @DisplayName("Добавить контекст типа Приложение")
    public void addContextTypeApplicationTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextApplication" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Приложение");
        createContextModal.selectContextSubType("Один");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Произвольное приложение");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 0, contextName, "REF_ITEM", true);
    }

    @Test
    @Link(value = "c0e494d2-e587-4f43-9220-7df8abd9aec6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c0e494d2-e587-4f43-9220-7df8abd9aec6)")
    @DisplayName("Проверить заполнение свойства по умолчанию")
    public void addContextTypeStringDefaultValueTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextStringDefaultValue" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Строка");
        createContextModal.setDefaultValue("Default");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Строка");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextDefaultValue(processId, 0, "Default");
    }

    @Test
    @Link(value = "c1325450-9a32-4548-9925-58fb9dc47ce1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c1325450-9a32-4548-9925-58fb9dc47ce1)")
    @DisplayName("Проверить работу настройки \\Заполняется по формуле\\")
    public void addContextTypeStringFormulaTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName2 = "contextStringFormula" + RandomString.get(8);
        String contextName1 = "context" + RandomString.get(8);
        String formula = String.format("$%s + $%s", contextName1, contextName1);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.selectContextType("Строка");
        createContextModal.fillContextName(contextName1);
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.selectContextType("Строка");
        createContextModal.fillContextName(contextName2);
        createContextModal.setCalcByFormula(formula);
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextFormula(processId, 1, formula);
    }

    @Test
    @Link(value = "cfe12974-cd8f-4bb7-a506-9647099680d6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cfe12974-cd8f-4bb7-a506-9647099680d6)")
    @DisplayName("Проверить отображение подсказки к свойству")
    public void addContextTypeStringWithTooltipTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextStringWithTooltip" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Строка");
        createContextModal.setTooltip("Текст подсказки");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextTooltip(processId, 0, "Текст подсказки");
    }

    @Test
    @Link(value = "3da1ddaf-9205-4fa5-868a-3f1c8647dcdd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3da1ddaf-9205-4fa5-868a-3f1c8647dcdd)")
    @DisplayName("Добавить контекст типа Дата/время с установкой текущего времени")
    public void addContextTypeDateTimeNowTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextDateTimeNow" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Дата/время");
        createContextModal.selectContextSubType("Дата/Время");
        createContextModal.setCheckboxByName("Устанавливать текущие дату и время");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextDateTimeCurrent(processId, 0, true);
    }

    @Test
    @Link(value = "bc8fb821-4944-4416-b5d4-dd14c8ac3b89", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/bc8fb821-4944-4416-b5d4-dd14c8ac3b89)")
    @DisplayName("Добавить контекст типа Дата/время с установкой опционального времени - начало дня")
    public void addContextTypeDateTimeStartOfDayTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextDateTimeStartOfDay" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Дата/время");
        createContextModal.selectContextSubType("Дата/Время");
        createContextModal.setCheckboxByName("Время опционально");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextDateTimeOptional(processId, 0, true, "startOfDay");
    }

    @Test
    @Link(value = "22a69428-2f1c-4562-abc2-f50c0da9d751", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/22a69428-2f1c-4562-abc2-f50c0da9d751)")
    @DisplayName("Добавить контекст типа Дата/время с установкой опционального времени - конец дня")
    public void addContextTypeDateTimeEndOfDayTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextDateTimeEndOfDay" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Дата/время");
        createContextModal.selectContextSubType("Дата/Время");
        createContextModal.setCheckboxByName("Время опционально");
        createContextModal.selectContextSubType("Конец дня");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextDateTimeOptional(processId, 0, true, "endOfDay");
    }

    @Test
    @Link(value = "b00f35a2-144f-48e5-8455-08cfe239c17a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b00f35a2-144f-48e5-8455-08cfe239c17a)")
    @DisplayName("Добавить контекст типа Выбор \\да/нет\\ - с изменением значений")
    //TODO: добавить проверку с запуском процесса
    //TODO: был продублирован в тест-плане номер 2, нужно определиться какой вариант лучше.
    public void addContextTypeBooleanChangeValueTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName1 = "context" + RandomString.get(8);
        String contextName2 = "contextBooleanChangeValue" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.selectContextType("Строка");
        createContextModal.fillContextName(contextName1);
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName2);
        createContextModal.selectContextType("Выбор «да/нет»");
        createContextModal.setVisibleByCondition(contextName1, "Пустое значение");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName2, "Выбор «да/нет»");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContext(processId, 1, contextName2, "BOOLEAN", "radio");
    }

    @Test
    @Link(value = "fd399ad3-497d-4c56-8728-ab1fcd945c8b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/fd399ad3-497d-4c56-8728-ab1fcd945c8b)")
    @DisplayName("Добавить контекст типа Пользователи с настройкой \\Показывать блокированных\\")
    public void addContextTypeUserShowBlockedTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextUserShowBlocked" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Пользователи");
        createContextModal.setCheckboxByName("Показывать заблокированных");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Пользователи");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextUserShowBlocked(processId, 0, true);
    }

    @Test
    @Link(value = "e2fdf98b-56dd-4eb7-ac79-0b8cd20ff219", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e2fdf98b-56dd-4eb7-ac79-0b8cd20ff219)")
    @DisplayName("Добавить контекст типа Изображение с настройкой \\Выбирать фрагмент изображения при загрузке\\")
    public void addContextTypeImageFragmentTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String contextName = "contextImageFragment" + RandomString.get(8);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Изображение");
        createContextModal.setCheckboxByName("Выбирать фрагмент изображения при загрузке");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkPropertyInContextTable(contextName, "Изображение");
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextImageIsSelectFragment(processId, 0, true);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "feebb087-4e32-47b1-b00d-168bb9415250", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/feebb087-4e32-47b1-b00d-168bb9415250)")
    @DisplayName("Добавить контекст типа Категория - с указанием значений")
    public void checkAddCategoryContextWithValuesTest() {
        String businessProcessName = "checkAddCategoryContextWithValuesProcessName" + RandomString.get(8);
        String contextName = "checkAddCategoryContextWithValuesContextName" + RandomString.get(8);
        String[] testValues = {"значение 1", "значение 2", "значение 3"};

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Категория");
        createContextModal.addValues(testValues);
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextVariableValues(processId, 0, contextName, "ENUM", testValues);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b00f35a2-144f-48e5-8455-08cfe239c17a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b00f35a2-144f-48e5-8455-08cfe239c17a)")
    @DisplayName("Добавить контекст типа Выбор да/нет - с изменением значений")
    public void checkAddYesNoContextWithValuesTest() {
        String businessProcessName = "checkAddYesNoContextWithValuesProcessName" + RandomString.get(8);
        String contextName = "checkAddYesNoContextWithValuesContextName" + RandomString.get(8);
        String[] testValues = {"верно", "неверно"};
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();

        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Выбор «да/нет»");
        createContextModal.changeYesNoValues(testValues);
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextVariableValues(processId, 0, contextName, "BOOLEAN", testValues);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "9171fd2a-7c25-4b37-87c3-1e99e84c9d30", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9171fd2a-7c25-4b37-87c3-1e99e84c9d30)")
    @DisplayName("Удалить контекстную переменную процесса")
    public void deleteContextVariableTest() {
        String businessProcessName = "checkAddYesNoContextWithValuesProcessName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithContextTable.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.deleteContextVariable("Таблица");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.checkContextVariableDeleted(processId, 0);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "12dd5560-5a34-4bf0-8240-d1037750ca23", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/12dd5560-5a34-4bf0-8240-d1037750ca23)")
    @DisplayName("Добавить контекст типа Роль")
    public void addRoleTypeContextTest() {
        String businessProcessName = "addRoleTypeContextProcessName" + RandomString.get(8);
        String contextName = "addRoleTypeContextContextName" + RandomString.get(8);
        String surnameAndName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Роль");
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(contextName, true);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.addUserRightsViaInputField(surnameAndName);
        sectionPage.clickButtonSelect();
        sectionPage.checkRemoveButtonByUser(surnameAndName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(businessProcessName, "Задача 1");

        sectionPage.checkFormRowWithNameContainsText(contextName, surnameAndName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "12dd5560-5a34-4bf0-8240-d1037750ca23", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/628bbe94-6eac-4b9e-81bf-b61248344f75)")
    @DisplayName("Добавить контекст типа Произвольное приложение")
    public void addCustomAppTypeContextTest() {
        String businessProcessName = "addCustomAppTypeContextProcessName" + RandomString.get(8);
        String contextName = "addCustomAppTypeContextContextName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Произвольное приложение");
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        sectionPage.clickExpandAdvancedSearch();

        sectionPage.checkListGroupVisible("Файлы");
        sectionPage.checkListGroupVisible("Линии");
        sectionPage.checkListGroupVisible("CRM");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f4959e77-3347-4a33-ba52-e9bcaf3a7730", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f4959e77-3347-4a33-ba52-e9bcaf3a7730)")
    @DisplayName("Добавить контекст типа Учетная запись")
    public void addAccountTypeContextTest() {
        String businessProcessName = "addAccountTypeContextProcessName" + RandomString.get(8);
        String contextName = "addAccountTypeContextContextName" + RandomString.get(8);
        String text = "text" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Учетная запись");
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(contextName, true);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        // todo Тут хватит проверки на стартовой форме, надо посмотреть что можно выбрать
        //  тип учетной записи например телеграм и скайп и на этом можно считать тест пройденным
        createContextModal.setTextInputByFormRowName(contextName, text);
        createContextModal.checkInputFormRowValue(contextName, text);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(businessProcessName, "Задача 1");

        sectionPage.checkFormRowWithNameContainsText(contextName, text);
        sectionPage.checkFormRowWithNameContainsText(contextName, "(Telegram)");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "76b1264a-e0f3-47cd-a7c5-9f8526e4067a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/76b1264a-e0f3-47cd-a7c5-9f8526e4067a)")
    @DisplayName("Проверить работу настройки \\Отображается при выполнении условия\\")
    public void checkOperationOfSettingsDisplayConditionMetTest() {
        String businessProcessName = "checkOperationOfSettingsDisplayConditionMetProcessName" + RandomString.get(8);
        String newVariableName = "contextName" + RandomString.get(8);
        String variableName = "String" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(newVariableName);
        createContextModal.setVisibleByCondition(variableName, "Не пустое значение");
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(newVariableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        createContextModal.setTextInputByFormRowName(variableName, RandomString.get(5));
        // todo В этом кейсе лучше использовать процесс с задачей, выносить на форму задачи созданные переменные,
        //  запускать процесс апишкой, придет задача ее открыть (в интерфейсе) и тогда можно ввести текст,
        //  нажать интер и проверить что появилась на форме контекстная переменная
        createContextModal.clickModalHeaderButton("fullscreen_enter");

        sectionPage.checkFormRowWithNameContainsText(newVariableName, "");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a440c6b2-08ff-4507-8793-8754bfd3abcf", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a440c6b2-08ff-4507-8793-8754bfd3abcf)")
    @DisplayName("Создать и добавить новое свойство")
    public void createAndAddNewConditionTest() {
        String businessProcessName = "createAndAddNewConditionProcessName" + RandomString.get(8);
        String contextName = "contextName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Строка");
        createContextModal.dialogWindowPressButton("Создать и новое");
        createContextModal.dialogWindowPressButton("Отмена");

        businessProcessPage.checkPropertyInContextTable(contextName, "Строка");
    }

    //:TODO Таким способом мы проверяем данный функционал
    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "87d7a93b-510d-43bb-a730-f3e1ae2b8346", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/87d7a93b-510d-43bb-a730-f3e1ae2b8346)")
    @DisplayName("Добавить контекст типа Пользователи с настройкой \"Ограничить выбор\"")
    public void addContextOfUsersTypeWithRestrictSelectionSettingTest() {
        String businessProcessName = "addContextOfUsersTypeWithRestrictSelectionSettingProcessName" + RandomString.get(8);
        String contextName = "contextName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);

        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/OnlyStartEnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(contextName);
        createContextModal.selectContextType("Пользователи");
        createContextModal.setCheckboxConditionByLabel("Ограничить выбор", true);
        createContextModal.clickButtonLinkByName("Настроить условия");
        createContextModal.clickButtonDefaultByName("фильтр");
        createContextModal.clickButtonLinkByName("<Не определен>");
        createContextModal.selectValueInPopover("Должность");
        parameterSettingsModal.clickAndSelectBoxItem(" ", "Генеральный директор");
        createContextModal.dialogWindowPressButton("Сохранить");
        createContextModal.dialogWindowPressButton("Создать");

        businessProcessPage.selectTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(contextName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        sectionPage.clickExpandAdvancedSearch();

        sectionPage.checkListUserVisible(adminLogin);
        sectionPage.checkListUserNotVisible(userLogin);
    }
}
