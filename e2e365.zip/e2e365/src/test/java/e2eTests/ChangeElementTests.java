package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("change_element")})
public class ChangeElementTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected ContractPage contractPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "ab837a46-bd4e-46c3-b4bf-d0c5024d6f33", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ab837a46-bd4e-46c3-b4bf-d0c5024d6f33)")
    @DisplayName("Проверить возможность привязки полей приложения с переменными процесса")
    public void checkBindingFieldWithVariableProcessTest() {
        String processName = "checkBindingFieldWithVariableProcess" + RandomString.get(4);
        String sectionName = "checkBindingFieldWithVariableSectionName" + RandomString.get(4);
        String appName = "addAppName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithChangeElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Строка");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Изменение");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Изменение элемента 1", " ", appName);
        settingsBlockModal.chooseTab("Значения полей");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Добавить");
        changeElementBlockModal.setFieldAppBinding("Строка");
        changeElementBlockModal.setFieldContextBPBinding(appName, "Строка");
        changeElementBlockModal.checkChooseFieldBinding("Строка");
        changeElementBlockModal.checkChooseFieldBinding(appName + " . Строка");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b08a069c-45c3-4ee3-9706-c804472a3f6f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b08a069c-45c3-4ee3-9706-c804472a3f6f)")
    @DisplayName("Проверить изменение полей элемента согласно настроенным значениям")
    public void checkEditFieldWithVariableProcessTest() {
        String processName = "checkEditFieldWithVariableProcess" + RandomString.get(4);
        String sectionName = "checkEditFieldWithVariableSectionName" + RandomString.get(4);
        String appName = "addAppName" + RandomString.get(4);
        String variableName = "String" + RandomString.get(4);
        String elementName = "element" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithChangeElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING, false))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Строка");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Изменение");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Изменение элемента 1", " ", appName);
        contractPage.chooseParameterRadioButton("Способ создания", "Автоматически");
        settingsBlockModal.chooseTab("Значения полей");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Добавить");
        changeElementBlockModal.setFieldAppBinding("Строка");
        changeElementBlockModal.setFieldContextBPBinding(variableName);

        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(sectionName, processName);
        businessProcessPage.clickButtonAddNewAppOnStartForm();
        contractPage.setParameterSingleInput("Название", elementName);
        changeElementBlockModal.clickModalFooterButton("Сохранить");
        contractPage.setParameterSingleInput(variableName, "TEST");
        sectionPage.clickNextStageOrExit();

        sectionPage.open(sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.checkAppElementExistsOnForm("TEST");
    }
}
