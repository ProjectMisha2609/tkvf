package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.AppFormSettingsModal;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.WidgetSettingsModal;
import pages.elmaPages.InterfaceDesignerPage;
import pages.elmaPages.PageConstructorPage;
import pages.elmaPages.SectionPage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("modal_window")})
public class ModalWindowTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected CreateContextModal createContextModal;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ba5406e1-71ec-4611-aafe-b319d0d63568", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ba5406e1-71ec-4611-aafe-b319d0d63568)")
    @DisplayName("Добавить виджет в модальное окно")
    public void checkAddWidgetToModalWindowTest() {
        String sectionName = "AddWidgetToModalWindowSectionName" + RandomString.get(8);
        String appName = "AddWidgetToModalWindowAppName" + RandomString.get(8);
        String elementName = "AddWidgetToModalWindowElementName" + RandomString.get(8);
        String textForWidget = "textForWidget" + RandomString.get(10);
        String contextName = RandomString.get(10);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(contextName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextBool();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickProperties();
        pageConstructorPage.dragContextAndDropModalMainArea(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickWidgets();
        pageConstructorPage.dragWidgetAndDropModalMainArea("Модальное окно");
        pageConstructorPage.clickButtonIconElementBind();
        pageConstructorPage.clickButtonNotInstalledAndSelectValue(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickAddWidgetInWidget();
        pageConstructorPage.selectWidget("Надпись");
        pageConstructorPage.inputTextInTextField(textForWidget);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        sectionPage.refreshPage();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.clickButtonYesInApplicationElement();

        interfaceDesignerPage.checkTextInModalWindow(textForWidget);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "68a458cf-085f-429d-babb-b8e96c83785f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/68a458cf-085f-429d-babb-b8e96c83785f)")
    @DisplayName("Удалить модальное окно")
    public void checkDeleteModalWindowTest() {
        String sectionName = "AddWidgetToModalWindowSectionName" + RandomString.get(8);
        String appName = "AddWidgetToModalWindowAppName" + RandomString.get(8);
        String elementName = "AddWidgetToModalWindowElementName" + RandomString.get(8);
        String contextName = RandomString.get(10);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(contextName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextBool();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickProperties();
        pageConstructorPage.dragContextAndDropModalMainArea(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickWidgets();
        pageConstructorPage.dragWidgetAndDropModalMainArea("Модальное окно");
        pageConstructorPage.clickButtonIconElementBind();
        pageConstructorPage.clickButtonNotInstalledAndSelectValue(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickButtonDeleteModalWindow();
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        sectionPage.refreshPage();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.clickButtonYesInApplicationElement();

        interfaceDesignerPage.checkButtonYesInApplicationElement();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "15a44438-a048-487f-b9fd-5753f12e7a3b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/15a44438-a048-487f-b9fd-5753f12e7a3b)")
    @DisplayName("Добавить модальное окно с вводом заголовка по связанному полю")
    public void checkAddModalWindowWithInputTitleTest() {
        String sectionName = "AddWidgetToModalWindowSectionName" + RandomString.get(8);
        String appName = "AddWidgetToModalWindowAppName" + RandomString.get(8);
        String elementName = "AddWidgetToModalWindowElementName" + RandomString.get(8);
        String contextName = RandomString.get(10);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(contextName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextBool();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickProperties();
        pageConstructorPage.dragContextAndDropModalMainArea(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickWidgets();
        pageConstructorPage.dragWidgetAndDropModalMainArea("Модальное окно");
        pageConstructorPage.clickButtonIconElementBindHeader();
        pageConstructorPage.clickButtonNotInstalledAndSelectIndexer();
        pageConstructorPage.clickButtonIconElementBind();
        pageConstructorPage.clickButtonNotInstalledAndSelectValue(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        sectionPage.refreshPage();
        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.clickButtonYesInApplicationElement();

        interfaceDesignerPage.checkHeaderTextInModalWindow(elmaBackend.getElementIdByName(sectionName, appName, elementName));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4ae28a15-277f-4c5a-8613-fa334df9e583", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4ae28a15-277f-4c5a-8613-fa334df9e583)")
    @DisplayName("Добавить модальное окно с вводом заголовка вручную")
    public void checkAddModalWindowWithInputTitleEntryTest() {
        String sectionName = "AddWidgetToModalWindowSectionName" + RandomString.get(8);
        String appName = "AddWidgetToModalWindowAppName" + RandomString.get(8);
        String elementName = "AddWidgetToModalWindowElementName" + RandomString.get(8);
        String contextName = RandomString.get(10);
        String headerName = RandomString.get(10);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(contextName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextBool();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickProperties();
        pageConstructorPage.dragContextAndDropModalMainArea(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickWidgets();
        pageConstructorPage.dragWidgetAndDropModalMainArea("Модальное окно");
        pageConstructorPage.inputTextInHeader(headerName);
        pageConstructorPage.clickButtonIconElementBind();
        pageConstructorPage.clickButtonNotInstalledAndSelectValue(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        sectionPage.refreshPage();
        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.clickButtonYesInApplicationElement();

        interfaceDesignerPage.checkHeaderTextInModalWindow(headerName);
    }
}