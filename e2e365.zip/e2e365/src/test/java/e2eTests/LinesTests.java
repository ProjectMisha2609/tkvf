package e2eTests;

import com.codeborne.selenide.Selenide;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendCrm;
import infrastructure.elmaBackend.BackendLines;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaPages.LinesPage;
import pages.elmaPages.SectionPage;

import java.util.HashSet;
import java.util.Set;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.ApplicationFields.APPLICATION_WITH_ACCOUNT_FIELD;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.LineJsonBodies.*;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.SystemGroups.ADMINISTRATORS;
import static infrastructure.utils.Constants.SystemGroups.ALL_USERS;

/**
 * Проверки функционала линий. Собраны в одном классе для исполнения одним потоком,
 * так как влияют друг на друга по причине удаления существующей линии в начале каждого теста.
 * <p>
 * В некоторых тестах явно требуется создавать группу на уровне компании,
 * что не даёт использовать системные группы.
 * Методы получения системных групп и групп на уровне компании отличаются,
 * потому было решено перегрузить методы и передавать группы компании обернув в HashSet<String>.
 * Так же это позволяет в одном аргументе передать несколько групп,
 * что может встречаться при работе именно с группами на уровне компании.
 */
@MicronautTest
@Tags({@Tag("express"), @Tag("lines")})
public class LinesTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendLines backendLines;
    @Inject
    protected LinesPage linesPage;
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "210f97a1-77ab-4108-8f53-f1616f34e139", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/210f97a1-77ab-4108-8f53-f1616f34e139)")
    @DisplayName("Приложение для фиксации обращений - Контакты")
    public void lineAppGetContactTest() {
        String sectionName = "lineAppGetContactSectionName" + RandomString.get(8);
        String appName = "lineAppGetContactAppName" + RandomString.get(8);
        String lineName = "lineAppGetContactLineName" + RandomString.get(8);
        String message = "lineAppGetContactMessage" + RandomString.get(8);
        String contactName = "lineAppGetContactContactName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.updateApplicationFields(sectionName, appName, APPLICATION_WITH_ACCOUNT_FIELD);
        elmaBackend.createElement(contactName, sectionName, appName);
        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                sectionName, appName);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        // добавленная на стадии ревью проверка: имя приложения
        linesPage.checkSessionAppBind(appName);
        linesPage.bindContact(contactName);

        linesPage.checkContactBound(contactName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "82683562-34a0-4a69-8d5d-5789629def8f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/82683562-34a0-4a69-8d5d-5789629def8f)")
    @DisplayName("Приложение для связи учетной записи - Контакты")
    public void lineCrmGetContactTest() {
        String lineName = "lineAppGetContactLineName" + RandomString.get(8);
        String message = "lineAppGetContactMessage" + RandomString.get(8);
        String contactName = "lineAppGetContactContactName" + RandomString.get(8);

        backendCrm.createContact(contactName);
        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CRM_ACCOUNT_BINDER);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.bindContact(contactName);

        linesPage.checkCrmContactBound(contactName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "59e3491b-72c6-45ed-aa50-b3ce4ce02265", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/59e3491b-72c6-45ed-aa50-b3ce4ce02265)")
    @DisplayName("Формирование отчёта по трафику обращений")
    public void messageTrafficReportTest() {
        String lineName = " messageTrafficReportLineName" + RandomString.get(8);
        String message = " messageTrafficReportMessage" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.openSessionFromQueue();
        linesPage.sendAnswer(message);
        linesPage.closeSession();

        linesPage.sectionToolbar().toolbarSubmenu()
                .clickSubmenuButtonByHref("_lines/_report");

        linesPage.checkMessageProcessingReport(lineName);
    }

    @Test
    @Tag("bugged")
    @Tag("Author=Krasilnikov")
    @Link(value = "8b78612f-655e-40c4-9644-2d34ba2a1160", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8b78612f-655e-40c4-9644-2d34ba2a1160)")
    @DisplayName("Формирование отчёта по эффективности линий")
    public void lineEfficiencyReportTest() {
        String lineName = " lineEfficiencyReportLineName" + RandomString.get(8);
        String message = " lineEfficiencyReportMessage" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.openSessionFromQueue();
        linesPage.sendAnswer(message);
        linesPage.closeSession();

        linesPage.sectionToolbar().toolbarSubmenu()
                .clickSubmenuButtonByHref("_lines/_report");

        linesPage.checkEfficiencyReport(lineName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "c0d31583-2bfc-4eee-bf4c-2ad8d0ea9e1d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c0d31583-2bfc-4eee-bf4c-2ad8d0ea9e1d)")
    @DisplayName("Формирование отчёта по эффективности операторов")
    public void operatorEfficiencyReportTest() {
        String lineName = " lineEfficiencyReportLineName" + RandomString.get(8);
        String message = " lineEfficiencyReportMessage" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.openSessionFromQueue();
        linesPage.sendAnswer(message);
        linesPage.closeSession();

        linesPage.sectionToolbar().toolbarSubmenu()
                .clickSubmenuButtonByHref("_lines/_report");
        // получить фамилию или логин текущего пользователя из хэдера, на случай если изменено.
        String operator = linesPage.getCurrentUserCredentialsFirstWord();

        linesPage.checkOperatorsReport(operator);
    }

    @Test
    @Tag("bugged") // todo: известный баг, не применяется шаблон сообщения
    @Tag("Author=Krasilnikov")
    @Link(value = "d899929e-2a97-4297-ba45-b4924ec519e4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d899929e-2a97-4297-ba45-b4924ec519e4)")
    @DisplayName("Использование шаблонов в переписке с пользователем")
    public void useAnswerTemplateInLineTest() {
        String lineName = "useAnswerTemplateInLineLineName" + RandomString.get(8);
        String message = "useAnswerTemplateInLineMessage" + RandomString.get(8);
        String messageTemplate = "useAnswerTemplateInLineTemplate" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);
        backendLines.createTemplate(messageTemplate);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.openSessionFromQueue();

        linesPage.sendAnswerTemplate(messageTemplate);

        linesPage.checkMessageContentExists("template_template");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "4cf4403c-f5ec-41b7-99f2-f3a75eceb86a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4cf4403c-f5ec-41b7-99f2-f3a75eceb86a)")
    @DisplayName("Использование статей в переписке с пользователем")
    public void useArticleInLineTest() {
        String lineName = "useArticleInLineLineName" + RandomString.get(8);
        String message = "useArticleInLineMessage" + RandomString.get(8);
        String article = "useArticleInLineArticle" + RandomString.get(8);
        backendLines.createArticle(article);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.openSessionFromQueue();

        linesPage.sendArticle(article);

        linesPage.checkMessageContentExists(article);
        linesPage.checkMessageContentExists("https://www.google.com");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "7f88e0cb-fa06-49c1-9838-6d10a1ce1ca5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7f88e0cb-fa06-49c1-9838-6d10a1ce1ca5)")
    @DisplayName("Изменение названия сессии")
    public void changeSessionNameTest() {
        String lineName = "changeSessionNameLineName" + RandomString.get(8);
        String message = "changeSessionNameMessage" + RandomString.get(8);
        String sessionName = "changeSessionNameSessionName" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());
        linesPage.openSessionFromQueue();

        linesPage.renameSessionAndCheckNewName(sessionName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "9f9ea16d-f454-4591-865e-dbfd89a69dd1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9f9ea16d-f454-4591-865e-dbfd89a69dd1)")
    @DisplayName("Проверка работы счётчика нераспределённых супервизором сессий (прозрачный счётчик)")
    public void checkUnassignedSessionsCounterTest() {
        String lineName = "checkUnassignedSessionsCounterLineName" + RandomString.get(8);
        String message = "checkUnassignedSessionsCounterMessage" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());

        linesPage.checkUnassignedSessionsCountEquals("1");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "463c6724-ab46-4147-811f-5fee746bf215", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/463c6724-ab46-4147-811f-5fee746bf215)")
    @DisplayName("Проверка работы счётчика сессий в очереди у оператора (голубой счётчик)")
    public void checkQueueSessionsCounterTest() {
        String lineName = "checkQueueSessionsCounterLineName" + RandomString.get(8);
        String message = "checkQueueSessionsCounterMessage" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ADMINISTRATORS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/" + backendLines.getUnassignedSessionId());

        linesPage.checkQueueSessionsCountEquals("1");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "a00fcb6b-ce5b-4c5b-b2bb-d45dd18fe06c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a00fcb6b-ce5b-4c5b-b2bb-d45dd18fe06c)")
    @DisplayName("Проверка работы счётчика назначенных на оператора сессий (красный счётчик)")
    public void checkLineSessionsCounterTest() {
        String lineName = "checkLineSessionsCounterLineName" + RandomString.get(8);
        String message = "checkLineSessionsCounterMessage" + RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                ALL_USERS, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, adminLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();
        backendLines.assignSessionToUser(sessionId, userLogin);

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        linesPage.open("_lines/_sessions/detail/" + sessionId);

        linesPage.checkLineSessionsCountEquals("1");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "a34576b5-baa2-4bda-92c4-8084a14fa4b6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a34576b5-baa2-4bda-92c4-8084a14fa4b6)")
    @DisplayName("Назначение сессии оператором группы 1 на операторов группы 2.")
    public void assignSessionToGroupTest() {
        String lineName = "assignSessionToGroupLineName" + RandomString.get(8);
        String message = "assignSessionToGroupMessage" + RandomString.get(8);

        Set<String> operators = new HashSet<>();
        String usersGroupName = "users_group" + RandomString.get(8);
        operators.add(usersGroupName);
        String adminGroupName = "admin_group" + RandomString.get(8);
        operators.add(adminGroupName);

        elmaBackend.createCompanyGroup(usersGroupName, elmaBackend.getUserIdByEmail(userLogin));
        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                operators, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, adminLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.assignSessionToUsersGroup(usersGroupName);

        linesPage.checkGroupAssigned(usersGroupName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "8cc00b9f-10d3-4b2c-b449-d450d7224736", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8cc00b9f-10d3-4b2c-b449-d450d7224736)")
    @DisplayName("Назначение сессии супервизором на группу операторов и на конкретного оператора из группы")
    public void assignSessionToUserTest() {
        String lineName = "assignSessionToUserLineName" + RandomString.get(8);
        String message = "assignSessionToUserMessage" + RandomString.get(8);
        Set<String> operators = new HashSet<>();
        Set<String> supervisors = new HashSet<>();
        String usersGroupName = "users_group" + RandomString.get(8);
        operators.add(usersGroupName);
        String adminGroupName = "admin_group" + RandomString.get(8);
        supervisors.add(adminGroupName);
        String operator = elmaBackend.getUserSurnameAndNameByEmail(userLogin);

        elmaBackend.createCompanyGroup(usersGroupName, elmaBackend.getUserIdByEmail(userLogin));
        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                operators, supervisors, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.assignSessionToUsersGroup(usersGroupName);
        linesPage.assignSessionToUser(operator);

        linesPage.checkGroupAssigned(usersGroupName);
        linesPage.checkOperatorAssigned(operator);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "28523801-5f15-4cea-8131-637e5f520c8d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/28523801-5f15-4cea-8131-637e5f520c8d)")
    @DisplayName("Назначение сессии с одного оператора на другого в рамках одной группы операторов")
    public void assignSessionToAnotherOperatorTest() {
        // сценарий изменён по требованиям приёмочного из ревью.
        String lineName = "assignSessionToAnotherOperatorLineName" + RandomString.get(8);
        String message = "assignSessionToAnotherOperatorMessage" + RandomString.get(8);
        Set<String> operators = new HashSet<>();
        String operatorsGroupName = "users_group" + RandomString.get(8);
        operators.add(operatorsGroupName);
        String operator = elmaBackend.getUserSurnameAndNameByEmail(userLogin);
        // Предусловие: оба пользователя состоят в одной группе операторов.
        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(userLogin), elmaBackend.getUserIdByEmail(adminLogin));
        // 1 Создание линии.
        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        // 2 Обновление линии (операторы - все пользователи, супервизоры - администраторы)
        backendLines.updateLine(lineId, lineName,
                operators, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        // 3 Создание сессии через написание сообщения от имени текущего пользователя
        backendLines.sendMessageToLine(lineId, adminLogin, message);

        linesPage.open("_lines/_sessions");
        // 4 Назначение сессии на текущего пользователя (назначается взятием из очереди)
        // 5 Открыть страницу с сессией (открывается взятием из очереди)
        linesPage.openSessionFromQueue();
        // 6 Переназначение сессии текущим пользователем на другого пользователя в рамках группы
        linesPage.assignSessionToUserByFindButton(operator);
        linesPage.checkGroupAssigned(operatorsGroupName);
        linesPage.checkOperatorAssigned(operator);

        // 7 Проведение проверки от имени другого пользователя
        String fullUrl = CustomDriver.getCurrentUrl();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        Selenide.open(fullUrl);

        linesPage.checkGroupAssigned(operatorsGroupName);
        linesPage.checkOperatorAssigned(operator);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "ca224ae7-7341-49a7-b8d9-a269cab4f675", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ca224ae7-7341-49a7-b8d9-a269cab4f675)")
    @DisplayName("Назначение сессии супервизором на группу операторов")
    public void assignSessionToGroupBySupervisorTest() {
        String lineName = "assignSessionToGroupBySupervisorLineName" + RandomString.get(8);
        String message = "assignSessionToGroupBySupervisorMessage" + RandomString.get(8);
        Set<String> operators = new HashSet<>();
        Set<String> supervisors = new HashSet<>();
        String usersGroupName = "users_group" + RandomString.get(8);
        operators.add(usersGroupName);
        String adminGroupName = "admin_group" + RandomString.get(8);
        supervisors.add(adminGroupName);

        elmaBackend.createCompanyGroup(usersGroupName, elmaBackend.getUserIdByEmail(userLogin));
        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                operators, supervisors, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.assignSessionToUsersGroupByFindButton(usersGroupName);

        linesPage.checkGroupAssigned(usersGroupName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "7a07ab5d-23f0-4667-b5a3-163488beca43", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7a07ab5d-23f0-4667-b5a3-163488beca43)")
    @DisplayName("Привязка элемента приложения к сессии")
    public void assignApplicationElementToLineTest() {
        String lineName = "assignApplicationElementToLineLineName" + RandomString.get(8);
        String message = "assignApplicationElementToLineMessage" + RandomString.get(8);
        String contactName = "assignApplicationElementToLineContactName" + RandomString.get(8);
        Set<String> adminGroup = new HashSet<>();
        String adminGroupName = "admin_group" + RandomString.get(8);
        adminGroup.add(adminGroupName);

        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));
        backendCrm.createContact(contactName);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                adminGroup, adminGroup, ALL_USERS,
                LINE_WITH_CRM_ACCOUNT_BINDER);
        backendLines.sendMessageToLine(lineId, adminLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.bindContact(contactName);

        linesPage.checkCrmContactBound(contactName);
        linesPage.refreshPage();

        linesPage.checkCrmContactBound(contactName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "0d1ebb72-abdf-47bf-850e-2a5f64521471", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0d1ebb72-abdf-47bf-850e-2a5f64521471)")
    @DisplayName("Запуск бизнес-процесса при закрытии сессии")
    public void startBusinessProcessOnEndOfSessionTest() {
        String lineName = "startBusinessProcessOnEndOfSessionLineName" + RandomString.get(8);
        String processName = "startBusinessProcessOnEndOfSessionProcessName" + RandomString.get(8);
        String message = "startBusinessProcessOnEndOfSessionMessage" + RandomString.get(8);
        String adminGroupName = "admin_group" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStringParameterForLinesTests.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));
        Set<String> operators = new HashSet<>();
        operators.add(adminGroupName);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                operators, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);
        backendLines.sendMessageToLine(lineId, userLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("admin/chatdesk/lines/" + lineId);
        linesPage.chooseAdministrationTab("Бизнес-процессы");
        linesPage.clickAddProcessOnTrigger("При закрытии");
        linesPage.selectFromCompanyProcesses(processName);
        linesPage.setProcessVariableToLineId("stroka");
        linesPage.saveEventChanges();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.openSessionFromQueue();
        linesPage.sendAnswer(message);
        linesPage.closeSession();

        sectionPage.open("/tasks/income");
        sectionPage.clickTask(lineId, processName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("bugged") // todo: известный баг, не срабатывает триггер бизнес-процесса
    @Tag("Author=Krasilnikov")
    @Link(value = "01d9dafb-a15a-47fe-b6e8-bbfa75537fd4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/01d9dafb-a15a-47fe-b6e8-bbfa75537fd4)")
    @DisplayName("Запуск бизнес-процесса при поступлении сообщения от клиента")
    public void startBusinessProcessOnClientMessageTest() {
        String lineName = "startBusinessProcessOnClientMessageLineName" + RandomString.get(8);
        String processName = "startBusinessProcessOnClientMessageProcessName" + RandomString.get(8);
        String message = "startBusinessProcessOnClientMessageMessage" + RandomString.get(8);
        String adminGroupName = "admin_group" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStringParameterForLinesTests.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));
        Set<String> operators = new HashSet<>();
        operators.add(adminGroupName);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                operators, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);

        linesPage.open("admin/chatdesk/lines/" + lineId);
        linesPage.chooseAdministrationTab("Бизнес-процессы");
        linesPage.clickAddProcessOnTrigger("При поступлении");
        linesPage.selectFromCompanyProcesses(processName);
        linesPage.setProcessVariableToLineId("stroka");
        linesPage.saveEventChanges();

        backendLines.sendMessageToLine(lineId, userLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.openSessionFromQueue();
        linesPage.sendAnswer(message);
        linesPage.closeSession();

        sectionPage.open("/tasks/income");
        sectionPage.clickTask(lineId, processName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("bugged") // todo: известный баг, не срабатывает триггер бизнес-процесса
    @Tag("Author=Krasilnikov")
    @Link(value = "69fa9649-c2b5-497b-9cd9-73b3bd0b84ec", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/69fa9649-c2b5-497b-9cd9-73b3bd0b84ec)")
    @DisplayName("Запуск бизнес-процесса при создании новой сессии")
    public void startBusinessProcessStartOfSessionTest() {
        String lineName = "startBusinessProcessStartOfSessionLineName" + RandomString.get(8);
        String processName = "startBusinessProcessStartOfSessionProcessName" + RandomString.get(8);
        String message = "startBusinessProcessStartOfSessionMessage" + RandomString.get(8);
        String adminGroupName = "admin_group" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStringParameterForLinesTests.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createCompanyGroup(adminGroupName, elmaBackend.getUserIdByEmail(adminLogin));
        Set<String> operators = new HashSet<>();
        operators.add(adminGroupName);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName,
                operators, ADMINISTRATORS, ALL_USERS,
                LINE_WITH_CLIENTS);

        linesPage.open("admin/chatdesk/lines/" + lineId);
        linesPage.chooseAdministrationTab("Бизнес-процессы");
        linesPage.clickAddProcessOnTrigger("При создании");
        linesPage.selectFromCompanyProcesses(processName);
        linesPage.setProcessVariableToLineId("stroka");
        linesPage.saveEventChanges();

        backendLines.sendMessageToLine(lineId, userLogin, message);
        String sessionId = backendLines.getUnassignedSessionId();

        linesPage.open("_lines/_sessions/detail/" + sessionId);
        linesPage.openSessionFromQueue();
        linesPage.sendAnswer(message);
        linesPage.closeSession();

        sectionPage.open("/tasks/income");
        sectionPage.clickTask(lineId, processName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "de652b3d-654e-4333-9e92-a9d9f806d422", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/de652b3d-654e-4333-9e92-a9d9f806d422)")
    @DisplayName("Задать приоритет сессии")
    public void setPriorityLineTest() {
        String lineName = "setPriorityLineLineName" + RandomString.get(8);
        String message = "setPriorityLineMessage" + RandomString.get(8);
        backendLines.deleteLineIfExists();

        linesPage.open("/admin/chatdesk/lines");
        linesPage.clickButtonOnConfigPage("Линия");

        linesPage.setTextInputByFormRowName("Название", lineName);
        linesPage.setTextInputWithSearchByFormRowName("Операторы", "Администраторы");
        linesPage.setTextInputWithSearchByFormRowName("Супервизоры", "Администраторы");
        linesPage.dialogWindowPressButton("Сохранить");
        linesPage.checkInputFormRowValue("Название", lineName);
        // метод получения ID из ссылки теперь итеративный, ищет пока не выйдет лимит времени.
        String lineId = linesPage.getCurrentId();
        linesPage.clickButtonOnConfigPage("Сохранить");

        backendLines.sendMessageToLine(lineId, userLogin, message);

        linesPage.open("_lines/_sessions/detail/");
        linesPage.openSessionFromQueue();
        linesPage.clickButtonByTitleParameterFullMatch("Задать приоритет");
        linesPage.selectDropDownItemByFormRowName("Задать приоритет", "Низкий");
        // зачем-то спрятали кнопку в строку формы, ещё и без имени.
        linesPage.clickButtonByNameAndFormRowName("", "Задать приоритет");

        linesPage.checkFormRowWithNameContainsText("Приоритет", "Низкий");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "a3ad9a79-ca15-4d97-ac3b-cebd599a973c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a3ad9a79-ca15-4d97-ac3b-cebd599a973c)")
    @DisplayName("Удалить правило в линиях")
    public void deleteRuleInLineTest() {
        String lineName = "deleteRuleInLineLineName" + RandomString.get(8);
        String ruleName = "rule_name";

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName, ADMINISTRATORS, ADMINISTRATORS, ALL_USERS, LINE_WITH_RULE);

        linesPage.open("/admin/chatdesk/lines");
        linesPage.openItemOnContentPageTable(lineName);
        linesPage.chooseAdministrationTab("Маршрутизация");

        linesPage.deleteRuleByName(ruleName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "c4c3f62b-418a-4679-8d13-6b69c2f079f9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c4c3f62b-418a-4679-8d13-6b69c2f079f9)")
    @DisplayName("Создать копию правила в линиях")
    public void copyRuleInLineTest() {
        String lineName = "copyRuleInLineLineName" + RandomString.get(8);
        String ruleName = "rule_name";

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName, ADMINISTRATORS, ADMINISTRATORS, ALL_USERS, LINE_WITH_RULE);

        linesPage.open("/admin/chatdesk/lines");
        linesPage.openItemOnContentPageTable(lineName);
        linesPage.chooseAdministrationTab("Маршрутизация");

        linesPage.copyRuleByName(ruleName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "e9d195e0-b9b4-4159-8344-f35aedd7186b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e9d195e0-b9b4-4159-8344-f35aedd7186b)")
    @DisplayName("Отредактировать созданное правило в линиях")
    public void editRuleInLineTest() {
        String lineName = "copyRuleInLineLineName" + RandomString.get(8);
        String ruleName = "rule_name";
        String ruleNameNew = RandomString.get(8);

        String lineId = backendLines.createNewLineAndDeleteExisting(lineName, ADMINISTRATORS, ADMINISTRATORS);
        backendLines.updateLine(lineId, lineName, ADMINISTRATORS, ADMINISTRATORS, ALL_USERS, LINE_WITH_RULE);

        linesPage.open("/admin/chatdesk/lines");
        linesPage.openItemOnContentPageTable(lineName);
        linesPage.chooseAdministrationTab("Маршрутизация");

        linesPage.openRuleEllipsisSettingsByName(ruleName);
        linesPage.selectPopoverOptionByName("Редактировать");
        linesPage.setTextInputByFormRowName("Название правила", ruleNameNew);
        linesPage.dialogWindowPressButton("Сохранить");
        linesPage.checkRuleWithNameExists(ruleNameNew);
    }
}
