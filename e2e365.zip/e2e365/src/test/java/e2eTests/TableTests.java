package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaModals.WidgetSettingsModal;
import pages.elmaPages.*;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;

@MicronautTest
@Tags({@Tag("express"), @Tag("table")})
public class TableTests {

    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected AdminSectionPage adminSectionPage;

    @Test
    @Link(value = "ae05ee47-f0bf-4d99-a889-8688a6912b04", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ae05ee47-f0bf-4d99-a889-8688a6912b04)")
    @DisplayName("Проверить поиск по таблице")
    public void tableFinderTest() {
        String sectionName = "addTableWithViewedFieldsSectionName" + RandomString.get(8);
        String applicationName = "addTableWithViewedFieldsApplicationName" + RandomString.get(8);
        String elementNameFirst = "addTableWithViewedFieldsElementNameFirst" + RandomString.get(8);
        String elementNameSecond = "addTableWithViewedFieldsElementNameSecond" + RandomString.get(8);
        String processName = "addTableWithViewedFieldsProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.createElement(elementNameFirst, sectionName, applicationName);
        elmaBackend.createElement(elementNameSecond, sectionName, applicationName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Таблица");
        widgetSettingsModal.tableWidgetSettingsModal().selectApplication(sectionName, applicationName);
        widgetSettingsModal.tableWidgetSettingsModal().addItemToFilteringFields("Название");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTableHeadItemVisible("Название");
        interfaceDesignerPage.checkFinderVisible();
        interfaceDesignerPage.fillFinderQuery(elementNameSecond);
        interfaceDesignerPage.clickFinderButton();
        interfaceDesignerPage.checkFindResultExists(elementNameSecond);
    }

    @Test
    @Link(value = "1831b1fa-af0b-4811-b10a-7127492e1437", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1831b1fa-af0b-4811-b10a-7127492e1437)")
    @DisplayName("Удалить таблицу")
    public void deleteTableTest() {
        String sectionName = "addTableWithViewedFieldsSectionName" + RandomString.get(8);
        String businessProcessName = "deleteTableBusinessProcessName" + RandomString.get(8);
        String applicationName = "addTableWithViewedFieldsApplicationName" + RandomString.get(8);
        String elementName = "addTableWithViewedFieldsElementName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.createElement(elementName, sectionName, applicationName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Таблица");
        widgetSettingsModal.tableWidgetSettingsModal().selectApplication(sectionName, applicationName);
        widgetSettingsModal.tableWidgetSettingsModal().addItemToViewedFields("Индекс");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        interfaceDesignerPage.checkTableHeadItemVisible("Индекс");

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.openExistingForm();

        interfaceDesignerPage.removeTable();

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTableNotExists();
    }

    @Test
    @Link(value = "aaf55979-1e39-4fd5-bca7-f91c5d84d843", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/aaf55979-1e39-4fd5-bca7-f91c5d84d843)")
    @DisplayName("Добавить элемент Таблица с указанием полей для агрегации")
    public void addTableWithAggregatedTest() {
        String sectionName = "addTableWithViewedFieldsSectionName" + RandomString.get(8);
        String applicationName = "addTableWithViewedFieldsApplicationName" + RandomString.get(8);
        String elementNameFirst = "addTableWithViewedFieldsElementNameFirst" + RandomString.get(8);
        String elementNameSecond = "addTableWithViewedFieldsElementNameSecond" + RandomString.get(8);
        String processName = "addTableWithViewedFieldsProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.createElement(elementNameFirst, sectionName, applicationName);
        elmaBackend.createElement(elementNameSecond, sectionName, applicationName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Таблица");
        widgetSettingsModal.tableWidgetSettingsModal().selectApplication(sectionName, applicationName);
        widgetSettingsModal.tableWidgetSettingsModal().addItemToViewedFields("Индекс");
        widgetSettingsModal.tableWidgetSettingsModal().addItemToAggregatedFields("Индекс");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTableHeadItemVisible("Индекс");
        interfaceDesignerPage.checkIndexTableElementsAggregated();
    }

    @Test
    @Link(value = "0b1216e6-c831-4f82-a33d-f6b93b78ff2f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0b1216e6-c831-4f82-a33d-f6b93b78ff2f)")
    @DisplayName("Добавить элемент таблица с указанием полей для фильтрации")
    public void addTableWithFilteredFieldsTest() {
        String sectionName = "addTableWithViewedFieldsSectionName" + RandomString.get(8);
        String applicationName = "addTableWithViewedFieldsApplicationName" + RandomString.get(8);
        String elementName = "addTableWithViewedFieldsElementName" + RandomString.get(8);
        String processName = "addTableWithViewedFieldsProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.createElement(elementName, sectionName, applicationName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Таблица");
        widgetSettingsModal.tableWidgetSettingsModal().selectApplication(sectionName, applicationName);
        widgetSettingsModal.tableWidgetSettingsModal().addItemToFilteringFields("Название");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTableHeadItemVisible("Название");
        interfaceDesignerPage.checkFinderVisible();
    }

    @Test
    @Link(value = "c5c0fc22-c53a-4c22-aa14-57f42269269d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c5c0fc22-c53a-4c22-aa14-57f42269269d)")
    @DisplayName("Добавить элемент Таблица с указанием отображаемых полей")
    public void addTableWithViewedFieldsTest() {
        String sectionName = "addTableWithViewedFieldsSectionName" + RandomString.get(8);
        String applicationName = "addTableWithViewedFieldsApplicationName" + RandomString.get(8);
        String elementName = "addTableWithViewedFieldsElementName" + RandomString.get(8);
        String processName = "addTableWithViewedFieldsProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.createElement(elementName, sectionName, applicationName);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Таблица");
        widgetSettingsModal.tableWidgetSettingsModal().selectApplication(sectionName, applicationName);
        widgetSettingsModal.tableWidgetSettingsModal().addItemToViewedFields("Индекс");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTableHeadItemVisible("Индекс");
    }
}
