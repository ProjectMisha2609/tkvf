package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import infrastructure.utils.Constants;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.SectionPage;

import java.nio.file.Paths;

import static infrastructure.elmaBackend.jsonTools.JsonBusinessProcess.PUBLISH_PROCESS;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("app_action")})
public class AppActionsTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected AddNewAppModal addNewAppModal;
    @Inject
    protected CreateBpModal createBpModal;
    @Inject
    protected SectionActionModal sectionActionModal;
    @Inject
    protected SettingsActionsButtonModal settingsActionsButtonModal;
    @Inject
    protected AddGroupOrRoleModal addGroupOrRoleModal;
    @Inject
    protected ExportModal exportApplicationModal;
    @Inject
    protected ImportModal importModal;
    @Inject
    protected CopyApplicationModal copyApplicationModal;
    @Inject
    protected CreateAppModal createAppModal;
    @Inject
    protected SelectProcessModal selectProcessModal;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Link(value = "6d174811-3d82-4b41-b553-d69371fad10d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6d174811-3d82-4b41-b553-d69371fad10d)")
    @DisplayName("Проверить добавление бизнес-процесса в приложении")
    public void addBusinessProcessTest() {
        String sectionName = "addBusinessProcessInAppTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        String appName = "AddBusinessProcessApp" + RandomString.get(8);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Бизнес-процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(appName);
        createBpModal.dialogWindowPressButton("Создать");

        sectionPage.checkDiagrammerExists();
    }

    @Test
    @Link(value = "24b68d6f-e743-49f2-8e46-67a48a58169c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/24b68d6f-e743-49f2-8e46-67a48a58169c)")
    @DisplayName("Проверить удаление Приложения")
    public void deleteApplicationTest() {
        String sectionName = "deleteApplicationTest" + RandomString.get(16);
        String appName = "DeleteApp" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Удалить Приложение");
        sectionActionModal.dialogWindowPressButton("ОК");

        sectionPage.checkAppDeleted();
    }

    @Test
    @Link(value = "0e515966-bcfe-4c4b-83e8-530c3cf11c7a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0e515966-bcfe-4c4b-83e8-530c3cf11c7a)")
    @DisplayName("Проверить экспорт Приложения")
    public void exportApplicationTest() {
        String sectionName = "exportApplicationTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        String appName = "ExportApp" + RandomString.get(8);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Экспорт Приложения");
        exportApplicationModal.dialogWindowPressButton("Начать экспорт");
        exportApplicationModal.dialogWindowPressButton("Далее");
        exportApplicationModal.dialogWindowPressButton("Далее");
        exportApplicationModal.clickLinkLoadFile();
        exportApplicationModal.dialogWindowPressButton("ОК");

        exportApplicationModal.checkFileExported(sectionName, appName);
    }

    @Test
    @Link(value = "e6f829ec-b1a0-4b09-803a-4aaa37dce22a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e6f829ec-b1a0-4b09-803a-4aaa37dce22a)")
    @DisplayName("Проверить импорт приложения")
    public void applicationImportTest() {
        String sectionName = "applicationImportTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickUploadFile();

        String filePath = Paths.get(Constants.PATH_TO_DEFAULT_DIR, "testData", "test.testapp.e365").toString();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.clickContinuePreview();
        importModal.dialogWindowPressButton("Перейти к приложению");

        sectionPage.checkCreatedAppAvailable("testApp");
    }

    @Test
    @Link(value = "7df29237-1c14-4640-9eca-74fa9ee09874", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7df29237-1c14-4640-9eca-74fa9ee09874)")
    @DisplayName("Проверить копирование Приложения")
    public void copyApplicationTest() {
        String sourceSectionName = "CopyAppTestSectionSource" + RandomString.get(16);
        String targetSectionName = "CopyAppTestSectionTarget" + RandomString.get(16);
        String appName = "CopyApp" + RandomString.get(8);

        elmaBackend.createSection(sourceSectionName);
        elmaBackend.createSection(targetSectionName);
        elmaBackend.createApplication(sourceSectionName, appName);

        sectionPage.open(sourceSectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Скопировать Приложение");

        copyApplicationModal.dialogWindowPressButton("Начать копирование");
        copyApplicationModal.clickNextStepOnCheckApplicationModal();
        copyApplicationModal.selectTargetSection(targetSectionName);
        copyApplicationModal.clickNextStepOnSettingsNewAppModal();
        copyApplicationModal.clickGoToApplication();

        sectionPage.checkAppCopiedInTargetSection(targetSectionName, appName);
    }

    @Test
    @Link(value = "e2c93e3d-d125-4f0a-a39d-a63ec7db9bde", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e2c93e3d-d125-4f0a-a39d-a63ec7db9bde)")
    @DisplayName("Проверить добавление Группы")
    public void createGroupTest() {
        String sectionName = "createGroupTest" + RandomString.get(32);
        String appName = "createGroupApp" + RandomString.get(32);
        String groupName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Группы и Роли");
        sectionPage.appHeaderToolbar().clickActionButton("Группа");

        addGroupOrRoleModal.fillName(groupName);
        addGroupOrRoleModal.fillDescription("TestDescription");
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");

        sectionPage.checkGroupOrRoleName(groupName);
    }

    @Test
    @Link(value = "11f4c771-c7cb-44f3-8110-ccbd7e0e992d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/11f4c771-c7cb-44f3-8110-ccbd7e0e992d)")
    @DisplayName("Проверить добавление Роли")
    public void createRoleTest() {
        String sectionName = "createRoleTest" + RandomString.get(32);
        elmaBackend.createSection(sectionName);
        String appName = "createRoleApp" + RandomString.get(32);
        String roleName = RandomString.get(8);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Группы и Роли");
        sectionPage.appHeaderToolbar().clickActionButton("Группа");

        addGroupOrRoleModal.fillName(roleName);
        addGroupOrRoleModal.clickRoleSelect();
        addGroupOrRoleModal.fillDescription("TestDescription");
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");

        sectionPage.checkGroupOrRoleName(roleName);
    }

    @Test
    @Link(value = "6272cd94-4c20-4dc1-a072-26f21bd18820", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6272cd94-4c20-4dc1-a072-26f21bd18820)")
    @DisplayName("Настройка действий. Добавить кнопку \"Создать\"")
    public void addButtonCreateTest() {
        String sectionName = "addButtonCreateTest" + RandomString.get(16);
        String appName = "AppBtnCreate" + RandomString.get(8);
        String newBtnName = "TestAction" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку \"Создать\"");
        sectionPage.appHeaderToolbar().clickSettingsInLastActionButton();

        settingsActionsButtonModal.fillName(newBtnName);
        settingsActionsButtonModal.selectColorImportant();
        settingsActionsButtonModal.clickSave();
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickAccessCreateCheckbox();
        sectionPage.clickSaveAccess();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();

        sectionPage.refreshPage();
        sectionPage.open(sectionName, appName);
        // Судя по всему, у продукта есть дефект. Даже после полной очистки куков, двух хранилищ,
        // закрытия и открытие браузера через webdriver, кнопка может отображаться.
        sectionPage.checkPermissionOnButtonCreate();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.refreshPage();
        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickSettingsInLastActionButton();
        sectionPage.clickDeleteButtonActionButton();
        sectionPage.appHeaderToolbar().clickCloseActionButton();

        sectionPage.checkButtonDeleted(newBtnName);
    }

    @Test
    @Link(value = "02eeb294-1e7a-46ea-bfbd-5dbe61742c24", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/02eeb294-1e7a-46ea-bfbd-5dbe61742c24)")
    @DisplayName("Настройка действий. Добавить кнопку запуска процесса")
    public void addButtonRunBusinessProcessTest() {
        String sectionName = "addButtonRunProcess" + RandomString.get(16);
        String appName = "ProcessRun" + RandomString.get(8);
        String BPName = "BusinessProc" + RandomString.get(8);
        String newBtnName = "TestAction" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, BPName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().selectActionSettings("Настройка действий");
        sectionPage.appHeaderToolbar().clickPlusActionAndSelectOptions("Добавить кнопку запуска процесса");

        settingsActionsButtonModal.fillName(newBtnName);
        settingsActionsButtonModal.selectColorImportant();
        settingsActionsButtonModal.clickSelectProcess();
        selectProcessModal.selectProcessByName(BPName);
        selectProcessModal.checkProcessAddedInButtonRun(BPName);
        settingsActionsButtonModal.clickDrawFormBesideButton();
        settingsActionsButtonModal.clickSave();
        sectionPage.appHeaderToolbar().clickCloseActionButton();
        sectionPage.appHeaderToolbar().clickActionButton(newBtnName);
        sectionPage.clickButtonOnProcessForm();

        sectionPage.isProcessRun(BPName);
    }

    @Test
    @Link(value = "31ca68cb-9418-4e20-b29b-e87cac588eed", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/31ca68cb-9418-4e20-b29b-e87cac588eed)")
    @DisplayName("Создание страницы в разделе")
    public void createAppTypePageTest() {
        String sectionName = "createAppTypePageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreatePage();
        createAppModal.fillPageName(pageName);
        createAppModal.dialogWindowPressButton("Создать");

        sectionPage.checkCreatedAppAvailable(pageName);
    }

    @Test
    @Link(value = "485e9c57-8099-4b4d-a21c-1aa23e218683", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/485e9c57-8099-4b4d-a21c-1aa23e218683)")
    @DisplayName("Создание приложения с типом \\Стандартное\\")
    public void createStandardApplicationTest() {
        String sectionName = "createStandardApplicationTest" + RandomString.get(8);
        String appName = "createStandardApplicationName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();

        createAppModal.chooseTypeOfApp("Стандартное");
        createAppModal.fillName(appName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");

        sectionPage.checkBPCreationWindowAppear();
        sectionPage.checkAppCreated(appName);
    }

    @Test
    @Link(value = "577cc987-f4af-4773-bb35-f2e4f929893c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/577cc987-f4af-4773-bb35-f2e4f929893c)")
    @DisplayName("Создание ссылки в разделе")
    public void createLinkInSectionTest() {
        String sectionName = "createLinkInSectionTest" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();

        createAppModal.chooseAppType("Ссылку");
        String link = "https://elma365.com/ru/help/";
        String linkName = "createLinkInSection" + RandomString.get(8);
        String linkIcon = createAppModal.fillLinkAppType(linkName, link);

        sectionPage.checkLinkAppear(linkName, linkIcon, link);
    }

    @Test
    @Link(value = "606aadc8-46de-4ea7-a92e-2cce028c6b4a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/606aadc8-46de-4ea7-a92e-2cce028c6b4a)")
    @DisplayName("Создание приложения с типом \\Событие\\")
    public void createEventInSectionTest() {
        String sectionName = "createEventInSectionTest" + RandomString.get(8);
        String eventName = "createEventInSection" + RandomString.get(8);
        elmaBackend.createSection(sectionName);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();

        createAppModal.chooseTypeOfApp("Событие");
        createAppModal.fillName(eventName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");

        sectionPage.checkBPCreationWindowAppear();
        sectionPage.checkAppCreated(eventName);
    }

    @Test
    @Link(value = "cdcb6c28-d124-4261-9f4a-649a0815802a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cdcb6c28-d124-4261-9f4a-649a0815802a)")
    @DisplayName("Создание приложения с типом \\Документ\\")
    public void createDocumentInSectionTest() {
        String sectionName = "createDocumentInSectionTest" + RandomString.get(8);
        String documentName = "createDocumentInSection" + RandomString.get(8);
        elmaBackend.createSection(sectionName);

        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickQuickCreateApplication();

        createAppModal.chooseTypeOfApp("Документ");
        createAppModal.fillName(documentName);
        createAppModal.dialogWindowPressButton("Создать");
        createAppModal.clickModalHeaderButton("Сохранить");

        sectionPage.checkBPCreationWindowAppear();
        sectionPage.checkAppCreated(documentName);
    }
}
