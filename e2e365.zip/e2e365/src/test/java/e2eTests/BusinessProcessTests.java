package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendCrm;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.backendProcess.BackendProcess;
import infrastructure.elmaBackend.backendProcess.JsonProcess;
import infrastructure.elmaBackend.backendProcess.ProcessInfo;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import infrastructure.utils.Constants;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.io.File;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

import static com.codeborne.selenide.Selenide.refresh;
import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.APPLICATION_WITH_STRING;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.elmaBackend.jsonTools.JsonBusinessProcess.PUBLISH_PROCESS;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_HH_MM;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.*;
import static java.time.LocalTime.now;

@MicronautTest
@Tags({@Tag("express"), @Tag("process")})
public class BusinessProcessTests {

    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected ProcessInstanceModal processInstanceModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected PropertyContextTypeTableModal propertyContextTypeTableModal;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected ProcessMonitorPage processMonitorPage;
    @Inject
    protected SelectProcessModal selectProcessModal;
    @Inject
    protected ProcessMapModal processMapModal;
    @Inject
    protected SelectAppModal selectAppModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected NotificationSettingsModal notificationSettingsModal;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected EmailNotificationModal emailNotificationModal;
    @Inject
    protected NotificationModal notificationModal;
    @Inject
    protected CreateTaskModal createTaskModal;
    @Inject
    protected MessagePage messagePage;
    @Inject
    protected AdminSectionPage adminSectionPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected StatusPage statusPage;
    @Inject
    protected BackendProcess backendProcess;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected FilePage filePage;

    @Test
    @Link(value = "c32c55de-04d6-4b9d-b45b-6ffff0522d6c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c32c55de-04d6-4b9d-b45b-6ffff0522d6c)")
    @DisplayName("Создать новую функцию")
    public void scriptBPCreateNewFunctionTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String taskName = "TestScript" + RandomString.get(8);
        String simpleScript = "Context.data.scripttestnum1 = 15;\n" +
                "Context.data.scripttestnum2 = 100;\n" +
                "Context.data.scriptresultnum = Context.data.scripttestnum1 * Context.data.scripttestnum2;";
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptBP.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.fillNameBlock(taskName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.fillNameBlock("createNewFunction" + RandomString.get(8));
        settingsBlockModal.clickAddNewFunction();
        settingsBlockModal.fillFunctionName("createFunction" + RandomString.get(4));
        settingsBlockModal.clickCreateFunction();
        settingsBlockModal.clickOpenFunction();
        businessProcessPage.fillSimpleScript(simpleScript);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId);
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(taskName, processName);

        taskModal.checkScriptCompleteSuccess("ScriptResultNum\\s*1\\s?500");
    }

    @Test
    @Link(value = "a3227c0e-ccb0-40c8-ab69-2f8f1fac5996", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a3227c0e-ccb0-40c8-ab69-2f8f1fac5996)")
    @DisplayName("Выбрать созданную ранее функцию")
    public void scriptBPSelectFunctionTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        ProcessInfo processInfo = backendProcess.createInCompany(processName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/ScriptBP.json", processInfo)
                        .addScript("""
                                async function testSript(): Promise<void> {
                                    Context.data.scripttestnum1 = 15;
                                    Context.data.scripttestnum2 = 100;
                                    Context.data.scriptresultnum = Context.data.scripttestnum1 + Context.data.scripttestnum2;
                                }
                                """))
                .save();
        String taskName = "TestScript" + RandomString.get(8);
        businessProcessPage.open("admin/process", processInfo.getId());
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.fillNameBlock(taskName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Сценарий");
        settingsBlockModal.fillNameBlock("selectFunction" + RandomString.get(4));
        settingsBlockModal.selectFunction("testSript");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendProcess.run(processInfo.getId());
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(taskName, processName);

        taskModal.checkScriptCompleteSuccess("ScriptResultNum\\s*115");
    }

    @Test
    @Link(value = "84910fa1-a625-4211-946a-4a0723e9a2c4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/84910fa1-a625-4211-946a-4a0723e9a2c4)")
    @DisplayName("Проверить запуск процесса с асинхронным запуском")
    public void asyncStartProcessTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String processMainName = "MainProcess" + RandomString.get(8);
        String processMainId = backendBusinessProcess.createBusinessProcess("global", processMainName);
        String lockHashMain = backendBusinessProcess.lock(processMainId);
        backendBusinessProcess.saveChanges(processMainId, lockHashMain,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/MainProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processMainId, lockHashMain);

        businessProcessPage.open("admin/process", processMainId);
        businessProcessPage.clickSettingsBlock("Запускпроцесса 1");
        settingsBlockModal.clickSelectProcess();
        selectProcessModal.selectProcessByName(processName);
        selectProcessModal.checkProcessAddedInProcessBlock(processName);
        settingsBlockModal.clickSyncOrAsyncStart();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processMainId);
        List<String> allInstancesProcess = backendBusinessProcess.getAllInstanceIDByProcessID(processId);
        allInstancesProcess.add(instanceId);
        List<String> getTasks = backendTasks.getTasksByManyInstances(allInstancesProcess, SECONDS_5);

        Assertions.assertEquals(2, getTasks.size(), "Размер списка процессов не соответствует ожидаемому");
    }

    @Test
    @Link(value = "a67836b0-8a6f-4864-a1bc-5c2ccff9a96e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a67836b0-8a6f-4864-a1bc-5c2ccff9a96e)")
    @DisplayName("Проверить запуск процесса с синхронным запуском")
    public void syncStartProcessTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String processMainName = "MainProcess" + RandomString.get(8);
        String processMainId = backendBusinessProcess.createBusinessProcess("global", processMainName);
        String lockHashMain = backendBusinessProcess.lock(processMainId);
        backendBusinessProcess.saveChanges(processMainId, lockHashMain,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/MainProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processMainId, lockHashMain);

        businessProcessPage.open("admin/process", processMainId);
        businessProcessPage.clickSettingsBlock("Запускпроцесса 1");
        settingsBlockModal.clickSelectProcess();
        selectProcessModal.selectProcessByName(processName);
        selectProcessModal.checkProcessAddedInProcessBlock(processName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processMainId);
        List<String> allInstancesProcess = backendBusinessProcess.getAllInstanceIDByProcessID(processId);
        allInstancesProcess.add(instanceId);
        List<String> getTasks = backendTasks.getTasksByManyInstances(allInstancesProcess, SECONDS_5);

        Assertions.assertEquals(1, getTasks.size(), "Размер списка процессов не соответствует ожидаемому");
    }

    //region Process monitor tests
    @Test
    @Link(value = "00c3ab65-64ba-4990-93f6-ad15a2180913", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/00c3ab65-64ba-4990-93f6-ad15a2180913)")
    @DisplayName("Проверить отображение информации о процессе на карточке процесса")
    public void checkProcessInfoTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin", "monitor", processId);
        processMonitorPage.checkProcessNameInTitle(processName);
        processMonitorPage.checkProcessInfoPanel();
        processMonitorPage.openProcessMap();

        processMapModal.checkProcessMap(4);
    }

    @Test
    @Link(value = "137c55dc-4169-4efc-814f-86bf4aeb2df8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/137c55dc-4169-4efc-814f-86bf4aeb2df8)")
    @DisplayName("Проверить отображение завершенных экземпляров процесса")
    public void checkFinishedProcessInfoTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        taskModal.clickNext();

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.checkProcessNameInTitle(processName);
        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);

        processMonitorPage.checkHaveStartEndDateInInstanceResultTable();
    }

    @Test
    @Link(value = "2c5524c5-aea1-4921-95f9-842ac1ea4207", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2c5524c5-aea1-4921-95f9-842ac1ea4207)")
    @DisplayName("Оставить сообщение в ленте на виджете на карточке экземпляра процесса")
    public void sendMessageFromProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();
        processInstanceModal.sendMessage("TEST MESSAGE");

        processInstanceModal.checkMessageExists("TEST MESSAGE");
    }

    @Test
    @Link(value = "35f29172-e62d-43d2-a666-8a9c6d63dc95", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/35f29172-e62d-43d2-a666-8a9c6d63dc95)")
    @DisplayName("Проверить отображение текущих экземпляров процесса")
    public void checkRunningProcessInfoTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);
        backendBusinessProcess.run(processId);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.checkProcessNameInTitle(processName);

        processMonitorPage.selectConditionInInstanceCountersPanel("Текущий", 3);
    }

    @Test
    @Link(value = "51ef4188-a82f-4b18-811a-2177c78c710e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/51ef4188-a82f-4b18-811a-2177c78c710e)")
    @DisplayName("Прервать процесс с карточки экземпляра процесса")
    public void interruptProcessTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();
        processInstanceModal.interruptProcess();

        processMonitorPage.checkNotificationBottomRight("INTERRUPT PROCESS TEST");

        processMonitorPage.refreshPage();

        processMonitorPage.selectConditionInInstanceCountersPanel("Прерван", 1);
    }

    @Test
    @Link(value = "29b4ba9e-6004-4c6b-afa8-1fb5f1df6c9c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/29b4ba9e-6004-4c6b-afa8-1fb5f1df6c9c)")
    @DisplayName("Проверить отображение прерванных процессов")
    public void checkInterruptedProcessInfoTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String processInstanceId = backendBusinessProcess.run(processId);
        backendBusinessProcess.interrupt(processInstanceId);

        processMonitorPage.open("admin", "monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.checkProcessNameInTitle(processName);
        processMonitorPage.selectConditionInInstanceCountersPanel("Прерван", 1);

        processMonitorPage.checkHaveStartEndDateInInstanceResultTable();
    }

    @Test
    @Link(value = "2c5524c5-aea1-4921-95f9-842ac1ea4207", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2c5524c5-aea1-4921-95f9-842ac1ea4207)")
    @DisplayName("Оставить сообщение с вложением в ленте на виджете на карточке экземпляра процесса")
    public void sendMessageWithAttachmentFromProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.sendMessage("TEST MESSAGE", "test_template.docx");

        processInstanceModal.checkMessageExists("TEST MESSAGE");
        processInstanceModal.checkAttachmentExists("test_template.docx");
    }

    @Test
    @Link(value = "1a44d1d6-b820-45e6-a778-8b1e7fdd5d1b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/1a44d1d6-b820-45e6-a778-8b1e7fdd5d1b)")
    @DisplayName("Выполнить таймер принудительно с карточки экземпляра процесса")
    public void skipTimerFromProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTimer.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.checkProcessInstanceHistory("Таймер 1");
        processInstanceModal.skipTimer();
        processMonitorPage.refreshPage();

        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
    }

    @Test
    @Link(value = "8c82ab3a-7062-4e86-bb3b-5a004221a345", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8c82ab3a-7062-4e86-bb3b-5a004221a345)")
    @DisplayName("Проверить работу кнопки Все процессы")
    public void checkAllProcessButtonTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String processInstanceId = backendBusinessProcess.run(processId);
        backendBusinessProcess.interrupt(processInstanceId);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.selectConditionInInstanceCountersPanel("Прерван", 1);
        processMonitorPage.selectConditionInInstanceCountersPanel("Текущий", 1);
        processMonitorPage.clickAllProcessButton();

        processMonitorPage.checkSizeOfResultTable(2);
    }

    @Test
    @Link(value = "890aec9e-9032-4b01-a268-60cb9b8745a3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/890aec9e-9032-4b01-a268-60cb9b8745a3)")
    @DisplayName("Проверить отображение свойств процесса на виджете на карточке экземпляра процесса")
    public void checkPropertiesOnProcessInstanceCardTest() {
        String initiator = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String startDatePattern = "\\d{1,2}.{5,}\\d{4}.{3},.\\d{1,2}:\\d{2}";
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.checkValueInProperties(processName);
        processInstanceModal.checkValuePatternInProperties(startDatePattern);
        processInstanceModal.checkValueInProperties(initiator);
    }

    @Test
    @Link(value = "c842a0d1-8967-4c57-bbd9-cfa2f1a4d620", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c842a0d1-8967-4c57-bbd9-cfa2f1a4d620)")
    @DisplayName("Проверить изменение контекста на карточке экземпляра процесса")
    public void checkContextChangeOnProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ContextChange.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.selectTab("Контекст");
        processInstanceModal.checkContext("Str1", "Before");
        processInstanceModal.checkContext("Int1", "123");
        processInstanceModal.changeContext();
        processInstanceModal.checkContext("Str1", "After");
        processInstanceModal.checkContext("Int1", "321");
        processInstanceModal.checkContext("Bool1", "checkbox");
    }

    @Test
    @Link(value = "9fec33a5-286c-4700-879c-a0824174e892", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9fec33a5-286c-4700-879c-a0824174e892)")
    @DisplayName("Проверить обновление версии на карточке экземпляра процесса")
    public void checkUpdateVersionOnProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.checkProcessVersion(1);
        lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();
        processInstanceModal.updateVersion();
        refresh();

        processInstanceModal.checkProcessVersion(2);
    }

    @Test
    @Link(value = "ba243572-fb2b-4e6a-8299-eab692ca8d23", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ba243572-fb2b-4e6a-8299-eab692ca8d23)")
    @DisplayName("Проверить корректность отображения информации на вкладке Карта карточки экземпляра процесса")
    public void checkProcessMapTabOnProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.selectTab("Карта");
        processInstanceModal.processMapCheck(4);
        processInstanceModal.processMapCountOfHighlightedBlocks(2);
        processInstanceModal.processMapCountOfCurrentBlocks(1);
    }

    @Test
    @Link(value = "ef184a99-21cc-496d-8941-9f242ab2de89", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ef184a99-21cc-496d-8941-9f242ab2de89)")
    @DisplayName("Возобновить выполнение экземпляра процесса при ошибке")
    public void rerunTaskWithErrorInProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptWithError.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.checkProcessInstanceHistory("Ошибка");
        processInstanceModal.rerunTaskWithError();
    }

    @Test
    @Link(value = "07103377-7391-4119-a22b-7cbc7f452140", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/07103377-7391-4119-a22b-7cbc7f452140)")
    @DisplayName("Пропустить шаг на карточке экземпляра процесса при ошибке")
    public void skipTaskWithErrorInProcessInstanceCardTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ScriptWithError.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openHistory();

        processInstanceModal.checkProcessInstanceHistory("Ошибка");
        processInstanceModal.skipTaskWithError();
        processInstanceModal.checkProcessInstanceHistory("Конец");
        processInstanceModal.close();
        processMonitorPage.refreshPage();
        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
    }

    //endregion
    //region Timer
    @Test
    @Link(value = "d266096a-fe74-41e9-b7f6-4eb6892727fe", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d266096a-fe74-41e9-b7f6-4eb6892727fe)")
    @DisplayName("Вынести таймер на схему бизнес-процесса")
    public void putTimerOnProcessSchemeTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.openFolder("События");
        businessProcessPage.simpleDragAndDrop("Таймер", "#content>:nth-child(1)");
        businessProcessPage.checkElementByName("Таймер 1");
    }

    @Test
    @Link(value = "abaf134e-2cb7-4bb0-938d-17844caa9262", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/abaf134e-2cb7-4bb0-938d-17844caa9262)")
    @DisplayName("Проверить работу таймера с ограничением по переменной")
    public void checkTimerWithContextVariableTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTimerContext.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
        processMonitorPage.openProcessInstanceInInstanceResultTable();

        processInstanceModal.selectTab("Карта");
        processInstanceModal.processMapCountOfHighlightedBlocks(3);
    }

    @Test
    @Link(value = "144bb642-f20d-4554-85db-6ad0097c2c09", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/144bb642-f20d-4554-85db-6ad0097c2c09)")
    @DisplayName("Проверить работу таймера с ограничением точное время")
    public void checkTimerWithActualTimeTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTimerActualTime.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);
        // Процесс не завершается, не может применить таймер на 0. проявился на версии 2023.1.4.
        CustomDriver.waitMills(MINUTES_1); // Таймер установлен на минуту. Ожидаем окончания.

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);

        processMonitorPage.selectConditionInInstanceCountersPanel("Завершен", 1);
        processMonitorPage.openProcessInstanceInInstanceResultTable();

        processInstanceModal.selectTab("Карта");
        processInstanceModal.processMapCountOfHighlightedBlocks(3);
    }

    @Test
    @Link(value = "03454f91-788d-4c51-a648-69d2dd57082b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/03454f91-788d-4c51-a648-69d2dd57082b)")
    @DisplayName("Проверить выполнение таймера без учета рабочего календаря")
    public void checkTimerExcludingWorkCalendarTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTimerActualTime.json")
                        .setDraft(PUBLISH_PROCESS)
                        .setTimeInTimerSettings("7f0e3d98-4350-4cf2-9b5a-0e523cc63a01", "hours", 16)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        backendBusinessProcess.run(processId);

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.selectConditionInInstanceCountersPanel("Текущий", 1);
        processMonitorPage.openProcessInstanceInInstanceResultTable();
        // AssertionFailedError: Разница дат не соответствует ожидаемой ==>
        // Expected : 961
        // Actual : 960
        // погрешность в одну минуту ломала тест, проверка переделана на часы целочисленным делением.
        Assertions.assertEquals(processInstanceModal.getDifferenceBetweenDatesInRow("Таймер 1") / 60, 16,
                "Разница времени не соответствует ожидаемой");
    }

    @Test
    @Link(value = "993c6c7a-7de4-4b0d-87f1-0c6b0ce8a69f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/993c6c7a-7de4-4b0d-87f1-0c6b0ce8a69f)")
    @DisplayName("Проверить выполнение таймера с учетом рабочего календаря")
    public void checkTimerAccordingWorkCalendarTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        ProcessInfo processInfo = backendProcess.createInCompany(processName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/ProcessWithTimerActualTime.json", processInfo)
                        .setTimeInTimerSettings("7f0e3d98-4350-4cf2-9b5a-0e523cc63a01", "hours", 16)
                        .setAbsoluteInTimerSettings("7f0e3d98-4350-4cf2-9b5a-0e523cc63a01", false))
                .publication();
        backendProcess.run(processInfo.getId());

        processMonitorPage.open("admin/monitor/");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.selectConditionInInstanceCountersPanel("Текущий", 1);
        processMonitorPage.openProcessInstanceInInstanceResultTable();

        Assertions.assertTrue(processInstanceModal.getDifferenceBetweenDatesInRow("Таймер 1") > 960,
                "Разница дат меньше ожидаемой");
    }

    //endregion
    //region ProcessTableTests
    @Test
    @Link(value = "e1ae9426-696a-4947-ae40-70b375d0d832", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e1ae9426-696a-4947-ae40-70b375d0d832)")
    @DisplayName("Сохранение данных внутри таблицы в процессе с колонками \"Простого типа\"")
    public void saveDataTypeSimpleInProcessContextTableTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithContextTable.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickFirstContextVariable();

        propertyContextTypeTableModal.clickSettingsTable();
        propertyContextTypeTableModal.clickAddColumn("Данные");
        String columnName = "Column" + RandomString.get(4);
        propertyContextTypeTableModal.fillNameColumn(columnName);
        propertyContextTypeTableModal.dialogWindowPressButton("Создать");//Закрываем модальное окно 3
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 2
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 1
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId);

        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        String randomVar1 = "Test" + RandomString.get(8);
        taskModal.inputTableCellString(randomVar1, 0, 0);
        String randomVar2 = "Test" + RandomString.get(8);
        taskModal.inputTableCellString(randomVar2, 1, 0);
        String randomVar3 = "Test" + RandomString.get(8);
        taskModal.inputTableCellString(randomVar3, 2, 0);
        taskModal.clickNext();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 2", processName);
        taskModal.checkValueTableCell(randomVar1, 0, 0);
        taskModal.checkValueTableCell(randomVar2, 1, 0);
        taskModal.checkValueTableCell(randomVar3, 2, 0);
    }

    @Test
    @Link(value = "21161032-89df-4908-91e2-139a9463a946", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/21161032-89df-4908-91e2-139a9463a946)")
    @DisplayName("Сохранение данных внутри таблицы в процессе с колонками \"Типа Приложение\"")
    public void saveDataTypeAppInProcessContextTableTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithContextTable.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickFirstContextVariable();

        propertyContextTypeTableModal.clickSettingsTable();
        propertyContextTypeTableModal.clickAddColumn("Данные");
        String columnName = "Column" + RandomString.get(4);
        propertyContextTypeTableModal.fillNameColumn(columnName);
        propertyContextTypeTableModal.selectTypeApp();
        propertyContextTypeTableModal.clickLinkSelectApp();
        selectAppModal.clickSectionInModal("CRM");
        selectAppModal.clickAppInModal("Компании");
        String companyName = RandomString.get(10);
        backendCrm.createCompany(companyName, RandomString.getUUID());
        propertyContextTypeTableModal.dialogWindowPressButton("Создать");//Закрываем модальное окно 3
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 2
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 1
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId);

        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        taskModal.inputTableCellTypeApp(companyName, 0, 0);
        taskModal.inputTableCellTypeApp(companyName, 1, 0);
        taskModal.inputTableCellTypeApp(companyName, 2, 0);
        taskModal.clickNext();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 2", processName);

        taskModal.checkLinkTableCell(companyName, 0, 0);
        taskModal.checkLinkTableCell(companyName, 1, 0);
        taskModal.checkLinkTableCell(companyName, 2, 0);
    }

    @Test
    @Link(value = "3514a760-b1ca-4ab1-b101-52c0173accd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3514a760-b1ca-4ab1-b101-52c0173accdc)")
    @DisplayName("Проверить работу формул в колонках таблиц на формах процесса")
    public void columnTypeFormulaWithSimplePropertyTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithContextTable.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickFirstContextVariable();

        propertyContextTypeTableModal.clickSettingsTable();
        propertyContextTypeTableModal.clickAddColumn("Данные");
        String columnName = "Column" + RandomString.get(4);
        propertyContextTypeTableModal.fillNameColumn(columnName);
        propertyContextTypeTableModal.selectTypeNumber();
        propertyContextTypeTableModal.dialogWindowPressButton("Создать");
        propertyContextTypeTableModal.clickAddColumn("Формула");
        String columnFormulaName = "Column" + RandomString.get(4);
        propertyContextTypeTableModal.fillNameColumn(columnFormulaName);
        propertyContextTypeTableModal.selectTypeNumber();
        propertyContextTypeTableModal.inputSimpleFormula("$" + columnName.toLowerCase(Locale.ROOT) + "*2");
        propertyContextTypeTableModal.dialogWindowPressButton("Создать");//Закрываем модальное окно 3
        CustomDriver.waitMills(500);
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 2
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 1
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId);

        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        int randomVar = 10;
        taskModal.inputTableCellNumber("" + randomVar, 1, 0);
        CustomDriver.waitMills(2000); //Секунда чтобы успела отработать формула
        taskModal.inputTableCellNumber("" + randomVar, 2, 0);
        CustomDriver.waitMills(2000); //Секунда чтобы успела отработать формула
        taskModal.inputTableCellNumber("" + randomVar, 3, 0);
        CustomDriver.waitMills(2000); //Секунда чтобы успела отработать формула
        taskModal.clickNext();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 2", processName);
        randomVar *= 2;

        taskModal.checkValueTableCell("" + randomVar, 0, 1);
        taskModal.checkValueTableCell("" + randomVar, 1, 1);
        taskModal.checkValueTableCell("" + randomVar, 2, 1);
    }

    @Test
    @Link(value = "eb011506-1430-4d5d-b1e7-5f1431ceb924", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/eb011506-1430-4d5d-b1e7-5f1431ceb924)")
    @DisplayName("Проверить работу формул в колонках таблицы с вложенными свойтсвами")
    public void columnTypeFormulaWithAttachedPropertyTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithContextTable.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId, "context");
        businessProcessPage.clickFirstContextVariable();

        propertyContextTypeTableModal.clickSettingsTable();
        propertyContextTypeTableModal.clickAddColumn("Данные");
        String columnName = "Column" + RandomString.get(4);
        propertyContextTypeTableModal.fillNameColumn(columnName);
        propertyContextTypeTableModal.selectTypeApp();
        propertyContextTypeTableModal.clickLinkSelectApp();
        selectAppModal.clickSectionInModal("CRM");
        selectAppModal.clickAppInModal("Компании");
        String companyName = RandomString.get(10);
        backendCrm.createCompany(companyName, RandomString.getUUID());
        propertyContextTypeTableModal.dialogWindowPressButton("Создать");//Закрываем модальное окно 3
        propertyContextTypeTableModal.clickAddColumn("Формула");
        String columnFormulaName = "Column" + RandomString.get(4);
        propertyContextTypeTableModal.fillNameColumn(columnFormulaName);
        propertyContextTypeTableModal.selectTypeString();
        propertyContextTypeTableModal.inputSimpleFormula("$" + columnName.toLowerCase(Locale.ROOT) + ".__name");
        propertyContextTypeTableModal.dialogWindowPressButton("Создать");//Закрываем модальное окно 3
        CustomDriver.waitMills(500);//TODO тут с формулами бага, по этому надо подождать
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 2
        propertyContextTypeTableModal.dialogWindowPressButton("Сохранить");//Закрываем модальное окно 1
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId);

        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        taskModal.inputTableCellTypeApp(companyName, 0, 0);
        taskModal.inputTableCellTypeApp(companyName, 1, 0);
        taskModal.inputTableCellTypeApp(companyName, 2, 0);
        taskModal.clickNext();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 2", processName);
        CustomDriver.waitMills(2000);//Ждем пока система подгрузит приложения в таблицу
        taskModal.checkValueTableCell("" + companyName, 0, 1);
        taskModal.checkValueTableCell("" + companyName, 1, 1);
        taskModal.checkValueTableCell("" + companyName, 2, 1);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "af32d932-80d2-4bc9-af7e-34b01f7e0e3e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/af32d932-80d2-4bc9-af7e-34b01f7e0e3e)")
    @DisplayName("Проверить отправку оповещения от системы")
    public void checkSystemNotificationOnProcessStartTest() {
        String sectionName = "checkSystemNotificationOnProcessStartSectionName" + RandomString.get(8);
        String businessProcessName = "checkSystemNotificationOnProcessStartProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String message = "message" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTwoTasksAndAlert.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Оповещение 1");
        notificationSettingsModal.fillNotificationTheme(theme);
        notificationSettingsModal.fillNotificationMessage(message);
        notificationSettingsModal.setNotificationAuthor("Система");
        notificationSettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkNotificationWithAuthorVisible("Система");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "684d8fb7-3e9c-4740-ae1e-c6fa3a93a9b6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/684d8fb7-3e9c-4740-ae1e-c6fa3a93a9b6)")
    @DisplayName("Проверить запуск процесса настроенный по кнопке \"Сохранить\"")
    public void checkSavedProcessStartTest() {
        String sectionName = "checkSavedProcessStartSectionName" + RandomString.get(8);
        String appName = "checkSavedProcessStartAppName" + RandomString.get(8);
        String processName = "checkSavedProcessStartProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.fillName("test");
        createAppElementModal.clickModalFooterButton("settings");
        createAppElementModal.clickModalFooterButton("settings");
        createAppElementModal.bindProcess(processName);
        createAppElementModal.clickModalFooterButton("system_close");
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3a749b8f-c8a0-42a3-ad94-13ff86e1ed8b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3a749b8f-c8a0-42a3-ad94-13ff86e1ed8b)")
    @DisplayName("Отладить процесс")
    public void debugProcessTest() {
        String processName = "debugProcessProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);

        businessProcessPage.open("admin/process/" + processId);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickDebug();

        sectionPage.clickNextStageOrExit();

        businessProcessPage.checkDebugTabVisible("TestStartSubProces");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "66bea0cb-69de-4b52-b077-bb4276ad5b98", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/66bea0cb-69de-4b52-b077-bb4276ad5b98)")
    @DisplayName("Проверить процесс")
    public void checkProcessTest() {
        String processName = "debugProcessProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickCheck();
        businessProcessPage.checkErrorMessageExists("Недостижимо конечное событие");
        businessProcessPage.clickBack();

        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickCheck();
        businessProcessPage.checkSuccessfulCheckMessage();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "731566da-ce21-4150-be5c-7013f000ebf8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/731566da-ce21-4150-be5c-7013f000ebf8)")
    @DisplayName("Опубликовать процесс")
    public void publishProcessTest() {
        String processName = "publishProcessProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickPublish(); // проверка сообщения есть в методе
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "c6015afb-db23-46f5-a0e4-4ee033eb238d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c6015afb-db23-46f5-a0e4-4ee033eb238d)")
    @DisplayName("Сохранить процесс")
    public void saveProcessTest() {
        String processName = "saveProcessProcessName" + RandomString.get(8);
        String taskName = "saveProcessTaskName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        // не стал добавлять новые блоки, просто переименовал существующий
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.fillNameBlock(taskName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();

        businessProcessPage.refreshPage();
        businessProcessPage.clickBlockExists(taskName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "ee62abdc-5f23-4981-a106-8ccc4a1d4799", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ee62abdc-5f23-4981-a106-8ccc4a1d4799)")
    @DisplayName("Проверить прерывание процесса при ошибке отправки оповещения на Email с переходом к другой операции")
    public void breakProcessIfEmailIsNotSendTest() {
        String processName = "breakProcessIfEmailIsNotSendProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/BreakableEmailSendProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("на email 1");

        emailNotificationModal.fillRecipient("notamail@notamail.notamail");
        emailNotificationModal.fillTheme("theme");
        emailNotificationModal.fillText("text");
        emailNotificationModal.selectModalWindowTab("Обработка ошибок");
        emailNotificationModal.setBreakCheckbox(true);
        emailNotificationModal.setTransition("Задача 1");
        emailNotificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "4e830500-e9e9-4d3b-9e93-036f9a1be572", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4e830500-e9e9-4d3b-9e93-036f9a1be572)")
    @DisplayName("Проверить отправку оповещения от пользователя, указанного в контекстной переменной")
    public void notificationFromUserInContextVariableTest() {
        String processName = "notificationFromUserInContextVariableProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setContextVariableAuthor("system_user");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        createTaskModal.fillUserContextVariable("system_user", elmaBackend.getUserSurnameAndNameByEmail(userLogin));
        sectionPage.processStartConfirmation();

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "674169ab-4815-4958-8d71-dd6db864d4da", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/674169ab-4815-4958-8d71-dd6db864d4da)")
    @DisplayName("Проверить отправку оповещения для получателя из группы")
    public void notificationForUserInGroupTest() {
        String processName = "notificationForUserInOrgStructureProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Система");
        notificationModal.selectModalWindowTab("Получатели");
        notificationModal.deleteRecipient();
        notificationModal.addRecipient("Группа", "Все пользователи");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "968ae45d-9a1c-4735-9f05-0e08886f9b23", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/968ae45d-9a1c-4735-9f05-0e08886f9b23)")
    @DisplayName("Проверить отправку оповещения с указанной темой и текстом")
    public void notificationWithThemeAntTextTest() {
        String processName = "notificationFromCurrentUserProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Система");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme, text);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "af32d932-80d2-4bc9-af7e-34b01f7e0e3e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/af32d932-80d2-4bc9-af7e-34b01f7e0e3e)")
    @DisplayName("Проверить отправку оповещения от системы")
    public void notificationFromSystemTest() {
        String processName = "notificationFromCurrentUserProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Система");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d8d69272-763c-4f86-b263-8785d38050bb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d8d69272-763c-4f86-b263-8785d38050bb)")
    @DisplayName("Проверить отправку оповещения от текущего пользователя")
    public void notificationFromCurrentUserTest() {
        String processName = "notificationFromCurrentUserProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Текущий пользователь");

        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");
        messagePage.readAllMessages();

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d5c7534a-f2d9-4a74-9959-0199a606c2fb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d5c7534a-f2d9-4a74-9959-0199a606c2fb)")
    @DisplayName("Проверить отправку оповещения для получателя, указанного в контекстной переменной")
    public void notificationForUserInContextVariableTest() {
        String processName = "notificationFromUserInContextVariableProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Система");
        notificationModal.selectModalWindowTab("Получатели");
        notificationModal.deleteRecipient();
        notificationModal.addRecipient("Контекстная переменная", "system_user");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        createTaskModal.fillUserContextVariable("system_user", elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        sectionPage.processStartConfirmation();

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "ea908cd4-e868-4c64-b958-fdca0b5c774f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ea908cd4-e868-4c64-b958-fdca0b5c774f)")
    @DisplayName("Проверить отправку оповещения пользователю из орг структуры")
    public void notificationForUserInOrgStructureTest() {
        String processName = "notificationForUserInOrgStructureProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Система");
        notificationModal.selectModalWindowTab("Получатели");
        notificationModal.deleteRecipient();
        // Отправляется письмо гендиректору, что бы не нарушать оргструктуру.
        notificationModal.addRecipient("Элемент оргструктуры", "Генеральный директор");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "cbfa0ba5-bb5b-4fbe-9804-12f4620e7cfe", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cbfa0ba5-bb5b-4fbe-9804-12f4620e7cfe)")
    @DisplayName("Проверить отправку оповещения текущему пользователю")
    public void notificationForCurrentUserTest() {
        String processName = "notificationForCurrentUserProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");

        notificationModal.fillTheme(theme);
        notificationModal.fillText(text);
        notificationModal.setAuthor("Система");
        notificationModal.selectModalWindowTab("Получатели");
        notificationModal.deleteRecipient();
        notificationModal.addRecipient("Текущий пользователь");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3039b6ae-4b98-4e0b-bc5c-2466f44b5a97", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3039b6ae-4b98-4e0b-bc5c-2466f44b5a97)")
    @DisplayName("Добавить новый процесс")
    public void createNewProcessTest() {
        String processName = "createNewProcessProcessName" + RandomString.get(8);
        // Если напрямую открывать admin/process, то могут не прогрузиться процессы.
        adminSectionPage.open("admin");
        adminSectionPage.clickBusinessProcesses();
        adminSectionPage.addBusinessProcess(processName, "CRM");

        businessProcessPage.checkIsBusinessProcessPage();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d1fef77e-bf07-4eed-a39b-eae356a15b5b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d1fef77e-bf07-4eed-a39b-eae356a15b5b)")
    @DisplayName("Создать копию процесса по нажатию на многоточие в списке процессов")
    public void copyProcessTest() {
        String processName = "copyProcessProcessName" + RandomString.get(8);
        String processNameNew = processName + "new";
        backendBusinessProcess.createBusinessProcess("global", processName);

        adminSectionPage.open("admin");
        adminSectionPage.clickBusinessProcesses();
        adminSectionPage.openCompanyProcesses();
        //TODO: странный баг: в выпадающем меню нет процессов компании, пришлось добавить логику.
        adminSectionPage.copyProcess(processName, processNameNew, "Процессы компании");

        adminSectionPage.refreshPage();
        adminSectionPage.openCompanyProcesses();

        adminSectionPage.checkProcessExists(processNameNew);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3d5ca9d4-00e1-4ba2-9ee6-eceffa92f9fa", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3d5ca9d4-00e1-4ba2-9ee6-eceffa92f9fa)")
    @DisplayName("Переместить процесс по нажатию на многоточие в списке процессов")
    public void moveProcessTest() {
        String processName = "moveProcessProcessName" + RandomString.get(8);
        String folderName = "moveProcessFolderName" + RandomString.get(8);

        elmaBackend.createFolderInCompanyProcesses(folderName);
        backendBusinessProcess.createBusinessProcess("global", processName);

        adminSectionPage.open("admin");
        adminSectionPage.clickBusinessProcesses();
        adminSectionPage.openCompanyProcesses();

        adminSectionPage.moveProcess(processName, folderName);

        adminSectionPage.refreshPage();
        adminSectionPage.openCompanyProcesses();
        adminSectionPage.openFolderWithProcesses(folderName);

        adminSectionPage.checkProcessIsInFolder(processName, folderName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "29f332df-f2f9-40b8-930a-f06cdb108be3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/29f332df-f2f9-40b8-930a-f06cdb108be3)")
    @DisplayName("Переименовать процесс по нажатию на многоточие в списке процессов")
    public void renameProcessTest() {
        String processName = "renameProcessProcessName" + RandomString.get(8);
        String processNameNew = processName + "new";
        backendBusinessProcess.createBusinessProcess("global", processName);

        adminSectionPage.open("admin");
        adminSectionPage.clickBusinessProcesses();
        adminSectionPage.openCompanyProcesses();

        adminSectionPage.renameProcess(processName, processNameNew);

        adminSectionPage.refreshPage();
        adminSectionPage.openCompanyProcesses();

        adminSectionPage.checkProcessExists(processNameNew);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "54983143-e2ec-4932-be65-80b8c86e29fc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/54983143-e2ec-4932-be65-80b8c86e29fc)")
    @DisplayName("Настроить запуск процесса по расписанию")
    public void checkScheduledProcessStartTest() {
        String businessProcessName = "checkDisplayTableInstancesAndTasksProcessProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickStartBlock();

        settingsBlockModal.chooseTab("Настройки запуска");
        settingsBlockModal.setNonRepeatableScheduledRunToday(now().plusMinutes(2).format(FORMATTER_HH_MM));
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.deleteFeature("Название");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        CustomDriver.waitMills(MINUTES_2);
        sectionPage.refreshPage();
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", businessProcessName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "5a748ca7-f42e-4d74-9055-882cbe3ee955", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5a748ca7-f42e-4d74-9055-882cbe3ee955)")
    @DisplayName("Настроить поля для отображения на карточке экземпляра процесса")
    public void setProcessInstanceFieldsTest() {
        String processName = "checkSkipStepButtonProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithStringParameter.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Настройки");
        businessProcessPage.selectSettingsTab("Карточка экземпляра");
        businessProcessPage.setProcessFormField("stroka");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
        sectionPage.clickNextStageOrExit();

        processMonitorPage.open("admin/monitor");
        processMonitorPage.selectProcess(processName);
        processMonitorPage.openProcessInstance("TestStartSubProces");

        processInstanceModal.selectTab("Контекст");
        processInstanceModal.checkContext("stroka", "text");
        // TODO: не получается исключить переменную "инициатор" с вкладки "контекст",
        //  на opnremise не проходит проверка списка переменных.
        processInstanceModal.checkContextsArrayEquals("stroka");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "74603f73-f6ee-4d9e-9b3c-b96dea8a1687", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/74603f73-f6ee-4d9e-9b3c-b96dea8a1687)")
    @DisplayName("Сформировать название экземпляра процесса по шаблону")
    public void setProcessNameByTemplateTest() {
        String processName = "checkSkipStepButtonProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Настройки");
        businessProcessPage.selectSettingsTab("Название");
        businessProcessPage.setNameTemplate("test name {$__createdBy} {$__createdAt}");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage("Поставлена задача: test name "
                + elmaBackend.getUserFIOByEmail(adminLogin) + " "
                + LocalDateTime.now().format(FORMATTER_DD_MM_YYYY));
    }

    @Test
    @Disabled // заблочен известным багом
    @Tag("Author=Krasilnikov")
    @Link(value = "9d6948e7-4c67-4b4a-b256-81a41f9ac3af", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9d6948e7-4c67-4b4a-b256-81a41f9ac3af)")
    @DisplayName("Создать форму для карточки экземпляра бизнес-процесса")
    public void createProcessInstanceFormTest() {
        String processName = "createProcessInstanceFormProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.selectTab("Настройки");
        businessProcessPage.selectSettingsTab("Карточка экземпляра");
        businessProcessPage.clickCreateProcessInstanceForm();

        pageConstructorPage.dragWidgetAndDropForm("Текст");
        widgetSettingsModal.fillTextInTextWidget(processName + "text");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        // TODO: наложение тулбаров, кнопка "сохранить" существует в двух экземплярах.
        pageConstructorPage.clickVisibleSaveButton();
        pageConstructorPage.clickBack();

        businessProcessPage.selectTab("Настройки");
        businessProcessPage.selectSettingsTab("Карточка экземпляра");
        businessProcessPage.selectProcessInstanceForm("Карточка экземпляра");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        // TODO: не удалось найти какие-либо изменения после смены формы, везде отображается обычная.
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "01f5ee02-bae7-40fd-ae2c-3a075ee9486e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/01f5ee02-bae7-40fd-ae2c-3a075ee9486e)")
    @DisplayName("Оповестить об ошибке пользователя из группы")
    public void alertForUserInGroupTest() {
        String processName = "alertForUserInGroupProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/BreakableEmailSendProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("на email 1");

        emailNotificationModal.fillRecipient("notamail@notamail.notamail");
        emailNotificationModal.fillTheme("theme");
        emailNotificationModal.fillText("text");
        emailNotificationModal.selectModalWindowTab("Обработка ошибок");
        emailNotificationModal.setBreakCheckbox(true);
        emailNotificationModal.setTransition("Задача 1");
        emailNotificationModal.setAlertRecipientsIfFail("Группа", "Все пользователи");
        emailNotificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.checkAlertMessageExists("email");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "311c54ad-e967-4f38-a591-909814ad2f27", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/311c54ad-e967-4f38-a591-909814ad2f27)")
    @DisplayName("Оповестить об ошибке пользователя из орг структуры")
    public void alertForUserInOrgStructureTest() {
        String processName = "alertForUserInOrgStructureProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/BreakableEmailSendProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("на email 1");

        emailNotificationModal.fillRecipient("notamail@notamail.notamail");
        emailNotificationModal.fillTheme("theme");
        emailNotificationModal.fillText("text");
        emailNotificationModal.selectModalWindowTab("Обработка ошибок");
        emailNotificationModal.setBreakCheckbox(true);
        emailNotificationModal.setTransition("Задача 1");
        emailNotificationModal.setAlertRecipientsIfFail("Элемент оргструктуры", "Генеральный директор");
        emailNotificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.checkAlertMessageExists("email");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "c02d3beb-3f68-4a10-9305-8647b42b4cf8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c02d3beb-3f68-4a10-9305-8647b42b4cf8)")
    @DisplayName("Оповестить об ошибке пользователя из контекстной переменной")
    public void alertForUserInContextVariableTest() {
        String processName = "alertForUserInContextVariableProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/BreakableEmailSendProcessWithUserVariable.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("на email 1");

        emailNotificationModal.fillRecipient("notamail@notamail.notamail");
        emailNotificationModal.fillTheme("theme");
        emailNotificationModal.fillText("text");
        emailNotificationModal.selectModalWindowTab("Обработка ошибок");
        emailNotificationModal.setBreakCheckbox(true);
        emailNotificationModal.setTransition("Задача 1");
        emailNotificationModal.setAlertRecipientsIfFail("Контекстная переменная", "system_user");
        emailNotificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        createTaskModal.fillUserContextVariable("system_user", elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        sectionPage.processStartConfirmation();

        sectionPage.checkAlertMessageExists("email");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("bugged")
    @Disabled
    // TODO: нужно проанализировать цели ТК, требуется ли переход к другой операции. Если да - дубль breakProcessIfEmailIsNotSendTest
    @Tag("Author=Krasilnikov")
    @Link(value = "cf3a262a-ca8c-442f-b7a3-b44598a45a95", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cf3a262a-ca8c-442f-b7a3-b44598a45a95)")
    @DisplayName("Проверить прерывание процесса при ошибке отправки оповещения на Email")
    public void checkBreakProcessTest() {
        String processName = "checkBreakProcessProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/BreakableSimpleEmailSendProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("на email 1");

        emailNotificationModal.fillRecipient("notamail@notamail.notamail");
        emailNotificationModal.fillTheme("theme");
        emailNotificationModal.fillText("text");
        emailNotificationModal.selectModalWindowTab("Обработка ошибок");
        emailNotificationModal.setBreakCheckbox(true);
        emailNotificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        processMonitorPage.open("admin/monitor", processId);
        // TODO: процесс не прерывается при ошибке отправки письма, баг.
        processMonitorPage.selectConditionInInstanceCountersPanel("Прерван", 1);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d287a418-a152-4ff3-981a-64c040cc1bc9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d287a418-a152-4ff3-981a-64c040cc1bc9)")
    @DisplayName("Оповестить об ошибке текущего пользователя")
    public void alertForCurrentUserTest() {
        String processName = "alertForCurrentUserProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/BreakableEmailSendProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("на email 1");

        emailNotificationModal.fillRecipient("notamail@notamail.notamail");
        emailNotificationModal.fillTheme("theme");
        emailNotificationModal.fillText("text");
        emailNotificationModal.selectModalWindowTab("Обработка ошибок");
        emailNotificationModal.setBreakCheckbox(true);
        emailNotificationModal.setTransition("Задача 1");
        emailNotificationModal.setAlertRecipientsIfFail("пользователь");
        emailNotificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.checkAlertMessageExists("email");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "8efcb594-f2d5-4388-850b-87b6e930501f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8efcb594-f2d5-4388-850b-87b6e930501f)")
    @DisplayName("Использовать простое подтверждение при переходе")
    public void checkSimpleTransitionTest() {
        String processName = "checkSimpleTransitionProcessName" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");

        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.openTransitionSettings("-> Выход");
        settingsBlockModal.chooseTab("Кнопка перехода");
        settingsBlockModal.clickRadioButtonByLabel("Простое подтверждение");
        settingsBlockModal.setTextBlockByFormRowName("Текст подтверждения", processName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("/tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
        sectionPage.clickTask(processName, "Задача 1");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkTextInConfirmationPopupAndConfirm(processName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "08a309be-7dd9-4805-9126-ff124d74ae0d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/08a309be-7dd9-4805-9126-ff124d74ae0d)")
    @DisplayName("Проверять заполнение обязательных полей задачи на переходе")
    public void checkVerifyRequiredFieldsTest() {
        String processName = "checkSimpleTransitionProcessName" + RandomString.get(8);
        String variableName = "string";

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING))
                        .addContextToActionFormByActionId("c93651cd-d34f-4627-b169-768fedacb19d", variableName, "", true, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");

        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.openTransitionSettings("Выход");
        settingsBlockModal.chooseTab("Кнопка перехода");
        settingsBlockModal.setCheckboxConditionByLabel("Проверять заполнение обязательных полей", true);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        sectionPage.open("/tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
        sectionPage.clickTask(processName, "Задача 1");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkRequiredFieldAlertAppearInFormRow(variableName);
        taskModal.setTextInputByFormRowName(variableName, variableName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "075d53e1-1307-4456-92c6-5f7da839c17f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/075d53e1-1307-4456-92c6-5f7da839c17f)")
    @DisplayName("Вынести событие на схему бизнес-процесса")
    public void bringEventToBusinessProcessSchemaTest() {
        String processName = "bringEventToBusinessProcessSchemaProcessName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.openFolder("События");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Конечное");

        businessProcessPage.isFinalBlockVisibleInWorkArea();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5fd4ffad-f613-4906-97b1-877323f9fa76", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5fd4ffad-f613-4906-97b1-877323f9fa76)")
    @DisplayName("Проверить присвоение полей после выполнения операции")
    public void checkAssignmentOfFieldsAfterOperationTest() {
        String sectionName = "checkAssignmentOfFieldsAfterOperationSectionName" + RandomString.get(8);
        String appName = "checkAssignmentOfFieldsAfterOperationAppName" + RandomString.get(8);
        String processName = "checkAssignmentOfFieldsAfterOperationProcessName" + RandomString.get(8);
        String variableName = "String" + RandomString.get(4);
        String text = "Text" + RandomString.get(8);
        String elementName = "elementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.updateApplicationFields(sectionName, appName, APPLICATION_WITH_STRING);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithAssignmentElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING, false))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Присваивание");
        settingsBlockModal.chooseTab("Таблица соответствия");
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        settingsBlockModal.clickButtonOnModalWindowByName("Выберите поле");
        settingsBlockModal.clickItemContextMenu(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Выберите поле");
        settingsBlockModal.clickItemContextMenu(appName);
        settingsBlockModal.clickItemContextMenu("Строка");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        createAppElementModal.fillFieldString(text);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists(appName + " успешно создан");
        // задача падает на админа после создания элемента
        taskModal.checkInputFormRowValue(variableName, text);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b8b1e187-6bab-42ef-81c1-5123451d714d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b8b1e187-6bab-42ef-81c1-5123451d714d)")
    @DisplayName("Проверить возможность привязки полей контекста со значениями в таблице соответствий")
    public void checkPossibilityOfLinkContextFieldsWithValuesInCorrespondenceTableTest() {
        String sectionName = "checkPossibilityOfLinkContextFieldsWithValuesInCorrespondenceTableSectionName" + RandomString.get(8);
        String appName = "checkPossibilityOfLinkContextFieldsWithValuesInCorrespondenceTableAppName" + RandomString.get(8);
        String processName = "checkPossibilityOfLinkContextFieldsWithValuesInCorrespondenceTableProcessName" + RandomString.get(8);
        String variableName = "String" + RandomString.get(4);
        String text = "Text" + RandomString.get(8);
        String elementName = "elementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.updateApplicationFields(sectionName, appName, APPLICATION_WITH_STRING);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithAssignmentElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING, false))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Присваивание");
        settingsBlockModal.chooseTab("Таблица соответствия");
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        settingsBlockModal.clickButtonOnModalWindowByName("Выберите поле");
        settingsBlockModal.clickItemContextMenu(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Выберите поле");
        settingsBlockModal.clickItemContextMenu(appName);
        settingsBlockModal.clickItemContextMenu("Строка");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        createAppElementModal.fillFieldString(text);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists(appName + " успешно создан");
        // задача падает на админа после создания элемента
        taskModal.checkInputFormRowValue(variableName, text);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d178c7d8-9234-4e65-bb39-f54c01718e3d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d178c7d8-9234-4e65-bb39-f54c01718e3d)")
    @DisplayName("Проверить, что после установки выбранного в настройках статуса процесс идет дальше")
    public void checkSettingStatusSelectedInSettingsProcessGoesOnTest() {
        String sectionName = "checkSettingStatusSelectedInSettingsProcessGoesOnSectionName" + RandomString.get(8);
        String appName = "checkSettingStatusSelectedInSettingsProcessGoesOnAppName" + RandomString.get(8);
        String processName = "checkSettingStatusSelectedInSettingsProcessGoesOnProcessName" + RandomString.get(8);
        String elementName = "elementName" + RandomString.get(8);
        String status1 = "status1" + RandomString.get(8);
        String status2 = "status2" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWaitStatus.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Поле \"Статус\"");
        statusPage.clickAddStatusField();
        selectAppModal.setCheckboxConditionByLabel("Статус Приложения можно менять вручную", true);
        statusPage.createNewStatus(status1);
        statusPage.createNewStatus(status2);
        statusPage.clickSaveStatuses(sectionName, appName);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickWaitChangeStatusBlock();
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Переменная", appName);
        settingsBlockModal.expandMenuWaitStatusAndSelectStatus(status2);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.checkTaskNameNotExists(processName);

        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.clickChangeStatusButtonAndSelectNewStatus(status2);
        sectionPage.checkAlertWithTextFragmentExists("Статус успешно изменен");

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f0ca7cfe-4a2d-4a5f-9322-7de8f4d2154a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f0ca7cfe-4a2d-4a5f-9322-7de8f4d2154a)")
    @DisplayName("Вынести операцию Отправить SMS на схему-бизнес процесса")
    public void addSendSMSBlockOnSchemeTest() {
        String processName = "addStartProcessBlock" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.chooseSidebarActivity("Интеграции");
        businessProcessPage.dragAndDropScriptBlockOnScheme("Отправить SMS");
        businessProcessPage.clickSave();

        businessProcessPage.checkElementByName("ОтправитьSMS");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3ff77297-c1be-40f6-b43e-4bf525ad42d0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3ff77297-c1be-40f6-b43e-4bf525ad42d0)")
    @DisplayName("Изменить название операции Оповещение на Email")
    public void editNotificationBlockTest() {
        String processName = "editNotificationBlockProcessName" + RandomString.get(4);

        ProcessInfo processInfo = backendProcess.createInCompany(processName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/BreakableEmailSendProcess.json", processInfo)).save();

        businessProcessPage.open("admin/process/" + processInfo.getId());

        businessProcessPage.clickSettingsBlock("Оповещение");
        settingsBlockModal.setTextInputByFormRowName("Название", "Тест");
        settingsBlockModal.setTextInputByFormRowName("Получатель", "email@mail.com");
        settingsBlockModal.setTextInputByFormRowName("Тема", "Новая тема");
        settingsBlockModal.setTextBlockByFormRowName("Текст", "Новый текст");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.checkElementByName("Тест");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "87903f85-d39a-4cf3-871c-1728ce2854c2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/87903f85-d39a-4cf3-871c-1728ce2854c2)")
    @DisplayName("Проверить работу активити Генерация по файлу")
    public void checkOperationOfActivationGenerationByFileTest() {
        String processName = "checkOperationOfActivationGenerationByFileProcessName" + RandomString.get(4);
        String variableStringName = "String" + RandomString.get(4);
        String variableFileName = "File" + RandomString.get(4);
        String text = "text" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithFileGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableStringName, ContextType.STRING, false))
                        .addContextOnDefaultStartForm(variableStringName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableFileName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableFileName, "", false, false, false)
                        .addContextToActionFormByActionId("30c2c98e-1465-486c-8e0f-6cccc39f8db6", variableFileName, "", false, true, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Генерация");
        businessProcessPage.clickAndSelectDropDownItemWithLabelRow("Входной файл", "", variableFileName);
        businessProcessPage.clickAndSelectDropDownItemWithLabelRow("Выходной файл", "", variableFileName);
        businessProcessPage.setTextInputByFormRowName("Имя выходного файла", "{$" + variableStringName.toLowerCase(Locale.ROOT) + "}.docx");
        businessProcessPage.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.setTextInputByFormRowName(variableStringName, text);
        documentTemplateCreatingModal.uploadFileWidget("testData/templates.docx");
        sectionPage.checkFormRowWithNameContainsText(variableFileName, "templates.docx");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(processName, "Задача 1");

        sectionPage.checkFormRowWithNameContainsText(variableFileName, text + ".docx");
        filePage.selectFile(text + ".docx");
        File file = filePage.downloadGenerationFile();
        Assertions.assertEquals("Test", filePage.getParagraphFromDocxFileByNum(file, 1), "Текст в документе отличается от указанного");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "bcf19ce9-e9c6-47a2-8307-fca0c7ce0fdb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bcf19ce9-e9c6-47a2-8307-fca0c7ce0fdb)")
    @DisplayName("Проверить работу активити Конвертация файла в PDF")
    public void checkOperationOfActivationFileConversionToPDFTest() {
        String processName = "checkOperationOfActivationFileConversionToPDFProcessName" + RandomString.get(4);
        String variableFileName = "File" + RandomString.get(4);
        String fileName = "file" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithFileGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableFileName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableFileName, "", false, false, false)
                        .addContextToActionFormByActionId("30c2c98e-1465-486c-8e0f-6cccc39f8db6", variableFileName, "", false, true, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Генерация");
        businessProcessPage.clickAndSelectDropDownItemWithLabelRow("Входной файл", "", variableFileName);
        businessProcessPage.clickAndSelectDropDownItemWithLabelRow("Выходной файл", "", variableFileName);
        businessProcessPage.setTextInputByFormRowName("Имя выходного файла", fileName);
        businessProcessPage.setCheckboxConditionByFormRowAndLabel("Конвертировать в PDF", "", true);
        businessProcessPage.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        documentTemplateCreatingModal.uploadFileWidget("testData/templates.docx");
        sectionPage.checkFormRowWithNameContainsText(variableFileName, "templates.docx");
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(processName, "Задача 1");

        sectionPage.checkFormRowWithNameContainsText(variableFileName, fileName + ".pdf");
        filePage.selectFile(fileName + ".pdf");
        File file = filePage.downloadGenerationFile();
        Assertions.assertEquals("Test", filePage.getTextFromPdfPage(file, 1), "Текст в документе отличается от указанного");
    }
}