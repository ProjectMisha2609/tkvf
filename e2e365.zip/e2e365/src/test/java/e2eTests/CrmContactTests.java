package e2eTests;

import infrastructure.elmaBackend.BackendCrm;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaModals.TaskModal;
import pages.elmaPages.*;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("crm_contact")})
public class CrmContactTests {
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected CrmSectionPage crmSectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected ContractPage contractPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BusinessProcessPage businessProcessPage;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f027cb12-91af-4bda-8fce-90ab21b551df", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f027cb12-91af-4bda-8fce-90ab21b551df)")
    @DisplayName("Добавить контакт")
    public void addContactAndCheckFieldsTest() {
        String dealName = "addContactTest" + RandomString.get(4);
        String leadName = "leadName" + RandomString.get(4);
        String contactName = "contact" + RandomString.get(4);
        String skype = "skypeName" + RandomString.get(4);
        String email = RandomString.get(8) + "@" + RandomString.get(4) + ".com";
        String professionName = "professionName" + RandomString.get(4);
        String companyName = "Company" + RandomString.get(4);
        String companyId = RandomString.getUUID();

        backendCrm.createCompany(companyName, companyId);
        backendCrm.createDeal(dealName);
        backendCrm.createLead(leadName);

        crmSectionPage.open("_clients/_contacts");
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Контакт");
        settingsBlockModal.setTextInputByFormRowName("Имя", contactName);
        settingsBlockModal.setTextInputByFormRowName("Должность", professionName);
        settingsBlockModal.setTextInputByFormRowName("Рабочая почта", email);
        settingsBlockModal.setTextInputByFormRowName("Skype", skype);
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Главный", "+79090554477", 1);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Мобильный", "+79090554476", 2);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Рабочий", "+79090554475", 3);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Домашний", "+79090554474", 4);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Раб. факс", "+79090554473", 5);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Пейджер", "+79090554472", 6);

        settingsBlockModal.clickButtonZoomAllWithRowName("Компания");
        mainPage.clickSelectName(companyName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Сделка");
        mainPage.clickSelectName(dealName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Лиды");
        mainPage.clickSelectName(leadName);

        settingsBlockModal.clickModalFooterButton("Сохранить");

        contractPage.clickSettingTableContractButton("Настройка таблицы");
        contractPage.addPropertyForTable("Лиды");
        contractPage.addPropertyForTable("Сделка");
        contractPage.addPropertyForTable("Skype");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        crmSectionPage.checkCellTextTableContactExists(contactName, leadName);
        crmSectionPage.checkCellTextTableContactExists(contactName, dealName);
        crmSectionPage.checkCellTextTableContactExists(contactName, skype);
        crmSectionPage.checkCellTextTableContactExists(contactName, email);
        crmSectionPage.checkCellTextTableContactExists(contactName, companyName);
        crmSectionPage.checkCellTextTableContactExists(contactName, professionName);
        crmSectionPage.checkCellTextTableContactExists(contactName, "+79090554477");
        crmSectionPage.checkCellTextTableContactExists(contactName, "+79090554476");
        crmSectionPage.checkCellTextTableContactExists(contactName, "+79090554475");
        crmSectionPage.checkCellTextTableContactExists(contactName, "+79090554474");
        crmSectionPage.checkCellTextTableContactExists(contactName, "+79090554473");
        crmSectionPage.checkCellTextTableContactExists(contactName, "+79090554472");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "165facbc-8bcc-4be3-a399-3b8df3ab467c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/165facbc-8bcc-4be3-a399-3b8df3ab467c)")
    @DisplayName("Проверить редактирование")
    public void checkEditFieldsContactTest() {
        String dealName = "dealName" + RandomString.get(4);
        String leadName = "leadName" + RandomString.get(4);
        String contactName = "contactName" + RandomString.get(4);
        String newContactName = "checkEditFieldsContactTest" + RandomString.get(4);
        String skype = "skypeName" + RandomString.get(4);
        String email = RandomString.get(8) + "@" + RandomString.get(4) + ".com";
        String professionName = "professionName" + RandomString.get(4);
        String companyName = "Company" + RandomString.get(4);
        String companyId = RandomString.getUUID();

        backendCrm.createContact(contactName);
        backendCrm.createCompany(companyName, companyId);
        backendCrm.createDeal(dealName);
        backendCrm.createLead(leadName);

        crmSectionPage.open("_clients/_contacts");
        crmSectionPage.openCompany(contactName);
        settingsBlockModal.clickModalFooterButton("Редактировать");

        settingsBlockModal.setTextInputByFormRowName("Имя", newContactName);
        settingsBlockModal.setTextInputByFormRowName("Должность", professionName);
        settingsBlockModal.setTextInputByFormRowName("Рабочая почта", email);
        settingsBlockModal.setTextInputByFormRowName("Skype", skype);
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Главный", "+79090554477", 1);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Мобильный", "+79090554476", 2);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Рабочий", "+79090554475", 3);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Домашний", "+79090554474", 4);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Раб. факс", "+79090554473", 5);
        mainPage.clickOnNameButtonElmaForm("+ Добавить ещё");
        crmSectionPage.setNumberTelephoneWithPosition("Рабочий телефон", "Пейджер", "+79090554472", 6);

        settingsBlockModal.clickButtonZoomAllWithRowName("Компания");
        mainPage.clickSelectName(companyName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Сделка");
        mainPage.clickSelectName(dealName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Лиды");
        mainPage.clickSelectName(leadName);

        settingsBlockModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Контакт успешно изменен");
        mainPage.clickBack();
        crmSectionPage.openCompany(newContactName);
        settingsBlockModal.checkTextForRowValue("Имя", newContactName);
        settingsBlockModal.checkTextForRowValue("Должность", professionName);
        settingsBlockModal.checkTextForRowValue("Рабочая почта", email);
        settingsBlockModal.checkTextForRowValue("Skype", skype);
        settingsBlockModal.checkTextForRowValue("Компания", companyName);
        settingsBlockModal.checkTextForRowValue("Сделка", dealName);
        settingsBlockModal.checkTextForRowValue("Лиды", leadName);
        settingsBlockModal.checkTextForRowValue("Рабочий телефон", "+79090554477");
        settingsBlockModal.checkTextForRowValue("Рабочий телефон", "+79090554476");
        settingsBlockModal.checkTextForRowValue("Рабочий телефон", "+79090554475");
        settingsBlockModal.checkTextForRowValue("Рабочий телефон", "+79090554474");
        settingsBlockModal.checkTextForRowValue("Рабочий телефон", "+79090554473");
        settingsBlockModal.checkTextForRowValue("Рабочий телефон", "+79090554472");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "ecb412bd-1211-4065-a71a-01b70c4a4bb3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ecb412bd-1211-4065-a71a-01b70c4a4bb3)")
    @DisplayName("Открыть карточку Компании")
    public void openCompanyCardInContactTest() {
        String contactName = "openCompanyCardInContactTest" + RandomString.get(4);

        String companyName = "Company" + RandomString.get(4);
        String companyId = RandomString.getUUID();

        backendCrm.createContact(contactName);
        backendCrm.createCompany(companyName, companyId);

        crmSectionPage.open("_clients/_contacts");
        crmSectionPage.openCompany(contactName);
        settingsBlockModal.clickModalFooterButton("Редактировать");
        settingsBlockModal.clickButtonZoomAllWithRowName("Компания");
        mainPage.clickSelectName(companyName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Контакт успешно изменен");

        mainPage.clickOnNameLinkElmaForm(companyName);
        settingsBlockModal.checkTextForRowValue("Контакты", contactName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "dfaebba8-35bb-4fda-b7ae-1b72b931dbe6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/dfaebba8-35bb-4fda-b7ae-1b72b931dbe6)")
    @DisplayName("Создать задачу")
    public void createTaskInContactTest() {
        String contactName = "createTaskInContactTest" + RandomString.get(4);
        String taskContact = "taskContact" + RandomString.get(4);

        backendCrm.createContact(contactName);

        crmSectionPage.open("_clients/_contacts");
        crmSectionPage.openCompany(contactName);
        crmSectionPage.fillTaskFromContact(taskContact);
        businessProcessPage.checkSurfaceMessage("Поставлена задача");
        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess(taskContact, "Задача");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b44c507e-fca9-4425-8e36-37314b095436", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b44c507e-fca9-4425-8e36-37314b095436)")
    @DisplayName("Выполнить задачу")
    public void performTaskInContactTest() {
        String contactName = "performTaskInContactTest" + RandomString.get(4);
        String taskContact = "taskContact" + RandomString.get(4);

        backendCrm.createContact(contactName);

        crmSectionPage.open("_clients/_contacts");
        crmSectionPage.openCompany(contactName);
        crmSectionPage.fillTaskFromContact(taskContact);
        businessProcessPage.checkSurfaceMessage("Поставлена задача");
        mainPage.clickOnNameButtonElmaForm(taskContact);
        settingsBlockModal.clickModalFooterButton("Сделано");
        taskModal.confirmCompleteTask();
        crmSectionPage.openCompany(contactName);
        crmSectionPage.checkCloseTaskInContact(taskContact);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c95ce87c-d335-4f14-9760-d98cdc6b2df8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c95ce87c-d335-4f14-9760-d98cdc6b2df8)")
    @DisplayName("Отправить сообщение в ленту")
    public void sendMessageInContactTest() {
        String contactName = "performTaskInContactTest" + RandomString.get(4);
        String feedMessage = "feedMessage" + RandomString.get(4);

        backendCrm.createContact(contactName);

        crmSectionPage.open("_clients/_contacts");
        crmSectionPage.openCompany(contactName);
        crmSectionPage.sendMessageInFeed(feedMessage);
        crmSectionPage.checkMessageSent(feedMessage);
    }
}