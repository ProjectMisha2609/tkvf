package e2eTests;

import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.ExportConfigurationModal;
import pages.elmaPages.AdminSectionPage;
import pages.elmaPages.IntegrationModulesPage;
import pages.elmaPages.OrgStructurePage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("admin")})
public class AdminTests {

    @Inject
    protected CreateAppElementModal createApplicationElementModal;
    @Inject
    protected AdminSectionPage adminSectionPage;
    @Inject
    protected OrgStructurePage orgStructurePage;
    @Inject
    protected ExportConfigurationModal exportConfigurationModal;
    @Inject
    protected IntegrationModulesPage integrationModulesPage;

    @Test
    @Link(value = "bfb2966e-7295-4b1f-ab39-c4a151457851", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/bfb2966e-7295-4b1f-ab39-c4a151457851)")
    @DisplayName("Проверить переход по ссылке Компания - Организационная структура")
    public void checkLinkToOrgStructureTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickLinkOrgStructure();

        orgStructurePage.checkPageHeaderContainsText("Организационная структура");
    }

    @Test
    @Link(value = "64d436f8-4c4d-4158-8a8f-d667866e1a72", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/64d436f8-4c4d-4158-8a8f-d667866e1a72)")
    @DisplayName("Проверить переход по ссылке Компания - Группы")
    public void checkLinkToGroupsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickLinkGroups();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Группы");
    }

    @Test
    @Link(value = "a4fb4ce6-6881-4dd8-91e6-af0f09bb8c44", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/a4fb4ce6-6881-4dd8-91e6-af0f09bb8c44)")
    @DisplayName("Проверить переход по ссылке Компания - Пользователи")
    public void checkLinkToUsersTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickLinkUsers();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Пользователи");
    }

    @Test
    @Link(value = "e76687d7-d477-4471-a431-c0a0ba3b68f4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e76687d7-d477-4471-a431-c0a0ba3b68f4)")
    @DisplayName("Проверить переход по ссылке Компания - Замещения")
    public void checkLinkToSubstitutionTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickSubstitutionUsers();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Замещения");
    }

    @Test
    @Link(value = "da3f0dfa-945e-4b4e-bada-3ddc0e102f93", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/da3f0dfa-945e-4b4e-bada-3ddc0e102f93)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Настройки компании ")
    public void checkLinkToCompanySettingsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickCompanySettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Настройки компании");
    }

    @Test
    @Link(value = "f861e9b3-0f05-46cf-99a8-2d891821e158", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f861e9b3-0f05-46cf-99a8-2d891821e158)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Оповещения")
    public void checkLinkToNotificationsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickNotifications();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Оповещения");
    }

    @Test
    @Link(value = "dbbdf935-5741-43ef-9f1d-b267ea95be95", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/dbbdf935-5741-43ef-9f1d-b267ea95be95)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Токены")
    public void checkLinkToTokensTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickTokens();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Токены");
    }

    @Test
    @Link(value = "b9aa6391-7080-4ef7-9e43-977b7eba5ad4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b9aa6391-7080-4ef7-9e43-977b7eba5ad4)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Файлы")
    public void checkLinkToFilesTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickFiles();
        // на onpremise нет ссылки
        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Файлы");
    }

    @Test
    @Link(value = "74bb61b2-6eae-4bde-ad7b-a392d977c11d", type = ELMA_TMS)
    @TmsLink("https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/74bb61b2-6eae-4bde-ad7b-a392d977c11d)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Модули")
    public void checkLinkToModulesTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickModules();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Модули");
    }

    @Test
    @Link(value = "f36dcb88-1a2a-482c-87ee-52a0ddcb5d79", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f36dcb88-1a2a-482c-87ee-52a0ddcb5d79)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Настройки отправки Email")
    public void checkLinkToEmailSendSettingsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickEmailSendSettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Настройки отправки Email");
    }

    @Test
    @Link(value = "34e62410-539d-4838-9271-2b69559540ad", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/34e62410-539d-4838-9271-2b69559540ad)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Дополнительные параметры")
    public void checkLinkToExtraParamsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickExtraParams();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Дополнительные параметры");
    }

    @Test
    @Link(value = "b1ec671f-3c54-49a5-be56-031696d1f1b5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b1ec671f-3c54-49a5-be56-031696d1f1b5)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Исполнительская дисциплина")
    public void checkLinkToPerformingDisciplineTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickPerformingDiscipline();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Настройки исполнительской дисциплины");
    }

    @Test
    @Link(value = "4033947c-2b91-4a71-9875-b6c116d87fc8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4033947c-2b91-4a71-9875-b6c116d87fc8)")
    @DisplayName("Проверить переход по ссылке Настройки системы - Экспорт конфигурации")
    public void checkLinkToExportConfigurationTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickExportConfiguration();

        exportConfigurationModal.checkHeaderContainsText("Экспорт Конфигурации");
    }

    @Test
    @Link(value = "4f586544-7880-4f15-b948-e1e8d5db9337", type = ELMA_TMS)
    @TmsLink("https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4f586544-7880-4f15-b948-e1e8d5db9337)")
    @DisplayName("Проверить переход по ссылке раздела Бизнес-процессы - Бизнес-процессы")
    public void checkLinkToBusinessProcessesTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickBusinessProcesses();
        // в вебе слово "процессы" написано с английской "c", исправлять грамматику тут нельзя.
        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Бизнес-процесcы");
    }

    @Test
    @Link(value = "60f05f1f-c489-4358-8868-99d3b431e737", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/60f05f1f-c489-4358-8868-99d3b431e737)")
    @DisplayName("Проверить переход по ссылке раздела Бизнес-процессы - Монитор процессов")
    public void checkLinkToProcessesMonitorTest() {

        adminSectionPage.open("admin/main");
        adminSectionPage.clickProcessesMonitor();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Монитор процессов");
    }

    @Test
    @Link(value = "5c7caa2e-a76e-4a75-9dc6-f10795b1ac45", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5c7caa2e-a76e-4a75-9dc6-f10795b1ac45)")
    @DisplayName("Проверить переход по ссылке раздела Бизнес-процессы - Рабочий календарь")
    public void checkLinkToWorkCalendarTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickWorkCalendar();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Рабочий календарь");
    }

    @Test
    @Link(value = "8cacc7a4-0fb6-4ee6-99e7-e4e4d194ec54", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8cacc7a4-0fb6-4ee6-99e7-e4e4d194ec54)")
    @DisplayName("Проверить переход по ссылке раздела Бизнес-процессы - Шаблоны документов")
    public void checkLinkToDocumentTemplatesTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickDocumentTemplates();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Шаблоны документов");
    }

    @Test
    @Link(value = "945f7cdc-5f19-42b3-a3a4-3e3958162455", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/945f7cdc-5f19-42b3-a3a4-3e3958162455)")
    @DisplayName("Пригласить пользователя: с заполнением только обязательных полей")
    public void addNewUserWithOnlyRequiredFieldsTest() {
        String emailString = RandomString.get(10) + "@qwer.ru";

        adminSectionPage.open("admin/main");
        adminSectionPage.appToolbar().selectAppByCode("admin",  "users");
        adminSectionPage.appHeaderToolbar().clickActionButton("+ Пользователь");
        createApplicationElementModal.fillEmail(emailString);
        createApplicationElementModal.clickModalFooterButton("Выслать приглашение");

        adminSectionPage.checkUserAdded();
    }

    @Test
    @Link(value = "4e4d9cae-1031-468c-a49e-86bd20eff337", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4e4d9cae-1031-468c-a49e-86bd20eff337)")
    @DisplayName("Проверить переход по ссылке Документооборот - Настройки номенклатуры")
    public void checkLinkToNomenclatureSettingsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickNomenclatureSettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Номенклатура");
    }

    @Test
    @Link(value = "596ef365-cdbe-4d33-8c8a-8f31d2a75ac1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/596ef365-cdbe-4d33-8c8a-8f31d2a75ac1)")
    @DisplayName("Проверить переход по ссылке Почта - Настройка сервисов")
    public void checkLinkToSettingsServiceTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickServiceSettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Настройка сервисов");
    }

    @Test
    @Link(value = "c7949fee-9c0c-4e2c-813c-c7ff7aa5b995", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c7949fee-9c0c-4e2c-813c-c7ff7aa5b995)")
    @DisplayName("Проверить переход по ссылке Почта - Настройка связей")
    public void checkLinkToSettingsConnectionsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickConnectionsSettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Настройка связей");
    }

    @Test
    @Link(value = "5233026d-9f6b-4897-8ea9-4588a9fedf7e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5233026d-9f6b-4897-8ea9-4588a9fedf7e)")
    @DisplayName("Проверить переход по ссылке Линии - Линии")
    public void checkLinkToSettingsLinesTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickLinesSettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Линии");
    }

    @Test
    @Link(value = "4ca9eb8d-47db-44e9-8bb4-332811ae2439", type = ELMA_TMS)
    @TmsLink("https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4ca9eb8d-47db-44e9-8bb4-332811ae2439)")
    @DisplayName("Проверить переход по ссылки Настройки безопасности")
    public void checkLinkToSecuritySettingsTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickSecuritySettings();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Настройки безопасности");
    }

    @Test
    @Link(value = "2b8c8833-5874-49c4-a571-a94b1cdfe949", type = ELMA_TMS)
    @TmsLink("https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2b8c8833-5874-49c4-a571-a94b1cdfe949)")
    @DisplayName("Проверить переход по ссылке Монитор ошибок")
    public void checkLinkToErrorMonitorTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickErrorMonitor();

        adminSectionPage.isPageErrorMonitor();
    }

    @Test
    @Link(value = "1e0cff07-2dcf-4bcb-b5a1-3a8fc45fe651", type = ELMA_TMS)
    @TmsLink("https://team.s-elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/1e0cff07-2dcf-4bcb-b5a1-3a8fc45fe651)")
    @DisplayName("Проверить переход по ссылке Интерфейсы")
    public void checkLinkToInterfacesTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.clickInterfaces();

        adminSectionPage.appHeaderToolbar().checkHeaderContainsText("Интерфейсы");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "65dc4e02-e7ce-4a84-917a-402f41011c28", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/65dc4e02-e7ce-4a84-917a-402f41011c28)")
    @DisplayName("Выбрать алгоритм обработки входящего звонка")
    public void setIncomingCallProcessingTest() {
        adminSectionPage.open("admin/main");
        adminSectionPage.sectionToolbar()
                .toolbarSubmenu()
                .clickSubmenuButtonByHref("extensions");
        integrationModulesPage.clickIntegrationCard("Гравител");
        integrationModulesPage.setCheckboxConditionByLabel("Включить модуль", true);
        integrationModulesPage.setApplicationByRowName("Связать с приложением", "CRM", "Компании");
        integrationModulesPage.clickButtonOnConfigPage("Сохранить");
        integrationModulesPage.checkAlertWithTextFragmentExists("Настройки сохранены");
    }
}
