package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.ParameterSettingsModal;
import pages.elmaModals.TableSettingsModal;
import pages.elmaPages.AdminSectionPage;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.InterfaceDesignerPage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;

@MicronautTest
@Tags({@Tag("express"), @Tag("additional_parameters")})
public class AdditionalParameterTests {
    @Inject
    protected AdminSectionPage adminSectionPage;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected TableSettingsModal tableSettingsModal;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "5f51b2aa-24a5-40ba-a6ce-00850c8ca8b0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5f51b2aa-24a5-40ba-a6ce-00850c8ca8b0)")
    @DisplayName("Удалить параметр")
    public void deleteGlobalParameterTest() {
        String parameterName = "deleteGlobalParameterParameterName" + RandomString.get(8);

        adminSectionPage.open("admin/params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkCompanyParameterExists(parameterName);
        adminSectionPage.openCompanyParameterByName(parameterName);

        parameterSettingsModal.clickDeleteButtonAndConfirm();

        adminSectionPage.checkCompanyParameterNotExists(parameterName);
    }


    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "cd4b5743-c3b7-484a-9855-f8de7c6a2def", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cd4b5743-c3b7-484a-9855-f8de7c6a2def)")
    @DisplayName("Проверить использование параметров")
    public void checkParametersViewingTest() {
        String sectionName = "checkParametersViewingSectionName" + RandomString.get(8);
        String parameterName = "test";
        String processName = "checkParametersViewingProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createStringParameterInSection(sectionName, parameterName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithParameters.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);

        sectionPage.openTask(taskId);
        interfaceDesignerPage.checkStringParameterValue(sectionName + "." + parameterName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "71d26837-c998-4a0a-b1a7-4389c8ef75eb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/71d26837-c998-4a0a-b1a7-4389c8ef75eb)")
    @DisplayName("Проверить отображение параметров и их значений в таблице")
    public void checkParametersViewingInTableTest() {
        elmaBackend.createCompanyParametersTestData();

        adminSectionPage.open("admin/params");

        adminSectionPage.checkCompanyParameterExists("test1");
        adminSectionPage.checkCompanyParameterExists("test2");
        adminSectionPage.checkCompanyParameterExists("test3");
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "46f8037e-35ab-47c0-91f9-290dfd19ec6d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/46f8037e-35ab-47c0-91f9-290dfd19ec6d)")
    @DisplayName("Создать глобальные параметры через многоточие")
    public void addGlobalParameterByEllipsisTest() {
        String parameterName = "addGlobalParameterByEllipsisParameterName" + RandomString.get(8);

        adminSectionPage.open("admin");
        adminSectionPage.sectionToolbar().toolbarSubmenu()
                .clickSubmenuButtonByHref("params");
        adminSectionPage.createCompanyParameterByEllipsisButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkCompanyParameterExists(parameterName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "076a9ada-93b5-4e28-8780-41a1e9c89288", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/076a9ada-93b5-4e28-8780-41a1e9c89288)")
    @DisplayName("Создать параметр раздела через многоточие")
    public void addSectionParameterByEllipsisTest() {
        String parameterName = "addSectionParameterByEllipsisParameterName" + RandomString.get(8);
        String sectionName = "addSectionParameterByEllipsisSectionName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        // при переходе напрямую в параметры может не отображаться раздел.
        adminSectionPage.open(sectionName);
        adminSectionPage.appToolbar().selectSettingsSections("Дополнительные параметры");
        adminSectionPage.createSectionParameterByEllipsisButton(sectionName);

        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkSectionParameterExists(parameterName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3870e103-8d97-43d0-bd66-e9b260b94c99", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3870e103-8d97-43d0-bd66-e9b260b94c99)")
    @DisplayName("Изменить значение параметра раздела в таблице параметров")
    public void changeSectionParameterTest() {
        String parameterName = "changeSectionParameterParameterName" + RandomString.get(8);
        String parameterValue = "changeSectionParameterParameterValue" + RandomString.get(8);
        String sectionName = "changeSectionParameterSectionName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);

        adminSectionPage.open(sectionName);
        adminSectionPage.appToolbar().selectSettingsSections("Дополнительные параметры");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkSectionParameterExists(parameterName);
        adminSectionPage.editSectionParameterValueByName(sectionName, parameterName, parameterValue);

        adminSectionPage.checkSectionParameterValueExists(sectionName, parameterValue);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b3d0d13f-9a66-4b45-9c00-13bc5ff02971", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b3d0d13f-9a66-4b45-9c00-13bc5ff02971)")
    @DisplayName("Редактировать параметр")
    public void editGlobalParameterTest() {
        String parameterName = "editGlobalParameterParameterName" + RandomString.get(8);
        String newParameterName = "editGlobalParameterNewParameterName" + RandomString.get(8);
        String parameterHint = "editGlobalParameterNewParameterHint" + RandomString.get(8);

        adminSectionPage.open("admin/params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkCompanyParameterExists(parameterName);
        adminSectionPage.openCompanyParameterByName(parameterName);

        parameterSettingsModal.clearParameterName();
        parameterSettingsModal.fillParameterName(newParameterName);
        parameterSettingsModal.fillParameterHint(parameterHint);
        parameterSettingsModal.dialogWindowPressButton("Сохранить");

        adminSectionPage.checkCompanyParameterExists(newParameterName);
        adminSectionPage.checkCompanyParameterTitle(newParameterName, parameterHint);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "4b159642-05a6-4e45-bf5e-fd6fc200ad5c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4b159642-05a6-4e45-bf5e-fd6fc200ad5c)")
    @DisplayName("Создать параметр раздела")
    public void addSectionParameterTest() {
        String parameterName = "addSectionParameterParameterName" + RandomString.get(8);
        String sectionName = "addSectionParameterSectionName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);

        adminSectionPage.open(sectionName + "/__params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkSectionParameterExists(parameterName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "47622167-c3b1-48e7-9f08-06fb5b5c4bf4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/47622167-c3b1-48e7-9f08-06fb5b5c4bf4)")
    @DisplayName("Создать глобальный параметр типа Приложение")
    public void addGlobalApplicationParameterTest() {
        String parameterName = "addGlobalApplicationParameterParameterName" + RandomString.get(8);
        String sectionName = "addGlobalApplicationParameterSectionName" + RandomString.get(8);
        String applicationName = "addGlobalApplicationParameterApplicationName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);

        adminSectionPage.open("admin/params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByAriaLabel("Приложение");

        parameterSettingsModal.selectApplicationParameter(sectionName, applicationName);
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkCompanyParameterExists(parameterName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "95f46e84-76a9-4006-8f0d-ccb25d20e30a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/95f46e84-76a9-4006-8f0d-ccb25d20e30a)")
    @DisplayName("Создать глобальный параметр типа Таблица")
    public void addGlobalTableTypeParameterTest() {
        String parameterName = "addGlobalTableTypeParameterParameterName" + RandomString.get(8);
        String firstColumnName = "addGlobalTableTypeParameterFirstColumnName" + RandomString.get(8);
        String secondColumnName = "addGlobalTableTypeParameterSecondColumnName" + RandomString.get(8);

        adminSectionPage.open("admin/params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        // Проблема наложения активных модальных окон, подробности в классе ParameterSettingsModal
        parameterSettingsModal.iterativeMethods().fillParameterName(parameterName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Таблица");
        parameterSettingsModal.clickTableParameters();

        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(firstColumnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        tableSettingsModal.plusDataColumn();
        parameterSettingsModal.iterativeMethods().fillParameterName(secondColumnName);
        parameterSettingsModal.iterativeMethods().selectParameterType("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        parameterSettingsModal.dialogWindowPressButton("Сохранить");
        parameterSettingsModal.dialogWindowPressButton("Создать");
        adminSectionPage.checkCompanyParameterExists(parameterName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "0fe35816-9f45-4e3e-82a6-4b62e4c9b628", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0fe35816-9f45-4e3e-82a6-4b62e4c9b628)")
    @DisplayName("Создать глобальный параметр простого типа с вводом значения")
    public void addGlobalSimpleTypeParameterWithValueTest() {
        String parameterName = "addGlobalSimpleTypeParameterWithValueParameterName" + RandomString.get(8);
        String parameterValue = "addGlobalSimpleTypeParameterWithValueParameterValue" + RandomString.get(8);

        adminSectionPage.open("admin/params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.fillParameterValue(parameterValue);
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkCompanyParameterExists(parameterName);
        adminSectionPage.checkCompanyParameterValueExists(parameterValue);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "6954c95e-d0de-4772-ae51-9480d74a6817", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6954c95e-d0de-4772-ae51-9480d74a6817)")
    @DisplayName("Создать глобальный параметр простого типа")
    public void addGlobalSimpleTypeParameterTest() {
        String parameterName = "addGlobalSimpleTypeParameterParameterName" + RandomString.get(8);

        adminSectionPage.open("admin/params");
        adminSectionPage.clickCreateParameterButton();

        parameterSettingsModal.checkSelectedSectionIsCompanyPatterns();
        parameterSettingsModal.fillParameterName(parameterName);
        parameterSettingsModal.selectParameterTypeByText("Строка");
        parameterSettingsModal.dialogWindowPressButton("Создать");

        adminSectionPage.checkCompanyParameterExists(parameterName);
    }
}
