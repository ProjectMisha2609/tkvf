package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendCrm;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.ChangeElementBlockModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.*;

import java.time.LocalDate;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("process_monitor")})
public class ProjectsTests {
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected ProjectPage projectPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CrmSectionPage crmSectionPage;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c69a3739-472f-4e6f-a798-22cdda6bba6f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c69a3739-472f-4e6f-a798-22cdda6bba6f)")
    @DisplayName("Создание проекта с добавлением шаблона проекта")
    public void createProjectWithAddTemplateTest() {
        String projectName = "projectName" + RandomString.get(4);
        String templateName = "templateName" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);

        sectionPage.open("_project_management/_templates");
        sectionPage.appHeaderToolbar().clickActionButton("Проект");
        sectionPage.setTextInputByFormRowName("Название", templateName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Руководитель проекта");
        mainPage.clickSelectUser(adminLogin);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        crmSectionPage.openCompany(templateName);
        // crmSectionPage.waitGreySpinnerDisappear();
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonAddTaskInProjectPlan();
        sectionPage.setTextInputByFormRowName("Название", taskName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        projectPage.clickButtonOfMainPanel("Сохранить");
        projectPage.clickButtonOfMainPanel("Опубликовать");
        sectionPage.checkAlertWithTextFragmentExists("План опубликован");
        sectionPage.open("_project_management/_projects_list_page");
        sectionPage.appHeaderToolbar().clickActionButton("Проект");
        sectionPage.setTextInputByFormRowName("Название", projectName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Шаблонный проект");
        mainPage.clickSelectName(templateName);
        settingsBlockModal.clickModalFooterButton("Сохранить");

        crmSectionPage.openCompany(projectName);
        projectPage.checkTextOnDiagramGantExists(taskName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f347a3b5-3bf8-470d-86c8-8a8dc4bc2c45", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f347a3b5-3bf8-470d-86c8-8a8dc4bc2c45)")
    @DisplayName("Проверить импорт плана проекта")
    public void checkImportPlanOfProjectTest() {
        String projectName = "checkImportPlanOfProject" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);

        String projectID = backendCrm.createProject(projectName);
        sectionPage.open("_project_management/_project/" + projectID);
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonAddTaskInProjectPlan();
        sectionPage.setTextInputByFormRowName("Название", taskName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        projectPage.clickButtonOfMainPanel("Сохранить");
        projectPage.clickButtonOfMainPanel("Опубликовать");
        projectPage.clickButtonOfMainPanel("download");
        projectPage.uploadingMPP("/testData/ProjectFiles/exportGant.mpp");
        settingsBlockModal.clickButtonZoomAllWithRowName("Установить исполнителя элементам без исполнителя");
        mainPage.clickSelectUser(adminLogin);
        projectPage.setCheckboxConditionByLabel("Импортировать завершенные задачи", true);
        projectPage.setCheckboxConditionByLabel("Объединить планы", true);
        projectPage.clickButtonOnModalWindowByName("Импорт");
        projectPage.waitGreySpinnerDisappear();
        projectPage.clickButtonOnModalWindowByName("Импорт");
        projectPage.checkTextOnDiagramGantExists(taskName);
        projectPage.checkTextOnDiagramGantExists("Задача 1");
        projectPage.checkTextOnDiagramGantExists("Задачка 2");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "3bc0726f-98a6-4ea2-bccd-8619c1a2f08a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3bc0726f-98a6-4ea2-bccd-8619c1a2f08a)")
    @DisplayName("Проверить экспорт плана проекта")
    public void checkExportPlanOfProjectTest() {
        String projectName = "checkExportPlanOfProject" + RandomString.get(4);

        String projectID = backendCrm.createProject(projectName);
        sectionPage.open("_project_management/_project/" + projectID);
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonZoomAllVersionPlan();
        mainPage.clickSelectName("Версия: 1");
        projectPage.clickButtonOfMainPanel("upload");
        settingsBlockModal.selectPopoverOptionByName(".mpp");

        mainPage.checkFileExistsInDownloadsFolderByPartOfName(projectName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "ecf6fb7b-aa25-4c22-878f-211059c1e3c4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ecf6fb7b-aa25-4c22-878f-211059c1e3c4)")
    @DisplayName("Проверить редактирование проектной задачи через диаграмму Ганта")
    public void checkTaskInDiagramGantTest() {
        String projectName = "checkTaskInDiagramGant" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);
        String newTaskName = "newTaskName" + RandomString.get(4);
        LocalDate localDate = LocalDate.now().minusDays(1);
        int countDays = 4;

        String projectID = backendCrm.createProject(projectName);
        sectionPage.open("_project_management/_project/" + projectID);
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonAddTaskInProjectPlan();
        sectionPage.setTextInputByFormRowName("Название", taskName);
        sectionPage.setTextInputByFormRowName("Длительность (в днях)", String.valueOf(countDays));
        sectionPage.setTextInputByFormRowName("Дата начала", localDate.format(FORMATTER_DD_MM_YYYY));
        sectionPage.checkInputFormRowValue("Дата окончания", localDate.plusDays(countDays).format(FORMATTER_DD_MM_YYYY));

        settingsBlockModal.clickModalFooterButton("Сохранить");
        projectPage.editTaskInDiagramGant(taskName, taskName, newTaskName);
        projectPage.editTaskInDiagramGant(newTaskName, localDate.format(FORMATTER_DD_MM_YYYY), localDate.minusDays(1).format(FORMATTER_DD_MM_YYYY));

        projectPage.clickButtonOfMainPanel("Сохранить");
        projectPage.clickButtonOfMainPanel("Опубликовать");
        sectionPage.checkAlertWithTextFragmentExists("План опубликован");
        projectPage.clickButtonOfMainPanel("system_close");

        projectPage.checkTextOnDiagramGantExists(newTaskName);
        projectPage.checkTextOnDiagramGantExists(localDate.minusDays(1).format(FORMATTER_DD_MM_YYYY));
        projectPage.checkTextOnDiagramGantExists(localDate.plusDays(countDays - 1).format(FORMATTER_DD_MM_YYYY));
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "717617a5-6979-48e1-ad67-e354ba604916", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/717617a5-6979-48e1-ad67-e354ba604916)")
    @DisplayName("Проверить создание проектной задачи")
    public void checkCreateTaskForProjectTest() {
        String projectName = "checkCreateTaskForProject" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);
        String text = "text" + RandomString.get(4);
        LocalDate localDate = LocalDate.now().minusDays(1);
        int countDays = 4;

        String projectID = backendCrm.createProject(projectName);
        sectionPage.open("_project_management/_project/" + projectID);
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonAddTaskInProjectPlan();
        sectionPage.setTextInputByFormRowName("Название", taskName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(userLogin);
        sectionPage.setTextBlockByFormRowName("Описание", text);
        sectionPage.setTextInputByFormRowName("Длительность (в днях)", String.valueOf(countDays));
        sectionPage.setTextInputByFormRowName("Дата начала", localDate.format(FORMATTER_DD_MM_YYYY));
        sectionPage.checkInputFormRowValue("Дата окончания", localDate.plusDays(countDays).format(FORMATTER_DD_MM_YYYY));

        settingsBlockModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Элемент плана проекта успешно создан");
        projectPage.clickButtonOfMainPanel("Сохранить");
        projectPage.clickButtonOfMainPanel("Опубликовать");
        sectionPage.checkAlertWithTextFragmentExists("План опубликован");
        projectPage.clickButtonOfMainPanel("system_close");

        projectPage.openContextByTask(taskName);
        settingsBlockModal.selectPopoverOptionByName("Открыть");

        sectionPage.checkTextForRowValue("Ответственный", backendCrm.getUserSurnameAndNameByEmail(userLogin));
        sectionPage.checkTextForRowValue("Описание", text);
        projectPage.checkDateTask("Дата начала", localDate);
        projectPage.checkDateTask("Дата окончания", localDate.plusDays(countDays));
        sectionPage.checkTextForRowValue("Длительность (в днях)", String.valueOf(countDays));  //TODO Баг. количество дней увеличивается на 1 день после сохранения
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "6072d670-0d2b-49b0-8d6d-2210d4fb54cb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6072d670-0d2b-49b0-8d6d-2210d4fb54cb)")
    @DisplayName("Проверить создание проектной задачи с типом Процесс")
    public void checkCreateProcessTaskForProjectTest() {
        String projectName = "checkCreateProcessTaskForProject" + RandomString.get(4);
        String processName = "checkCreateProcessTaskForProjectProcessName" + RandomString.get(8);
        String taskName = "taskName" + RandomString.get(4);
        String variableName = "variableName" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.REF_ITEM, true, false))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String projectID = backendCrm.createProject(projectName);

        sectionPage.open("_project_management/_project/" + projectID);
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonAddTaskInProjectPlan();
        sectionPage.setTextInputByFormRowName("Название", taskName);
        projectPage.selectDropDownItemByFormRowName("Тип", "Процесс");
        projectPage.clickButtonOnFormRow("Бизнес-процесс", "Выберите процесс");
        projectPage.selectFoldedTreeNodeElementByName("Процессы компании", processName);
        settingsBlockModal.clickButtonOnModalWindowByName("Продолжить");
        projectPage.clickButtonOnFormRow("", "Настроить входные параметры");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Поле");

        changeElementBlockModal.setFieldContextBPBinding("Инициатор");
        changeElementBlockModal.setFieldContextBPBinding("Руководитель проекта");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        settingsBlockModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Элемент плана проекта успешно создан");

        projectPage.clickButtonOfMainPanel("Сохранить");
        projectPage.clickButtonOfMainPanel("Опубликовать");
        sectionPage.checkAlertWithTextFragmentExists("План опубликован");
        projectPage.clickButtonOfMainPanel("system_close");

        projectPage.openContextByTask(taskName);
        settingsBlockModal.selectPopoverOptionByName("Открыть");
        mainPage.clickButtonByNameAndFormRowName("Связанный процесс", processName);
        settingsBlockModal.clickButtonOnModalWindowByName("Да");
        businessProcessPage.checkSurfaceMessage("Поставлена задача");
        sectionPage.open("/tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7b67f82d-ec1b-49c1-8a62-01ce33be7526", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7b67f82d-ec1b-49c1-8a62-01ce33be7526)")
    @DisplayName("Проверить создание проектной задачи с типом контрольная точка")
    public void checkControlPointForProjectTest() {
        String projectName = "checkControlPointForProject" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);

        String projectID = backendCrm.createProject(projectName);

        sectionPage.open("_project_management/_project/" + projectID);
        projectPage.clickButtonNameOnBlockOfProject("Диаграмма Ганта", "Редактировать");
        projectPage.clickButtonAddTaskInProjectPlan();
        sectionPage.setTextInputByFormRowName("Название", taskName);
        projectPage.selectDropDownItemByFormRowName("Тип", "Контрольная точка");
        settingsBlockModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Элемент плана проекта успешно создан");

        projectPage.checkColorMileStone(148, 85, 211); //violet

        projectPage.clickButtonOfMainPanel("Сохранить");
        projectPage.clickButtonOfMainPanel("Опубликовать");
        sectionPage.checkAlertWithTextFragmentExists("План опубликован");
        projectPage.clickButtonOfMainPanel("system_close");

        projectPage.openContextByTask(taskName);
        settingsBlockModal.selectPopoverOptionByName("Выполнить");
        settingsBlockModal.clickButtonOnModalWindowByName("Да");

        projectPage.checkColorMileStone(86, 180, 97); //green
    }
}
