package e2eTests;

import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.AddCreateEventModal;
import pages.elmaPages.SectionPage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("calendar")})
public class CalendarTests {
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected AddCreateEventModal addCreateEventModal;

    @Test
    @Link(value = "495345ed-10b1-4f0e-9ae7-682596e3c425", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/495345ed-10b1-4f0e-9ae7-682596e3c425)")
    @DisplayName("Создать Событие")
    public void createEventTest() {
        String sectionName = "schedule";
        String eventName = RandomString.get(16);

        sectionPage.open(sectionName);
        sectionPage.appHeaderToolbar().clickActionButton("Событие");
        addCreateEventModal.isErrorValidationExists();
        addCreateEventModal.fillName(eventName);
        addCreateEventModal.chooseDate("Дата начала");
        addCreateEventModal.chooseDate("Дата окончания");
        addCreateEventModal.clickModalFooterButton("Сохранить");
        sectionPage.clickOnEvent(eventName);

        sectionPage.checkElementNameExists(eventName);
    }
}
