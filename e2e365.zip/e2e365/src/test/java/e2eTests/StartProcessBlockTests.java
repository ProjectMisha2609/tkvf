package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("start_process_block")})
public class StartProcessBlockTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected ContractPage contractPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e1214bfe-3f2e-4dbe-8cdf-218ddadaf564", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e1214bfe-3f2e-4dbe-8cdf-218ddadaf564)")
    @DisplayName("Выбрать поле для связи")
    public void checkFieldForBindingTest() {
        String processName = "checkFieldForBindingPB" + RandomString.get(4);
        String sectionName = "checkFieldForBindingSectionName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/MainProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), appName.toLowerCase()))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Запускпроцесса 1");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Запуск процесса 1", "Выберите переменную", appName);
        nomenclatureModal.checkChooseFieldLinkedWithElement("Связать с полем", appName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "dcf695dc-56b6-4030-854b-33cd6b0088e0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/dcf695dc-56b6-4030-854b-33cd6b0088e0)")
    @DisplayName("Выбрать процесс для запуска")
    public void chooseProcessForStartingTest() {
        String processMainName = "chooseProcessForStarting" + RandomString.get(4);
        String processChildName = "processChild" + RandomString.get(4);
        String sectionName = "chooseProcessForStartingSectionName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processMainName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/MainProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String processChildId = backendBusinessProcess.createBusinessProcess(sectionName, processChildName);
        String lockHashChild = backendBusinessProcess.lock(processChildId);
        backendBusinessProcess.saveChanges(processChildId, lockHashChild,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processChildId, lockHashChild);

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Запускпроцесса 1");
        parameterSettingsModal.selectProcessParameter(sectionName, processChildName);
        nomenclatureModal.checkChooseFieldLinkedWithElement("Процесс", processChildName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7db86a9c-0d71-4a5d-b4e3-bb0725756f0b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7db86a9c-0d71-4a5d-b4e3-bb0725756f0b)")
    @DisplayName("Вынести операцию Запуск процесса на схему бизнес-процесса")
    public void addStartProcessBlockOnSchemeTest() {
        String processName = "addStartProcessBlock" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.dragAndDropScriptBlockOnScheme("Запуск процесса");
        businessProcessPage.clickSave();

        businessProcessPage.checkElementByName("Запускпроцесса");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "34febba6-61df-4767-aa00-daca9e4c7b19", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/34febba6-61df-4767-aa00-daca9e4c7b19)")
    @DisplayName("Проверить работу настройки \\Отображается при выполнении условия\\")
    public void checkWorkSettingTest() {
        String processName = "checkWorkSetting" + RandomString.get(4);
        String sectionName = "checkWorkSettingSectionName" + RandomString.get(4);
        String variable1 = "first" + RandomString.get(4);
        String variable2 = "second" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTwoTasks.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variable1, ContextType.STRING, false))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variable2, ContextType.STRING, false))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.openSettingItemContext(variable2);
        nomenclatureModal.setTextInputByFormRowName("По умолчанию", variable2);
        createContextModal.setCheckboxConditionByFormRowAndLabel("Отображается при выполнении условия", "", true);
        settingsBlockModal.clickButtonOnModalWindowByName("Настроить условия");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Условие");
        changeElementBlockModal.setDisplayConditionField(variable1);
        changeElementBlockModal.setDisplayConditionFieldManually(variable1, "Ввести значение");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variable1);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(variable1, false);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 2");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variable2);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(variable2, true);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.clickNextStageOrExit();
        contractPage.setParameterSingleInput(variable1, variable1);
        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkAppElementExistsOnForm(variable2);
        sectionPage.clickNextStageOrExit();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.clickNextStageOrExit();
        contractPage.setParameterSingleInput(variable1, variable2);
        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkExistsWidgetOnToolBar("Задачи");
        interfaceDesignerPage.checkAppElementNotExistsOnForm(variable2);
        sectionPage.clickNextStageOrExit();
    }
}
