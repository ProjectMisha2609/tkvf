package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.time.LocalDate;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("setting_task_block")})
public class SettingTaskBlockTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CreateTaskModal createTaskModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected MessagePage messagePage;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "41928acf-6dea-4b78-ae45-67bff3688e5f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/41928acf-6dea-4b78-ae45-67bff3688e5f)")
    @DisplayName("Изменить название операции Задача")
    public void changeNameTaskBlockPBTest() {
        String processName = "changeNameTaskBlockPB" + RandomString.get(4);
        String sectionName = "changeNameTaskBlockPBSectionName" + RandomString.get(4);
        String newNameTask = "newName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setTextInputByFormRowName("Название", newNameTask);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(newNameTask, processName);
        interfaceDesignerPage.checkTaskNameVisible(newNameTask);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2ac397d0-9882-4e4a-b854-f4a0e5f681a9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2ac397d0-9882-4e4a-b854-f4a0e5f681a9)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи с типом - контекстная переменная с вычитанием времени")
    public void checkDeadlineTaskWithMinusTimePBTest() {
        String processName = "checkDeadlineTaskWithMinusTimePB" + RandomString.get(4);
        String sectionName = "checkDeadlineTaskWithMinusTimePBSectionName" + RandomString.get(4);
        String variableTimerName = "variableTime" + RandomString.get(4);
        LocalDate date = LocalDate.now().plusDays(1);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Время выполнения", "Ограничивать срок выполнения задачи", true);
        settingsBlockModal.clickRadioButtonByLabel("Переменная");
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Срок выполнения", "", variableTimerName);
        settingsBlockModal.clickRadioButtonByLabel("Вычесть");
        settingsBlockModal.setDaysHoursMinutes(0, 1, 0);
        settingsBlockModal.setCheckboxConditionByLabel("С учётом рабочего календаря", false);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "1:00");
        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickBack();

        sectionPage.checkDateFinishTask(processName, date);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5a588f45-7e07-4c33-b19c-5b424129df72", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5a588f45-7e07-4c33-b19c-5b424129df72)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи с типом - контекстная переменная с добавлением времени")
    public void checkDeadlineTaskWithPlusTimePBTest() {
        String processName = "checkDeadlineTaskWithPlusTimePB" + RandomString.get(4);
        String sectionName = "checkDeadlineTaskWithMinusPlusPBSectionName" + RandomString.get(4);
        String variableTimerName = "variableTime" + RandomString.get(4);
        LocalDate date = LocalDate.now();

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Время выполнения", "Ограничивать срок выполнения задачи", true);
        settingsBlockModal.clickRadioButtonByLabel("Переменная");
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Срок выполнения", "", variableTimerName);
        settingsBlockModal.clickRadioButtonByLabel("Добавить");
        settingsBlockModal.setDaysHoursMinutes(0, 1, 0);
        settingsBlockModal.setCheckboxConditionByLabel("С учётом рабочего календаря", false);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "23:00");
        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.clickBack();

        sectionPage.checkDateFinishTask(processName, date.plusDays(1));
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "34ef8186-ebd8-4003-bc97-6b15e233ecba", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/34ef8186-ebd8-4003-bc97-6b15e233ecba)")
    @DisplayName("Разрешить переназначить задачу на другого пользователя")
    public void allowReassigningTaskToAnotherUserPBTest() {
        String processName = "allowReassigningTaskToAnotherUserPB" + RandomString.get(4);
        String sectionName = "allowReassigningTaskToAnotherUserPBSectionName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Переназначение", "Разрешить переназначать задачу на другого исполнителя", true);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        sectionPage.TaskPageHeaderMenu().actionsTask("Переназначить");
        parameterSettingsModal.setTextBlockByFormRowName("Комментарий", "text");
        sectionPage.clickLoupeButtonByFormRowName("");
        mainPage.clickSelectUser(userLogin);
        createTaskModal.clickConfirmDone();
        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("/tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "4fda32ad-2de0-4bbb-b9be-600cba9dc81a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4fda32ad-2de0-4bbb-b9be-600cba9dc81a)")
    @DisplayName("Отправить сообщение в ленту о просрочке задачи пользователю из орг структуры")
    public void sendMessageAboutDelayTaskFromOrgStrTest() {
        String processName = "sendMessageAboutDelayTaskFromOrgStr" + RandomString.get(4);
        String sectionName = "sendMessageAboutDelayTaskFromOrgStrSectionName" + RandomString.get(4);
        String variableTimerName = "variableTime" + RandomString.get(4);
        String newNameTask = "newName" + RandomString.get(4);
        LocalDate date = LocalDate.now().minusDays(1);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setTextInputByFormRowName("Название", newNameTask);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Время выполнения", "Ограничивать срок выполнения задачи", true);
        settingsBlockModal.clickRadioButtonByLabel("Переменная");
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Срок выполнения", "", variableTimerName);
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Оповещение", "Отправить сообщение в ленту указанным пользователям", true);
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        settingsBlockModal.clickRadioButton("Элемент оргструктуры");
        parameterSettingsModal.clickAndSelectBoxItem(" ", "Генеральный директор");
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "23:00");
        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkTaskNameVisible(newNameTask);
        sectionPage.clickBack();

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage(newNameTask + " просрочена");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "6f666638-69db-4f8c-a89f-ed367cb3e8b1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6f666638-69db-4f8c-a89f-ed367cb3e8b1)")
    @DisplayName("Отправить сообщение в ленту о просрочке задачи пользователям из контекста")
    public void sendMessageAboutDelayTaskFromContextTest() {
        String processName = "sendMessageAboutDelayTaskFromContext" + RandomString.get(4);
        String sectionName = "sendMessageAboutDelayTaskFromContextSectionName" + RandomString.get(4);
        String variableTimerName = "variableTime" + RandomString.get(4);
        String variableUserName = "variableUser" + RandomString.get(4);
        String newNameTask = "newName" + RandomString.get(4);
        LocalDate date = LocalDate.now().minusDays(1);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableUserName, ContextType.SYS_USER, true, false))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .addContextOnDefaultStartForm(variableUserName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setTextInputByFormRowName("Название", newNameTask);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Время выполнения", "Ограничивать срок выполнения задачи", true);
        settingsBlockModal.clickRadioButtonByLabel("Переменная");
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Срок выполнения", "", variableTimerName);
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Оповещение", "Отправить сообщение в ленту указанным пользователям", true);
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        settingsBlockModal.clickRadioButton("Контекстная переменная");
        parameterSettingsModal.clickAndSelectDropDownItem("Выберите переменную", variableUserName);
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "23:00");
        settingsBlockModal.clickButtonZoomAllWithRowName(variableUserName);
        mainPage.clickSelectUser(adminLogin);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableUserName);
        mainPage.clickSelectUser(userLogin);
        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkTaskNameVisible(newNameTask);
        sectionPage.clickBack();

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage(newNameTask + " просрочена");
        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage(newNameTask + " просрочена");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e1626f7c-fc71-49b5-b45e-4ea0a4166fba", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e1626f7c-fc71-49b5-b45e-4ea0a4166fba)")
    @DisplayName("Оповещать исполнителя о постановке задачи")
    public void doNotifyExecutorTaskBlockPBTest() {
        String processName = "doNotifyExecutorTaskBlockPB" + RandomString.get(4);
        String sectionName = "doNotifyExecutorTaskBlockPBSectionName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Оповещение", "Оповещать исполнителя о постановке задачи", true);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.selectTab("Настройки");
        businessProcessPage.selectSettingsTab("Название");
        businessProcessPage.setNameTemplate(processName + " {$__createdAt}");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        sectionPage.clickNextStageOrExit();

        messagePage.open("messages/feed");
        messagePage.waitGreySpinnerDisappear();
        messagePage.checkExistsMessage(processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "ad4fb463-cfbe-437e-bba9-939c98a67ce5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ad4fb463-cfbe-437e-bba9-939c98a67ce5)")
    @DisplayName("Не оповещать исполнителя о постановке задачи")
    public void doNotNotifyExecutorTaskBlockPBTest() {
        String processName = "doNotNotifyExecutorTaskBlockPB" + RandomString.get(4);
        String sectionName = "doNotNotifyExecutorTaskBlockPBSectionName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Оповещение", "Оповещать исполнителя о постановке задачи", false);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.selectTab("Настройки");
        businessProcessPage.selectSettingsTab("Название");
        businessProcessPage.setNameTemplate(processName + " {$__createdAt}");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);
        sectionPage.clickNextStageOrExit();

        messagePage.open("messages/feed");
        messagePage.waitGreySpinnerDisappear();
        messagePage.checkNotExistsMessage(processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "ae9cc917-90ba-4164-94c4-2443dc0508dc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ae9cc917-90ba-4164-94c4-2443dc0508dc)")
    @DisplayName("Запретить переназначать задачу на другого исполнителя")
    public void forbidReassignTaskBlockPBTest() {
        String processName = "forbidReassignTaskBlockPB" + RandomString.get(4);
        String sectionName = "forbidReassignTaskBlockPBSectionName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Переназначение", "Разрешить переназначать задачу на другого исполнителя", false);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Задача 1", processName);

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
        sectionPage.TaskPageHeaderMenu().checkNotExistsActionButton("Переназначить");
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b6557b8c-0d0d-412f-b1c0-bc76f80a16a1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b6557b8c-0d0d-412f-b1c0-bc76f80a16a1)")
    @DisplayName("Отправить сообщение в ленту о просрочке задачи текущему пользователю")
    public void sendMessageAboutDelayTaskFromCurrentUserTest() {
        String processName = "sendMessageAboutDelayTaskFromCurrentUser" + RandomString.get(4);
        String sectionName = "sendMessageAboutDelayTaskFromCurrentUserSectionName" + RandomString.get(4);
        String variableTimerName = "variableTime" + RandomString.get(4);
        String newNameTask = "newName" + RandomString.get(4);
        LocalDate date = LocalDate.now().minusDays(1);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setTextInputByFormRowName("Название", newNameTask);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Время выполнения", "Ограничивать срок выполнения задачи", true);
        settingsBlockModal.clickRadioButtonByLabel("Переменная");
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Срок выполнения", "", variableTimerName);
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Оповещение", "Отправить сообщение в ленту указанным пользователям", true);
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        settingsBlockModal.clickRadioButton("Группа");
        parameterSettingsModal.clickAndSelectDropDownItem("Выберите группу", "Все пользователи");
        settingsBlockModal.dialogWindowPressButton("Выбрать");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "23:00");

        sectionPage.clickNextStageOrExit();
        interfaceDesignerPage.checkTaskNameVisible(newNameTask);
        sectionPage.clickBack();

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage(newNameTask + " просрочена");
        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();

        messagePage.open("messages/feed");
        messagePage.checkExistsMessage(newNameTask + " просрочена");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "75edcd0d-6b72-49a2-a99d-6817af972322", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/75edcd0d-6b72-49a2-a99d-6817af972322)")
    @DisplayName("Проверить прерывание выполнения задачи при просрочке с переходом к следующему шагу")
    public void checkAbortingDoingTaskTest() {
        String processName = "checkAbortingDoingTask" + RandomString.get(4);
        String sectionName = "checkAbortingDoingTaskSectionName" + RandomString.get(4);
        String variableTimerName = "variableTime" + RandomString.get(4);
        LocalDate date = LocalDate.now();

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithBranchTasks.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Время выполнения", "Ограничивать срок выполнения задачи", true);
        settingsBlockModal.clickRadioButtonByLabel("Переменная");
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Срок выполнения", "", variableTimerName);
        settingsBlockModal.setCheckboxConditionByFormRowAndLabel("Прервать", "По истечению срока перейти к следующему шагу", true);
        nomenclatureModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Задача 1", "Прервать", "", "-> Задача 2");
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.inputDateInModalWindow(date.minusDays(2).format(FORMATTER_DD_MM_YYYY), "23:00");
        sectionPage.clickNextStageOrExit();
        sectionPage.open("/tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 2", processName);
    }
}