package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("start_event")})
public class StartEventTest {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected SelectWidgetsModal selectWidgetsModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected CreateBpModal createBpModal;


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "cdbbf3b7-3c0c-4498-b730-06425bec5c49", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cdbbf3b7-3c0c-4498-b730-06425bec5c49)")
    @DisplayName("Проверить, что стартовое событие сразу добавлено в зоне ответственности после создания процесса")
    public void checkAddStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        businessProcessPage.open("admin/process");
        mainPage.clickButtonOnAppContent("Процесс");
        createBpModal.dialogWindowEnterName(processName);
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.checkElementByName("Инициатор");
        businessProcessPage.clickStartBlock();
        createBpModal.checkModalWindowWithNameVisible("Стартовое событие");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "01093385-f53e-43fe-8429-ed902b8379f1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/01093385-f53e-43fe-8429-ed902b8379f1)")
    @DisplayName("Проверить, что стартовое событие нельзя удалить")
    public void checkIconRemoveExistsOnStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);
        businessProcessPage.chooseStartBlock();
        businessProcessPage.checkIconRemoveNotExists();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e5e6c72c-4d30-4502-b6d1-dbdfd9c53a87", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e5e6c72c-4d30-4502-b6d1-dbdfd9c53a87)")
    @DisplayName("Проверить отображение краткой инструкции, отображаемой в стартовом окне")
    public void checkViewInstructionStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String instructionText = "текст инструкции";
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickStartBlock();
        businessProcessPage.setTextInstruction(instructionText);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);

        createBpModal.checkExistWidgetOnBodyModal(instructionText);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5076135b-8f9f-48f0-a45d-ae67f842010d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5076135b-8f9f-48f0-a45d-ae67f842010d)")
    @DisplayName("Проверить отображение уведомления о запуске процесса")
    public void checkNoticeStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String text = "текст запуска " + processName;
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickStartBlock();
        parameterSettingsModal.fillFieldSetting("Уведомление о запуске процесса", text);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.processStartConfirmation();

        taskModal.confirmInfoStartTask(text);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "76e9e18e-c364-4570-8909-2fb0ea016bca", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/76e9e18e-c364-4570-8909-2fb0ea016bca)")
    @DisplayName("Добавить на форму стартового события контекст простого типа")
    public void addContextStringVariableOnStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String variableName = "stringContext" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextString();
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);

        businessProcessPage.checkContextStringOnStartEventExists(variableName);
        sectionPage.processStartConfirmation();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b6fbf1ca-2ae8-4188-9239-e4d9a2ada24e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b6fbf1ca-2ae8-4188-9239-e4d9a2ada24e)")
    @DisplayName("Добавить на форму стартового события контекст типа приложение")
    public void addContextAppVariableOnStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String variableName = "appContext" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextApp();
        parameterSettingsModal.selectApplicationParameter("CRM", "Лиды");
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);

        settingsBlockModal.checkExistWidgetOnBodyModal(variableName);
        sectionPage.processStartConfirmation();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "91dbeeb9-0b80-4ae6-b5c8-3cd08a5792f9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/91dbeeb9-0b80-4ae6-b5c8-3cd08a5792f9)")
    @DisplayName("Создать новую форму стартового события")
    public void createFormStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);

        businessProcessPage.clickStartBlock();
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Вкладки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);

        selectWidgetsModal.checkExistWidgetOnBodyModal("Вкладка");
        sectionPage.processStartConfirmation();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f29c492d-68c3-4d51-84cf-d24c1c28b15d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f29c492d-68c3-4d51-84cf-d24c1c28b15d)")
    @DisplayName("Проверить добавление процесса в меню Создать")
    public void addStartFromMenuStartOnStartEventTest() {
        String processName = "StartEventBP" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(true)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);

        businessProcessPage.clickStartBlock();
        settingsBlockModal.chooseTab("Настройки запуска");
        createContextModal.setCheckboxConditionByLabel("Добавить запуск процесса в меню «Создать»", true);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("");
        mainPage.clickHeaderButton("Создать");
        mainPage.clickItemMenu("Запустить бизнес-процесс");
        sectionPage.startCompanyProcessFromMainPage(processName);

        settingsBlockModal.checkModalWindowWithNameVisible(processName);
        sectionPage.processStartConfirmation();
    }
}
