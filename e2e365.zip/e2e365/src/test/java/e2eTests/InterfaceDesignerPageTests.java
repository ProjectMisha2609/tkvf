package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.utils.Constants.ELMA_TMS;
import static org.junit.jupiter.api.Assertions.assertEquals;

@MicronautTest
@Tags({@Tag("express"), @Tag("interface_designer")})
public class InterfaceDesignerPageTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected SelectWidgetsModal selectWidgetsModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected UserWidgetPage userWidgetPage;
    @Inject
    protected NomenclaturePage nomenclaturePage;

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "d459087e-121f-4254-9e74-63ba71b4af8b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d459087e-121f-4254-9e74-63ba71b4af8b)")
    @DisplayName("Добавить виджет боковой панели без заголовка")
    public void addSidePanelWidgetWithoutHeaderTest() {
        String sectionName = "addSidePanelWidgetWithoutHeaderSectionName" + RandomString.get(8);
        String appName = "addSidePanelWidgetWithoutHeaderAppName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.dragSidePanelWidgetToSidePanel();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.checkWidgetTemplateToolsExists();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "ad67cdbe-f65c-40e6-b1d7-5a0beb851c61", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ad67cdbe-f65c-40e6-b1d7-5a0beb851c61)")
    @DisplayName("Добавить виджет боковой панели с указанием заголовка")
    public void addSidePanelWidgetWithHeaderTest() {
        String sectionName = "addSidePanelWidgetWithHeaderSectionName" + RandomString.get(8);
        String appName = "addSidePanelWidgetWithHeaderAppName" + RandomString.get(8);
        String widgetName = "addSidePanelWidgetWithHeaderWidgetName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.dragSidePanelWidgetToSidePanel();
        widgetSettingsModal.fillPanelWithHeaderName(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.checkWidgetTemplateToolsExists();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "50607d31-def6-4ac8-a847-c1ad26fd9f3a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/50607d31-def6-4ac8-a847-c1ad26fd9f3a)")
    @DisplayName("Добавить виджет в виджет боковой панели")
    public void addWidgetIntoSidePanelWidgetTest() {
        String sectionName = "addWidgetIntoSidePanelWidgetSectionName" + RandomString.get(8);
        String appName = "addWidgetIntoSidePanelWidgetAppName" + RandomString.get(8);
        String titleWidgetName = "addWidgetIntoSidePanelWidgetTitleWidgetName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.dragAndDropTitleWidgetToSidePanelWidget();
        widgetSettingsModal.fillPanelWithHeaderName(titleWidgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.checkTitleWidgetVisible(titleWidgetName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "65da627a-510a-4f61-8176-ac56edcc4c6e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/65da627a-510a-4f61-8176-ac56edcc4c6e)")
    @DisplayName("Удалить виджет боковой панели")
    public void removeSidePanelWidgetTest() {
        String sectionName = "removeSidePanelWidgetSectionName" + RandomString.get(8);
        String appName = "removeSidePanelWidgetAppName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        // на форме, созданной через бэк боковых виджетов много, потому удаление происходит в цикле
        while (interfaceDesignerPage.isSidePanelWidgetExists()) {
            interfaceDesignerPage.removeSidePanelWidget();
        }
        interfaceDesignerPage.checkNoMoreSidePanelWidgets();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "0ab5d544-2554-4f36-bd28-22c29fc54cd2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0ab5d544-2554-4f36-bd28-22c29fc54cd2)")
    @DisplayName("Добавить вкладку плюсом")
    public void addTabByPlusTest() {
        String sectionName = "addTabByPlusSectionName" + RandomString.get(8);
        String appName = "addTabByPlusAppName" + RandomString.get(8);
        String tabName = "addTabByPlusTabName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByPlusButton();
        widgetSettingsModal.fillPanelWithHeaderName(tabName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.checkTabVisible(tabName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "4d44d16e-4171-498a-b03f-336041e461b5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4d44d16e-4171-498a-b03f-336041e461b5)")
    @DisplayName("Добавить виджет на вкладку")
    public void addWidgetToTabTest() {
        String sectionName = "addWidgetToTabSectionName" + RandomString.get(8);
        String appName = "addWidgetToTabAppName" + RandomString.get(8);
        String widgetName = "addWidgetToTabWidgetName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        // в тесте написано "Выбрать виджет", добавляю "Панель с заголовком"
        interfaceDesignerPage.clickAddWidgetOnOpenedTab();
        selectWidgetsModal.pressCreateTitleBarWidget();
        selectWidgetsModal.createTitleBarWidget(widgetName);

        interfaceDesignerPage.checkWidgetExists(widgetName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "be6a95dc-4c58-44b5-b871-ed2987cb4e0b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/be6a95dc-4c58-44b5-b871-ed2987cb4e0b)")
    @DisplayName("Удалить одну вкладку")
    public void removeOneTabTest() {
        String sectionName = "removeOneTabSectionName" + RandomString.get(8);
        String appName = "removeOneTabAppName" + RandomString.get(8);
        String tabName = "removeOneTabTabName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByPlusButton();
        widgetSettingsModal.fillPanelWithHeaderName(tabName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.removeTabByName(tabName);

        interfaceDesignerPage.checkTabNotExists(tabName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "a068f620-c273-491f-811a-a1544a2a3db2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a068f620-c273-491f-811a-a1544a2a3db2)")
    @DisplayName("Удалить несколько вкладок")
    public void removeTwoTabsTest() {
        String sectionName = "removeTwoTabsSectionName" + RandomString.get(8);
        String appName = "removeTwoTabsAppName" + RandomString.get(8);
        String tabName = "removeTwoTabsTabName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addTabByPlusButton();
        widgetSettingsModal.fillPanelWithHeaderName(tabName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.removeAllTabs();
        // удалённый элемент не исчезает, а становится невидимым: role="tab" displayed:false
        interfaceDesignerPage.refreshPage();
        // приходится перезагружать страницу
        interfaceDesignerPage.checkNoMoreTabs();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3e70be8d-0293-4bd8-8cc6-a366a270fe05", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3e70be8d-0293-4bd8-8cc6-a366a270fe05)")
    @DisplayName("Добавить виджет меню с формой на форму просмотра")
    public void addMenuWithFormWidgetTest() {
        String sectionName = "addMenuWithFormWidgetSectionName" + RandomString.get(8);
        String appName = "addMenuWithFormWidgetAppName" + RandomString.get(8);
        String elementName = "addMenuWithFormWidgetElementName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addMenuWithFormByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkNavItemExists();
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.checkNavItemExists();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "8b8f71e1-f4f0-4ae3-9281-3559f6bebd31", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8b8f71e1-f4f0-4ae3-9281-3559f6bebd31)")
    @DisplayName("Добавить меню с формой с вводом заголовка по связанному полю")
    public void addMenuWithFormWidgetWithLinkedNameTest() {
        String sectionName = "addMenuWithFormWidgetWithLinkedNameSectionName" + RandomString.get(8);
        String appName = "addMenuWithFormWidgetWithLinkedNameAppName" + RandomString.get(8);
        String elementName = "addMenuWithFormWidgetWithLinkedNameElementName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addMenuWithFormByDragAndDrop();
        widgetSettingsModal.linkWidgetNameWithAppName();
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        String elementId = elmaBackend.getElementIdByName(sectionName, appName, elementName);

        interfaceDesignerPage.checkNavItemNameVisible(elementId);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "179236ec-6982-465a-b577-684a1ec1c464", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/179236ec-6982-465a-b577-684a1ec1c464)")
    @DisplayName("Добавить меню с формой с вводом заголовка вручную")
    public void addMenuWithFormWidgetWithFilledNameTest() {
        String sectionName = "addMenuWithFormWidgetWithFilledNameSectionName" + RandomString.get(8);
        String appName = "addMenuWithFormWidgetWithFilledNameAppName" + RandomString.get(8);
        String elementName = "addMenuWithFormWidgetWithFilledNameElementName" + RandomString.get(8);
        String widgetName = "addMenuWithFormWidgetWithFilledNameWidgetName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addMenuWithFormByDragAndDrop();
        widgetSettingsModal.fillPanelWithHeaderName(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkNavItemNameVisible(widgetName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkNavItemNameVisible(widgetName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "5575ad33-1083-4e96-ad03-26df2a7d3d0a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5575ad33-1083-4e96-ad03-26df2a7d3d0a)")
    @DisplayName("Удалить меню с формой")
    public void deleteMenuWithFormTest() {
        String sectionName = "deleteMenuWithFormSectionName" + RandomString.get(8);
        String appName = "deleteMenuWithFormAppName" + RandomString.get(8);
        String elementName = "deleteMenuWithFormElementName" + RandomString.get(8);
        String widgetName = "deleteMenuWithFormWidgetName" + RandomString.get(8);
        /* Не удалось создать тестовые данные одним запросом, пришлось создавать поэтапно.
        (обёрнутое в раздел приложение с выбранной формой просмотра, в которой существует меню с формой) */
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addMenuWithFormByDragAndDrop();
        widgetSettingsModal.fillPanelWithHeaderName(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkNavItemNameVisible(widgetName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkNavItemNameVisible(widgetName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.openExistingForm();
        interfaceDesignerPage.removeNavItemByName(widgetName);
        interfaceDesignerPage.checkNoMoreNavItems();
        interfaceDesignerPage.saveAndPublish();
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkNoMoreNavItems();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "f16c65e2-e2ce-4ec1-8a09-06ac0cada803", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f16c65e2-e2ce-4ec1-8a09-06ac0cada803)")
    @DisplayName("Добавить виджет в меню с формой")
    public void addWidgetToMenuWithFormTest() {
        String sectionName = "addMenuWithFormWidgetSectionName" + RandomString.get(8);
        String appName = "addMenuWithFormWidgetAppName" + RandomString.get(8);
        String elementName = "addMenuWithFormWidgetElementName" + RandomString.get(8);
        String widgetName = "addMenuWithFormWidgetWidgetName" + RandomString.get(8);
        String titleWidgetName = "titleWidgetName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addMenuWithFormByDragAndDrop();
        widgetSettingsModal.fillPanelWithHeaderName(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkNavItemNameVisible(widgetName);
        interfaceDesignerPage.dragAndDropTitleWidgetToMenuWithForm();
        widgetSettingsModal.fillPanelWithHeaderName(titleWidgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkNavItemNameVisible(widgetName);
        interfaceDesignerPage.checkTitleWidgetVisible(titleWidgetName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "0818fbaa-e0ec-4504-8048-e43cd287f543", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0818fbaa-e0ec-4504-8048-e43cd287f543)")
    @DisplayName("Удалить Панель")
    public void deletePanelWithHeaderFromFormTest() {
        String sectionName = "deletePanelWithHeaderFromFormSectionName" + RandomString.get(8);
        String appName = "deletePanelWithHeaderFromFormAppName" + RandomString.get(8);
        String elementName = "deletePanelWithHeaderFromFormElementName" + RandomString.get(8);
        String panelName = "deletePanelWithHeaderFromFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.openExistingForm();
        interfaceDesignerPage.removePanelWithHeaderByName(panelName);
        interfaceDesignerPage.checkNoMorePanelWithHeaders();
        interfaceDesignerPage.saveAndPublish();
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkNoMorePanelWithHeaders();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "1d746d63-5507-4853-b1bb-7b659f228ee6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1d746d63-5507-4853-b1bb-7b659f228ee6)")
    @DisplayName("Добавить на форму элемент Панель с заголовком с видом отображения Простой")
    public void addSimpleDisplayingPanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.panelWidgetSettingsModal().setPanelWithHeaderDisplayingMode("Простой");
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkPanelWithHeaderIsSimplyViewed();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "bd029186-e40b-4fe0-9ab8-f181d1005654", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bd029186-e40b-4fe0-9ab8-f181d1005654)")
    @DisplayName("Добавить на форму элемент Панель с заголовком с видом отображения по умолчанию")
    public void addDefaultDisplayingPanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.panelWidgetSettingsModal().setPanelWithHeaderDisplayingMode("По умолчанию");
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkPanelWithHeaderIsDefaultViewed();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "2a749ae8-c0d4-4125-bf6d-b30529e996fa", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2a749ae8-c0d4-4125-bf6d-b30529e996fa)")
    @DisplayName("Добавить на форму Панель с заголовком: Развернута - Да")
    public void addUnfoldedPanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.panelWidgetSettingsModal().setFoldedMode("Да");
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkPanelWithHeaderIsNotFolded();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "ab785fab-c1e8-4023-862a-893bb7539ff7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ab785fab-c1e8-4023-862a-893bb7539ff7)")
    @DisplayName("Добавить на форму Панель с заголовком: Развернута - Нет")
    public void addFoldedPanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.panelWidgetSettingsModal().setFoldedMode("Нет");
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkPanelWithHeaderIsFolded();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "2bee2984-de4c-4cf6-867d-0bcd5e397888", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2bee2984-de4c-4cf6-867d-0bcd5e397888)")
    @DisplayName("Добавить на форму элемент Панель с заголовком с вводом заголовка вручную")
    public void addNamedPanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "4383f2a4-9227-4e92-8372-d80e73d78b17", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4383f2a4-9227-4e92-8372-d80e73d78b17)")
    @DisplayName("Добавить на форму элемент несворачиваемая Панель с заголовком")
    public void addNotCollapsablePanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.panelWidgetSettingsModal().setCollapsibleMode("Нет");
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkNoFoldButtonOnPanelWithHeader();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "6616815b-1781-4672-b4eb-434b58a893ea", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6616815b-1781-4672-b4eb-434b58a893ea)")
    @DisplayName("Добавить на форму элемент сворачиваемая Панель с заголовком")
    public void addCollapsablePanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.panelWidgetSettingsModal().setCollapsibleMode("Да");
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkFoldButtonOnPanelWithHeader();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "e730b059-9512-44cb-a17c-d67e0005a810", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e730b059-9512-44cb-a17c-d67e0005a810)")
    @DisplayName("Добавить на форму элемент Панель с заголовком с указанием заголовка по связанному полю")
    public void addLinkNamedPanelWithHeaderToFormTest() {
        String sectionName = "addLinkNamedPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addLinkNamedPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addLinkNamedPanelWithHeaderToFormElementName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.linkWidgetNameWithAppName();
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        String elementId = elmaBackend.getElementIdByName(sectionName, appName, elementName);
        interfaceDesignerPage.checkPanelWithHeaderVisible(elementId);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Tag("panel_with_header")
    @Link(value = "ef5356da-6a24-496c-81e6-2b010329bf25", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ef5356da-6a24-496c-81e6-2b010329bf25)")
    @DisplayName("Добавить виджет в Панель")
    public void addWidgetToPanelWithHeaderToFormTest() {
        String sectionName = "addSimpleDisplayingPanelWithHeaderToFormSectionName" + RandomString.get(8);
        String appName = "addSimpleDisplayingPanelWithHeaderToFormAppName" + RandomString.get(8);
        String elementName = "addSimpleDisplayingPanelWithHeaderToFormElementName" + RandomString.get(8);
        String panelName = "addSimpleDisplayingPanelWithHeaderToFormPanelName" + RandomString.get(8);
        String titleWidgetName = "titleWidgetName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm(" Панель с заголовком ");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить ");
        interfaceDesignerPage.dragAndDropTitleWidgetToPanelWithHeader();
        widgetSettingsModal.fillPanelWithHeaderName(titleWidgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        interfaceDesignerPage.checkPanelWithHeaderVisible(panelName);
        interfaceDesignerPage.checkTitleWidgetVisible(titleWidgetName);
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2b51ecf2-5f1d-4285-84de-d5bea799092a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2b51ecf2-5f1d-4285-84de-d5bea799092a)")
    @DisplayName("Удалить Счетчик")
    public void deleteCounterTest() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        String counterName = "Counter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Счетчик");
        pageConstructorPage.fillCardOfCounter(counterName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistWidgetOnWrapper(counterName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");

        pageConstructorPage.findAndDeleteCounter(counterName);
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkNotExistWidgetOnWrapper(counterName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c47bfae1-260a-49ce-b826-a7814fdf9adf", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c47bfae1-260a-49ce-b826-a7814fdf9adf)")
    @DisplayName("Удалить элемент Текст")
    public void deleteHtmlTextTest() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        String counterName = "Counter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Текст");
        widgetSettingsModal.fillTextInTextWidget(counterName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistWidgetOnWrapper(counterName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteHtml(counterName);
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkNotExistWidgetOnWrapper(counterName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "13238661-d2e5-4f62-ad10-c44766aecaf0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/13238661-d2e5-4f62-ad10-c44766aecaf0)")
    @DisplayName("Удалить элемент Код")
    public void deleteHtmlTextCode() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        String counterName = "Counter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Код");
        widgetSettingsModal.fillCodeInCodeEditor("<div>" + counterName + "</div>");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistWidgetOnWrapper(counterName);

        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteHtml(counterName);
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkNotExistWidgetOnWrapper(counterName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "78bc46f0-ce47-4de7-a13a-d322fabfb7bd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/78bc46f0-ce47-4de7-a13a-d322fabfb7bd)")
    @DisplayName("Удалить элемент строка")
    public void deleteLine() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Строка");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        interfaceDesignerPage.checkExistLineOnWrapper();

        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteLine();
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkNotExistLineOnWrapper();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2e20b955-5a16-4d87-95b7-3d910418bba8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2e20b955-5a16-4d87-95b7-3d910418bba8)")
    @DisplayName("Добавить колонку плюсом")
    public void addColumnButtonPlus() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Колонки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        interfaceDesignerPage.checkExistColumnOnWrapper();

        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.clickPlusOnColumn();
        selectWidgetsModal.pressCreateWidget("Колонка");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistColumnOnWrapper();
        assertEquals(pageConstructorPage.getCountColumnOnWrapper(), 3, "Колонка не добавилась");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "9b0cb528-2506-4052-81d9-c0472a71401a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9b0cb528-2506-4052-81d9-c0472a71401a)")
    @DisplayName("Удалить одну колонку")
    public void deleteOneColumn() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Колонки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistColumnOnWrapper();
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteOneColumn();
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistColumnOnWrapper();
        assertEquals(pageConstructorPage.getCountColumnOnWrapper(), 1, "Колонка не удалилась");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "9b1aff34-93bb-4027-8f0b-bec603a28b43", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9b1aff34-93bb-4027-8f0b-bec603a28b43)")
    @DisplayName("Добавить виджет Лист согласования на форму элемента приложения")
    public void addApprovalListWidgetTest() {
        String sectionName = "addApprovalListWidgetSectionName" + RandomString.get(8);
        String appName = "addApprovalListWidgetNameAppName" + RandomString.get(8);
        String elementName = "addApprovalListWidgetElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addApprovalListWidgetByDragAndDrop();
        widgetSettingsModal.linkItemAppApprovalListWidget();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        sectionPage.clickButtonSetApprove();
        widgetSettingsModal.setListApprovalAndFamiliarizationUsers();
        interfaceDesignerPage.clickBack();
        sectionPage.openAppElement(sectionName, appName, elementName);
        widgetSettingsModal.checkCountUsersApprovalAndFamiliarizationList();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "a4753604-67b5-489e-95a8-f64531e4fda0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a4753604-67b5-489e-95a8-f64531e4fda0)")
    @DisplayName("Добавить виджет Лист ознакомления на форму элемента приложения")
    public void addFamiliarizationListWidgetTest() {
        String sectionName = "addFamiliarizationListWidgetSectionName" + RandomString.get(8);
        String appName = "addFamiliarizationListWidgetNameAppName" + RandomString.get(8);
        String elementName = "addFamiliarizationListWidgetElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addFamiliarizationListWidgetByDragAndDrop();
        widgetSettingsModal.linkItemAppApprovalListWidget();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();
        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.clickButtonSetFamiliarization();
        widgetSettingsModal.setListApprovalAndFamiliarizationUsers();
        interfaceDesignerPage.clickBack();

        sectionPage.openAppElement(sectionName, appName, elementName);
        widgetSettingsModal.checkCountUsersApprovalAndFamiliarizationList();
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5adea25f-76e3-48a1-8525-89d1c2b60192", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5adea25f-76e3-48a1-8525-89d1c2b60192)")
    @DisplayName("Добавить событие при перемещении курсора за границы кнопки на Клиенте")
    public void addEventMoveInsideOnClientTest() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);
        elmaBackend.createPreparedWidgetPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");

        pageConstructorPage.dragWidgetAndDropPageContent("Кнопка создать");
        String nameFunc = "funcOutsideClient" + RandomString.get(4);
        widgetSettingsModal.createFuncForMoveOutsideClientServer(nameFunc, "Клиент");
        pageConstructorPage.checkContainsTextInScript(nameFunc);
        pageConstructorPage.checkSwitchButtonClientServer("Клиент");
        String simpleScript = "Context.data.testcontext = \"This script work on Client\";\n";
        pageConstructorPage.writeScript(simpleScript, "8");
        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        mainPage.checkScriptRun(pageName, "Создать", "This script work on Client");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0fdfa3da-3cbd-4f4c-b6de-0c0fc08a6426", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0fdfa3da-3cbd-4f4c-b6de-0c0fc08a6426)")
    @DisplayName("Добавить событие при перемещении курсора за границы кнопки на Сервере")
    public void addEventMoveInsideOnServerTest() {
        String sectionName = "createPageFromCounterTest" + RandomString.get(32);
        String pageName = "PageCounter" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);
        elmaBackend.createPreparedWidgetPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");

        pageConstructorPage.dragWidgetAndDropPageContent("Кнопка создать");
        String nameFunc = "funcOutsideServer" + RandomString.get(4);
        widgetSettingsModal.createFuncForMoveOutsideClientServer(nameFunc, "Сервер");
        pageConstructorPage.checkContainsTextInScript(nameFunc);
        pageConstructorPage.checkSwitchButtonClientServer("Сервер");
        String simpleScript = "Context.data.testcontext = \"This script work on Server\";\n";
        pageConstructorPage.writeScript(simpleScript, "4");
        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        mainPage.checkScriptRun(pageName, "Создать", "This script work on Server");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "eae23008-b893-4b80-b53b-e374afcac4cc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/eae23008-b893-4b80-b53b-e374afcac4cc)")
    @DisplayName("Удалить кнопку")
    public void deleteCreateButtonTest() {
        String sectionName = "createPageFromButtonTest" + RandomString.get(32);
        String pageName = "PageButton" + RandomString.get(10);

        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");

        pageConstructorPage.dragWidgetAndDropPageContent("Кнопка создать");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistWidgetOnWrapper("Создать");
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteButtonCreate("Создать");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkNotExistWidgetOnWrapper("Создать");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e3f252a6-7d46-4c2d-8776-bb2f7641c467", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e3f252a6-7d46-4c2d-8776-bb2f7641c467)")
    @DisplayName("Удалить Загрузку файла с предпросмотром")
    public void deleteUploaderFileWidgetTest() {
        String sectionName = "createPageUploaderFileTest" + RandomString.get(32);
        String pageName = "PageUploaderFile" + RandomString.get(10);
        String variableName = "ButtonFile" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();

        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextFiles();
        createContextModal.dialogWindowPressButton("Создать");

        interfaceDesignerPage.clickSaveToolbarButton();
        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.dragWidgetAndDropPageContent("Загрузка файла с предпросмотром");
        widgetSettingsModal.fillUploaderFileViewWidget(variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistWidgetOnWrapper("Файл");

        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteUploaderFile("Файл");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkNotExistWidgetOnWrapper("Файл");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "45bcb15b-1e5c-4069-9748-ed08cd395a28", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/45bcb15b-1e5c-4069-9748-ed08cd395a28)")
    @DisplayName("Удалить несколько колонок")
    public void deleteSomeColumnsTest() {
        String sectionName = "createPageFromColumnTest" + RandomString.get(32);
        String pageName = "PageColumn" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");

        pageConstructorPage.dragWidgetAndDropPageContent("Колонки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPlusOnColumn();
        selectWidgetsModal.pressCreateWidget("Колонка");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        interfaceDesignerPage.checkExistColumnOnWrapper();

        assertEquals(pageConstructorPage.getCountColumnOnWrapper(), 3, "Количество колонок должно быть 3 штуки");

        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteOneColumn();
        pageConstructorPage.findAndDeleteOneColumn();

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        interfaceDesignerPage.checkExistColumnOnWrapper();

        assertEquals(pageConstructorPage.getCountColumnOnWrapper(), 1, "Колонка не удалилась");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "67d8bdeb-aa61-4ba3-b987-de51594c1821", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/67d8bdeb-aa61-4ba3-b987-de51594c1821)")
    @DisplayName("Добавить на форму элемент Колонки")
    public void addDefaultColumnsOnFormTest() {
        String sectionName = "createPageFromColumnTest" + RandomString.get(32);
        String pageName = "PageColumn" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Колонки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistColumnOnWrapper();
        assertEquals(pageConstructorPage.getCountColumnOnWrapper(), 2, "Колонки не добавились на форму");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5369b582-9583-42c8-83a1-c757c112139c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5369b582-9583-42c8-83a1-c757c112139c)")
    @DisplayName("Добавить виджет в колонку")
    public void addWidgetToColumnTest() {
        String sectionName = "createPageFromColumnTest" + RandomString.get(32);
        String pageName = "PageColumn" + RandomString.get(10);
        String columnName = "Column" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropPageContent("Колонки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        //добавление второго виджета
        pageConstructorPage.addWidgetToColumn();
        selectWidgetsModal.pressCreateWidget("Надпись");
        widgetSettingsModal.fillInscriptionWidget(columnName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkExistWidgetOnWrapper(columnName);
        interfaceDesignerPage.checkExistColumnOnWrapper();
        assertEquals(pageConstructorPage.getCountColumnOnWrapper(), 2, "Колонки не добавились на форму");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0a628b46-df27-42e4-84d4-4ffa60301b60", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0a628b46-df27-42e4-84d4-4ffa60301b60)")
    @DisplayName("Проверить добавление пользовательского виджета в приложение")
    public void addUserWidgetOnAppTest() {
        String sectionName = "addUserWidgetSectionName" + RandomString.get(8);
        String appName = "addUserWidgetNameAppName" + RandomString.get(8);
        String elementName = "addUserWidgetElementName" + RandomString.get(8);
        String widgetName = "userWidget" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createEmptyUserWidget(widgetName);

        userWidgetPage.open(widgetName);
        userWidgetPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.openDefaultTabSettings();
        widgetSettingsModal.clearPanelHeaderName();
        widgetSettingsModal.fillPanelWithHeaderName(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.addUserWidgetByDragAndDrop(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        widgetSettingsModal.checkExistWidgetOnBodyModal(widgetName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "9eac7288-3e22-446e-8fbd-6ba4ab41ec4a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9eac7288-3e22-446e-8fbd-6ba4ab41ec4a)")
    @DisplayName("Проверить добавление пользовательского виджета в виджет")
    public void addUserWidgetInAnotherUserWidgetTest() {
        String sectionName = "addUserWidgetSectionName" + RandomString.get(8);
        String appName = "addUserWidgetNameAppName" + RandomString.get(8);
        String elementName = "addUserWidgetElementName" + RandomString.get(8);
        String widgetName1 = "userWidget" + RandomString.get(4);
        String widgetName2 = "userWidget" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createUserWidgetWithTab(widgetName1);
        elmaBackend.createEmptyUserWidget(widgetName2);

        userWidgetPage.open(widgetName2);
        userWidgetPage.addInscriptionByDragAndDrop();
        widgetSettingsModal.fillInscriptionWidget(widgetName2);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();

        userWidgetPage.open(widgetName1);
        userWidgetPage.clickAddWidget();
        selectWidgetsModal.pressCreateWidget(widgetName2);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.addUserWidgetByDragAndDrop(widgetName1);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);

        widgetSettingsModal.checkExistWidgetOnBodyModal(widgetName1);
        widgetSettingsModal.checkExistWidgetOnBodyModal(widgetName2);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "75128377-ccdc-4e70-a4c3-38152ab327bb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/75128377-ccdc-4e70-a4c3-38152ab327bb)")
    @DisplayName("Удалить Просмотр файла")
    public void deleteViewFileWidgetTest() {
        String sectionName = "createPageViewFileTest" + RandomString.get(32);
        String pageName = "PageViewFile" + RandomString.get(10);
        String variableName = "ButtonFile" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();

        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextFiles();
        createContextModal.dialogWindowPressButton("Создать");
        interfaceDesignerPage.clickSaveToolbarButton();
        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.dragWidgetAndDropPageContent("Просмотр файла");

        widgetSettingsModal.fillUploaderFileViewWidget(variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkViewFileWidgetOnForm();

        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.findAndDeleteViewFile("Просмотр файла");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        interfaceDesignerPage.checkViewFileWidgetIsNotExistsOnForm();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "fd003110-c9ce-4e2e-829c-1325222d31d1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/fd003110-c9ce-4e2e-829c-1325222d31d1)")
    @DisplayName("Удалить стандартную форму элемента")
    public void deleteStandardFormElementWidgetOnAppTest() {
        String sectionName = "deleteStandardFormElementWidgetSectionName" + RandomString.get(8);
        String appName = "deleteStandardFormElementAppName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        settingsBlockModal.noteContextVariable("Автор");
        settingsBlockModal.clickContentButtonSettingWindow("Перенести");
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.findAndDeleteStandardFormElement("Стандартная форма элемента");
        interfaceDesignerPage.checkStandardFormElementExistsOnForm();

        pageConstructorPage.clickPublishAndCheckPublish();

        interfaceDesignerPage.checkStandardFormElementExistsOnForm();

        String elementName = "deleteStandardForm" + RandomString.get(8);
        elmaBackend.createElement(elementName, sectionName, appName);

        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.elementNotHaveStandardForm();

    }

    @Test
    @Tag("Author=Lenkevich")
    @TmsLink("Добавить виджет Регистрация документа на форму элемента приложения")
    @DisplayName("Добавить виджет Регистрация документа на форму элемента приложения")
    public void addRegDocumentWidgetOnAppTest() {
        String sectionName = "addRegDocWidget" + RandomString.get(8);
        String appName = "addRegDocAppName" + RandomString.get(8);
        String placeRegName = "placeReg" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        appFormSettingsModal.dialogWindowPressButton("Сохранить");

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        sectionPage.clickCheckBox("Включить регистрацию");
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.dragWidgetAndDropForm("Регистрация документа");
        widgetSettingsModal.fillRegDocumentWidget();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();

        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        widgetSettingsModal.clickModalFooterButton("Сохранить");
        sectionPage.open(sectionName, appName);
        // todo: разобраться зачем два раза подряд открывать страницы.
        sectionPage.openAppElement(sectionName, appName, "cats.png");
        nomenclaturePage.runRegDocument(placeRegName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegName + "/" + dossierName);
    }
}

