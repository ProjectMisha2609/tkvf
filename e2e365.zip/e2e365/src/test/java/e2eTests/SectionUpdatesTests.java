package e2eTests;

import com.codeborne.selenide.Selenide;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.AppFormSettingsModal;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.ImportModal;
import pages.elmaPages.AdminSectionPage;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import java.nio.file.Paths;

import static infrastructure.drivers.CustomDriver.getCurrentUrl;
import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.PATH_TO_DEFAULT_DIR;

@MicronautTest
@Tags({@Tag("express"), @Tag("section_updates")})
public class SectionUpdatesTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected ImportModal importModal;
    @Inject
    protected AdminSectionPage adminSectionPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d6398032-6669-4017-b588-33ba18328d11", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d6398032-6669-4017-b588-33ba18328d11)")
    @DisplayName("Проверить обновление раздела с приложением типа Событие")
    public void checkUpdateOfSectionWithEventTypeApplicationTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "eventNew.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "eventUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        // подтверждение имени раздела может принимать любые названия, если ввести ""
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkCreatedAppAvailable("Event Update");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f013c0b4-e537-4000-ad30-d38924f591ef", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f013c0b4-e537-4000-ad30-d38924f591ef)")
    @DisplayName("Проверить обновление раздела с приложением типа Документ")
    public void checkUpdateOfSectionWithDocumentTypeApplicationTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "document.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "documentUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkCreatedAppAvailable("Document Update");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b4de4d57-9a69-4eae-a08c-2c1d4a5e8cb8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b4de4d57-9a69-4eae-a08c-2c1d4a5e8cb8)")
    @DisplayName("Проверить обновление раздела с удаленными приложениями")
    public void checkUpdateOfSectionWithDeleteApplicationTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "deleteApp.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "deleteAppUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.clickAppSettingButton();
        sectionPage.selectModalWindowTab("Корзина");

        sectionPage.checkAppNameInListBasket("DeleteApp");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b74bf2f3-ac6c-4f4c-96fe-1831aee76568", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b74bf2f3-ac6c-4f4c-96fe-1831aee76568)")
    @DisplayName("Проверить обновление раздела со скрытыми приложениями")
    public void checkUpdateOfSectionWithHiddenApplicationTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "hiddenApp.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "hiddenAppUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.clickAppSettingButton();
        sectionPage.selectModalWindowTab("Активные Приложения");

        sectionPage.checkAppNameInListBasket("HiddenApp");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "fed3de30-5021-4481-b26a-7b0d2c6fe726", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/fed3de30-5021-4481-b26a-7b0d2c6fe726)")
    @DisplayName("Проверить повторное обновление раздела")
    public void checkReUpdateOfSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "application.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "applicationUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkCreatedAppAvailable("ApplicationUpdate");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkCreatedAppAvailable("ApplicationUpdate");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5f1a87d2-511f-4f4b-9755-3fc0bdaaca8c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5f1a87d2-511f-4f4b-9755-3fc0bdaaca8c)")
    @DisplayName("Проверить обновление бизнес-процессов приложения раздела")
    public void checkUpdateOfBusinessProcessesOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "businessProcess.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "businessProcessUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        Selenide.open(getCurrentUrl() + "/__processes");

        adminSectionPage.checkProcessExists("Process");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9d2e5244-bd49-446d-a5ce-118575cc86fe", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9d2e5244-bd49-446d-a5ce-118575cc86fe)")
    @DisplayName("Проверить обновление веб-формы приложения в разделе")
    public void checkUpdateOfWebFormsOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "webAppForm.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "webAppFormUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        Selenide.open(getCurrentUrl() + "/__webforms");

        sectionPage.checkItemExistOnConfigPageTable("Веб-форма");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e2775139-de66-4e09-8cda-f2fb7e26aaa2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e2775139-de66-4e09-8cda-f2fb7e26aaa2)")
    @DisplayName("Проверить обновление групп и ролей для приложения в разделе")
    public void checkUpdateOfGroupAndRolesOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appRoleGroup.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appRoleGroupUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Установить");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.checkCreatedAppAvailable("AppRoleGroup");

        Selenide.open(getCurrentUrl() + "/__groups");
        sectionPage.openItemOnContentPageTable("AppRoleGroup");

        sectionPage.checkItemExistOnConfigPageTable("Измененная группа");
        sectionPage.checkItemExistOnConfigPageTable("Измененная роль");
        sectionPage.checkItemExistOnConfigPageTable("Новая группа");
        sectionPage.checkItemExistOnConfigPageTable("Новая роль");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "09c9b9aa-7815-477f-b0f3-573d5f690bab", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/09c9b9aa-7815-477f-b0f3-573d5f690bab)")
    @DisplayName("Проверить обновление шаблонов документов приложения в разделе")
    public void checkUpdateOfPatternOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appDocTemplates.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appDocTemplatesUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.checkCreatedAppAvailable("AppDocTemplates");

        Selenide.open(getCurrentUrl() + "/__doctemplates");
        sectionPage.openItemOnContentPageTable("AppDocTemplates");

        sectionPage.checkItemExistOnConfigPageTable("newTemplates");
        sectionPage.checkItemExistOnConfigPageTable("templatesUpdate");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d3b76af6-0793-4539-8761-e6ee115f80f0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d3b76af6-0793-4539-8761-e6ee115f80f0)")
    @DisplayName("Проверить обновление поля статус для приложения в разделе")
    public void checkUpdateOfFieldStatusOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appStatus.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appStatusUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.checkCreatedAppAvailable("AppStatus");

        Selenide.open(getCurrentUrl() + "/__status");

        sectionPage.checkTextInFieldInput("StatusUpdate");
        sectionPage.checkTextInFieldInput("NewStatus");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3ad30a37-7082-4355-b287-c486adf33bea", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3ad30a37-7082-4355-b287-c486adf33bea)")
    @DisplayName("Проверить обновление настроек доступа к приложению в разделе")
    public void checkUpdateOfAccessSettingsOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appAccessSettings.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appAccessSettingsUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.checkCreatedAppAvailable("appAccessSetting");

        Selenide.open(getCurrentUrl() + "/__permissions");

        sectionPage.checkStatusOfRadiobuttonByLabel("На уровне Приложения", true);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4397375b-7bac-47de-b003-ba09af3f73b3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4397375b-7bac-47de-b003-ba09af3f73b3)")
    @DisplayName("Проверить обновление названия элемента приложения в разделе")
    public void checkUpdateOfElementNameOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appElementName.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appElementNameUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.checkCreatedAppAvailable("appElementName");

        Selenide.open(getCurrentUrl() + "/__name");

        sectionPage.checkTextInFieldInput("Element - {$__index}");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "17864ab9-87e4-49d0-a71f-ab80d0b4df5e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/17864ab9-87e4-49d0-a71f-ab80d0b4df5e)")
    @DisplayName("Проверить обновление отображения плитки приложения в разделе")
    public void checkUpdateOfTieDisplayOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appTileDisplay.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appTileDisplayUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.checkCreatedAppAvailable("appTileDisplay");

        mainPage.clickButtonOnAppContent("+ appTileDisplay");
        createAppElementModal.fillName("appName");
        sectionPage.clickSaveButton();

        sectionPage.checkItemExistOnConfigPageTable("Название");
        sectionPage.checkItemExistOnConfigPageTable("Автор");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3526c1a7-6429-4942-b8ab-10fe2799a1fd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3526c1a7-6429-4942-b8ab-10fe2799a1fd)")
    @DisplayName("Проверить обновление формы просмотра приложения в разделе")
    public void checkUpdateOfViewFormOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "newAppViewForms.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "newAppViewFormsUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.selectModalWindowTab("Просмотр");
        appFormSettingsModal.checkFormNameExists("Строка");
        appFormSettingsModal.checkFormNameExists("Число");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ed47c791-9562-40a9-a397-f66f41729ffe", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ed47c791-9562-40a9-a397-f66f41729ffe)")
    @DisplayName("Проверить обновление формы редактирования приложения в разделе")
    public void checkUpdateOfEditFormOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appEditForms.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appEditFormsUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.selectModalWindowTab("Редактирование");

        appFormSettingsModal.checkRequiredToFillInAndReadOnly("Строка", true, false);
        appFormSettingsModal.checkRequiredToFillInAndReadOnly("Число", false, true);
        appFormSettingsModal.checkFormNameExists("Роль");
        appFormSettingsModal.checkFormNameExists("Название");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "52ca99d0-b1c5-42f4-a85d-c21607f9ab63", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/52ca99d0-b1c5-42f4-a85d-c21607f9ab63)")
    @DisplayName("Проверить обновление формы создания приложения в разделе")
    public void checkUpdateOfCreateFormOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appCreateForms.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appCreateFormsUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.selectModalWindowTab("Создание");

        appFormSettingsModal.checkRequiredToFillInAndReadOnly("Строка", true, false);
        appFormSettingsModal.checkRequiredToFillInAndReadOnly("Число", false, true);
        appFormSettingsModal.checkFormNameExists("Пользователи");
        appFormSettingsModal.checkFormNameExists("Название");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3bc25ae8-8f54-4087-99d7-38647a0e0134", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3bc25ae8-8f54-4087-99d7-38647a0e0134)")
    @DisplayName("Проверить обновление режима формы на расширенный")
    public void checkUpdateOfFormModemOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appFormMode.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appFormModeUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        // Сценарий кейса описан некорректно, добавлена проверка на обычный режим формы приложения в первом файле
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.checkModalHeaderButtonVisible("Расширенный режим");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        // Добавлена проверка на расширенный режим формы приложения через переключение на вкладку.
        appFormSettingsModal.selectModalWindowTab("Создание");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9fbd50b9-c248-409b-8c1c-93b2bd45dcee", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9fbd50b9-c248-409b-8c1c-93b2bd45dcee)")
    @DisplayName("Проверить обновление контекста приложения в разделе")
    public void checkUpdateOfContextOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appContext.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "appContextUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsApp("Настройка формы");

        appFormSettingsModal.checkInContextTab("Новая строка");
        appFormSettingsModal.clickInContextTab("Новая строка");
        appFormSettingsModal.checkInContextTab("Число");
        appFormSettingsModal.checkInContextTab("Название");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "1b58e0d3-0f38-4f02-a4ef-9a8cbcf778f6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1b58e0d3-0f38-4f02-a4ef-9a8cbcf778f6)")
    @DisplayName("Проверить обновление Разделителя в разделе")
    public void checkUpdateOfDelimiterOfSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "delimiter.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "delimiterUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkNameMenuSeparator("DelimiterUpdate");
        sectionPage.checkCreatedAppAvailable("Page");
        sectionPage.checkNameMenuSeparator("NewDelimiter");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3729b510-45cf-421d-b61c-de9023402e27", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3729b510-45cf-421d-b61c-de9023402e27)")
    @DisplayName("Проверить обновление Ссылки в разделе")
    public void checkUpdateOfLinkOfSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "link.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "linkUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkCreatedAppsAvailable("LinkUpdate");
        sectionPage.checkCreatedAppsAvailable("newLink");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "1ffcb8b9-7e8c-46b4-b8c7-3ec542b76b7d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1ffcb8b9-7e8c-46b4-b8c7-3ec542b76b7d)")
    @DisplayName("Проверить обновление Страницы раздела")
    public void checkUpdateOfPageOfSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "page.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "pageUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.checkCreatedAppAvailable("PageUpdate");
        sectionPage.checkTextFromInscriptionWidgetOnAppTypePage("Test");
        sectionPage.checkCreatedAppsAvailable("NewPage");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "fe17d043-5553-4523-9bf7-90cee6e03fd9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/fe17d043-5553-4523-9bf7-90cee6e03fd9)")
    @DisplayName("Проверить обновление настроек групп раздела")
    public void checkUpdateOfGroupSectionOfApplicationSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "groupSection.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "groupSectionUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Установить");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.appToolbar().checkSectionName("GroupSection");

        Selenide.open(getCurrentUrl() + "/__groups");
        sectionPage.openItemOnContentPageTable("GroupSection");

        sectionPage.checkItemExistOnConfigPageTable("Измененная группа");
        sectionPage.checkItemExistOnConfigPageTable("Измененная роль");
        sectionPage.checkItemExistOnConfigPageTable("Новая группа");
        sectionPage.checkItemExistOnConfigPageTable("Новая роль");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "8183c7cc-2490-438a-b889-00fb254796cc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8183c7cc-2490-438a-b889-00fb254796cc)")
    @DisplayName("Проверить обновление шаблонов документов раздела")
    public void checkUpdateOfPatternOfSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "docTemplatesSection.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "docTemplatesSectionUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");
        sectionPage.appToolbar().checkSectionName("docTemplatesSection");

        Selenide.open(getCurrentUrl() + "/__doctemplates");
        sectionPage.openItemOnContentPageTable("docTemplatesSection");

        sectionPage.checkItemExistOnConfigPageTable("newTemplates");
        sectionPage.checkItemExistOnConfigPageTable("templatesUpdate");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3a4b79c2-3e56-4465-b4bb-15eca47d30f3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3a4b79c2-3e56-4465-b4bb-15eca47d30f3)")
    @DisplayName("Проверить обновление модифицированного раздела")
    public void checkUpdateOfSectionOfSectionTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "section.e365").toString();
        String updateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "sectionUpdate.e365").toString();
        String secondUpdateFilePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "secondSectionUpdate.e365").toString();

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(updateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().checkSectionName("sectionUpdate");

        sectionPage.appToolbar().selectSettingsSections("Обновить Раздел");
        importModal.uploadApplication(secondUpdateFilePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Далее");
        importModal.dialogWindowPressButton("Подтверждаю обновление раздела");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().checkSectionName("secondSectionUpdate");
        sectionPage.checkCreatedAppAvailable("App");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "941a7533-0444-4208-a748-c1ddc8a1b259", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/941a7533-0444-4208-a748-c1ddc8a1b259)")
    @DisplayName("Скачать раздел (Загрузить файл)")
    public void checkUploadSectionFileTest() {
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "SectionFiles", "razdel.e365").toString();
        String sectionName = "checkUploadSectionFile" + RandomString.get(8);

        mainPage.open();
        mainPage.clickUploadSection();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.fillName(sectionName);
        importModal.fillSectionLink(sectionName);
        importModal.dialogWindowPressButton("Далее");
        importModal.confirmSectionNameIfRequired("");
        sectionPage.checkListStepOneCheckSectionAllSuccess();
        importModal.dialogWindowPressButton("Далее");
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.addUserRights(adminLogin);
        sectionPage.clickButtonSelect();
        importModal.dialogWindowPressButton("Установить");
        importModal.dialogWindowPressButton("Перейти в Раздел");

        sectionPage.appToolbar().checkSectionName(sectionName);
    }
}