package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import infrastructure.utils.Constants;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.SectionPage;

import java.nio.file.Paths;

import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("hierarchical_reference_books")})
public class HierarchicalReferenceBooksTests {
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected AddNewAppModal addNewAppModal;
    @Inject
    protected ImportModal importModal;
    @Inject
    protected ExportModal exportModal;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;
    @Inject
    protected SettingFolderFilterModal settingFolderFilterModal;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4ea473bf-e42d-400f-af0d-856430880919", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4ea473bf-e42d-400f-af0d-856430880919)")
    @DisplayName("Добавить элементы приложения в папке")
    public void addApplicationItemsToFolderTest() {
        String sectionName = "addApplicationItemsToFolderSectionName" + RandomString.get(8);
        String appName = "addApplicationItemsToFolderAppName" + RandomString.get(8);
        String nameNewFolder = "nameNewFolder" + RandomString.get(4);
        String nameNewApp = "nameNewApp" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickAddFolderButton();
        sectionPage.inputNewFolder(nameNewFolder);
        sectionPage.clickNameFolder(nameNewFolder);
        sectionPage.clickPlusAppButton();
        sectionPage.inputNameApp(nameNewApp);
        sectionPage.clickSaveButton();

        sectionPage.checkAddedApp(nameNewApp);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "213659e7-2c15-43d6-a725-c92aa311b674", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/213659e7-2c15-43d6-a725-c92aa311b674)")
    @DisplayName("Добавить элементы приложения в корне")
    public void addApplicationItemsToRootTest() {
        String sectionName = "addApplicationItemsToRootSectionName" + RandomString.get(8);
        String appName = "addApplicationItemsToRootAppName" + RandomString.get(8);
        String nameNewApp = "nameNewApp" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.clickNameFolder("Все записи");
        sectionPage.clickPlusAppButton();
        sectionPage.inputNameApp(nameNewApp);
        sectionPage.clickSaveButton();

        sectionPage.checkAddedApp(nameNewApp);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a5f5a41d-fe12-4fc9-8ca0-27dd98557678", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a5f5a41d-fe12-4fc9-8ca0-27dd98557678)")
    @DisplayName("Проверить перемещение папок с помощью drag-n-drop")
    public void checkFolderMovementManualTest() {
        String sectionName = "checkFolderMovementManualSectionName" + RandomString.get(8);
        String appName = "checkFolderMovementManualAppName" + RandomString.get(8);
        String idFolderOne = RandomString.getUUID();
        String idFolderTwo = RandomString.getUUID();
        String nameFolderOne = "nameFolderOne" + RandomString.get(4);
        String nameFolderTwo = "nameFolderTwo" + RandomString.get(4);
        String nameAppItemOne = "nameAppItemOne" + RandomString.get(4);
        String nameAppItemTwo = "nameAppItemTwo" + RandomString.get(4);
        String idAppItemOne = RandomString.getUUID();
        String idAppItemTwo = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolderOne, nameFolderOne);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolderTwo, nameFolderTwo);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItemOne, nameAppItemOne, idFolderOne);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItemTwo, nameAppItemTwo, idFolderTwo);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.moveFolderDown(nameFolderOne);

        sectionPage.isFolderInLastPosition(nameFolderOne);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "be7b2ee7-b1e0-4475-8f1d-f74bc4bb3a6f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/be7b2ee7-b1e0-4475-8f1d-f74bc4bb3a6f)")
    @DisplayName("Добавить в права доступа Группу")
    public void addGroupToAccessRightsTest() {
        String sectionName = "addGroupToAccessRightsSectionName" + RandomString.get(8);
        String appName = "addGroupToAccessRightsAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String nameAppItem = "nameAppItem" + RandomString.get(4);
        String idAppItem = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickLimitAccess("На уровне папок Приложения");
        sectionPage.clickSaveAccess();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        sectionPage.checkAppNotVisible(nameFolder);
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Права доступа");
        sectionPage.clickButtonAddInAccessRights();
        sectionPage.addRightToGroup("Все пользователи");
        sectionPage.clickButtonSelect();
        sectionPage.clickButtonSave();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);

        sectionPage.checkAppVisible(nameFolder);
        sectionPage.checkAppElementExist(nameAppItem);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "57d592e0-7445-4490-a1c4-62342c993636", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/57d592e0-7445-4490-a1c4-62342c993636)")
    @DisplayName("Добавить в права доступа Пользователя")
    public void addUserToAccessRightsTest() {
        String sectionName = "addUserToAccessRightsSectionName" + RandomString.get(8);
        String appName = "addUserToAccessRightsAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String nameAppItem = "nameAppItem" + RandomString.get(4);
        String idAppItem = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickLimitAccess("На уровне папок Приложения");
        sectionPage.clickSaveAccess();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        sectionPage.checkAppNotVisible(nameFolder);
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Права доступа");
        sectionPage.clickButtonAddInAccessRights();
        sectionPage.addUserRights(userLogin);
        sectionPage.clickButtonSelect();
        sectionPage.clickButtonSave();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);

        sectionPage.checkAppVisible(nameFolder);
        sectionPage.checkAppElementExist(nameAppItem);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "12d35a0c-3104-4988-9398-5bc8aeecb7b3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/12d35a0c-3104-4988-9398-5bc8aeecb7b3)")
    @DisplayName("Настроить права доступа к папке убрать галочку \\Наследовать права родительской папки\\")
    public void configureFolderAccessRightsUncheckInheritRightsOfParentFolderTest() {
        String sectionName = "configureFolderAccessRightsUncheckInheritRightsOfParentFolderSectionName" + RandomString.get(8);
        String appName = "configureFolderAccessRightsUncheckInheritRightsOfParentFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String nameAppItem = "nameAppItem" + RandomString.get(4);
        String idAppItem = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickLimitAccess("На уровне папок Приложения");
        sectionPage.clickSaveAccess();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        sectionPage.checkAppNotVisible(nameFolder);
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Права доступа");
        sectionPage.clickTurnOffCheckbox();
        sectionPage.clickButtonSave();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);

        sectionPage.checkAppVisible(nameFolder);
        sectionPage.checkAppElementExist(nameAppItem);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "36a7332c-2565-4eb1-9d90-6917214d8e75", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/36a7332c-2565-4eb1-9d90-6917214d8e75)")
    @DisplayName("Проверить импорт приложения с иерархическим справочником")
    public void checkImportOfApplicationWithHierarchicalDirectoryTest() {
        String sectionName = "ImportOfAppWithHierarchicalDirectorySectionName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().clickAddNewAppInToolbar();
        addNewAppModal.clickUploadFile();
        String filePath = Paths.get(Constants.PATH_TO_DEFAULT_DIR, "testData", "addinscriptionwidgetpagetest3b245b3678c14f75b9235cd33935ff9b.test01.e365").toString();
        importModal.uploadApplication(filePath);
        importModal.dialogWindowPressButton("Далее");
        importModal.clickContinuePreview();
        importModal.dialogWindowPressButton("Перейти к приложению");

        sectionPage.checkCreatedAppAvailable("test01");
        sectionPage.checkAppVisible("testFolder01");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d809971d-a1d6-44ba-9f48-bb56f636e0a4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d809971d-a1d6-44ba-9f48-bb56f636e0a4)")
    @DisplayName("Проверить экспорт приложения с иерархическим справочником")
    public void checkExportOfApplicationWithHierarchicalDirectoryTest() {
        String sectionName = "ExportOfAppWithHierarchicalDirectorySectionName" + RandomString.get(8);
        String appName = "ExportOfAppWithHierarchicalDirectoryAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String nameAppItem = "nameAppItem" + RandomString.get(4);
        String idAppItem = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Экспорт Приложения");
        exportModal.dialogWindowPressButton("Начать экспорт");
        exportModal.dialogWindowPressButton("Далее");
        exportModal.dialogWindowPressButton("Далее");
        exportModal.clickLinkLoadFile();
        exportModal.dialogWindowPressButton("ОК");

        exportModal.checkFileExported(sectionName, appName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b188bac2-7c31-4481-837b-aeab1955a281", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b188bac2-7c31-4481-837b-aeab1955a281)")
    @DisplayName("Удалить не пустую папку")
    public void deleteNotEmptyFolderTest() {
        String sectionName = "deleteNotEmptyFolderSectionName" + RandomString.get(8);
        String appName = "deleteNotEmptyFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String nameAppItem = "nameAppItem" + RandomString.get(4);
        String idAppItem = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Удалить");
        sectionPage.clickDeleteModalWindow();

        sectionPage.checkAppNotVisible(nameFolder);
        sectionPage.checkAppElementExist(nameAppItem);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "287c4d37-8106-4c6a-844b-15dde4d30815", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/287c4d37-8106-4c6a-844b-15dde4d30815)")
    @DisplayName("Удалить пустую папку")
    public void deleteEmptyFolderTest() {
        String sectionName = "deleteEmptyFolderSectionName" + RandomString.get(8);
        String appName = "deleteEmptyFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Удалить");
        sectionPage.clickDeleteModalWindow();

        sectionPage.checkAppNotVisible(nameFolder);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "65508be7-3d09-4e7d-872c-7599f8e6aca5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/65508be7-3d09-4e7d-872c-7599f8e6aca5)")
    @DisplayName("Настроить права доступа к папке \\Наследовать права родительской папки\\")
    public void configureAccessRightsToFolderInheritRightsOfParentFolderTest() {
        String sectionName = "configureAccessRightsToFolderInheritRightsOfParentFolderSectionName" + RandomString.get(8);
        String appName = "configureAccessRightsToFolderInheritRightsOfParentFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String nameAppItem = "nameAppItem" + RandomString.get(4);
        String idAppItem = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItem, nameAppItem, idFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickLimitAccess("На уровне папок Приложения");
        sectionPage.clickCheckBoxAllUsers();
        sectionPage.clickSaveAccess();
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Права доступа");
        sectionPage.clickButtonSave();
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);

        sectionPage.checkAppVisible(nameFolder);
        sectionPage.checkAppElementExist(nameAppItem);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "546c875d-7470-41ce-854d-9bfb74c9f731", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/546c875d-7470-41ce-854d-9bfb74c9f731)")
    @DisplayName("Переместить папку")
    public void checkMoveFolderTest() {
        String sectionName = "checkMoveFolderSectionName" + RandomString.get(8);
        String appName = "checkMoveFolderAppName" + RandomString.get(8);
        String idFolderOne = RandomString.getUUID();
        String idFolderTwo = RandomString.getUUID();
        String nameFolderOne = "nameFolderOne" + RandomString.get(4);
        String nameFolderTwo = "nameFolderTwo" + RandomString.get(4);
        String nameAppItemOne = "nameAppItemOne" + RandomString.get(4);
        String nameAppItemTwo = "nameAppItemTwo" + RandomString.get(4);
        String idAppItemOne = RandomString.getUUID();
        String idAppItemTwo = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolderOne, nameFolderOne);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolderTwo, nameFolderTwo);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItemOne, nameAppItemOne, idFolderOne);
        elmaBackend.createAppItemInFolder(sectionName, appName, idAppItemTwo, nameAppItemTwo, idFolderTwo);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolderOne);
        sectionPage.selectSettingFolder("Переместить");
        sectionPage.selectWhichFolderToMoveTo(nameFolderTwo);
        sectionPage.clickButtonMove();

        sectionPage.checkFolderTwo(nameFolderOne, nameFolderTwo);
    }


    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "edd665ee-1acd-45d9-b770-da4557de86a6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/edd665ee-1acd-45d9-b770-da4557de86a6)")
    @DisplayName("Переименовать папку")
    public void renameFolderTest() {
        String sectionName = "renameFolderSectionName" + RandomString.get(8);
        String appName = "renameFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String newNameFolder = "nameFolder" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Переименовать");
        sectionPage.inputRenameFolder(newNameFolder);

        sectionPage.checkAppVisible(newNameFolder);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2df111ac-bda8-4378-b09e-f4875fd6f9bf", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2df111ac-bda8-4378-b09e-f4875fd6f9bf)")
    @DisplayName("Добавить вложенную папку к папке")
    public void addSubfolderToFolderTest() {
        String sectionName = "addSubfolderToFolderSectionName" + RandomString.get(8);
        String appName = "addSubfolderToFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String newNameFolder = "nameFolder" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickButtonSettingByFolder(nameFolder);
        sectionPage.selectSettingFolder("Добавить вложенную папку");
        sectionPage.inputNewFolder(newNameFolder);

        sectionPage.checkFolderTwo(nameFolder, newNameFolder);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f4b91e80-b4b6-4f36-9ed3-9f54743db260", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f4b91e80-b4b6-4f36-9ed3-9f54743db260)")
    @DisplayName("Добавить папку")
    public void addToFolderTest() {
        String sectionName = "addToFolderSectionName" + RandomString.get(8);
        String appName = "addToFolderAppName" + RandomString.get(8);
        String nameNewFolder = "nameNewFolder" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.clickPencilButton();
        sectionPage.clickAddFolderButton();
        sectionPage.inputNewFolder(nameNewFolder);

        sectionPage.checkAppVisible(nameNewFolder);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "0a058d2d-ad07-49c4-8e67-a21abeb62082", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0a058d2d-ad07-49c4-8e67-a21abeb62082)")
    @DisplayName("Проверить включение иерархии")
    public void checkWhetherHierarchyEnabledTest() {
        String sectionName = "checkWhetherHierarchyEnabledSectionName" + RandomString.get(8);
        String appName = "checkWhetherHierarchyEnabledAppName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Иерархический справочник");
        sectionPage.clickCheckboxHierarchy();

        sectionPage.isAllFolderAndPencilVisible();
    }

    //TODO: Тест проходит на стейдже
    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b755a1b8-da87-4913-acd6-81ccc9d6d3db", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b755a1b8-da87-4913-acd6-81ccc9d6d3db)")
    @DisplayName("В фильтре настроить поиск только по выбранной папке")
    public void filterSetUpSearchOnlyForSelectedFolderTest() {
        String sectionName = "filterSetUpSearchOnlyForSelectedFolderSectionName" + RandomString.get(8);
        String appName = "filterSetUpSearchOnlyForSelectedFolderAppName" + RandomString.get(8);
        String idFolder = RandomString.getUUID();
        String nameFolder = "nameFolder" + RandomString.get(4);
        String filterName = "filterName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableHierarchicalDirectoryOfApplication(sectionName, appName);
        elmaBackend.createFolderInHierarchicalDirectory(sectionName, appName, idFolder, nameFolder);

        sectionPage.open(sectionName, appName);
        sectionPage.clickNameFolder(nameFolder);
        sectionPage.clickSearchInParametersTasks();
        changeElementBlockModal.setManualTextInput(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр для папки");
        sectionPage.setTextInputByFormRowName("", filterName);
        settingFolderFilterModal.clickButtonInPopoverBody("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Фильтр успешно сохранен");
        settingFolderFilterModal.clickFooterButton("Поиск");
        sectionPage.clickNameFolder(nameFolder);

        sectionPage.checkAppVisible(filterName);
    }
}