package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.DocumentTemplateCreatingModal;
import pages.elmaPages.DocumentTemplatesPage;

import java.nio.file.Paths;

import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.PATH_TO_DEFAULT_DIR;

@MicronautTest
@Tags({@Tag("express"), @Tag("document")})
public class DocumentTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected DocumentTemplatesPage documentTemplatesPage;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;

    @Test
    @Link(value = "6f51a9e2-1bd1-4ad8-83f9-2f0160efb177", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6f51a9e2-1bd1-4ad8-83f9-2f0160efb177)")
    @DisplayName("Добавить новый шаблон xlsx на уровне приложения")
    public void addExcelTemplateAppTest() {
        String sectionName = "addExcelTemplateAppTest" + RandomString.get(8);
        String appName = "addExcelTemplateApp" + RandomString.get(8);
        String templateName = "addExcelTemplateAppTest" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        documentTemplatesPage.open(sectionName, appName);
        documentTemplatesPage.appToolbar().selectSettingsApp("Шаблоны документов");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_xlsx.xlsx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection(appName);

        documentTemplatesPage.checkSectionContentExists(templateName);
    }

    @Test
    @Link(value = "0ebb4bda-9d2c-4594-bc0e-d888aa8e0f0c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0ebb4bda-9d2c-4594-bc0e-d888aa8e0f0c)")
    @DisplayName("Добавить новый шаблон docx на уровне приложения")
    public void addWordTemplateAppTest() {
        String sectionName = "addWordTemplateAppTest" + RandomString.get(8);
        String appName = "addWordTemplateApp" + RandomString.get(8);
        String templateName = "addWordTemplateAppTest" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        documentTemplatesPage.open(sectionName, appName);
        documentTemplatesPage.appToolbar().selectSettingsApp("Шаблоны документов");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_docx.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection(appName);

        documentTemplatesPage.checkSectionContentExists(templateName);
    }

    @Test
    @Link(value = "1f0db6ec-bab8-4f9a-9410-9e8ae30471e6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/1f0db6ec-bab8-4f9a-9410-9e8ae30471e6)")
    @DisplayName("Добавить новый шаблон xlsx на уровне раздела")
    public void addExcelTemplateSectionTest() {
        String sectionName = "addExcelTemplateSectionTest" + RandomString.get(8);
        String templateName = "addExcelTemplateSectionTest" + RandomString.get(8);
        elmaBackend.createSection(sectionName);

        documentTemplatesPage.open(sectionName);
        documentTemplatesPage.appToolbar().selectSettingsSections("Шаблоны документов");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_xlsx.xlsx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection(sectionName);

        documentTemplatesPage.checkSectionContentExists(templateName);
    }

    @Test
    @Link(value = "92766aa7-52a9-4426-b7d3-033ef94dc809", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/92766aa7-52a9-4426-b7d3-033ef94dc809)")
    @DisplayName("Добавить новый шаблон docx на уровне раздела")
    public void addWordTemplateSectionTest() {
        String sectionName = "addWordTemplateSectionTest" + RandomString.get(8);
        String templateName = "addWordTemplateSectionTest" + RandomString.get(8);
        elmaBackend.createSection(sectionName);

        documentTemplatesPage.open(sectionName);
        documentTemplatesPage.appToolbar().selectSettingsSections("Шаблоны документов");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_docx.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection(sectionName);

        documentTemplatesPage.checkSectionContentExists(templateName);
    }

    @Test
    @Link(value = "26939a95-ea18-4ac9-8501-51616930aed4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/26939a95-ea18-4ac9-8501-51616930aed4)")
    @DisplayName("Добавить новый шаблон xlsx на уровне компании")
    public void addExcelTemplateCompanyTest() {
        String templateName = "addExcelTemplateCompanyTest" + RandomString.get(8);

        documentTemplatesPage.open("admin/main");
        documentTemplatesPage.appToolbar().selectAppByCode("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_xlsx.xlsx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection("Шаблоны компании");

        documentTemplatesPage.checkSectionContentExists(templateName);
    }

    @Test
    @Link(value = "d2a5f2a7-0e6a-4645-8d6b-9f901c84189d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d2a5f2a7-0e6a-4645-8d6b-9f901c84189d)")
    @DisplayName("Добавить новый шаблон docx на уровне компании")
    public void addWordTemplateCompanyTest() {
        String templateName = "addWordTemplateCompanyTest" + RandomString.get(8);

        documentTemplatesPage.open("admin/main");
        documentTemplatesPage.appToolbar().selectAppByCode("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_docx.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection("Шаблоны компании");

        documentTemplatesPage.checkSectionContentExists(templateName);
    }

    @Test
    @Link(value = "d5ec7fcd-c7db-478a-8ee8-d5c4ae75e92a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d5ec7fcd-c7db-478a-8ee8-d5c4ae75e92a)")
    @DisplayName("Редактировать добавленный файл шаблона")
    public void redactExcelTemplateAppTest() {
        String templateName = "redactExcelTemplateAppTest" + RandomString.get(8);
        String newTemplateName = "redactExcelTemplateAppTest" + RandomString.get(8);

        documentTemplatesPage.open("admin/main");
        documentTemplatesPage.appToolbar().selectAppByCode("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");

        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_xlsx.xlsx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        documentTemplatesPage.pressSection("Шаблоны компании");
        documentTemplatesPage.pressSection(templateName);
        documentTemplatesPage.pressTrashIcon();
        documentTemplateCreatingModal.fillName(newTemplateName);
        filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "template_xlsx_modified.xlsx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);

        documentTemplateCreatingModal.checkFileModified();

        documentTemplateCreatingModal.dialogWindowPressButton("Закрыть");
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");
        documentTemplatesPage.pressSection("Шаблоны компании");

        documentTemplatesPage.checkSectionContentExists(newTemplateName);
    }

    @Test
    @Link(value = "388b1587-ae62-415a-9537-590f02068100", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/388b1587-ae62-415a-9537-590f02068100)")
    @DisplayName("Проверить отображение шаблонов и групп")
    public void displayDocumentTemplatesAndSectionsTest() {
        documentTemplatesPage.open("admin/main");
        documentTemplatesPage.appToolbar().selectAppByCode("admin", "doctemplates");

        documentTemplatesPage.checkSectionExists("Шаблоны компании");
    }

    @Test
    @Link(value = "63d38ef2-1a62-44e7-bdc0-c34fff818b02", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/63d38ef2-1a62-44e7-bdc0-c34fff818b02)")
    @DisplayName("Проверить разворачивание разделов с шаблонами")
    public void unfoldSectionsInDocumentTemplatesTest() {
        documentTemplatesPage.open("admin/main");
        documentTemplatesPage.appToolbar().selectAppByCode("admin", "doctemplates");

        documentTemplatesPage.clickTurnAllTemplates();
        documentTemplatesPage.checkSectionExists("Поступления");
        documentTemplatesPage.checkSectionContentNotExists("Исходящие счета");
        documentTemplatesPage.checkSectionContentNotExists("Шаблон счета");

        documentTemplatesPage.clickExpandAllTemplates();
        documentTemplatesPage.checkSectionExists("Поступления");
        documentTemplatesPage.checkSectionContentExists("Исходящие счета");
        documentTemplatesPage.checkSectionContentExists("Шаблон счета");
    }

    @Test
    @Link(value = "f2b747bd-bbbf-4f01-803d-9495284b119b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/f2b747bd-bbbf-4f01-803d-9495284b119b)")
    @DisplayName("Проверить сворачивание разделов с шаблонами")
    public void foldSectionsInDocumentTemplatesTest() {
        documentTemplatesPage.open("admin/main");
        documentTemplatesPage.appToolbar().selectAppByCode("admin", "doctemplates");

        documentTemplatesPage.clickExpandAllTemplates();
        documentTemplatesPage.checkSectionExists("Поступления");
        documentTemplatesPage.checkSectionContentExists("Исходящие счета");
        documentTemplatesPage.checkSectionContentExists("Шаблон счета");

        documentTemplatesPage.clickTurnAllTemplates();
        documentTemplatesPage.checkSectionExists("Поступления");
        documentTemplatesPage.checkSectionContentNotExists("Исходящие счета");
        documentTemplatesPage.checkSectionContentNotExists("Шаблон счета");
    }
}
