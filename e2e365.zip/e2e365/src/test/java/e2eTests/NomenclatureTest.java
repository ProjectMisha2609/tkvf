package e2eTests;


import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendOrgStructure;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonOrgStructure;
import infrastructure.helpers.RandomString;
import infrastructure.helpers.configs.E2eTestConfig;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.MainPage;
import pages.elmaPages.NomenclaturePage;
import pages.elmaPages.SectionPage;

import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("nomenclature")})
public class NomenclatureTest {
    private final E2eTestConfig config = E2eTestConfig.getInstance();
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected NomenclaturePage nomenclaturePage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsPageModal settingsPageModal;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected BackendOrgStructure backendOrgStructure;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e7704be9-2f97-413e-ad2a-bd8899bdc2b5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e7704be9-2f97-413e-ad2a-bd8899bdc2b5)")
    @DisplayName("Добавить Место регистрации")
    public void addPlaceRegistrationTest() {
        String placeRegistrationName = "addPlaceRegistrationName" + RandomString.get(4);

        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        sectionPage.open("_designer", "nom ");
        mainPage.appHeaderToolbar().clickActionButton("Место регистрации");
        nomenclaturePage.fillName(placeRegistrationName);
        settingsPageModal.dialogWindowPressButton("Сохранить");

        nomenclaturePage.checkNomenclatureOnSettingListExists(placeRegistrationName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "aa35725c-d3aa-45a9-a201-92d4d40c8d94", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/aa35725c-d3aa-45a9-a201-92d4d40c8d94)")
    @DisplayName("Добавить раздел")
    public void addNomenclatureSectionTest() {
        String placeRegistrationName = "addNomenclatureSectionName" + RandomString.get(4);
        String nomenclatureSectionName = "NomenclatureSection" + RandomString.get(4);

        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        sectionPage.open("_designer", "nom ");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Раздел");
        nomenclaturePage.fillName(nomenclatureSectionName);
        settingsPageModal.dialogWindowPressButton("Сохранить");

        sectionPage.open("_office", "all");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);
        nomenclaturePage.checkNomenclatureSectionExists(placeRegistrationName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c7b02a08-b8a5-4180-af62-942aa4b7b908", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c7b02a08-b8a5-4180-af62-942aa4b7b908)")
    @DisplayName("Отображение разделов в канцелярии")
    public void viewNomenclatureSectionTest() {
        String placeRegistrationName = "viewNomenclatureSectionName" + RandomString.get(4);
        String nomenclatureSectionName = "NomenclatureSection" + RandomString.get(4);

        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        sectionPage.open("_designer", "nom ");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Раздел");
        nomenclaturePage.fillName(nomenclatureSectionName);
        settingsPageModal.dialogWindowPressButton("Сохранить");

        sectionPage.open("_office", "all");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);
        nomenclaturePage.clickNomenclatureSection(nomenclatureSectionName);

        nomenclaturePage.checkBreadCrumbTrailsExists(placeRegistrationName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "fe3432bd-271d-428d-8bce-956133681f37", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/fe3432bd-271d-428d-8bce-956133681f37)")
    @DisplayName("Создать дело в документопотоке Исходящие")
    public void createDossierInStreamSendTest() {
        String sectionName = "createDossierInStreamSendSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "createDossierInStreamSendName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Исходящие");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.checkRegDocument("Исходящие");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e3518999-c90c-405f-b15d-dc08b360afc0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e3518999-c90c-405f-b15d-dc08b360afc0)")
    @DisplayName("Создать дело в документопотоке Внутренние")
    public void createDossierInStreamInnerTest() {
        String sectionName = "createDossierInStreamInnerSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "createDossierInStreamSendName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Внутренние");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.checkRegDocument("Внутренние");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e94358ec-8d17-4423-a014-6d5b428b6a5e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e94358ec-8d17-4423-a014-6d5b428b6a5e)")
    @DisplayName("Добавить в настройки доступа группу пользователей")
    public void addAccessGroupUsersTest() {
        String sectionName = "addAccessGroupUsersSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "addAccessGroupUsersName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Настройки доступа");
        settingsPageModal.clickButtonOnModalWindowByName("Добавить");
        nomenclaturePage.chooseRowRadioButton("Группа");
        settingsBlockModal.clickLoupeButtonByFormRowName("");
        nomenclaturePage.chooseItemTreeWrapper("Все пользователи", "Системные группы");
        settingsPageModal.clickButtonOnModalWindowByName("Выбрать");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.checkRegDocument("Входящие");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d6531c9c-5bbb-4f12-91d0-f52270fa8b34", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d6531c9c-5bbb-4f12-91d0-f52270fa8b34)")
    @DisplayName("Редактирование дела из канцелярии под администратором")
    public void editDossierInChanceryTest() {
        String sectionName = "editDossierSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "editDossierInChanceryName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);
        sectionPage.selectItemFromRootDirectory(dossierName);
        nomenclaturePage.clickButtonSettingDossier();
        nomenclatureModal.clearParameterSingleInput("Название");
        nomenclatureModal.setParameterSingleInput("Название", "test");
        nomenclatureModal.dialogWindowPressButton("Сохранить");

        nomenclaturePage.checkNameInHeaderExists("test");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "cd6d7c39-4902-4807-a7ca-8c887a6864e4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cd6d7c39-4902-4807-a7ca-8c887a6864e4)")
    @DisplayName("Добавить дело с ручной нумерацией")
    public void addDossierWithManualNumerationTest() {
        String sectionName = "addDossierWithManualNumerationSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "addDossierWithManualNumerationName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.chooseParameterRadioButton("Нумерация", "Вручную");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocumentManualNumberForRegDocument(dossierName, "500");

        nomenclaturePage.checkNumerationRegDocument("500");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "cad33a83-c2d5-4440-b90a-bd9fc33b6d1e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cad33a83-c2d5-4440-b90a-bd9fc33b6d1e)")
    @DisplayName("Настроить видимость папки Канцелярия")
    public void settingVisibleFolderChanceryTest() {
        String placeRegistrationName = "settingVisibleFolderChanceryName" + RandomString.get(4);

        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();

        sectionPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);
        nomenclaturePage.checkNameInHeaderExists(placeRegistrationName);

        //admin
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.open("_office/all");
        mainPage.appToolbar().selectSettingsSections("Доступ к Разделу");
        settingsPageModal.clickRemoveUserOrGroupButton("Все пользователи");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.refreshPage();
        mainPage.sectionToolbar().checkSectionExist("Задачи");
        mainPage.sectionToolbar().checkSectionNotExist("Номенклатура дел");

        //вернуть права обратно
        String sectionId = elmaBackend.getSectionIdByName("Номенклатура дел");
        elmaBackend.setDefaultAccessForSection(sectionId);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "bd69c9df-cf73-4725-a307-8a66d8f38b36", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bd69c9df-cf73-4725-a307-8a66d8f38b36)")
    @DisplayName("Изменить шаблон номера")
    public void changeTemplateNumberTest() {
        String sectionName = "changeTemplateNumberSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "changeTemplateNumberName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.clearInnerParameterSingleInput("Шаблон номера");
        nomenclatureModal.setInnerParameterSingleInput("Шаблон номера", "{$__name} {$__index}");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(dossierName);

        nomenclaturePage.checkNumerationRegDocument("starfish.png 1");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b429bc66-6f4d-4d50-9274-aa7717791eb9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b429bc66-6f4d-4d50-9274-aa7717791eb9)")
    @DisplayName("Отображение приложений в папке Исходящие")
    public void viewAppOutComingTest() {
        String sectionName = "viewAppOutGoingSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "viewAppOutComingName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Исходящие");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        businessProcessPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection("Исходящие");
        nomenclaturePage.checkRegAppInChancellery("starfish.png", dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "acb0744f-75a8-4875-9f8f-54d189d18f3e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/acb0744f-75a8-4875-9f8f-54d189d18f3e)")
    @DisplayName("Добавить в настройки доступа элемент орг структуры")
    public void addAcceptOgrStructureTest() {
        String sectionName = "addAcceptOgrStructureSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "addAcceptOgrStructureName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String positionName = "StructureForNomenclature" + RandomString.get(4);
        String positionId = RandomString.getUUID();
        String jsonOrgStructure = new JsonOrgStructure.Builder()
                .addNewPositionInJson(new JsonOrgStructure.Builder()
                        .setJsonFile("testData/OrgStructure/PositionCreation.json")
                        .createDefault())
                .setJsonFile("testData/OrgStructure/PositionCreation.json")
                .setName(positionName)
                .setId(positionId)
                .setType("POSITION")
                .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                .addStructureInJsonArray()
                .buildAndGetAsString();
        backendOrgStructure.createOrgStructure(jsonOrgStructure);
        elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(config.userLogin), positionId);


        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Настройки доступа");
        settingsPageModal.clickButtonOnModalWindowByName("Добавить");
        nomenclaturePage.chooseRowRadioButton("Элемент оргструктуры");
        parameterSettingsModal.clickAndSelectBoxItem(" ", positionName);
        settingsPageModal.clickButtonOnModalWindowByName("Выбрать");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.refreshPage();
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkSelectDossierReg(placeRegistrationName + "/" + dossierName);

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/" + dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "a9bf8557-cd1f-42d1-b51d-4b7b0e7d499d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a9bf8557-cd1f-42d1-b51d-4b7b0e7d499d)")
    @DisplayName("Проверить сквозную нумерацию с другим делом")
    public void checkEndToEndNumerationTest() {
        String sectionName = "checkEndToEndNumerationSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName1 = "checkEndToEndNumerationName" + RandomString.get(4);
        String dossierName1 = "dossier" + RandomString.get(4);
        String placeRegId1;
        String serialId1 = RandomString.getUUID();

        //1
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName1);
        elmaBackend.createSerialNumForNomenclature(serialId1, dossierName1);
        placeRegId1 = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName1);
        elmaBackend.createDossierNomenclature(dossierName1, placeRegId1, serialId1);
        //2
        String placeRegistrationName2 = "checkEndToEndNumerationName" + RandomString.get(4);
        String dossierName2 = "dossier" + RandomString.get(4);
        String placeRegId2;
        String serialId2 = RandomString.getUUID();

        elmaBackend.createPlaceOfRegistration(placeRegistrationName2);
        elmaBackend.createSerialNumForNomenclature(serialId2, dossierName2);
        placeRegId2 = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName2);
        elmaBackend.createDossierNomenclature(dossierName2, placeRegId2, serialId2);


        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName2);
        nomenclaturePage.clickItemOnAdministrationList(dossierName2);
        nomenclatureModal.setParameterCheckBox("Нумерация", "Сквозная нумерация с другим делом");
        nomenclatureModal.clickInnerParameterButton("Выберите дело для нумерации");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Настройка нумерации", " ", placeRegistrationName1 + "/" + dossierName1);
        settingsPageModal.clickButtonOnModalWindowByName("Установить");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName2);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName2);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName1 + "/" + dossierName1);
        sectionPage.clickMultiSelectItem(placeRegistrationName2 + "/" + dossierName2);
        nomenclaturePage.clickControlButton("Сохранить");

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName1 + "/" + dossierName1);
        nomenclaturePage.runRegDocument(placeRegistrationName2 + "/" + dossierName2);

        nomenclaturePage.checkNumerationRegDocument("1");
        nomenclaturePage.checkNumerationRegDocument("2");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "94d13900-1abb-435c-a71c-58cea9f64584", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/94d13900-1abb-435c-a71c-58cea9f64584)")
    @DisplayName("Отображение места, раздела и дела, в котором зарегистрировано приложение на карточке приложения")
    public void viewPlaceSectionDossierOnAppTest() {
        String sectionName = "viewPlaceSectionDossierOnAppSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "viewPlaceSectionDossierOnAppName" + RandomString.get(4);
        String nomenclatureSectionName = "NomenclatureSection" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);

        sectionPage.open("_designer/nom");
        mainPage.appHeaderToolbar().clickActionButton("Место регистрации");
        nomenclaturePage.fillName(placeRegistrationName);
        settingsPageModal.dialogWindowPressButton("Сохранить");


        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Раздел");
        nomenclaturePage.fillName(nomenclatureSectionName);
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);

        nomenclaturePage.clickThreeDotsButton(nomenclatureSectionName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/ " + nomenclatureSectionName + "/ " + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/ " + nomenclatureSectionName + "/ " + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/ " + nomenclatureSectionName + "/ " + dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "898f04f6-5621-4995-9fac-04178b820f22", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/898f04f6-5621-4995-9fac-04178b820f22)")
    @DisplayName("Проверить настройку Можно редактировать номер после регистрации")
    public void checkEditNumberAfterRegTest() {
        String sectionName = "checkEditNumberAfterRegSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "checkEditNumberAfterRegName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.setParameterCheckBox("Нумерация", "Можно редактировать номер после регистрации");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");

        nomenclaturePage.runRegDocument(dossierName);
        nomenclaturePage.clickButtonEditNumberRegDocument();
        nomenclaturePage.setNumberReg("1000");

        nomenclaturePage.checkNumerationRegDocument("1000");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "74755aa1-a5c2-4413-8388-2c665bf3fa93", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/74755aa1-a5c2-4413-8388-2c665bf3fa93)")
    @DisplayName("Отображение мест в канцелярии")
    public void viewPlaceInChanceryTest() {

        String placeRegistrationName = "viewPlaceInChanceryName" + RandomString.get(4);

        sectionPage.open("_designer/nom");
        mainPage.appHeaderToolbar().clickActionButton("Место регистрации");
        nomenclaturePage.fillName(placeRegistrationName);
        settingsPageModal.dialogWindowPressButton("Сохранить");

        sectionPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);
        nomenclaturePage.checkNameInHeaderExists(placeRegistrationName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "354abe77-4742-44f0-bd63-864dca6cac4d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/354abe77-4742-44f0-bd63-864dca6cac4d)")
    @DisplayName("Отображение дел в канцелярии")
    public void viewDossierInChanceryTest() {
        String placeRegistrationName = "viewPlaceInChanceryName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        sectionPage.open("_designer/nom");
        mainPage.appHeaderToolbar().clickActionButton("Место регистрации");
        nomenclaturePage.fillName(placeRegistrationName);
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkNomenclatureOnSettingListExists(placeRegistrationName);

        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection(placeRegistrationName);
        sectionPage.selectItemFromRootDirectory(dossierName);
        nomenclaturePage.checkNameInHeaderExists(dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "4575d2ce-ac4f-413e-8bdd-703f36c096a3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4575d2ce-ac4f-413e-8bdd-703f36c096a3)")
    @DisplayName("Отображение приложений в папке Входящие")
    public void viewAppInComingTest() {
        String sectionName = "viewAppInComingSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "viewAppInComingName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Входящие");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        businessProcessPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection("Входящие");
        nomenclaturePage.checkRegAppInChancellery("starfish.png", dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2ffa099c-4120-46d0-95bc-5f19c1ce6216", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2ffa099c-4120-46d0-95bc-5f19c1ce6216)")
    @DisplayName("Отображение приложений в папке Внутренние")
    public void viewAppInnerTest() {
        String sectionName = "viewAppInnerSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "viewAppInnerName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Внутренние");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        businessProcessPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection("Внутренние");
        nomenclaturePage.checkRegAppInChancellery("starfish.png", dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "33961ab3-f72a-4387-9a07-e63af657b1ba", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/33961ab3-f72a-4387-9a07-e63af657b1ba)")
    @DisplayName("Добавить в настройки доступа к месту пользователя")
    public void addAccessPlaceUserTest() {
        String sectionName = "addAccessPlaceUserSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "addAccessPlaceUserName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Настройки доступа");
        settingsPageModal.clickButtonOnModalWindowByName("Добавить");
        nomenclaturePage.chooseRowRadioButton("Пользователь");
        settingsBlockModal.clickLoupeButtonByFormRowName("");
        mainPage.clickSelectUser(userLogin);
        settingsPageModal.clickButtonOnModalWindowByName("Выбрать");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        sectionPage.refreshPage();
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkSelectDossierReg(placeRegistrationName + "/" + dossierName);

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/" + dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2a67e594-43cc-4be2-b8c8-0268c7a1f68b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2a67e594-43cc-4be2-b8c8-0268c7a1f68b)")
    @DisplayName("Создать дело в документопотоке Входящие")
    public void createDossierInStreamInComingTest() {
        String sectionName = "createDossierInStreamSendSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "createDossierInStreamSendName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Входящие");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickButtonExpandRegDocument();

        nomenclaturePage.checkRegDocument(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.checkRegDocument("Входящие");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "1dff5ec2-21bf-4941-9207-1dee6a861976", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1dff5ec2-21bf-4941-9207-1dee6a861976)")
    @DisplayName("Проверить настройку Разрешить резервировать регистрационный номер до регистрации")
    public void checkEditNumberBeforeRegTest() {
        String sectionName = "checkEditNumberBeforeRegSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "checkEditNumberBeforeRegName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.setParameterCheckBox("Нумерация", "Разрешить резервировать регистрационный номер до регистрации");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");

        nomenclaturePage.runRegDocumentWithReserveNumber(dossierName);

        nomenclaturePage.checkReserveNumerationRegDocument("1");
        nomenclaturePage.clickButton("Регистрировать");
        nomenclaturePage.checkNumerationRegDocument("1");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "1c4b941d-0a3a-45af-9adf-3dfdd24362d1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1c4b941d-0a3a-45af-9adf-3dfdd24362d1)")
    @DisplayName("Добавить дело с автоматической нумерацией")
    public void addDossierWithAutoNumerationTest() {
        String sectionName = "addDossierWithAutoNumerationSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "addDossierWithAutoNumerationName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.chooseParameterRadioButton("Нумерация", "Автоматическая");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(dossierName);

        nomenclaturePage.checkNumerationRegDocument("1");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "1431eafb-2769-4b50-bfb1-cc4b20b51f7f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1431eafb-2769-4b50-bfb1-cc4b20b51f7f)")
    @DisplayName("Изменить минимальное количество знаков в деле")
    public void changeMinimalSignsNumberTest() {
        String sectionName = "changeMinimalSignsNumberSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "changeMinimalSignsNumberName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.clearInnerParameterSingleInput("Минимальное количество знаков");
        nomenclatureModal.setInnerParameterSingleInput("Минимальное количество знаков", "5");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(dossierName);

        nomenclaturePage.checkNumerationRegDocument("00001");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0ace153d-f8d4-41e9-8f52-23056efa088e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0ace153d-f8d4-41e9-8f52-23056efa088e)")
    @DisplayName("Изменение следующего номера в деле вручную")
    public void changeManualNextNumberTest() {
        String sectionName = "changeManualNextNumberSectionName" + RandomString.get(8);
        String appName = "addAppName" + RandomString.get(8);
        String placeRegistrationName = "changeManualNextNumberName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.clickInnerParameterButton("Следующий номер");

        nomenclatureModal.clearInputWithNameForm("Установить следующее значение");
        nomenclatureModal.setInputWithNameForm("Установить следующее значение", "100");
        settingsPageModal.clickButtonOnModalWindowByName("Установить");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.checkArrowRightExists(placeRegistrationName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocument(dossierName);

        nomenclaturePage.checkNumerationRegDocument("100");
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "03eb0210-dee6-4064-b367-f232b36fc18f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/03eb0210-dee6-4064-b367-f232b36fc18f)")
    @DisplayName("Удалить дело")
    public void deleteDossierTest() {
        String placeRegistrationName = "deleteDossierName" + RandomString.get(4);
        String dossierName = "dossier" + RandomString.get(4);
        String placeRegId;
        String serialId = RandomString.getUUID();

        elmaBackend.createPlaceOfRegistration(placeRegistrationName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegistrationName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.clickThreeDotsButton(dossierName);
        nomenclaturePage.clickItemMenu("Удалить");
        nomenclaturePage.clickDeleteButtonModalWindow();
        nomenclaturePage.checkItemOnAdministrationListDisappear(dossierName);
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegistrationName);
        nomenclaturePage.clickItemOnAdministrationList(placeRegistrationName);
        nomenclaturePage.checkItemOnAdministrationListNotExists(dossierName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "95997cb5-7b26-4737-85a0-2cd19a2efef0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/95997cb5-7b26-4737-85a0-2cd19a2efef0)")
    @DisplayName("Отображение приложений в папке Журнал регистрации")
    public void viewAppJournalRegTest() {
        //Внутренние
        String sectionName1 = "viewAppJournalRegSectionName" + RandomString.get(8);
        String appName1 = "addAppName" + RandomString.get(8);
        String placeRegistrationName1 = "viewAppJournalRegName" + RandomString.get(4);
        String dossierName1 = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName1);
        elmaBackend.createApplicationDocumentType(sectionName1, appName1);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName1);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName1);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName1);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Внутренние");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName1);

        sectionPage.open(sectionName1, appName1);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName1 + "/" + dossierName1);
        nomenclaturePage.clickControlButton("Сохранить");

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName1, appName1, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName1 + "/" + dossierName1);

        //Исходящие
        String sectionName2 = "viewAppJournalRegSectionName" + RandomString.get(8);
        String appName2 = "addAppName" + RandomString.get(8);
        String placeRegistrationName2 = "viewAppJournalRegName" + RandomString.get(4);
        String dossierName2 = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName2);
        elmaBackend.createApplicationDocumentType(sectionName2, appName2);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName2);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName2);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName2);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Исходящие");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName2);

        sectionPage.open(sectionName2, appName2);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName2 + "/" + dossierName2);
        nomenclaturePage.clickControlButton("Сохранить");

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName2, appName2, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName2 + "/" + dossierName2);

        //Входящие
        String sectionName3 = "viewAppJournalRegSectionName" + RandomString.get(8);
        String appName3 = "addAppName" + RandomString.get(8);
        String placeRegistrationName3 = "viewAppJournalRegName" + RandomString.get(4);
        String dossierName3 = "dossier" + RandomString.get(4);

        elmaBackend.createSection(sectionName3);
        elmaBackend.createApplicationDocumentType(sectionName3, appName3);
        elmaBackend.createPlaceOfRegistration(placeRegistrationName3);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickThreeDotsButton(placeRegistrationName3);
        nomenclaturePage.clickItemMenu("Дело");
        nomenclaturePage.fillName(dossierName3);
        parameterSettingsModal.clickParameterDropDown("Документопоток");
        parameterSettingsModal.chooseParameterItemDropDown("Входящие");
        settingsPageModal.dialogWindowPressButton("Сохранить");
        nomenclaturePage.checkExpandIconExists(placeRegistrationName3);

        sectionPage.open(sectionName3, appName3);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegistrationName3 + "/" + dossierName3);
        nomenclaturePage.clickControlButton("Сохранить");

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");

        sectionPage.openAppElement(sectionName3, appName3, "starfish.png");
        nomenclaturePage.runRegDocument(placeRegistrationName3 + "/" + dossierName3);

        businessProcessPage.open("_office/all");
        nomenclaturePage.clickNomenclatureSection("Журнал регистрации");
        nomenclaturePage.checkRegAppInChancellery("starfish.png", dossierName1);
        nomenclaturePage.checkRegAppInChancellery("starfish.png", dossierName2);
        nomenclaturePage.checkRegAppInChancellery("starfish.png", dossierName3);
    }
}
