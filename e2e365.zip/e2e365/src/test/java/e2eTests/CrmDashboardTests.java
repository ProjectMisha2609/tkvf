package e2eTests;

import infrastructure.elmaBackend.BackendCrm;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.CrmSectionPage;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import java.time.LocalDate;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;
import static java.lang.String.valueOf;

@MicronautTest
@Tags({@Tag("express"), @Tag("crm_dashboard")})
public class CrmDashboardTests {
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected CrmSectionPage crmSectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected MainPage mainPage;

    //TODO: Тесты проходят только на t-elma365

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "93200be0-3061-459d-a3b9-95e714060a59", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/93200be0-3061-459d-a3b9-95e714060a59)")
    @DisplayName("Проверить корректность отображения информации в виджете Топ сделок (Дэшборд РОП)")
    public void checkCorrectnessOfInformationDisplayInTopDealsWidgetTest() {
        String dealName = "topDealsWidget" + RandomString.get(4);

        backendCrm.createDealWithBudget(dealName, adminLogin, 900000);

        crmSectionPage.open("_clients/_dashboard_sales_manager");
        crmSectionPage.clickButtonOnConfigPage("arrow_down");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственные");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonOnConfigPage("Построить");
        crmSectionPage.checkDealByBlockName("Топ сделок", dealName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f0504859-8013-4b4e-8223-5c9b8b7b8fb9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f0504859-8013-4b4e-8223-5c9b8b7b8fb9)")
    @DisplayName("Проверить корректность отображения информации на странице Дешборд руководителя отдела продаж после смены периода")
    public void checkDashboardAfterPeriodChangeTest() {
        String itemName = "checkDashboardAfterPeriodChangeItemName" + RandomString.get(4);
        String cfoName = "checkDashboardAfterPeriodChangeCFOName" + RandomString.get(4);
        String companyName = "checkDashboardAfterPeriodChangeCompanyName" + RandomString.get(4);
        String dealName = "checkDashboardAfterPeriodChangeDealName" + RandomString.get(4);
        String leadName = "checkDashboardAfterPeriodChangeLeadName" + RandomString.get(4);
        String idCompany = RandomString.getUUID();
        LocalDate date = LocalDate.now();

        String itemOfIncomeId = backendCrm.createIncomeItem(itemName, adminLogin);
        String cfoId = backendCrm.createCFO(cfoName);
        backendCrm.createCompany(companyName, idCompany);
        String dealId = backendCrm.createDealWithBudget(dealName, adminLogin, 100000, idCompany, date + "T00:00:00.000Z");
        backendCrm.createPlannedReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, date + "T00:00:00.000Z");
        backendCrm.createLead(leadName);

        crmSectionPage.open("_clients/_dashboard_sales_manager");
        crmSectionPage.clickButtonOnConfigPage("arrow_down");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственные");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonOnConfigPage("Построить");

        crmSectionPage.disappearWaitReportBuilt();
        crmSectionPage.checkDealByBlockNameNotVisible("Топ сделок", "Нет данных");
        crmSectionPage.checkDealByBlockNameNotVisible("Распределение Лидов по сотрудникам", "Нет данных");
        crmSectionPage.checkDealByBlockNameNotVisible("Распределение Сделок по сотрудникам", "Нет данных");
        crmSectionPage.checkDealByBlockNameNotVisible("Поступления цель/план/факт по сотрудникам", "Нет данных");
        crmSectionPage.checkThatStatusNotPercent("Воронка продаж - Лиды", "Новое", "0%");
        crmSectionPage.checkThatStatusNotPercent("Воронка продаж - Сделки", "Новое", "0%");

        crmSectionPage.setPeriodWithLabelRow("Начало периода", date.minusYears(2).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.setPeriodWithLabelRow("Конец периода", date.minusYears(2).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonOnConfigPage("Построить");
        crmSectionPage.disappearWaitReportBuilt();

        crmSectionPage.checkDealByBlockNameVisible("Топ сделок", "Нет данных");
        crmSectionPage.checkDealByBlockNameVisible("Распределение Лидов по сотрудникам", "Нет данных");
        crmSectionPage.checkDealByBlockNameVisible("Распределение Сделок по сотрудникам", "Нет данных");
        crmSectionPage.checkDealByBlockNameVisible("Поступления цель/план/факт по сотрудникам", "Нет данных");
        crmSectionPage.checkThatStatusPercent("Воронка продаж - Лиды", "Новое", "0%");
        crmSectionPage.checkThatStatusPercent("Воронка продаж - Сделки", "Новое", "0%");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2dbcba55-9dd2-433a-948b-8110d53e64b3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2dbcba55-9dd2-433a-948b-8110d53e64b3)")
    @DisplayName("Проверить корректность отображения информации в виджете Поступления цель/план/факт по сотрудникам (Дэшборд РОП)")
    public void checkDashboardReceiptsTest() {
        String itemName = "checkDashboardReceiptsItemName" + RandomString.get(4);
        String cfoName = "checkDashboardReceiptsCFOName" + RandomString.get(4);
        String dealName = "checkDashboardReceiptsDealName" + RandomString.get(4);
        String companyName = "checkDashboardReceiptsCompanyName" + RandomString.get(4);
        String idCompany = RandomString.getUUID();

        String itemOfIncomeId = backendCrm.createIncomeItem(itemName, adminLogin);
        String cfoId = backendCrm.createCFO(cfoName);
        backendCrm.createCompany(companyName, idCompany);
        String dealId = backendCrm.createDealWithBudget(dealName, adminLogin, 100000, idCompany, LocalDate.now() + "T00:00:00.000Z");
        backendCrm.createPlannedReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, LocalDate.now() + "T00:00:00.000Z");

        crmSectionPage.open("_clients/_dashboard_sales_manager");
        crmSectionPage.clickButtonOnConfigPage("arrow_down");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственные");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonOnConfigPage("Построить");
        crmSectionPage.disappearWaitReportBuilt();

        crmSectionPage.checkDealByBlockNameNotVisible("Поступления цель/план/факт по сотрудникам", "Нет данных");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "377f0d71-b36a-4c1e-af08-dfeca1865c96", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/377f0d71-b36a-4c1e-af08-dfeca1865c96)")
    @DisplayName("Проверить корректность отображения информации в виджете Воронка продаж Лиды/Сделки (Дэшборд РОП)")
    public void checkDashboardSalesFunnelTest() {
        String leadName = "checkDashboardSalesFunnelLeadName" + RandomString.get(4);
        String dealName = "checkDashboardSalesFunnelDealName" + RandomString.get(4);

        backendCrm.createLead(leadName);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_dashboard_sales_manager");
        crmSectionPage.clickButtonOnConfigPage("arrow_down");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственные");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonOnConfigPage("Построить");
        crmSectionPage.disappearWaitReportBuilt();

        crmSectionPage.checkThatStatusNotPercent("Воронка продаж - Лиды", "Новое", "0%");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "640bc4a2-69c4-45b2-877e-74871bb6d459", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/640bc4a2-69c4-45b2-877e-74871bb6d459)")
    @DisplayName("Проверить корректность отображения информации в виджетах Распределение лидов по сотрудникам, Распределение сделок по сотрудникам")
    public void checkDashboardLeadDistributionAndDealDistributionDTest() {
        String leadName = "checkDashboardSalesFunnelLeadName" + RandomString.get(4);
        String dealName = "checkDashboardSalesFunnelDealName" + RandomString.get(4);

        backendCrm.createLead(leadName);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_dashboard_sales_manager");
        crmSectionPage.clickButtonOnConfigPage("arrow_down");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственные");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonOnConfigPage("Построить");
        crmSectionPage.disappearWaitReportBuilt();

        crmSectionPage.checkDealByBlockNameNotVisible("Распределение Лидов по сотрудникам", "Нет данных");
        crmSectionPage.checkDealByBlockNameNotVisible("Распределение Сделок по сотрудникам", "Нет данных");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3dd8a103-565a-4072-82c2-a9bbcc175972", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3dd8a103-565a-4072-82c2-a9bbcc175972)")
    @DisplayName("Проверить корректность отображения информации на странице Дешборд сотрудника отдела продаж после смены периода")
    public void checkDashboardSalesDepartmentAfterPeriodChangeTest() {
        String itemName = "checkDashboardReceiptsItemName" + RandomString.get(4);
        String cfoName = "checkDashboardReceiptsCFOName" + RandomString.get(4);
        String dealName = "checkDashboardReceiptsDealName" + RandomString.get(4);
        String leadName = "checkDashboardReceiptsLeadName" + RandomString.get(4);
        String companyName = "checkDashboardReceiptsCompanyName" + RandomString.get(4);
        String goalName = "checkDashboardReceiptsGoalName" + RandomString.get(4);
        String idCompany = RandomString.getUUID();
        LocalDate date = LocalDate.now();

        String itemOfIncomeId = backendCrm.createIncomeItem(itemName, adminLogin);
        String cfoId = backendCrm.createCFO(cfoName);
        backendCrm.createCompany(companyName, idCompany);
        String dealId = backendCrm.createDealWithBudget(dealName, adminLogin, 100000, idCompany, date + "T00:00:00.000Z");
        String plannedReceiptId = backendCrm.createPlannedReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, date + "T00:00:00.000Z");
        backendCrm.createActualReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, plannedReceiptId, date + "T00:00:00.000Z");
        backendCrm.createGoal(goalName, adminLogin);
        backendCrm.createLead(leadName);
        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();

        mainPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();
        crmSectionPage.open("_clients/_dashboard_sales_employee");

        crmSectionPage.checkDashboardGridNotVisible("Цель", "0 ₽");
        crmSectionPage.checkDashboardGridNotVisible("План по поступлениям", "0 ₽");
        crmSectionPage.checkDealByBlockNameNotVisible("Топ 5 сделок", "Нет данных");
        crmSectionPage.checkThatPercentNotEmployee("Воронка продаж - Мои лиды", "Новое", "0");
        crmSectionPage.checkThatPercentNotEmployee("Воронка продаж - Мои сделки", "Новое", "0");
        crmSectionPage.checkCRMActivityNotVisible("Мои лиды", "Запланировано", "0");
        crmSectionPage.checkDashboardGridNotVisible("Факт по поступлениям", "0 ₽");
        crmSectionPage.checkCRMActivityNotVisible("Мои сделки", "Запланировано", "0");

        crmSectionPage.setPeriodWithLabelRow("Начало периода", date.minusYears(3).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.setPeriodWithLabelRow("Конец периода", date.minusYears(3).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonOnConfigPage("Построить");

        crmSectionPage.checkDashboardGridVisible("Цель", "0 ₽");
        crmSectionPage.checkDashboardGridVisible("План по поступлениям", "0 ₽");
        crmSectionPage.checkDashboardGridVisible("Факт по поступлениям", "0 ₽");
        crmSectionPage.checkDealByBlockNameVisible("Топ 5 сделок", "Нет данных");
        crmSectionPage.checkThatPercentEmployee("Воронка продаж - Мои лиды", "Новое", "0");
        crmSectionPage.checkThatPercentEmployee("Воронка продаж - Мои сделки", "Новое", "0");
        crmSectionPage.checkCRMActivityVisible("Мои лиды", "Запланировано", "0");
        crmSectionPage.checkCRMActivityVisible("Мои сделки", "Запланировано", "0");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a078da74-41b1-44bb-b103-467c864985fd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a078da74-41b1-44bb-b103-467c864985fd)")
    @DisplayName("Проверить корректность отображения информации в виджете Задачи CRM на сегодня")
    public void checkDashboardTaskCRMTest() {
        String leadName = "checkDashboardTaskCRMLeadName" + RandomString.get(4);
        String dealName = "checkDashboardTaskCRMDealName" + RandomString.get(4);

        backendCrm.createLead(leadName);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadName);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealName);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();

        crmSectionPage.open("_clients/_dashboard_sales_employee");

        //TODO: если уже есть 5 задач на сегодня, то остальные уже не высвечиваются
        crmSectionPage.checkDealByBlockNameVisible("Мои задачи CRM на сегодня", "Позвонить " + leadName);
        crmSectionPage.checkDealByBlockNameVisible("Мои задачи CRM на сегодня", "Позвонить " + dealName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e8a6d2e5-6683-49dc-83ed-9e124fe3d5c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e8a6d2e5-6683-49dc-83ed-9e124fe3d5ce)")
    @DisplayName("Проверить корректность отображения информации в виджете Топ 5 сделок (Дешборд СОП)")
    public void checkDashboardInTopFiveDealsWidgetTest() {
        String dealName = "topDealsWidget" + RandomString.get(4);

        backendCrm.createDealWithBudget(dealName, adminLogin, 900000);

        crmSectionPage.open("_clients/_dashboard_sales_employee");
        crmSectionPage.checkDealByBlockName("Топ 5 сделок", dealName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "83ac1655-beba-445e-a067-ba6d67e748fd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/83ac1655-beba-445e-a067-ba6d67e748fd)")
    @DisplayName("Проверить корректное отображение поступлений на странице приложения Реестр поступлений")
    public void checkCorrectDisplayOfReceiptsOnAppPageRegisterOfReceiptsTest() {
        String itemName = "checkRegisterOfReceiptsItemName" + RandomString.get(4);
        String cfoName = "checkRegisterOfReceiptsCFOName" + RandomString.get(4);
        String dealName = "checkRegisterOfReceiptsDealName" + RandomString.get(4);
        String companyName = "checkRegisterOfReceiptsCompanyName" + RandomString.get(4);
        String idCompany = RandomString.getUUID();
        LocalDate date = LocalDate.now();

        String itemOfIncomeId = backendCrm.createIncomeItem(itemName, adminLogin);
        String cfoId = backendCrm.createCFO(cfoName);
        backendCrm.createCompany(companyName, idCompany);
        String dealId = backendCrm.createDealWithBudget(dealName, adminLogin, 100000, idCompany, date + "T00:00:00.000Z");
        String plannedReceiptId = backendCrm.createPlannedReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, date + "T00:00:00.000Z");
        backendCrm.createActualReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, plannedReceiptId, date + "T00:00:00.000Z");

        crmSectionPage.open("_transactions/_income");
        sectionPage.checkNameTaskPattern(String.format("Факт. поступление от %s по %s", date.format(FORMATTER_DD_MM_YYYY), companyName));
        sectionPage.checkNameTaskPattern(String.format("План. поступление на %s по %s", date.format(FORMATTER_DD_MM_YYYY), companyName));

        sectionPage.clickNameFolder("Плановые поступления");
        sectionPage.checkNameTaskPattern(String.format("План. поступление на %s по %s", date.format(FORMATTER_DD_MM_YYYY), companyName));
        sectionPage.checkTaskNameNotExists(String.format("Факт. поступление от %s по %s", date.format(FORMATTER_DD_MM_YYYY), companyName));

        sectionPage.clickNameFolder("Фактические поступления");
        sectionPage.checkNameTaskPattern(String.format("Факт. поступление от %s по %s", date.format(FORMATTER_DD_MM_YYYY), companyName));
        sectionPage.checkTaskNameNotExists(String.format("План. поступление н %s по %s", date.format(FORMATTER_DD_MM_YYYY), companyName));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "eac49001-4e7c-4f04-8d09-b5dc601e5c87", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/eac49001-4e7c-4f04-8d09-b5dc601e5c87)")
    @DisplayName("Проверить корректность отображения информации в виджете Воронка продаж Лиды/Сделки (Дешборд СОП)")
    public void checkCorrectnessDisplaySalesFunnelWidgetTest() {
        String leadName = "checkCorrectnessDisplaySalesFunnelWidgetLeadName" + RandomString.get(4);
        String dealName = "checkCorrectnessDisplaySalesFunnelWidgetDealName" + RandomString.get(4);

        backendCrm.createLead(leadName);
        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_dashboard_sales_employee");

        crmSectionPage.checkThatPercentNotEmployee("Воронка продаж - Мои лиды", "Новое", "0");
        crmSectionPage.checkThatPercentNotEmployee("Воронка продаж - Мои сделки", "Новое", "0");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "eac49001-4e7c-4f04-8d09-b5dc601e5c87", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8b2c0d53-3c4c-4376-8abc-2c140ce2a667)")
    @DisplayName("Проверить корректность отображения информации в виджете Активности CRM по сделкам/лидам")
    public void checkCorrectnessDisplayCRMActivityTest() {
        LocalDate startDate = LocalDate.now().minusDays(2);

        crmSectionPage.open("_clients/_dashboard_sales_employee");
        int myLeadPlan = crmSectionPage.getCountInCRMActivity("Мои лиды", "Запланировано");
        int myLeadWithoutActivity = crmSectionPage.getCountInCRMActivity("Мои лиды", "Без активности");
        int myLeadOverdue = crmSectionPage.getCountInCRMActivity("Мои лиды", "Просрочено");

        int myDealPlan = crmSectionPage.getCountInCRMActivity("Мои сделки", "Запланировано");
        int myDealWithoutActivity = crmSectionPage.getCountInCRMActivity("Мои сделки", "Без активности");
        int myDealOverdue = crmSectionPage.getCountInCRMActivity("Мои сделки", "Просрочено");

        String leadNameOne = "checkCorrectnessDisplayCRMActivityLeadNameOne" + RandomString.get(4);
        String leadNameTwo = "checkCorrectnessDisplayCRMActivityLeadNameTwo" + RandomString.get(4);
        String leadNameThree = "checkCorrectnessDisplayCRMActivityLeadNameTree" + RandomString.get(4);

        String dealNameOne = "checkCorrectnessDisplayCRMActivityDealNameOne" + RandomString.get(4);
        String dealNameTwo = "checkCorrectnessDisplayCRMActivityDealNameTwo" + RandomString.get(4);
        String dealNameThree = "checkCorrectnessDisplayCRMActivityDealNameTree" + RandomString.get(4);

        backendCrm.createLead(leadNameOne);
        backendCrm.createLead(leadNameTwo);
        backendCrm.createLead(leadNameThree);

        backendCrm.createDeal(dealNameOne);
        backendCrm.createDeal(dealNameTwo);
        backendCrm.createDeal(dealNameThree);

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadNameOne);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();

        mainPage.open("_clients/_opportunities/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(leadNameTwo);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.inputDateStart(startDate);
        crmSectionPage.saveTask();

        mainPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealNameOne);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.saveTask();

        mainPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.openCard(dealNameTwo);
        crmSectionPage.clickNewTaskButton();
        crmSectionPage.inputDateStart(startDate);
        crmSectionPage.saveTask();

        crmSectionPage.open("_clients/_dashboard_sales_employee");

        crmSectionPage.checkCRMActivityVisible("Мои лиды", "Запланировано", valueOf(myLeadPlan + 1));
        crmSectionPage.checkCRMActivityVisible("Мои лиды", "Без активности", valueOf(myLeadWithoutActivity + 1));
        crmSectionPage.checkCRMActivityVisible("Мои лиды", "Просрочено", valueOf(myLeadOverdue + 1));

        crmSectionPage.checkCRMActivityVisible("Мои сделки", "Запланировано", valueOf(myDealPlan + 1));
        crmSectionPage.checkCRMActivityVisible("Мои сделки", "Без активности", valueOf(myDealWithoutActivity + 1));
        crmSectionPage.checkCRMActivityVisible("Мои сделки", "Просрочено", valueOf(myDealOverdue + 1));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "fe1926c8-5676-470e-b70d-48dfa306d8b9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/fe1926c8-5676-470e-b70d-48dfa306d8b9)")
    @DisplayName("Проверить корректность отображения информации в виджете Цель/План/Факт")
    public void checkInformationDisplayedCorrectlyInGoalPlanFactWidgetTest() {
        String itemName = "checkInformationDisplayedCorrectlyInGoalPlanFactItemName" + RandomString.get(4);
        String cfoName = "checkInformationDisplayedCorrectlyInGoalPlanFactCFOName" + RandomString.get(4);
        String dealName = "checkInformationDisplayedCorrectlyInGoalPlanFactDealName" + RandomString.get(4);
        String goalName = "checkInformationDisplayedCorrectlyInGoalPlanFactGoalName" + RandomString.get(4);
        String companyName = "checkInformationDisplayedCorrectlyInGoalPlanFactCompanyName" + RandomString.get(4);
        String idCompany = RandomString.getUUID();
        LocalDate date = LocalDate.now();

        String itemOfIncomeId = backendCrm.createIncomeItem(itemName, adminLogin);
        String cfoId = backendCrm.createCFO(cfoName);
        backendCrm.createCompany(companyName, idCompany);
        String dealId = backendCrm.createDealWithBudget(dealName, adminLogin, 100000, idCompany, date + "T00:00:00.000Z");
        String plannedReceiptId = backendCrm.createPlannedReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, date + "T00:00:00.000Z");
        backendCrm.createActualReceipt(adminLogin, idCompany, itemOfIncomeId, cfoId, dealId, plannedReceiptId, date + "T00:00:00.000Z");
        backendCrm.createGoal(goalName, adminLogin);

        crmSectionPage.open("_clients/_dashboard_sales_employee");

        crmSectionPage.checkDashboardGridNotVisible("Цель", "0 ₽");
        crmSectionPage.checkDashboardGridNotVisible("План по поступлениям", "0 ₽");
        crmSectionPage.checkDashboardGridNotVisible("Факт по поступлениям", "0 ₽");
    }
}
