package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.NotificationModal;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.MessagePage;
import pages.elmaPages.SectionPage;

import java.util.Locale;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("notification_block")})
public class NotificationBlockTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected NotificationModal notificationModal;
    @Inject
    protected MessagePage messagePage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "06f7db9c-e8de-4577-a86c-bac284d0097c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/06f7db9c-e8de-4577-a86c-bac284d0097c)")
    @DisplayName("Проверить отправку оповещения с указанной темой")
    public void notificationWithThemeTest() {
        String processName = "notificationWithThemeProcessName" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");
        notificationModal.setTextInputByFormRowName("Тема сообщения", theme);
        notificationModal.clickRadioButtonByLabel("Система");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        messagePage.open("messages/feed");

        messagePage.checkExistsMessage(theme);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b35bd152-f025-4f8c-9612-d1e98f537e9f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b35bd152-f025-4f8c-9612-d1e98f537e9f)")
    @DisplayName("Изменить название операции Оповещение")
    public void changeNotificationNameTest() {
        String processName = "changeNotificationNameProcessName" + RandomString.get(8);
        String notificationName = "newName" + RandomString.get(4);
        String theme = "theme" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");
        notificationModal.setTextInputByFormRowName("Название", notificationName);
        notificationModal.setTextInputByFormRowName("Тема сообщения", theme);
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.checkElementByName(notificationName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "338f067a-f334-4dc0-ad71-6f3040d57040", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/338f067a-f334-4dc0-ad71-6f3040d57040)")
    @DisplayName("Указать ассоциированный объект - контекстная переменная")
    public void setAssociatedObjectContextVariableTest() {
        String processName = "setAssociatedObjectContextVariable" + RandomString.get(4);
        String sectionName = "setAssociatedObjectContextVariableSectionName" + RandomString.get(4);
        String appName = "createApp" + RandomString.get(4);
        String elementName = "elementName" + RandomString.get(4);
        String theme = "theme" + RandomString.get(8);
        String text = "text" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");
        notificationModal.setTextInputByFormRowName("Тема сообщения", theme);
        notificationModal.setTextBlockByFormRowName("Текст сообщения", text);
        notificationModal.chooseRadioButtonByFormRowNameAndLabel("Ассоциированный объект", "Контекстная переменная");
        notificationModal.clickAndSelectDropDownItemWithLabelAndNameModalForm("Оповещение 1", "", "Выберите переменную", appName);
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementName);
        createAppElementModal.clickModalFooterButton("Сохранить");
        sectionPage.clickNextStageOrExit();
        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.checkNotificationMessageTitle(theme);
        sectionPage.checkNotificationMessageTitle("Процесс " + processName);
        sectionPage.checkNotificationMessageBodyThread(text);
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2b7d9431-7ed5-40c7-9791-5b0b7b983cf3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2b7d9431-7ed5-40c7-9791-5b0b7b983cf3)")
    @DisplayName("Указать ассоциированный объект - текущий процесс")
    public void setAssociatedObjectIsCurrentProcessTest() {
        String processName = "setAssociatedObjectIsCurrentProcessPB" + RandomString.get(4);
        String text = "text" + RandomString.get(8);
        String theme = "theme" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/NotificationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Оповещение 1");
        notificationModal.setTextInputByFormRowName("Тема сообщения", theme);
        notificationModal.setTextBlockByFormRowName("Текст сообщения", text);
        notificationModal.chooseRadioButtonByFormRowNameAndLabel("Ассоциированный объект", "Текущий процесс");
        notificationModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        businessProcessPage.open("admin/monitor", processId + "(p:history/" + instanceId + ")");
        sectionPage.checkNotificationMessageTitle(theme);
        sectionPage.checkNotificationMessageBodyThread(text);
    }
}