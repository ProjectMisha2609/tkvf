package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import infrastructure.utils.Constants;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.nio.file.Paths;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("sections")})
public class SectionTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected AddGroupOrRoleModal addGroupOrRoleModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected CreateBpModal createBpModal;
    @Inject
    protected CreateAppElementModal createApplicationElementModal;
    @Inject
    protected ExportModal sectionExportModal;
    @Inject
    protected SectionSettingsModal sectionSettingsModal;
    @Inject
    protected StatusPage statusPage;
    @Inject
    protected SectionSettingsModal settingsModal;
    @Inject
    protected ApiPage apiPage;
    @Inject
    protected ChooseSectionIframe chooseSectionIframe;
    @Inject
    protected ImportModal importModal;
    @Inject
    protected SectionActionModal sectionActionModal;
    @Inject
    protected AddCounterModal addCounterModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SetupSectionRolesAndGroups setupSectionRolesAndGroups;
    @Inject
    protected SectionInstallSucceededModal sectionInstallSucceededModal;

    @Test
    @Link(value = "73da0c1b-d2be-44e1-8d9d-8cd8155c5fbe", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/73da0c1b-d2be-44e1-8d9d-8cd8155c5fbe)")
    @DisplayName("Создать раздел")
    public void addSectionFromLeftToolbarTest() {
        sectionPage.open();
        sectionPage.sectionToolbar().clickAddSection();
        sectionActionModal.clickCreateSectionFast();

        String sectionName = "addSectionTest" + RandomString.get(16);
        settingsModal.fillNewSectionName(sectionName);
        settingsModal.dialogWindowPressButton("Создать");

        sectionPage.appToolbar().checkSectionName(sectionName);
    }

    @Test
    @Link(value = "85cae424-2aa8-476f-9183-eaf1a55a663c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/85cae424-2aa8-476f-9183-eaf1a55a663c)")
    @DisplayName("Скачать раздел (Выбрать готовый Раздел из каталога)")
    public void addSectionDownloadFromStoreTest() {
        mainPage.open();
        mainPage.clickDownloadExistingSection();

        String componentName = "Управление заказами — окна, двери";
        chooseSectionIframe.chooseSectionIframe();
        chooseSectionIframe.clickSolutionByName(componentName);
        chooseSectionIframe.clickInstallSection();
        chooseSectionIframe.closeSectionIframe();

        String sectionName = RandomString.get(32);
        importModal.fillName(sectionName);
        importModal.fillSectionLink(sectionName);
        importModal.clickContinue();
        setupSectionRolesAndGroups.clickInstallIfPresented();
        sectionInstallSucceededModal.clickMoveToSection();

        mainPage.appToolbar().checkSectionName(sectionName);
    }

    @Test
    @Link(value = "c759cc68-2b8e-4239-8645-311533f630f2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c759cc68-2b8e-4239-8645-311533f630f2)")
    @DisplayName("Проверить добавление бизнес-процесса")
    public void addBusinessProcessTest() {
        String sectionName = "addBusinessProcessTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Бизнес-процессы");
        sectionPage.clickAddProcess();
        createBpModal.dialogWindowEnterName(sectionName);
        createBpModal.dialogWindowPressButton("Создать");

        sectionPage.checkDiagrammerExists();
    }

    @Test
    @Link(value = "4ccadd60-1cff-4098-8a91-0507d1e44dc3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/4ccadd60-1cff-4098-8a91-0507d1e44dc3)")
    @DisplayName("Проверить добавление Группы/Роли")
    public void addUserGroupTest() {
        String sectionName = "addUserGroupTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Настройки групп");
        sectionPage.appHeaderToolbar().clickActionButton("Группа");

        addGroupOrRoleModal.fillName("TestGroup");
        addGroupOrRoleModal.fillDescription("TestDescription");
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");

        sectionPage.checkToastAppeared();
    }

    @Test
    @Link(value = "db229427-cdc8-4ed6-bb45-e630ec838362", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/db229427-cdc8-4ed6-bb45-e630ec838362)")
    @DisplayName("Проверить добавление шаблона документа")
    public void addDocumentTemplateTest() {
        String sectionName = "addDocumentTemplateTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Шаблоны документов");
        sectionPage.appHeaderToolbar().clickActionButton("шаблон");

        String templateName = "Template" + RandomString.get(8);
        documentTemplateCreatingModal.fillName(templateName);
        String filePath = Paths.get(Constants.PATH_TO_DEFAULT_DIR, "testData", "test_template.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        sectionPage.checkNameTemplateDoc(templateName);

    }

    @Test
    @Link(value = "d20bcdad-0a18-444c-ab56-ef448ec022d3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d20bcdad-0a18-444c-ab56-ef448ec022d3)")
    @DisplayName("Настройки Раздела. Редактировать раздел")
    public void editSectionTest() {
        String sectionName = "editSectionTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Настройки Раздела");
        String newName = "NewSectionName" + RandomString.get(8);
        sectionSettingsModal.fillNewSectionName(newName);
        String description = "TestDescription" + RandomString.get(8);
        sectionSettingsModal.fillSectionDescription(description);
        sectionSettingsModal.selectNewSectionIcon();
        sectionSettingsModal.dialogWindowPressButton("Сохранить");

        sectionPage.checkNewSectionSettingsApplied(newName, description);
    }

    @Test
    @Link(value = "3aa19eaa-ae23-4797-b14e-3979857f6005", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3aa19eaa-ae23-4797-b14e-3979857f6005)")
    @DisplayName("Проверить добавление нумератора")
    public void addCounterTest() {
        String sectionName = "addCounterTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Нумераторы");
        sectionPage.appHeaderToolbar().clickActionButton("Нумератор");

        addCounterModal.fillName("testcounter");
        addCounterModal.dialogWindowPressButton("Создать");
        sectionPage.checkCounterNameExists("testcounter");
    }

    @Test
    @Link(value = "3cc3d3f2-bb81-44b4-8373-8cfe153b1fda", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3cc3d3f2-bb81-44b4-8373-8cfe153b1fda)")
    @DisplayName("Изменение нумератора в приложении")
    public void numeratorChangeTest() {
        String sectionName = "numeratorChangeTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        String appName = "numeratorChangeApp" + RandomString.get(16);
        elmaBackend.createApplication(sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Название элемента");
        sectionPage.changeTitleTemplate();
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkAppElementExist("1");

        sectionPage.appToolbar().selectSettingsApp("Нумератор");
        sectionPage.changeNumeratorNextNumber("5");
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkAppElementExist("5");
    }

    @Test
    @Link(value = "86d309f9-a833-4d6d-9369-48e4179b99f3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/86d309f9-a833-4d6d-9369-48e4179b99f3)")
    @DisplayName("Проверить удаление раздела")
    public void deleteSectionTest() {
        String sectionName = "deleteSectionTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Удалить раздел");
        sectionActionModal.dialogWindowPressButton("Отмена");
        sectionPage.appToolbar().selectSettingsSections("Удалить раздел");
        sectionActionModal.dialogWindowPressButton("ОК");
        sectionPage.checkSectionDeleted(sectionName);
    }

    @Test
    @Link(value = "994bd126-3d5f-4ae1-a359-b0131c95e5f9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/994bd126-3d5f-4ae1-a359-b0131c95e5f9)")
    @DisplayName("Проверить копирование Раздела")
    public void copySectionTest() {
        String sectionName = "copySectionTest" + RandomString.get(16);
        String newSectionName = "newSectionName" + RandomString.get(16);
        String newSectionLink = "newSectionLink" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Скопировать раздел");
        sectionPage.closeDialogWindow();
        sectionPage.appToolbar().selectSettingsSections("Скопировать раздел");

        sectionActionModal.dialogWindowPressButton("Отмена");
        sectionPage.appToolbar().selectSettingsSections("Скопировать раздел");
        sectionActionModal.dialogWindowPressButton("Начать копирование");
        sectionActionModal.dialogWindowPressButton("Далее");
        sectionPage.enterNameAndLink(newSectionName, newSectionLink);
        sectionActionModal.dialogWindowPressButton("Далее");
        sectionPage.goInCopiedSection();

        sectionPage.checkSectionCopied(newSectionName, newSectionLink);
    }

    @Test
    @Link(value = "2a8b1f94-0119-428c-a37b-2754d3aba83b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/2a8b1f94-0119-428c-a37b-2754d3aba83b)")
    @DisplayName("Проверить настройки видимости")
    public void sectionVisionSettingsTest() {
        String sectionName = "sectionVisionSettingsTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Доступ к Разделу");
        sectionPage.dialogChangeGroupToAdmin();
        sectionActionModal.dialogWindowPressButton("Сохранить");
        CustomDriver.setCookieUser();
        sectionPage.open();
        sectionPage.checkSectionNotVisible(sectionName);
    }

    @Test
    @Link(value = "ff559eec-d979-4cdc-a484-ca2690b4e704", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ff559eec-d979-4cdc-a484-ca2690b4e704)")
    @DisplayName("Проверить экспорт Раздела")
    public void exportSectionTest() {
        String sectionName = "exportSectionTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsSections("Экспорт Раздела");
        sectionExportModal.dialogWindowPressButton("Начать экспорт");
        sectionExportModal.dialogWindowPressButton("Далее");
        sectionExportModal.dialogWindowPressButton("Экспортировать в файл");
        String sectionDescription = "exportSectionDescription" + RandomString.get(16);
        sectionExportModal.exportSectionInFile(sectionDescription);
        sectionExportModal.dialogWindowPressButton("Далее");
        sectionExportModal.clickLinkLoadFile();

        sectionExportModal.checkFileExported(sectionName);
    }

    @Test
    @Link(value = "5696fd13-d490-4fa0-82a1-1e255aa5acd6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/5696fd13-d490-4fa0-82a1-1e255aa5acd6)")
    @DisplayName("Проверить запрос Создать элемент")
    public void createElementWithApiTest() {
        String sectionName = "createElementWithApiTest" + RandomString.get(8);
        String appName = "createElementWithApi" + RandomString.get(8);
        String elementName = "createElementApiName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        apiPage.open(sectionName, appName, "__api");
        apiPage.chooseApiMethod("Создать элемент");
        apiPage.chooseApiAction("Проверить");
        apiPage.enterCreateElementJson(elementName);
        apiPage.pressSendRequestButton();

        apiPage.checkAnswerContain(elementName);
    }

    @Test
    @Link(value = "caa97a1f-5d33-49a0-80b5-2d470d8d3463", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/caa97a1f-5d33-49a0-80b5-2d470d8d3463)")
    @DisplayName("Проверить запрос Получить элемент")
    public void getElementWithApiTest() {
        String sectionName = "getElementWithApiTest" + RandomString.get(8);
        String appName = "getElementWithApi" + RandomString.get(8);
        String elementName = "getElementWithApiName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String elementId = elmaBackend.createElement(elementName, sectionName, appName);

        apiPage.open(sectionName, appName, "__api");
        apiPage.chooseApiMethod("Получить элемент");
        apiPage.chooseApiAction("Проверить");
        apiPage.enterGetElementId(elementId);
        apiPage.pressSendRequestButton();

        apiPage.checkAnswerContain(elementName, elementId);
    }

    @Test
    @Link(value = "6a75a86b-05cf-4b5b-a436-a9137afbd63b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6a75a86b-05cf-4b5b-a436-a9137afbd63b)")
    @DisplayName("Проверить запрос Изменить элемент")
    public void changeElementWithApiTest() {
        String sectionName = "changeElementWithApiTest" + RandomString.get(8);
        String appName = "changeElementWithApi" + RandomString.get(8);
        String elementName = "changeElementWithApiName" + RandomString.get(8);
        String elementNewName = "elementNewName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String elementId = elmaBackend.createElement(elementName, sectionName, appName);

        apiPage.open(sectionName, appName, "__api");
        apiPage.chooseApiMethod("Изменить элемент");
        apiPage.chooseApiAction("Проверить");
        apiPage.enterGetElementId(elementId);
        apiPage.enterCreateElementJson(elementNewName);
        apiPage.pressSendRequestButton();

        apiPage.checkAnswerContain(elementNewName, elementId);
    }

    @Test
    @Link(value = "9d0cc470-d067-4ae5-8b4b-a411438c8e21", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/9d0cc470-d067-4ae5-8b4b-a411438c8e21)")
    @DisplayName("Проверить запрос Изменить статус")
    public void changeElementStatusWithApiTest() {
        String sectionName = "changeElementStatusWithApiTest" + RandomString.get(8);
        String appName = "changeElementStatusWithApi" + RandomString.get(8);
        String elementName = "changeElementStatusWithApiName" + RandomString.get(8);
        String status1 = "status" + RandomString.get(8);
        String status2 = "status" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String elementId = elmaBackend.createElement(elementName, sectionName, appName);

        statusPage.open(sectionName, appName);
        statusPage.appToolbar().selectSettingsApp("Поле \"Статус\"");
        statusPage.clickAddStatusField();
        statusPage.createNewStatus(status1);
        statusPage.createNewStatus(status2);
        statusPage.clickSaveStatuses(sectionName, appName);

        apiPage.open(sectionName, appName, "__api");
        apiPage.chooseApiMethod("Изменить статус");
        apiPage.chooseApiAction("Проверить");
        apiPage.enterGetElementId(elementId);
        apiPage.enterChangeElementStatusJson(status2);
        apiPage.pressSendRequestButton();

        apiPage.checkAnswerContain(elementName, elementId, 2);
    }

    @Test
    @Link(value = "d77acb99-85c9-4fb6-90b8-e81181f130df", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/d77acb99-85c9-4fb6-90b8-e81181f130df)")
    @DisplayName("Проверить запрос на получение Списка элементов")
    public void getElementListWithApiTest() {
        String sectionName = "getElementListWithApiTest" + RandomString.get(8);
        String appName = "getElementListWithApi" + RandomString.get(8);
        String elementName = "getElementListWithApi" + RandomString.get(8);
        String status = "status" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String elementId = elmaBackend.createElement(elementName, sectionName, appName);

        statusPage.open(sectionName, appName);
        statusPage.appToolbar().selectSettingsApp("Поле \"Статус\"");
        statusPage.clickAddStatusField();
        statusPage.createNewStatus(status);
        statusPage.clickSaveStatuses(sectionName, appName);

        apiPage.open(sectionName, appName, "__api");
        apiPage.chooseApiMethod("Список элементов");
        apiPage.chooseApiAction("Проверить");
        apiPage.getElementListJson(elementName, status);
        apiPage.pressSendRequestButton();

        apiPage.checkAnswerContainInArray(elementName, elementId, 1);
    }
}
