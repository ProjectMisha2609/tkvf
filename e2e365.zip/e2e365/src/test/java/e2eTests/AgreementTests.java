package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.backendProcess.BackendProcess;
import infrastructure.elmaBackend.backendProcess.JsonProcess;
import infrastructure.elmaBackend.backendProcess.ProcessInfo;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.DocumentTemplateCreatingModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaModals.WidgetSettingsModal;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.FilePage;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import java.time.LocalDate;
import java.util.Locale;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.MINUTES_1;
import static java.time.LocalDate.now;

@MicronautTest
@Tags({@Tag("express"), @Tag("agreement")})
public class AgreementTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected FilePage filePage;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected BackendProcess backendProcess;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "23b1b16a-b49d-498c-a943-46db5d673be4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/23b1b16a-b49d-498c-a943-46db5d673be4)")
    @DisplayName("Проверить согласование с элементом приложения")
    public void checkAgreementWithAppElementTest() {
        String sectionName = "checkAgreementWithAppElementSectionName" + RandomString.get(8);
        String appName = "checkAgreementWithAppElementAppName" + RandomString.get(8);
        String elementName = "checkAgreementWithAppElementElementName" + RandomString.get(8);
        String businessProcessName = "checkAgreementWithAppElementBusinessProcessName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        ProcessInfo processInfo = backendProcess.createInApplication(sectionName, appName, businessProcessName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/SimpleAgreementProcess.json", processInfo))
                .save();

        businessProcessPage.open("admin/process", processInfo.getId());
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", appName);
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementName);
        createAppElementModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName);
        sectionPage.agreeWithoutComment();
        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(elementName);

        sectionPage.checkInscriptionAgreed("Согласовано");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3415ec9d-1ad8-4870-8806-5e768cebafad", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3415ec9d-1ad8-4870-8806-5e768cebafad)")
    @DisplayName("Проверить согласование с файлом")
    public void checkAgreementWithFileTest() {
        String sectionName = "checkAgreementWithFileSectionName" + RandomString.get(8);
        String businessProcessName = "checkAgreementWithFileBusinessProcessName" + RandomString.get(8);
        String namePhoto = "cats.png";
        String nameFolder = "checkAgreementWithFileFolder" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        //Предусловие - Предварительно создать папку в раздел Файлы - Мои Файлы и загрузить в нее изображение
        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(sectionName, businessProcessName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(namePhoto, businessProcessName);
        sectionPage.clickAgreeButtonAndInputComment(namePhoto);
        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo();

        sectionPage.checkInscriptionAgreed("Согласовано");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "57a50d6b-a803-4a89-b63f-3962408a784e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/57a50d6b-a803-4a89-b63f-3962408a784e)")
    @DisplayName("Проверить отображение резолюции по согласованию на карточке элемента приложения")
    public void checkDisplayOfResolutionByAgreementOnAppElementCardTest() {
        String sectionName = "checkDisplayOfResolutionByAgreementOnAppElementCardSectionName" + RandomString.get(8);
        String appName = "checkDisplayOfResolutionByAgreementOnAppElementCardAppName" + RandomString.get(8);
        String elementName = "checkDisplayOfResolutionByAgreementOnAppElementCardElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.clickButtonSetApprove();
        widgetSettingsModal.setListApprovalAndFamiliarizationUsers(elmaBackend.getUserFIOByEmail(adminLogin));
        sectionPage.refreshPage();

        widgetSettingsModal.checkVisibleListApproval("На согласовании");
        widgetSettingsModal.checkVisibleQuestionMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "6d47ad90-db7c-47e3-b9f3-2a7ad3f908cb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6d47ad90-db7c-47e3-b9f3-2a7ad3f908cb)")
    @DisplayName("Проверить параллельное согласование")
    public void checkParallelAgreementTest() {
        String operatorsGroupName = "users_group" + RandomString.get(8);
        String processName = "checkParallelAgreementBusinessProcessName" + RandomString.get(8);
        String namePhoto = "cats.png";
        String nameFolder = "checkParallelAgreementFolder" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);

        ProcessInfo processInfo = backendProcess.createInCompany(processName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/ProcessApprovalOfFilesForGroup.json", processInfo)
                        .setGroupCode(groupId, "32928604-cfd7-4cf7-a3c1-3878045dd6f7"))
                .save();

        //Предусловие - Предварительно создать папку в раздел Файлы - Мои Файлы и загрузить в нее изображение
        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processInfo.getId());
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", "файл");
        settingsBlockModal.clickButtonParallel();
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Согласовать", processName);

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("tasks/income");

        sectionPage.checkTaskWithNameAppearFromProcess("Согласовать", processName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "6eff9398-17c4-401e-be36-865b12756f8e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6eff9398-17c4-401e-be36-865b12756f8e)")
    @DisplayName("Проверить настройку Оставлять только фактических участников")
    public void checkSettingToLeaveOnlyActualParticipantsTest() {
        String operatorsGroupName = "users_group" + RandomString.get(8);
        String sectionName = "checkSettingToLeaveOnlyActualParticipantsSectionName" + RandomString.get(8);
        String applicationName = "checkSettingToLeaveOnlyActualParticipantsApplicationName" + RandomString.get(8);
        String businessProcessName = "checkSettingToLeaveOnlyActualParticipantsBusinessProcessName" + RandomString.get(8);
        String elementName = "ElementName" + RandomString.get(8);

        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, applicationName);
        elmaBackend.createElement(elementName, sectionName, applicationName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessApprovalOfAppsForGroup.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(applicationName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), applicationName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(applicationName, "", false, false, false)
                        .setGroupCode(groupId)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", applicationName);
        settingsBlockModal.checkBoxLeaveOnlyActualParticipants();
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButtonByName("Выход 1");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(sectionName, businessProcessName);
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.selectAppInModalWindow(elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName);
        sectionPage.agreeWithoutComment();

        sectionPage.openAppElement(sectionName, applicationName, elementName);
        sectionPage.checkInscriptionAgreed("Согласовано");
        // проверить что принял только админ
        sectionPage.checkAgreementListApproverUsers(adminLogin);
        // проверить что в согласовании участвовал только админ
        sectionPage.checkAgreementListParticipantUsers(adminLogin);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "71e3538c-75c6-44c3-a4ed-93471cdadc38", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/71e3538c-75c6-44c3-a4ed-93471cdadc38)")
    @DisplayName("Указать переход по умолчанию")
    public void specifyDefaultTransitionTest() {
        String sectionName = "specifyDefaultTransitionSectionName" + RandomString.get(8);
        String appName = "specifyDefaultTransitionAppName" + RandomString.get(8);
        String processName = "specifyDefaultTransitionProcess" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementDefaultTransitionProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", appName);
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButtonByName("-> Переход по умолчанию");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(appName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        sectionPage.agreeWithoutComment();

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Переход по умолчанию", processName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "978dd99f-3645-41b8-82b6-4f9f10db1143", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/978dd99f-3645-41b8-82b6-4f9f10db1143)")
    @DisplayName("Проверить последовательное согласование")
    public void checkConsistentAgreementTest() {
        String operatorsGroupName = "users_group" + RandomString.get(8);
        String sectionName = "checkParallelAgreementSectionName" + RandomString.get(8);
        String businessProcessName = "checkParallelAgreementBusinessProcessName" + RandomString.get(8);
        String namePhoto = "cats.png";
        String nameFolder = "checkConsistentAgreementFolder" + RandomString.get(8);

        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessApprovalOfFilesForGroup.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .setGroupCode(groupId)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        //Предусловие - Предварительно создать папку в раздел Файлы - Мои Файлы и загрузить в нее изображение
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);
        // редактируем процесс
        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", "файл");
        settingsBlockModal.clickButtonConsistent();
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        // запускаем процесс
        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(sectionName, businessProcessName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        // пока не сменили аккаунт, проверим что файл согласуется обоими пользователями.
        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo();
        widgetSettingsModal.checkVisibleListApproval("На согласовании");
        widgetSettingsModal.checkVisibleQuestionMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        widgetSettingsModal.checkVisibleQuestionMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
        // теперь можно смотреть на кого упала задача
        sectionPage.open("tasks/income");
        if (sectionPage.isTaskBindToCurrentUser("Согласовать", businessProcessName)) {
            // если задача упала на админа - выполняем
            sectionPage.open("tasks/income");
            sectionPage.clickTask("Согласовать", businessProcessName);
            sectionPage.clickAgreeButtonAndInputComment(namePhoto);
            // смотрим что файл ещё согласуется, но админ его принял
            sectionPage.open("files", idFolder);
            filePage.clickByFolderOrPhoto(namePhoto);
            filePage.clickMenuSystemInfo();
            widgetSettingsModal.checkVisibleListApproval("На согласовании");
            widgetSettingsModal.checkVisibleCheckMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
            widgetSettingsModal.checkVisibleQuestionMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
            // заходим под пользователем
            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();
            sectionPage.open("tasks/income");
            // и выполняем задачу
            sectionPage.clickTask("Согласовать", businessProcessName);
            sectionPage.clickAgreeButtonAndInputComment(namePhoto);
            // вернёмся на админскую учётку что бы проверить файл
            CustomDriver.clearStoredData();
            CustomDriver.setCookieAdmin();
        } else {
            // если задача упала на пользака - меняем акк и выполняем
            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();
            sectionPage.open("tasks/income");
            sectionPage.clickTask("Согласовать", businessProcessName);
            sectionPage.clickAgreeButtonAndInputComment(namePhoto);
            // заходим под админом
            CustomDriver.clearStoredData();
            CustomDriver.setCookieAdmin();
            // смотрим что пользователь согласовал файл, но он ещё согласуется
            sectionPage.open("files", idFolder);
            filePage.clickByFolderOrPhoto(namePhoto);
            filePage.clickMenuSystemInfo();
            widgetSettingsModal.checkVisibleListApproval("На согласовании");
            widgetSettingsModal.checkVisibleQuestionMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
            widgetSettingsModal.checkVisibleCheckMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
            // и выполняем задачу
            sectionPage.open("tasks/income");
            sectionPage.clickTask("Согласовать", businessProcessName);
            sectionPage.clickAgreeButtonAndInputComment(namePhoto);
            // остаёмся под администратором бы проконтролировать файл
        }
        // проверяем, что файл согласован обоими пользователями
        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo();
        widgetSettingsModal.checkVisibleListApproval("СОГЛАСОВАНО");
        widgetSettingsModal.checkVisibleCheckMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        widgetSettingsModal.checkVisibleCheckMarkAndUserApproval(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ae180ec0-126c-47e6-afef-55edf2bb2034", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ae180ec0-126c-47e6-afef-55edf2bb2034)")
    @DisplayName("Проверить согласование с различным процентом отказа в условиях перехода")
    public void checkAgreementPercentTest() {
        String sectionName = "checkAgreementPercentSectionName" + RandomString.get(8);
        String appName = "checkAgreementPercentAppName" + RandomString.get(8);
        String processName = "checkAgreementPercentProcess" + RandomString.get(8);
        String operatorsGroupName = "users_group" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementPercentWithTwoTasksAnd.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .setGroupCode(groupId)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", appName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(appName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        sectionPage.agreeWithoutComment();

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("tasks/income");
        sectionPage.clickTask(appName + ": Согласовать");
        sectionPage.refuseWithComment(appName);

        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("50% отказ", processName);

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(appName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        sectionPage.refuseWithComment(appName);

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("tasks/income");
        sectionPage.clickTask(appName + ": Согласовать");
        sectionPage.refuseWithComment(appName);

        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();

        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("100% отказ", processName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "911fbebb-eb14-4ab4-b5ec-dde3272bf90d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/911fbebb-eb14-4ab4-b5ec-dde3272bf90d)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи согласования с типом - точное время")
    public void checkAgreementWithTypeExactTimeTest() {
        int differenceOfDays = 5;
        String namePhoto = "cats.png";
        String nameFolder = "checkAgreementWithTypeExactTimeFolder" + RandomString.get(8);
        String processName = "checkAgreementWithTypeExactTimeProcess" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);

        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        //Предусловие - Предварительно в Файлы - Мои Файлы - в созданную папку загрузить изображение
        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.inputDateLimitDeadline(differenceOfDays);
        settingsBlockModal.removeCheckMarkFromTakeIntoAccountWorkCalendar();
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.checkDifferentDateStartAndFinishDate(processName, differenceOfDays);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e5a5a6a1-4569-47b0-843f-fed4c1a9eeec", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e5a5a6a1-4569-47b0-843f-fed4c1a9eeec)")
    @DisplayName("Проверить прерывание выполнения задачи согласования при просрочке")
    public void checkIfApprovalTaskIsInterruptedInCaseOfDelayTest() {
        int differenceOfTime = 1;
        String namePhoto = "cats.png";
        String nameFolder = "checkIfApprovalTaskIsInterruptedInCaseOfDelayFolder" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);

        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String processName = "checkIfApprovalTaskIsInterruptedInCaseOfDelayProcess" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementWithTaskProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.inputTimeMinuteLimitDeadline(differenceOfTime);
        settingsBlockModal.removeCheckMarkFromTakeIntoAccountWorkCalendar();
        settingsBlockModal.clickCheckboxAbortAndSelectNextStep();
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButtonByName("-> Выход");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 1", processName, MINUTES_1);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e97a7bb3-7854-4ec0-ac51-2e466de0135b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e97a7bb3-7854-4ec0-ac51-2e466de0135b)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи согласования с типом - контекстная переменная")
    public void checkTimeLimitSettingForTaskAgreementWithTypeContextVariableTest() {
        LocalDate date = now().plusDays(5);

        String sectionName = "checkTimeLimitSettingForTaskOfAgreementWithTypeContextVariableSectionName" + RandomString.get(8);
        String appName = "checkTimeLimitSettingForTaskOfAgreementWithTypeContextVariableAppName" + RandomString.get(8);
        String elementName = "checkTimeLimitSettingForTaskOfAgreementWithTypeContextVariableElementName" + RandomString.get(8);
        String processName = "checkTimeLimitSettingForTaskOfAgreementWithTypeContextVariableProcess" + RandomString.get(8);
        String placeRegName = "checkTimeLimitSettingForTaskOfAgreementWithTypeContextVariablePlaceReg" + RandomString.get(4);
        String dossierName = "checkTimeLimitSettingForTaskOfAgreementWithTypeContextVariableDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(4);
        String variableTimerName = "timer" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.clickRadioButtonVariable();
        settingsBlockModal.expandDueDateMenuAndSelect(variableTimerName);
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "00:00");

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkDateFinishTask(processName, date);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f9740e6f-3452-4b29-9fcb-51f79af1b9c1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f9740e6f-3452-4b29-9fcb-51f79af1b9c1)")
    @DisplayName("Изменить название задачи согласования, используя контекстные переменные")
    public void changeNameOfAgreementTaskUsingContextVariablesTest() {
        String namePhoto = "cats.png";
        String nameFolder = "changeNameOfAgreementTaskUsingContextVariablesFolder" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        String variableName = "file" + RandomString.get(8);
        String processName = "checkInterruptionOfAgreementTaskInCaseOfDelayProcess" + RandomString.get(8);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.checkInputFormRowValue("Название задачи",
                "{$" + variableName + "}: Согласовать");
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkTaskWithNameAppearFromProcess("cats.png: Согласовать", processName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "483fa34a-1f57-46fd-ba4d-1ed55720d152", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/483fa34a-1f57-46fd-ba4d-1ed55720d152)")
    @DisplayName("Закрыть согласование элемента приложения с резолюцией Отказано")
    public void closeAgreementOfAppElementWithResolutionRefusedTest() {
        String sectionName = "closeAgreementOfAppElementWithResolutionRefusedSectionName" + RandomString.get(8);
        String appName = "closeAgreementOfAppElementWithResolutionRefusedAppName" + RandomString.get(8);
        String elementName = "closeAgreementOfAppElementWithResolutionRefusedElementName" + RandomString.get(8);
        String processName = "closeAgreementOfAppElementWithResolutionRefusedProcess" + RandomString.get(8);
        String variableName = "application" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessCloseAgreement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласования");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Закрыть");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Объект согласования", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        //Создает приложение
        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.selectAppInModalWindow(elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(processName, elementName + ": Согласовать");
        sectionPage.agreeWithoutComment();

        sectionPage.openAppElement(sectionName, appName, elementName);
        widgetSettingsModal.checkVisibleListApproval("ОТКАЗАНО");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a2878df9-d749-4688-b257-0d958ca4579f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a2878df9-d749-4688-b257-0d958ca4579f)")
    @DisplayName("Закрыть согласование элемента приложения с резолюцией Согласовано")
    public void closeAgreementOfAppElementWithResolutionApprovalTest() {
        String sectionName = "closeAgreementOfAppElementWithResolutionApprovalSectionName" + RandomString.get(8);
        String appName = "closeAgreementOfAppElementWithResolutionApprovalAppName" + RandomString.get(8);
        String elementName = "closeAgreementOfAppElementWithResolutionApprovalElementName" + RandomString.get(8);
        String processName = "closeAgreementOfAppElementWithResolutionApprovalProcess" + RandomString.get(8);
        String variableName = "application" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessCloseAgreement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласования");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Закрыть");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Объект согласования", variableName);
        settingsBlockModal.clickButtonAgreed();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        //Создает приложение
        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.selectAppInModalWindow(elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(processName, elementName + ": Согласовать");
        sectionPage.refuseWithComment(appName);

        sectionPage.openAppElement(sectionName, appName, elementName);
        widgetSettingsModal.checkVisibleListApproval("СОГЛАСОВАНО");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "76ce133f-dcdd-42fa-b7bf-8d924413476f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/76ce133f-dcdd-42fa-b7bf-8d924413476f)")
    @DisplayName("Закрыть согласование файла с резолюцией Отказано")
    public void closeAgreementOfFileWithResolutionRefusedTest() {
        String processName = "closeAgreementOfFileWithResolutionRefusedProcessName" + RandomString.get(8);
        String nameFolder = "closeAgreementResolutionRefusedWithFileFolder" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);
        String namePhoto = "cats.png";
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessCloseAgreement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласования");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Закрыть");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Объект согласования", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(namePhoto, processName);
        sectionPage.clickAgreeButtonAndInputComment(namePhoto);

        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo();

        widgetSettingsModal.checkVisibleListApproval("ОТКАЗАНО");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "61874f09-9e5e-4320-9aa6-1bd8cc5bca75", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/61874f09-9e5e-4320-9aa6-1bd8cc5bca75)")
    @DisplayName("Закрыть согласование файла с резолюцией Согласовано")
    public void closeAgreementOfFileWithResolutionApprovalTest() {
        String processName = "closeAgreementOfFileWithResolutionApprovalProcessName" + RandomString.get(8);
        String nameFolder = "closeAgreementResolutionApprovalWithFileFolder" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);
        String namePhoto = "cats.png";
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessCloseAgreement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласования");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Закрыть");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Объект согласования", variableName);
        settingsBlockModal.clickButtonAgreed();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(namePhoto, processName);
        sectionPage.clickRefuseButtonAndInputComment("Отказано");

        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo();

        widgetSettingsModal.checkVisibleListApproval("СОГЛАСОВАНО");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3384d1a1-b175-4b4f-a212-4d44c4d487b7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3384d1a1-b175-4b4f-a212-4d44c4d487b7)")
    @DisplayName("Проверить настройку \"Использовать пользовательский статус\" в Согласовании с элементом приложения")
    public void checkUserStatusSettingInAgreementToAppElementTest() {
        String sectionName = "checkUserStatusSettingInAgreementToAppElementSectionName" + RandomString.get(8);
        String appName = "checkUserStatusSettingInAgreementToAppElementAppName" + RandomString.get(8);
        String elementName = "checkUserStatusSettingInAgreementToAppElementElementName" + RandomString.get(8);
        String businessProcessName = "checkUserStatusSettingInAgreementToAppElementBusinessProcessName" + RandomString.get(8);
        String variableName = "application" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.chooseTab("Пользовательские статусы");
        settingsBlockModal.setCheckboxConditionByLabel("Использовать пользовательский статус", true);
        settingsBlockModal.setTextInputByFormRowName("Текст кнопки в задаче", "Согласовать условно");
        settingsBlockModal.setTextInputByFormRowName("Текст статуса", "Согласовано с условием");
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.clickExpandAdvancedSearch();
        sectionPage.selectAppInModalWindow(elementName);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(elementName);
        sectionPage.clickFamiliarizationButton("Согласовать условно");

        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(elementName);

        widgetSettingsModal.checkTooltipTextByButtonName("approved", "Согласовано с условием");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3b553df3-4af7-4c8a-8760-f989e7c9d2dc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3b553df3-4af7-4c8a-8760-f989e7c9d2dc)")
    @DisplayName("Проверить пакетное согласование")
    public void checkBatchAgreementTest() {
        String sectionName = "checkBatchAgreementSectionName" + RandomString.get(8);
        String appNameOne = "checkBatchAgreementAppNameOne" + RandomString.get(8);
        String appNameTwo = "checkBatchAgreementAppNameTwo" + RandomString.get(8);
        String elementNameOne = "checkBatchAgreementElementNameOne" + RandomString.get(8);
        String elementNameTwo = "checkBatchAgreementElementNameTwo" + RandomString.get(8);
        String businessProcessName = "checkBatchAgreementProcessName" + RandomString.get(8);
        String variableNameOne = "applicationOne" + RandomString.get(8);
        String variableNameTwo = "applicationTwo" + RandomString.get(8);
        String packageName = "package" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appNameOne);
        elmaBackend.createApplication(sectionName, appNameTwo);
        elmaBackend.createElement(elementNameOne, sectionName, appNameOne);
        elmaBackend.createElement(elementNameTwo, sectionName, appNameTwo);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessPackageFormationWithAgreement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableNameOne, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appNameOne.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableNameOne, "", false, false, false)

                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableNameTwo, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appNameTwo.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableNameTwo, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(packageName, ContextType.REF_ITEM, false))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Формирование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документы для объединения", variableNameOne);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Пакет документов", packageName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документы для объединения", 2, variableNameTwo);
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", packageName);
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);

        settingsBlockModal.clickButtonZoomAllWithRowName(variableNameOne);
        sectionPage.selectAppInModalWindow(elementNameOne);
        settingsBlockModal.clickButtonZoomAllWithRowName(variableNameTwo);
        sectionPage.selectAppInModalWindow(elementNameTwo);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(packageName + ": Согласовать", packageName);
        sectionPage.clickButtonInItemBoxByItemName(elementNameOne, "Оставить комментарий");
        sectionPage.inputComment("ок1");
        settingsBlockModal.clickConfirmDialogButton("Отправить");
        sectionPage.clickButtonInItemBoxByItemName(elementNameTwo, "Оставить комментарий");
        sectionPage.inputComment("ок2");
        sectionPage.clickConfirmDialogButton("Отправить");
        sectionPage.clickFamiliarizationButton("Согласовать");

        sectionPage.open(sectionName, appNameOne);
        sectionPage.clickOnCardApp(elementNameOne);

        widgetSettingsModal.checkVisibleListApproval("Пакет согласован");
        widgetSettingsModal.checkTooltipTextByButtonName("file", "Посмотреть пакет");

        sectionPage.open(sectionName, appNameTwo);
        sectionPage.clickOnCardApp(elementNameTwo);

        widgetSettingsModal.checkVisibleListApproval("Пакет согласован");
        widgetSettingsModal.checkTooltipTextByButtonName("file", "Посмотреть пакет");
    }

    //TODO: тест с багом, проходит только на t-elma365
    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "23df5f9e-51d5-4c89-94f6-bfc97c942b5d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/23df5f9e-51d5-4c89-94f6-bfc97c942b5d)")
    @DisplayName("Проверить настройку \"Использовать пользовательский статус\" в Согласовании с файлом")
    public void checkUserStatusSettingInAgreementWithFileTest() {
        String businessProcessName = "checkUserStatusSettingInAgreementWithFileBusinessProcessName" + RandomString.get(8);
        String variableName = "file" + RandomString.get(8);
        String namePhoto = "cats.png";
        String nameFolder = "checkUserStatusSettingInAgreementWithFile" + RandomString.get(8);
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);

        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open("files", idFolder);
        filePage.uploadingPhotos("/testData/images/" + namePhoto);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Что отправляем на согласование", variableName);
        settingsBlockModal.chooseTab("Пользовательские статусы");
        settingsBlockModal.setCheckboxConditionByLabel("Использовать пользовательский статус", true);
        settingsBlockModal.setTextInputByFormRowName("Текст кнопки в задаче", "Согласовать условно");
        settingsBlockModal.setTextInputByFormRowName("Текст статуса", "Согласовано с условием");
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButton();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(businessProcessName);
        sectionPage.selectFileFromSection(nameFolder, namePhoto);
        sectionPage.clickNextStageOrExit();
        //TODO: на t-elma365 не появляется alert с текст "Запущен процесс"
//        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");
        sectionPage.clickTask(namePhoto, businessProcessName);
        sectionPage.clickModalHeaderButton(" Согласовать условно");
        settingsBlockModal.clickConfirmDialogButton("Согласовать");

        sectionPage.open("files", idFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.clickMenuSystemInfo("Листы согласования");

        widgetSettingsModal.checkTooltipTextByButtonName("approved", "Согласовано с условием");
    }
}