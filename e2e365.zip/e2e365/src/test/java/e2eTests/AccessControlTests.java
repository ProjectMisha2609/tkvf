package e2eTests;

import com.codeborne.selenide.Selenide;
import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.backendProcess.BackendProcess;
import infrastructure.elmaBackend.backendProcess.JsonProcess;
import infrastructure.elmaBackend.backendProcess.ProcessInfo;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateAppElementModal;
import pages.elmaModals.ProcessInstanceModal;
import pages.elmaPages.*;

import java.util.Locale;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("access_control")})
public class AccessControlTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected FilePage filePage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected ProcessInstanceModal processInstanceModal;
    @Inject
    protected ProcessMonitorPage processMonitorPage;
    @Inject
    protected BackendProcess backendProcess;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3dd19c23-6f74-4360-9a6d-78ff7b15b785", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3dd19c23-6f74-4360-9a6d-78ff7b15b785)")
    @DisplayName("Добавить пользователю дополнительные права")
    @Link(value = "3dd19c23-6f74-4360-9a6d-78ff7b15b785", type = ELMA_TMS)
    public void addAdditionalRightsToUserTest() {
        String namePhoto = "cats.jpg";
        String nameFolder = "addAdditionalRightsToUser" + RandomString.get(8);
        // Файл загружается в новую папку, что бы избежать дублирования имён, приводящего к имени файла cats({номер дубликата}).jpg.
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        mainPage.open("files", idFolder);
        mainPage.sectionToolbar().selectSectionByCode("files");
        filePage.uploadingPhotos("/testData/" + namePhoto);

        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.clickByFolderOrPhoto(nameFolder);
        filePage.clickMenuHorizontal(namePhoto);
        filePage.selectFromMenuHorizontal("Управление доступом");
        filePage.giveUserRightViewFile(userLogin);
        filePage.clickButtonSelect();
        filePage.clickButtonSave();
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.checkMenuVertical();
        String fullUrl = CustomDriver.getCurrentUrl();

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        Selenide.open(fullUrl);

        filePage.checkMenuVertical();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "02acea56-17df-4eb5-9ede-ec2aef70d977", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/02acea56-17df-4eb5-9ede-ec2aef70d977)")
    @DisplayName("Проверить наследование прав родительской папки")
    @Link(value = "02acea56-17df-4eb5-9ede-ec2aef70d977", type = ELMA_TMS)
    public void checkInheritanceOfRightsOfParentFolderTest() {
        String namePhoto = "cats.jpg";
        String nameFolder = "checkInheritanceOfRightsOfParentFolder" + RandomString.get(8);
        //Предусловие - Предварительно создать папку в раздел Файлы - Мои Файлы и загрузить в нее изображение
        String idFolder = elmaBackend.createFolderInMyFilePageByUserLogin(nameFolder, adminLogin);
        mainPage.open("files", idFolder);
        mainPage.sectionToolbar().selectSectionByCode("files");
        filePage.uploadingPhotos("/testData/" + namePhoto);

        mainPage.open("files", elmaBackend.getUserIdByEmail(adminLogin));
        filePage.clickMenuHorizontal(nameFolder);
        filePage.selectFromMenuHorizontal("Управление доступом");
        filePage.giveUserRightViewFile(userLogin);
        filePage.clickButtonSelect();
        filePage.clickButtonSave();
        filePage.clickByFolderOrPhoto(nameFolder);
        filePage.clickByFolderOrPhoto(namePhoto);
        filePage.checkMenuVertical();
        String fullUrl = CustomDriver.getCurrentUrl();

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        Selenide.open(fullUrl);

        filePage.checkMenuVertical();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "6beb4d6a-c80f-4940-9be1-70b3156cfdc5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6beb4d6a-c80f-4940-9be1-70b3156cfdc5)")
    @DisplayName("Проверить отображение на карточке элемента возможность назначать права")
    public void checkDisplayOnCardOfElementAbilityToAssignRightsTest() {
        String sectionName = "ElementAbilityToAssignRightsSectionName" + RandomString.get(8);
        String appName = "ElementAbilityToAssignRightsAppName" + RandomString.get(8);
        String elementName = "ElementAbilityToAssignRightsElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickLimitAccess("На уровне элементов Приложения");
        sectionPage.clickSaveAccess();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists(appName + " успешно создан");
        sectionPage.clickOnCardApp(elementName);
        sectionPage.clickAccessRightButton();


        sectionPage.clickButtonAddInAccessRights();
        sectionPage.addRightToGroupViaInputField("Администраторы");
        sectionPage.clickButtonSelect();

        sectionPage.checkInBlockAdditionalRightsAddRight("Администраторы");

        sectionPage.clickButtonAddInAccessRights();
        sectionPage.addUserRights(adminLogin);
        sectionPage.clickButtonSelect();

        sectionPage.checkInBlockAdditionalRightsAddRight(elmaBackend.getUserSurnameAndNameByEmail(adminLogin));

        sectionPage.clickButtonAddInAccessRights();
        sectionPage.addRightToOrgStructure("Генеральный директор");
        sectionPage.clickButtonSelect();

        sectionPage.checkInBlockAdditionalRightsAddRight("Генеральный директор");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3ab4176a-d02c-491b-8dbe-73e7831452c6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3ab4176a-d02c-491b-8dbe-73e7831452c6)")
    @DisplayName("Ограничить доступ к данным. На уровне Приложения. Полный доступ")
    public void restrictAccessToDataAtAppLevelFullAccessTest() {
        String sectionName = "restrictAccessToDataAtAppLevelFullAccessSectionName" + RandomString.get(8);
        String appName = "restrictAccessToDataAtAppLevelFullAccessAppName" + RandomString.get(8);
        String elementName = "restrictAccessToDataAtAppLevelFullAccessElementName" + RandomString.get(8);
        String processName = "restrictAccessToDataAtAppLevelFullAccessProcess" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        ProcessInfo processInfo = backendProcess.createInApplication(sectionName, appName, processName);
        backendProcess.action(new JsonProcess("testData/JsonProcess/SimpleProcess.json", processInfo)).publication();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.setCheckboxInTableByColumnNameAndNameInRow("Полный доступ", "Все пользователи", true);
        sectionPage.setCheckboxInTableByColumnNameAndNameInRow("Полный доступ", "Все пользователи", false);
        sectionPage.clickButtonOnConfigPage("Сохранить");

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementName);
        createAppElementModal.clickModalFooterButton("settings");
        createAppElementModal.clickModalFooterButton("system_add_round");
        createAppElementModal.selectPopoverOptionByName("Добавить кнопку \"Удалить\"");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        mainPage.checkButtonOnAppContentNotExist("+ " + appName);
        sectionPage.clickOnCardApp(elementName);

        createAppElementModal.checkNameButtonInFooterModalWindowNotExists("Редактировать");
        createAppElementModal.checkNameButtonInFooterModalWindowNotExists("Удалить");
        sectionPage.clickTaskInTaskBlock();

        processMonitorPage.checkTabList("История");
        processInstanceModal.checkButtonInterruptProcessNotExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e7292f06-c76d-4be7-8fcb-eca366e09b06", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e7292f06-c76d-4be7-8fcb-eca366e09b06)")
    @DisplayName("Ограничить доступ к данным. На уровне Приложения. Управление процессами")
    public void restrictAccessToDataAtAppLevelProcessManagementTest() {
        String sectionName = "restrictAccessToDataAtAppLevelProcessManagementSectionName" + RandomString.get(8);
        String appName = "restrictAccessToDataAtAppLevelProcessManagementAppName" + RandomString.get(8);
        String elementName = "restrictAccessToDataAtAppLevelProcessManagementElementName" + RandomString.get(8);
        String processName = "restrictAccessToDataAtAppLevelProcessManagementProcess" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickProcessManagementCheckbox();
        sectionPage.clickSaveAccess();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.clickTaskInTaskBlock();

        processMonitorPage.checkTabList("История");
        processInstanceModal.checkButtonInterruptProcessNotExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "d4f71d07-1810-42e7-b781-d3b1576f1f29", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d4f71d07-1810-42e7-b781-d3b1576f1f29)")
    @DisplayName("Ограничить доступ к данным. На уровне Приложения. Редактирование и Удаление")
    public void restrictAccessToDataAtAppLevelEditingAndDeletingTest() {
        String sectionName = "restrictAccessToDataAtAppLevelEditingAndDeletingSectionName" + RandomString.get(8);
        String appName = "restrictAccessToDataAtAppLevelEditingAndDeletingAppName" + RandomString.get(8);
        String elementName = "restrictAccessToDataAtAppLevelEditingAndDeletingElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickUpdateCheckbox();
        sectionPage.clickDeleteCheckbox();
        sectionPage.clickSaveAccess();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists(appName + " успешно создан");
        sectionPage.clickOnCardApp(elementName);

        createAppElementModal.clickModalFooterButton("settings");
        createAppElementModal.clickModalFooterButton("system_add_round");
        createAppElementModal.selectPopoverOptionByName("Добавить кнопку \"Удалить\"");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(elementName);

        createAppElementModal.checkNameButtonInFooterModalWindowNotExists("Редактировать");
        createAppElementModal.checkNameButtonInFooterModalWindowNotExists("Удалить");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b35720cb-9e31-4c5b-92bf-a22910b98c4b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b35720cb-9e31-4c5b-92bf-a22910b98c4b)")
    @DisplayName("Ограничить доступ к данным. На уровне Приложения. Создание")
    public void restrictAccessToDataAtAppLevelCreationTest() {
        String sectionName = "restrictAccessToDataAtAppLevelCreationSectionName" + RandomString.get(8);
        String appName = "restrictAccessToDataAtAppLevelCreationAppName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");
        sectionPage.clickLimitAccess("Ограничить доступ к данным");
        sectionPage.clickAccessCreateCheckbox();
        sectionPage.clickSaveAccess();

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);

        mainPage.checkButtonOnAppContentNotExist("+ " + appName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "3c5e1ad8-b5aa-421b-ab87-909a52de1065", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3c5e1ad8-b5aa-421b-ab87-909a52de1065)")
    @DisplayName("У всех пользователей есть доступ к Приложению и ко всем его полям")
    public void allUsersHaveAccessToAppAndAllItsFieldsTest() {
        String sectionName = "allUsersHaveAccessToAppAndAllItsFieldsSectionName" + RandomString.get(8);
        String appName = "allUsersHaveAccessToAppAndAllItsFieldsAppName" + RandomString.get(8);
        String elementName = "allUsersHaveAccessToAppAndAllItsFieldsElementName" + RandomString.get(8);
        String processName = "allUsersHaveAccessToAppAndAllItsFieldsProcess" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName, appName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.fillName(elementName);
        sectionPage.clickSaveButton();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.openAppElement(sectionName, appName, elementName);
        createAppElementModal.clickModalFooterButton("settings");
        createAppElementModal.clickModalFooterButton("system_add_round");
        createAppElementModal.selectPopoverOptionByName("Добавить кнопку \"Удалить\"");
        sectionPage.clickTaskInTaskBlock();

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open(sectionName, appName);
        mainPage.checkButtonOnAppContentExist("+ " + appName);
        sectionPage.clickOnCardApp(elementName);

        createAppElementModal.checkNameButtonInFooterModalWindowExists("Редактировать");
        createAppElementModal.checkNameButtonInFooterModalWindowExists("Удалить");
        sectionPage.clickTaskInTaskBlock();
        processInstanceModal.checkButtonInterruptProcessExist();
    }
}