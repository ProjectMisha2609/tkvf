package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.AddGroupOrRoleModal;
import pages.elmaPages.*;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("groups")})
public class GroupsTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected AddGroupOrRoleModal addGroupOrRoleModal;
    @Inject
    protected AdminSectionPage adminSectionPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected DocumentTemplatesPage documentTemplatesPage;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5b36e0b3-fec1-4610-af08-0a6c16f4c48b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5b36e0b3-fec1-4610-af08-0a6c16f4c48b)")
    @DisplayName("Редактировать роль с указанием нового описания")
    public void editRoleWithNewDescriptionTest() {
        String roleName = "roleName" + RandomString.get(8);
        String text = "editRoleWithNewDescriptionTest" + RandomString.get(8);
        String idRole = elmaBackend.createNewRole(roleName);

        adminSectionPage.openRole(idRole);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        addGroupOrRoleModal.fillDescription(text);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Описание", text);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "33584df0-66a8-4595-8d75-2c3590e57c32", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/33584df0-66a8-4595-8d75-2c3590e57c32)")
    @DisplayName("Редактировать роль с указанием нового названия")
    public void editRoleWithNewNameTest() {
        String roleName = "roleName" + RandomString.get(8);
        String newRoleName = "newRoleName" + RandomString.get(8);
        String idRole = elmaBackend.createNewRole(roleName);

        adminSectionPage.openRole(idRole);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        addGroupOrRoleModal.clearFillName();
        addGroupOrRoleModal.fillName(newRoleName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkModalWindowHeader(newRoleName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "2a7a88c8-d6dc-43ff-9cd8-ea681c2bbec2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2a7a88c8-d6dc-43ff-9cd8-ea681c2bbec2)")
    @DisplayName("Редактировать роль с изменением участника-пользователя")
    public void editRoleWithMemberUserTest() {
        String roleName = "roleName" + RandomString.get(8);
        String idRole = elmaBackend.createNewRole(roleName, null, elmaBackend.getUserIdByEmail(userLogin));
        String userName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        adminSectionPage.openRole(idRole);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        adminSectionPage.clickLoupeButtonByFormRowName("");
        sectionPage.addUserRights(adminLogin);
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", userName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ebbadcec-1b7b-4dd0-b9b1-0d83077a102c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ebbadcec-1b7b-4dd0-b9b1-0d83077a102c)")
    @DisplayName("Проверить корректность отображения данных на карточке роли")
    public void checkCorrectnessOfDataDisplayOnRoleCardTest() {
        String roleName = "roleName" + RandomString.get(8);
        String roleDescription = "roleDescription" + RandomString.get(8);
        String idRole = elmaBackend.createNewRole(roleName, roleDescription, elmaBackend.getUserIdByEmail(adminLogin));

        adminSectionPage.openRole(idRole);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        addGroupOrRoleModal.checkModalWindowHeader(roleName);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Описание", roleDescription);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9fdd9d90-00a4-4050-8354-e6ac3aafa2d3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9fdd9d90-00a4-4050-8354-e6ac3aafa2d3)")
    @DisplayName("Добавить роль с выбором пользователей через ввод текста в поле")
    public void addRoleWithUserSelectionByEnteringTextInFieldTest() {
        String roleName = "roleName" + RandomString.get(8);
        String name = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(roleName);
        addGroupOrRoleModal.clickRoleSelect();
        sectionPage.addUserRightsViaInputField(name);
        addGroupOrRoleModal.checkInputFormRowValue("Список участников группы", name);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(roleName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", name);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e4800a17-432c-4bb4-af6a-53ebbb463192", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e4800a17-432c-4bb4-af6a-53ebbb463192)")
    @DisplayName("Добавить роль с выбором пользователей - элементов орг структуры через луп")
    public void editRoleWithOrgStructureTest() {
        String roleName = "roleName" + RandomString.get(8);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(roleName);
        addGroupOrRoleModal.clickRoleSelect();
        adminSectionPage.clickLoupeButtonByFormRowName("Список участников группы");
        sectionPage.addRightToOrgStructure("Генеральный директор");
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.checkInputFormRowValue("Список участников группы", "Генеральный директор");
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(roleName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", "Генеральный директор");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "0d8bb4a4-a0bd-40b9-bccc-0669900d5a89", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0d8bb4a4-a0bd-40b9-bccc-0669900d5a89)")
    @DisplayName("Добавить роль с выбором пользователя через лупу")
    public void ddRoleWithUserSelectionTest() {
        String roleName = "roleName" + RandomString.get(8);
        String userName = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(roleName);
        addGroupOrRoleModal.clickRoleSelect();
        adminSectionPage.clickLoupeButtonByFormRowName("");
        sectionPage.addUserRightsViaInputField(userName);
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.checkInputFormRowValue("Список участников группы", userName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(roleName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", userName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "14dda517-b162-452c-98be-16743ecb04fc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/14dda517-b162-452c-98be-16743ecb04fc)")
    @DisplayName("Добавить роль, не заполнив обязательные поля")
    public void addRoleWithoutFillingInRequiredFieldsTest() {
        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.clickRoleSelect();
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");

        addGroupOrRoleModal.checkNameFieldHighlightedInRed();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "25c3da18-70c8-4a2a-926b-9348715abb5a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/25c3da18-70c8-4a2a-926b-9348715abb5a)")
    @DisplayName("Добавить роль с заполнением только обязательных полей")
    public void addRoleWithFillingInRequiredFieldsTest() {
        String roleName = "roleName" + RandomString.get(8);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(roleName);
        addGroupOrRoleModal.clickRoleSelect();
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(roleName);

        documentTemplatesPage.checkSectionContentExists(roleName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a4fe7312-23f1-43c4-821b-997c03401272", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a4fe7312-23f1-43c4-821b-997c03401272)")
    @DisplayName("Добавить роль с заполнением всех полей")
    public void addRoleWithAllFieldsFilledTest() {
        String roleName = "roleName" + RandomString.get(8);
        String name = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(roleName);
        addGroupOrRoleModal.fillDescription(roleName);
        addGroupOrRoleModal.clickRoleSelect();
        sectionPage.addUserRightsViaInputField(name);
        addGroupOrRoleModal.checkInputFormRowValue("Список участников группы", name);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(roleName);

        documentTemplatesPage.checkSectionContentExists(roleName);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Описание", roleName);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", name);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "7c9f5be4-b4cd-4ae2-9d7e-790161a73b0e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7c9f5be4-b4cd-4ae2-9d7e-790161a73b0e)")
    @DisplayName("Проверить работу кнопки Справка")
    public void checkOperationOfHelpButtonTest() {
        String expectedUrl = "https://elma365.com/ru/help/360007146071.html";

        adminSectionPage.open("admin/groups");

        mainPage.checkHelpButton(expectedUrl);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "94232f70-c104-4d8d-a89a-75cf1fa23323", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/94232f70-c104-4d8d-a89a-75cf1fa23323)")
    @DisplayName("Редактировать группу с указанием нового описания")
    public void editGroupWithNewDescriptionTest() {
        String groupName = "groupName" + RandomString.get(8);
        String groupDescription = "groupDescription" + RandomString.get(8);
        String groupId = elmaBackend.createCompanyGroup(groupName);

        adminSectionPage.openRole(groupId);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        addGroupOrRoleModal.fillDescription(groupDescription);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Описание", groupDescription);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a46c8c3e-8915-4abf-864b-2545c7cd96c8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a46c8c3e-8915-4abf-864b-2545c7cd96c8)")
    @DisplayName("Редактировать группу с изменением значения поля группа по умолчанию")
    public void editGroupByChangingValueOfDefaultGroupFieldTest() {
        String groupName = "groupName" + RandomString.get(8);
        String groupId = elmaBackend.createCompanyGroup(groupName);

        adminSectionPage.openRole(groupId);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        interfaceDesignerPage.clickButtonYesInApplicationElement();
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Группа по умолчанию", "Да");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4cbefad3-08de-4af0-b3d7-82ddfa9f5f64", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4cbefad3-08de-4af0-b3d7-82ddfa9f5f64)")
    @DisplayName("Редактировать группу с указанием нового названия")
    public void editGroupWithNewNameTest() {
        String groupName = "groupName" + RandomString.get(8);
        String newGroupName = "groupNewName" + RandomString.get(8);
        String groupId = elmaBackend.createCompanyGroup(groupName);

        adminSectionPage.openRole(groupId);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        addGroupOrRoleModal.clearFillName();
        addGroupOrRoleModal.fillName(newGroupName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkModalWindowHeader(newGroupName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "53e6363d-9e4e-49f5-9716-702a5f0b25b0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/53e6363d-9e4e-49f5-9716-702a5f0b25b0)")
    @DisplayName("Редактировать группу с удалением участников из списка")
    public void editGroupWithRemovalOfMembersFromListTest() {
        String groupName = "groupName" + RandomString.get(8);
        String groupId = elmaBackend.createCompanyGroup(groupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));

        adminSectionPage.openRole(groupId);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        addGroupOrRoleModal.clickRemoveButtonByUser(elmaBackend.getUserSurnameAndNameByEmail(userLogin));
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "53e6363d-9e4e-49f5-9716-702a5f0b25b0", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/53e6363d-9e4e-49f5-9716-702a5f0b25b0)")
    @DisplayName("Проверить отображение данных на карточке группы")
    public void checkGroupCardDataDisplayTest() {
        String groupName = "groupName" + RandomString.get(8);
        String groupDescription = "groupDescription" + RandomString.get(8);
        String groupId = elmaBackend.createNewGroup(groupName, groupDescription, elmaBackend.getUserIdByEmail(adminLogin));

        adminSectionPage.openRole(groupId);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        addGroupOrRoleModal.checkModalWindowHeader(groupName);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Описание", groupDescription);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Группа по умолчанию", "Нет");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e5881492-507d-432b-9f07-78434a0e9917", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e5881492-507d-432b-9f07-78434a0e9917)")
    @DisplayName("Редактировать группу с указанием новых участников")
    public void checkEditGroupWithNewMembersTest() {
        String groupName = "groupName" + RandomString.get(8);
        String groupId = elmaBackend.createNewGroup(groupName, "", elmaBackend.getUserIdByEmail(adminLogin));
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);

        adminSectionPage.openRole(groupId);
        addGroupOrRoleModal.clickModalFooterButton("Редактировать");
        sectionPage.addUserRightsViaInputField(userName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно изменена");

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", userName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "a4fe7312-23f1-43c4-821b-997c03401272", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a4fe7312-23f1-43c4-821b-997c03401272)")
    @DisplayName("Добавить группу по умолчанию")
    public void addDefaultGroupTest() {
        String groupName = "groupName" + RandomString.get(8);
        String name = elmaBackend.getUserSurnameAndNameByEmail(adminLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(groupName);
        interfaceDesignerPage.clickButtonYesInApplicationElement();
        sectionPage.addUserRightsViaInputField(name);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(groupName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Группа по умолчанию", "Да");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5c023849-59a0-4741-850c-e064df3af5ad", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5c023849-59a0-4741-850c-e064df3af5ad)")
    @DisplayName("Добавить группу с выбором пользователей через ввод текста в поле")
    public void addGroupWithUserSelectionByTextEntryTest() {
        String groupName = "groupName" + RandomString.get(8);
        String name = elmaBackend.getUserSurnameAndNameByEmail(userLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(groupName);
        sectionPage.addUserRightsViaInputField(name);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(groupName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", name);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "1a9de99b-b536-4ce6-a4e4-8152894721d7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1a9de99b-b536-4ce6-a4e4-8152894721d7)")
    @DisplayName("Добавить группу с выбором пользователей - элементов орг структуры через лупу")
    public void editGroupWithOrgStructureTest() {
        String groupName = "editGroupWithOrgStructure" + RandomString.get(8);
        String generalDirector = "Генеральный директор";

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(groupName);
        adminSectionPage.clickLoupeButtonByFormRowName("");
        sectionPage.addRightToOrgStructure(generalDirector);
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.checkRemoveButtonByUser(generalDirector);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(groupName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", generalDirector);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "6243951e-c55c-4100-ae2e-d1a6ceecf873", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6243951e-c55c-4100-ae2e-d1a6ceecf873)")
    @DisplayName("Добавить группу с выбором пользователей - групп через лупу")
    public void editGroupWithGroupTest() {
        String groupName = "groupName" + RandomString.get(8);
        String newGroupName = "newGroupName" + RandomString.get(8);
        elmaBackend.createCompanyGroup(groupName);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(newGroupName);
        adminSectionPage.clickLoupeButtonByFormRowName("");
        sectionPage.addRightToGroupViaInputField(groupName);
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.checkRemoveButtonByUser(groupName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(newGroupName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", groupName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "cf00a3bd-6df9-4d43-a7bd-bb257def2bfb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cf00a3bd-6df9-4d43-a7bd-bb257def2bfb)")
    @DisplayName("Добавить группу с выбором пользователей через лупу")
    public void editGroupWithUserTest() {
        String groupName = "groupName" + RandomString.get(8);
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(groupName);
        adminSectionPage.clickLoupeButtonByFormRowName("");
        sectionPage.addUserRights(userLogin);
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.checkRemoveButtonByUser(userName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(groupName);

        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", userName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "135c66e6-ccb4-406f-b53a-6c5b79ad3c1d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/135c66e6-ccb4-406f-b53a-6c5b79ad3c1d)")
    @DisplayName("Добавить группу, не заполнив обязательные поля")
    public void addGroupWithoutFillingInRequiredFieldsTest() {
        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");

        addGroupOrRoleModal.checkNameFieldHighlightedInRed();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "baf5f8ac-74a7-414a-9cd1-0ca645c836f1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/baf5f8ac-74a7-414a-9cd1-0ca645c836f1)")
    @DisplayName("Добавить группу с заполнением только обязательных полей")
    public void addGroupWithFillingInRequiredFieldsTest() {
        String groupName = "groupName" + RandomString.get(8);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(groupName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(groupName);

        documentTemplatesPage.checkSectionContentExists(groupName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "47c67ccf-fa6b-42a0-8f6d-f18d8bfa3729", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/47c67ccf-fa6b-42a0-8f6d-f18d8bfa3729)")
    @DisplayName("Добавить группу с заполнением всех полей")
    public void addGroupWithAllFieldsFilledTest() {
        String groupName = "groupName" + RandomString.get(8);
        String userName = elmaBackend.getUserSurnameAndNameByEmail(userLogin);

        adminSectionPage.open("admin/groups");
        mainPage.clickButtonOnAppContent("Группа");
        addGroupOrRoleModal.fillName(groupName);
        addGroupOrRoleModal.fillDescription(groupName);
        adminSectionPage.clickLoupeButtonByFormRowName("");
        sectionPage.addUserRights(userLogin);
        sectionPage.clickButtonSelect();
        addGroupOrRoleModal.checkRemoveButtonByUser(userName);
        addGroupOrRoleModal.clickModalFooterButton("Сохранить");
        adminSectionPage.checkAlertWithTextFragmentExists("Группа успешно создана");
        documentTemplatesPage.pressSection("Группы компании");
        documentTemplatesPage.pressSection(groupName);

        documentTemplatesPage.checkSectionContentExists(groupName);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Описание", groupName);
        addGroupOrRoleModal.checkNameContextWidgetOnGroupOrRoleModal("Список участников группы", userName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "ce8a0712-6fc0-4025-a742-8b24568e5c5d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ce8a0712-6fc0-4025-a742-8b24568e5c5d)")
    @DisplayName("Проверить корректность отображения списка групп и ролей")
    public void checkGroupAndRoleListDisplayTest() {
        String groupName = "groupName" + RandomString.get(8);
        elmaBackend.createNewGroup(groupName, null, null);

        adminSectionPage.open("admin/groups");
        documentTemplatesPage.pressSection("Группы компании");

        mainPage.checkButtonOnAppContentExist("Группа");
        documentTemplatesPage.checkSectionContentExists(groupName);
    }
}
