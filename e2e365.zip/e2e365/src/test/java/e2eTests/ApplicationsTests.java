package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendCrm;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("app_page")})
public class ApplicationsTests {
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SelectAppModal selectAppModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected StatusPage statusPage;
    @Inject
    protected CreateAppElementModal createAppElementModal;
    @Inject
    protected ExportElementsModal exportElementsModal;
    @Inject
    protected ImportElementsModal importElementsModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SignSettingsModal signSettingsModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected MainPage mainPage;

    @Test
    @Link(value = "fcc6ed0a-e508-4102-8761-feb746e1242b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/fcc6ed0a-e508-4102-8761-feb746e1242b)")
    @DisplayName("Создать элемент приложения")
    public void createApplicationElementTest() {
        String sectionName = "createApplicationElementTest" + RandomString.get(16);
        elmaBackend.createSection(sectionName);
        String appName = "CreateApplicationElementApp" + RandomString.get(8);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName("appElementNameTest");
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkToastAppeared();
    }

    @Test
    @Link(value = "630bcd25-660e-4c12-83e2-4387947734c1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/630bcd25-660e-4c12-83e2-4387947734c1)")
    @DisplayName("Простой режим. Проверить отображение свойств простого типа на форме")
    public void addSimplePropertyOnFormTest() {
        String sectionName = "addSimplePropertyOnFormTest" + RandomString.get(16);
        String appName = "addSimplePropertyOnFormTest" + RandomString.get(8);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Строка");
        appFormSettingsModal.dragAndDropProperty("Число");
        appFormSettingsModal.dragAndDropProperty("Выбор «да/нет»");
        appFormSettingsModal.dragAndDropProperty("Дата/время");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.fillName(elementAppName);
        createAppElementModal.fillFieldString("qwerty");
        createAppElementModal.fillFieldNumber("123456");
        createAppElementModal.clickFieldTypeBoolTrue();
        createAppElementModal.clickTodayInFieldDateTime();
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkHeaderTitleCard(elementAppName);
    }

    @Test
    @Link(value = "7208b304-88c7-4e94-90fe-47e3b7c267a2", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7208b304-88c7-4e94-90fe-47e3b7c267a2)")
    @DisplayName("Простой режим. Проверить отображение свойств типа \"Приложение\" на форме")
    public void addAppPropertyOnFormTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String companyName = RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        backendCrm.createCompany(companyName, RandomString.getUUID());

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Приложение");
        appFormSettingsModal.clickSelectApp();

        selectAppModal.clickSectionInModal("CRM");
        selectAppModal.clickAppInModal("Компании");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.fillName(elementAppName);
        createAppElementModal.setTextInputWithSearchByFormRowName("Компания", companyName);
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkHeaderTitleCard(elementAppName);
    }

    @Test
    @Link(value = "8c8e133d-8747-48e3-b5ef-fc303ae48184", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8c8e133d-8747-48e3-b5ef-fc303ae48184)")
    @DisplayName("Расширенный режим. Проверить отображение свойства простого типа на форме")
    public void addSimplePropertyOnFormAdvancedModeTest() {
        String sectionName = "addSimplePropertyOnFormAdvancedModeTest" + RandomString.get(16);
        String appName = "addSimplePropertyOnFormAdvancedModeTest" + RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickAddContext();

        createContextModal.fillContextName("Строка");
        createContextModal.dialogWindowPressButton("Создать");
        appFormSettingsModal.clickAddContext();
        createContextModal.fillContextName("Число");
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextNumber();
        createContextModal.dialogWindowPressButton("Создать");
        appFormSettingsModal.clickAddContext();
        createContextModal.fillContextName("Выбор «да/нет»");
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextBool();
        createContextModal.dialogWindowPressButton("Создать");
        appFormSettingsModal.clickAddContext();
        createContextModal.fillContextName("Дата/время");
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextDateTime();
        createContextModal.dialogWindowPressButton("Создать");
        appFormSettingsModal.clickCreateTab();
        appFormSettingsModal.movePropertyOnForm("Строка");
        appFormSettingsModal.movePropertyOnForm("Число");
        appFormSettingsModal.movePropertyOnForm("Выбор «да/нет»");
        appFormSettingsModal.movePropertyOnForm("Дата/время");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementAppName);
        createAppElementModal.fillFieldString("qwerty");
        createAppElementModal.fillFieldNumber("123456");
        createAppElementModal.clickFieldTypeBoolTrue();
        createAppElementModal.clickTodayInFieldDateTime();
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkHeaderTitleCard(elementAppName);
    }

    @Test
    @Link(value = "dd7a48b8-b428-4ba2-8b00-d21f1f7ac41b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/dd7a48b8-b428-4ba2-8b00-d21f1f7ac41b)")
    @DisplayName("Расширенный режим. Проверить отображение свойства типа Приложение на форме")
    public void addAppPropertyOnFormAdvancedModeTest() {
        String sectionName = "addAppPropertyOnFormAdvancedModeTest" + RandomString.get(16);
        String appName = "addAppPropertyOnFormAdvancedModeTest" + RandomString.get(10);
        String companyName = RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        backendCrm.createCompany(companyName, RandomString.getUUID());

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickAddContext();

        createContextModal.fillContextName("Приложение");
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextApp();
        createContextModal.clickLinkSelectApp();

        selectAppModal.clickSectionInModal("CRM");
        selectAppModal.clickAppInModal("Компании");
        createContextModal.dialogWindowPressButton("Создать");
        appFormSettingsModal.clickCreateTab();
        appFormSettingsModal.movePropertyOnForm("Приложение");
        appFormSettingsModal.clickReadOnlyField("Приложение");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.fillName(elementAppName);
        createAppElementModal.setTextInputWithSearchByFormRowName("Приложение", companyName);
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkHeaderTitleCard(elementAppName);
    }

    @Test
    @Link(value = "cca3ef0c-2230-4d5b-8fad-d62dbc9f0706", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cca3ef0c-2230-4d5b-8fad-d62dbc9f0706)")
    @DisplayName("Проверить формирование названия элемента по шаблону")
    public void checkAppElementNameByTemplate() {
        String sectionName = "checkAppElementNameByTemplate" + RandomString.get(16);
        String appName = "checkAppElementNameByTemplate" + RandomString.get(10);
        String partPattern = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Название элемента");
        sectionPage.clickElementNameByTemplate();
        sectionPage.clickElementNameByTemplate();

        sectionPage.fillPatternElementName(partPattern);
        sectionPage.clickSavaSettingsName();
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.clickModalFooterButton("Сохранить");

        sectionPage.checkHeaderTitleCard(partPattern);
    }

    @Test
    @Link(value = "6d4acd19-8007-4066-9830-f4f0feb5bc8e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6d4acd19-8007-4066-9830-f4f0feb5bc8e)")
    @DisplayName("Проверить экспорт данных")
    public void dataExportElementsTest() {
        String sectionName = "dataExportElementsTest" + RandomString.get(16);
        String appName = "dataExportElementsElement" + RandomString.get(8);
        String elementName = "dataExportElement" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String elementId = elmaBackend.createElement(elementName, sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickExportData();

        exportElementsModal.exportSystemInfoCheckboxClick();
        exportElementsModal.exportWithFilterCheckboxClick();
        exportElementsModal.dialogWindowPressButton("Экспортировать");
        exportElementsModal.downloadLinkClick();

        exportElementsModal.checkAllFieldsEquals(appName, elementId, elementName);
    }

    @Test
    @Link(value = "24f1c663-3329-4f73-9220-3534e3669399", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/24f1c663-3329-4f73-9220-3534e3669399)")
    @DisplayName("Проверить импорт данных")
    public void dataImportElementsTest() {
        String sectionName = "dataImportElementsTest" + RandomString.get(12);
        String appName = "dataImportElementsElement" + RandomString.get(5);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickImportData();

        importElementsModal.importFile();
        importElementsModal.dialogWindowPressButton("Импортировать");
        importElementsModal.dialogWindowPressButton("Закрыть");

        importElementsModal.checkElementExist("dataImportElementTest");
    }

    @Test
    @Link(value = "e556469a-882f-491c-b5b7-b9be4e934345", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e556469a-882f-491c-b5b7-b9be4e934345)")
    @DisplayName("Проверить смену статуса на указанный в операции для приложения")
    public void changeStatusTest() {
        String sectionName = "changeStatusTest" + RandomString.get(8);
        String appName = "changeStatusApp" + RandomString.get(8);
        String status1 = "status" + RandomString.get(8);
        String status2 = "status2" + RandomString.get(8);
        String processName = "TestingProcess" + RandomString.get(16);
        String elementAppName = "changeStatusTestElement" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Поле \"Статус\"");
        statusPage.clickAddStatusField();

        statusPage.createNewStatus(status1);
        statusPage.createNewStatus(status2);
        statusPage.clickSaveStatuses(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Бизнес-процессы");
        sectionPage.clickAddProcess();

        businessProcessPage.createBusinessProcess(processName);
        businessProcessPage.chooseSidebarActivity("Системные элементы");
        businessProcessPage.simpleDragAndDrop("Управление статусом", "#content>:nth-child(1)");
        businessProcessPage.moveArrow("", "статус 1");
        businessProcessPage.moveArrowFinish("статус 1");
        businessProcessPage.clickSettingsBlock("статус 1");

        settingsBlockModal.selectFunction(status2);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.clickBack();
        sectionPage.appToolbar().selectAppByName(appName);
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementAppName);
        createAppElementModal.clickModalFooterButton("Сохранить");
        createAppElementModal.checkNameButtonInFooterModalWindowNotExists("Сохранить");
        sectionPage.refreshPage();
        sectionPage.openElementStatusLast(elementAppName);

        sectionPage.checkAppElementStatus(status2);
    }

    @Test
    @Link(value = "02e8b159-6eed-44bd-b0ce-5a85e8af1aef", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/02e8b159-6eed-44bd-b0ce-5a85e8af1aef)")
    @DisplayName("Добавить контекст типа Дата/время с установкой опционального времени - начало дня")
    public void addDateTimeContextSettingStartDayTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Дата/время");
        appFormSettingsModal.clickTypeDateTime("Дата/время");
        appFormSettingsModal.clickTimeOptional();
        appFormSettingsModal.selectTimeOptional("Начало дня");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.fillName(elementAppName);
        createAppElementModal.clickTodayInFieldDateTime();
        createAppElementModal.clickSpecifyTime();

        createAppElementModal.checkElementChooseTime();
    }

    @Test
    @Link(value = "3b9d5458-529d-455a-a788-e332061d8c62", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3b9d5458-529d-455a-a788-e332061d8c62)")
    @DisplayName("Добавить контекст типа Дата/время с установкой опционального времени - конец дня")
    public void addDateTimeContextSettingEndDayTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Дата/время");
        appFormSettingsModal.clickTypeDateTime("Дата/время");
        appFormSettingsModal.clickTimeOptional();
        appFormSettingsModal.selectTimeOptional("Конец дня");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.fillName(elementAppName);
        createAppElementModal.clickTodayInFieldDateTime();
        createAppElementModal.clickSpecifyTime();

        createAppElementModal.checkElementChooseTime();
    }

    @Test
    @Link(value = "25e068f4-fcc0-4a9e-a010-de25f3013503", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/25e068f4-fcc0-4a9e-a010-de25f3013503)")
    @DisplayName("Добавить контекст типа Дата/время в виде Дата")
    public void addDateTimeContextSettingDateTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Дата/время");
        appFormSettingsModal.clickTypeDateTime("Дата");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementAppName);

        createAppElementModal.checkHiddenElementChoseTime();
    }

    @Test
    @Link(value = "8027a827-4530-41e5-b995-48a3f7237d52", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8027a827-4530-41e5-b995-48a3f7237d52)")
    @DisplayName("Добавить контекст типа Дата/время в виде Время")
    public void addDateTimeContextSettingTimeTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Дата/время");
        appFormSettingsModal.clickTypeDateTime("Время");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementAppName);

        createAppElementModal.checkHiddenElementChoseDate();
    }

    @Test
    @Link(value = "c3ec9ee4-7a7a-4d6e-affa-08d739d1ea4c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c3ec9ee4-7a7a-4d6e-affa-08d739d1ea4c)")
    @DisplayName("Добавить контекст типа Выбор \"да/нет\" - с изменением значений")
    public void addYesNoContextChangingParametersTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String valuesYes = RandomString.get(3);
        String valuesNo = RandomString.get(3);
        String valuesYesNo = valuesYes + "\n" + valuesNo;
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Выбор «да/нет»");
        appFormSettingsModal.fillInputYes(valuesYes);
        appFormSettingsModal.fillInputNo(valuesNo);
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.checkValuesYesNoVariable(valuesYesNo);
    }

    @Test
    @Link(value = "cfe12974-cd8f-4bb7-a506-9647099680d6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/cfe12974-cd8f-4bb7-a506-9647099680d6)")
    @DisplayName("Проверить отображение подсказки к свойству")
    public void checkPropertyTooltipDisplayTest() {
        String sectionName = "addAppPropertyOnFormTest" + RandomString.get(32);
        String appName = "addAppPropertyOnFormTest" + RandomString.get(10);
        String tooltip = RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Строка");
        appFormSettingsModal.fillVariableTooltip(tooltip);
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.checkTooltipVariable(tooltip);
    }

    @Test
    @Link(value = "c0e494d2-e587-4f43-9220-7df8abd9aec6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c0e494d2-e587-4f43-9220-7df8abd9aec6)")
    @DisplayName("Проверить заполнение свойства по умолчанию")
    public void checkDefaultPropertyCompletionTest() {
        String sectionName = "addSimplePropertyOnFormAdvancedModeTest" + RandomString.get(16);
        String appName = "addSimplePropertyOnFormAdvancedModeTest" + RandomString.get(10);
        String elementAppName = RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.clickAddContext();
        createContextModal.fillContextName("Строка");
        createContextModal.fillInputDefault("По умолчанию");
        createContextModal.dialogWindowPressButton("Создать");
        appFormSettingsModal.clickCreateTab();
        appFormSettingsModal.movePropertyOnForm("Строка");
        appFormSettingsModal.clickViewTab();
        appFormSettingsModal.movePropertyOnViewForm("Строка");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);
        createAppElementModal.fillName(elementAppName);
        createAppElementModal.clickModalFooterButton("Сохранить");
        sectionPage.clickOnCardApp(elementAppName);

        createAppElementModal.checkValuesStringVariable("По умолчанию");
    }

    @Test
    @Link(value = "aae83d06-99ea-42dd-9cc7-fff9d1a3551c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/aae83d06-99ea-42dd-9cc7-fff9d1a3551c)")
    @DisplayName("Удалить контекст")
    public void deleteContextTest() {
        String sectionName = "addSimplePropertyOnFormTest" + RandomString.get(16);
        String appName = "addSimplePropertyOnFormTest" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.dragAndDropProperty("Строка");
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickDeleteContext();
        appFormSettingsModal.clickModalHeaderButton("Сохранить");
        sectionPage.appHeaderToolbar().clickActionButton(appName);

        createAppElementModal.checkStringVariableNotExists();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "7b5eaa64-941c-41b5-b467-9a6b18cc1c67", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7b5eaa64-941c-41b5-b467-9a6b18cc1c67)")
    @DisplayName("Открыть настройки подписи")
    public void checkSignSettingsTest() {
        String sectionName = "checkSignSettingsSectionName" + RandomString.get(8);
        String appName = "checkSignSettingsAppName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableDigitalSign();

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки подписи");

        signSettingsModal.checkModalOpened();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "24a425a0-ce01-4d83-9176-0bb98ab9f439", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/24a425a0-ce01-4d83-9176-0bb98ab9f439)")
    @DisplayName("Указать пользователей с правом подписи - выбрать элемент орг структуры из списка")
    public void addSignRightsElementTest() {
        String sectionName = "addSignRightsElementSectionName" + RandomString.get(8);
        String appName = "addSignRightsElementAppName" + RandomString.get(8);
        String elementName = "addSignRightsElementElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableDigitalSign();
        elmaBackend.createElement(elementName, sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки подписи");

        signSettingsModal.selectUserOrRoleOrGroupByQuery("Генеральный директор");
        signSettingsModal.clickModalFooterButton("Сохранить");

        sectionPage.openAppElement(sectionName, appName, elementName);

        sectionPage.checkSignButtonVisible();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "e31ad33a-9c81-46aa-9ff7-5e8b52070652", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e31ad33a-9c81-46aa-9ff7-5e8b52070652)")
    @DisplayName("Указать пользователей с правом подписи - выбрать группу из списка")
    public void addSignRightsGroupTest() {
        String sectionName = "addSignRightsGroupSectionName" + RandomString.get(8);
        String appName = "addSignRightsGroupAppName" + RandomString.get(8);
        String elementName = "addSignRightsGroupElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableDigitalSign();
        elmaBackend.createElement(elementName, sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки подписи");

        signSettingsModal.selectUserOrRoleOrGroupByQuery("Администраторы");
        signSettingsModal.clickModalFooterButton("Сохранить");

        sectionPage.openAppElement(sectionName, appName, elementName);

        sectionPage.checkSignButtonVisible();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "9daaf3c3-d22a-4619-94d7-db6b02c834d1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9daaf3c3-d22a-4619-94d7-db6b02c834d1)")
    @DisplayName("Указать пользователей с правом подписи - выбрать пользователя из списка")
    public void addSignRightsUserTest() {
        String sectionName = "addSignRightsUserSectionName" + RandomString.get(8);
        String appName = "addSignRightsUserAppName" + RandomString.get(8);
        String elementName = "addSignRightsUserElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.enableDigitalSign();
        elmaBackend.createElement(elementName, sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройки подписи");

        signSettingsModal.selectUserOrRoleOrGroupByQuery(
                elmaBackend.getUserSurnameAndNameByEmail(adminLogin));
        signSettingsModal.clickModalFooterButton("Сохранить");

        sectionPage.openAppElement(sectionName, appName, elementName);

        sectionPage.checkSignButtonVisible();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "eba01b68-73cc-4d8e-8eea-299b01960d20", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/eba01b68-73cc-4d8e-8eea-299b01960d20)")
    @DisplayName("Создать новую форму редактирования")
    public void createNewEditFormAppTest() {
        String sectionName = "createNewEditFormAppSectionName" + RandomString.get(4);
        String appName = "editFormApp" + RandomString.get(4);
        String elementName = "element" + RandomString.get(4);
        String titleWidgetName = "titleWidgetName" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.chooseTabSettingFormApp("Редактирование");
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm("Надпись");
        widgetSettingsModal.setTextInputByFormRowName("Текст", titleWidgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Виджет опубликован");
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        interfaceDesignerPage.refreshPage();
        sectionPage.openAppElement(sectionName, appName, elementName);
        createAppElementModal.clickModalFooterButton("Редактировать");
        createAppElementModal.checkExistWidgetOnBodyModal(titleWidgetName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b7bba5b2-2690-4c46-95ed-8e6ba17c5d92", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b7bba5b2-2690-4c46-95ed-8e6ba17c5d92)")
    @DisplayName("Создать новую форму создания")
    public void createNewCreateFormAppTest() {
        String sectionName = "createNewCreateFormAppSectionName" + RandomString.get(4);
        String appName = "createFormApp" + RandomString.get(4);
        String titleWidgetName = "titleWidgetName" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.chooseTabSettingFormApp("Создание");
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm("Надпись");
        widgetSettingsModal.setTextInputByFormRowName("Текст", titleWidgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Виджет опубликован");
        interfaceDesignerPage.clickBack();

        mainPage.clickButtonOnAppContent("+ " + appName);
        createAppElementModal.checkExistWidgetOnBodyModal(titleWidgetName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "754e2049-0cb8-47b5-b7f7-b6bee34aa566", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/754e2049-0cb8-47b5-b7f7-b6bee34aa566)")
    @DisplayName("Создать новую форму просмотра")
    public void createNewViewFormAppTest() {
        String sectionName = "createNewViewFormAppSectionName" + RandomString.get(4);
        String appName = "ViewFormApp" + RandomString.get(4);
        String elementName = "element" + RandomString.get(4);
        String titleWidgetName = "titleWidgetName" + RandomString.get(4);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Настройка формы");
        appFormSettingsModal.clickModalHeaderButton("Расширенный режим");
        appFormSettingsModal.dialogWindowPressButton("ОК");
        appFormSettingsModal.chooseTabSettingFormApp("Просмотр");
        appFormSettingsModal.createDefaultForm();
        appFormSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.addWidgetWithExactNameByDragAndDropToMainForm("Надпись");
        widgetSettingsModal.setTextInputByFormRowName("Текст", titleWidgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.saveAndPublish();
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Виджет опубликован");
        interfaceDesignerPage.clickBack();

        elmaBackend.createElement(elementName, sectionName, appName);
        interfaceDesignerPage.refreshPage();
        sectionPage.clickOnCardApp(elementName);
        createAppElementModal.checkExistWidgetOnBodyModal(titleWidgetName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "a07e0e11-9f5d-4dd9-932b-6b8f689eef56", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a07e0e11-9f5d-4dd9-932b-6b8f689eef56)")
    @DisplayName("Отправить на ознакомление с карточки элемента приложения")
    public void sendFamiliarizationFromFormAppTest() {
        String sectionName = "sendFamiliarizationFromFormApp" + RandomString.get(4);
        String appName = "App" + RandomString.get(4);
        String elementName = "element" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.clickButtonSetFamiliarization();
        settingsBlockModal.clickButtonZoomAllWithRowName("Получатели");
        mainPage.clickSelectUser(userLogin);
        appFormSettingsModal.clickPopoverFooterButton("-> Отправить");
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Отправлено на ознакомление");

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(elementName + ": Ознакомиться", "Ознакомление");
        interfaceDesignerPage.checkHeaderTextInModalWindow(elementName + ": Ознакомиться");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c9a7e2ab-47a1-4564-b923-2036ef9aec70", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c9a7e2ab-47a1-4564-b923-2036ef9aec70)")
    @DisplayName("Отправить на согласование с карточки элемента приложения")
    public void sendApproveFromFormAppTest() {
        String sectionName = "sendApproveFromFormApp" + RandomString.get(4);
        String appName = "App" + RandomString.get(4);
        String elementName = "element" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        sectionPage.open(sectionName, appName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        sectionPage.clickButtonSetApprove();
        settingsBlockModal.clickButtonZoomAllWithRowName("Согласующие");
        mainPage.clickSelectUser(userLogin);
        appFormSettingsModal.clickPopoverFooterButton("-> Отправить");
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Отправлено на согласование");

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(elementName + ": Согласовать", "Согласование");
        interfaceDesignerPage.checkHeaderTextInModalWindow(elementName + ": Согласовать");
    }
}