package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendCrm;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.AppFormSettingsModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.*;

import java.time.LocalDate;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("crm_deals")})
public class CrmDealsTests {
    @Inject
    protected BackendCrm backendCrm;
    @Inject
    protected CrmSectionPage crmSectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected ContractPage contractPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected FilePage filePage;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "303e8e31-d4d5-46e5-8cc7-8752c0ad9a6c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/303e8e31-d4d5-46e5-8cc7-8752c0ad9a6c)")
    @DisplayName("Сменить ответственного")
    public void changeResponsibleTest() {
        String dealName = "changeResponsibleTest" + RandomString.get(4);
        String funnelName = "funnelName" + RandomString.get(4);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.addNewFunnel(funnelName);
        crmSectionPage.checkPageContainsNewFunnel(funnelName);
        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkPageContainsNewFunnel("Все");
        crmSectionPage.clickExpandFunnelButton();
        crmSectionPage.checkPageContainsNewFunnel(funnelName);
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Сделка");
        settingsBlockModal.setTextInputByFormRowName("Название", dealName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        crmSectionPage.checkCardVisible(dealName, 1);

        //admin
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();

        crmSectionPage.open("_clients/_deal_dynamics");
        mainPage.selectPageSettings("Редактировать");
        contractPage.addPropertyForTable("Ответственный");
        settingsBlockModal.dialogWindowPressButton("Сохранить");

        crmSectionPage.clickAndSelectDropDownItemWithLabelRow("Воронка", "", funnelName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonBuilding();
        Assertions.assertEquals(0, crmSectionPage.getCountDealsFromDynamicTable("Созданы за период", "Созданы за период"), "Количество сделок должно быть 0");

        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(userLogin);
        crmSectionPage.clickButtonBuilding();
        Assertions.assertEquals(1, crmSectionPage.getCountDealsFromDynamicTable("Созданы за период", "Созданы за период"), "Количество сделок должно быть 1");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "6f377f90-b198-425f-a2f8-7cd6ce6eeeb5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6f377f90-b198-425f-a2f8-7cd6ce6eeeb5)")
    @DisplayName("Проверить опцию Показывать удаленные")
    public void checkDeleteDealsTest() {
        String dealName = "checkDeleteDealsTest" + RandomString.get(4);

        String dealID = backendCrm.createDeal(dealName);
        backendCrm.deleteDeal(dealID);

        crmSectionPage.open("_clients/_deal_dynamics");
        settingsBlockModal.setCheckboxConditionByLabel("Показывать удалённые?", false);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.clickAllDealsFromDynamicTable();
        crmSectionPage.checkLoadDealsList();
        sectionPage.checkTaskNameNotExists(dealName);
        settingsBlockModal.clickButtonOnModalWindowByName("Закрыть");

        settingsBlockModal.setCheckboxConditionByLabel("Показывать удалённые?", true);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.clickAllDealsFromDynamicTable();
        sectionPage.checkNameTaskPattern(dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "12683265-088f-4a9c-9d85-9b3cf5593c44", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/12683265-088f-4a9c-9d85-9b3cf5593c44)")
    @DisplayName("Проверить изменение воронки продаж")
    public void checkChangeFunnelDealsTest() {
        String dealName = "checkChangeFunnelDealsTest" + RandomString.get(4);
        String funnelName = "funnelName" + RandomString.get(4);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.addNewFunnel(funnelName);
        crmSectionPage.checkPageContainsNewFunnel(funnelName);
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Сделка");
        settingsBlockModal.setTextInputByFormRowName("Название", dealName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        crmSectionPage.checkCardVisible(dealName, 1);

        crmSectionPage.open("_clients/_deal_dynamics");
        crmSectionPage.clickAndSelectDropDownItemWithLabelRow("Воронка", "", funnelName);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.clickCellDealsFromDynamicTable("Созданы за период", "Созданы за период");
        sectionPage.checkNameTaskPattern(dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0987c5fc-a50d-451e-aaf9-019cbfc8bc6d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0987c5fc-a50d-451e-aaf9-019cbfc8bc6d)")
    @DisplayName("Проверить изменение периода")
    public void checkChangePeriodDealsTest() {
        String dealName = "checkChangePeriodDealsTest" + RandomString.get(4);
        int countDeals;

        String funnelName = "funnelName" + RandomString.get(4);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.addNewFunnel(funnelName);
        crmSectionPage.checkPageContainsNewFunnel(funnelName);
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Сделка");
        settingsBlockModal.setTextInputByFormRowName("Название", dealName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        crmSectionPage.checkCardVisible(dealName, 1);

        LocalDate date = LocalDate.now();
        crmSectionPage.open("_clients/_deal_dynamics");
        crmSectionPage.clickAndSelectDropDownItemWithLabelRow("Воронка", "", funnelName);
        crmSectionPage.clickButtonBuilding();
        countDeals = crmSectionPage.getCountDealsFromDynamicTable("Созданы за период", "Созданы за период");
        Assertions.assertTrue(countDeals > 0, "Количество сделок должно быть больше 0");

        crmSectionPage.setPeriodWithLabelRow("Период", date.minusYears(1).format(FORMATTER_DD_MM_YYYY), date.minusYears(1).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonBuilding();

        countDeals = crmSectionPage.getCountDealsFromDynamicTable("Созданы за период", "Созданы за период");
        Assertions.assertEquals(0, countDeals, "Количество сделок должно быть равно 0");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "120c2c43-f46d-4e6b-a30d-f464a322f3fc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/120c2c43-f46d-4e6b-a30d-f464a322f3fc)")
    @DisplayName("Проверить корректное отображение информации по сделкам")
    public void checkRealInfoAboutDealsTest() {
        String dealName = "checkRealInfoAboutDealsTest" + RandomString.get(4);
        int countDeals;

        backendCrm.createDeal(dealName);

        LocalDate date = LocalDate.now();
        crmSectionPage.open("_clients/_deal_dynamics");
        crmSectionPage.clickAndSelectDropDownItemWithLabelRow("Воронка", "", "Воронка продаж");
        crmSectionPage.clickButtonBuilding();

        crmSectionPage.setPeriodWithLabelRow("Период", date.minusDays(7).format(FORMATTER_DD_MM_YYYY), date.format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonBuilding();

        countDeals = crmSectionPage.getCountDealsFromDynamicTable("Созданы за период", "Созданы за период");
        Assertions.assertTrue(countDeals > 0, "Количество сделок должно быть больше 0");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2831cac1-5d5f-46ca-b764-3d5255129233", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2831cac1-5d5f-46ca-b764-3d5255129233)")
    @DisplayName("Сменить ответственного в карточке сделки")
    public void changeResponsibleInCardDealTest() {
        String dealName = "changeResponsibleInCardDealTest" + RandomString.get(4);
        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");
        mainPage.clickOnNameButtonElmaForm("Сменить");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(userLogin);
        settingsBlockModal.clickButtonOnModalWindowByName("Назначить");
        sectionPage.checkAlertWithTextFragmentExists("Успешно назначено");
        crmSectionPage.checkExistWidgetOnBodyModal(backendCrm.getUserSurnameAndNameByEmail(userLogin));
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "32ce4741-6741-48d0-a28e-5f2d0ba84078", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/32ce4741-6741-48d0-a28e-5f2d0ba84078)")
    @DisplayName("Проверить историю вебинаров в Календаре")
    public void checkHistoryWebinarInCalendarTest() {
        String dealName = "checkHistoryWebinarTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");
        crmSectionPage.pressNewTaskButton("Вебинар");
        mainPage.clickOnNameButtonElmaForm("Сохранить");
        sectionPage.waitGreySpinnerDisappear();

        sectionPage.open("schedule");
        sectionPage.waitGreySpinnerDisappear();
        crmSectionPage.clickTaskOnCalendar("Провести вебинар для " + dealName);
        crmSectionPage.checkTaskOnCardDealExists("Провести вебинар для " + dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "3890d3d5-2a16-4cc7-97fe-f0ab2d9f1f8e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3890d3d5-2a16-4cc7-97fe-f0ab2d9f1f8e)")
    @DisplayName("Создать вебинар в карточке сделки")
    public void createWebinarOnCardDealTest() {
        String dealName = "createWebinarOnCardDealTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");
        crmSectionPage.pressNewTaskButton("Вебинар");
        mainPage.clickOnNameButtonElmaForm("Сохранить");

        crmSectionPage.checkTaskOnCardDealExists("Провести вебинар для " + dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "45be2e30-432f-45e7-b85e-6631dfe8a14b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/45be2e30-432f-45e7-b85e-6631dfe8a14b)")
    @DisplayName("Проверить редактирование Сделки")
    public void checkEditDealTest() {
        String dealName = "checkHistoryWebinarTest" + RandomString.get(4);
        String newDealName = "newDealName" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");
        settingsBlockModal.clickModalFooterButton("Редактировать");

        settingsBlockModal.setTextInputByFormRowName("Название", newDealName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAlertWithTextFragmentExists("Сделка успешно изменен");
        sectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkCardVisible(newDealName, 1);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e4baac13-d56b-4382-94d9-0abe5a1c112a", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e4baac13-d56b-4382-94d9-0abe5a1c112a)")
    @DisplayName("Отправить сделку на Ознакомление")
    public void sendFamiliarizationFromFormDealTest() {
        String dealName = "sendFamiliarizationFromFormDealTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");

        sectionPage.clickButtonSetFamiliarization();
        settingsBlockModal.clickButtonZoomAllWithRowName("Получатели");
        mainPage.clickSelectUser(userLogin);
        appFormSettingsModal.clickPopoverFooterButton("-> Отправить");
        sectionPage.checkAlertWithTextFragmentExists("Отправлено на ознакомление");

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(dealName + ": Ознакомиться", "Ознакомление");
        interfaceDesignerPage.checkHeaderTextInModalWindow(dealName + ": Ознакомиться");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "8e99bad1-4307-4095-8f43-ce4b5586cec8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8e99bad1-4307-4095-8f43-ce4b5586cec8)")
    @DisplayName("Отправить сделку на Согласование")
    public void sendApproveFromFormDealTest() {
        String dealName = "sendApproveFromFormDealTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");

        sectionPage.clickButtonSetApprove();
        settingsBlockModal.clickButtonZoomAllWithRowName("Согласующие");
        mainPage.clickSelectUser(userLogin);
        appFormSettingsModal.clickPopoverFooterButton("-> Отправить");
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Отправлено на согласование");

        //user
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("/tasks/income");
        sectionPage.clickTask(dealName + ": Согласовать", "Согласование");
        interfaceDesignerPage.checkHeaderTextInModalWindow(dealName + ": Согласовать");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d21c65e5-8da7-4f12-949f-6e27f145d04e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d21c65e5-8da7-4f12-949f-6e27f145d04e)")
    @DisplayName("Создать письмо")
    public void createMailInCardDealTest() {
        String dealName = "createMailInCardDealTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");
        crmSectionPage.pressNewTaskButton("Письмо");
        mainPage.clickOnNameButtonElmaForm("Сохранить");
        sectionPage.waitGreySpinnerDisappear();

        sectionPage.open("/tasks/income");
        sectionPage.clickTask("Написать письмо " + dealName, "Письмо");
        interfaceDesignerPage.checkHeaderTextInModalWindow(dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "dba84f77-6ca2-4d47-8442-ee5bf55c33c5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/dba84f77-6ca2-4d47-8442-ee5bf55c33c5)")
    @DisplayName("Проверить историю задач в Календаре")
    public void checkHistoryTaskInCalendarTest() {
        String dealName = "createMailInCardDealTest" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);

        businessProcessPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000(p:item/_clients/_leads/" + dealId + ")");
        crmSectionPage.pressNewTaskButton("задача");
        crmSectionPage.enterTaskName(taskName);
        mainPage.clickOnNameButtonElmaForm("Сохранить");
        sectionPage.waitGreySpinnerDisappear();

        sectionPage.open("schedule");
        sectionPage.waitGreySpinnerDisappear();
        crmSectionPage.clickTaskOnCalendar(taskName);
        mainPage.clickOnNameLinkElmaForm(dealName);

        crmSectionPage.checkTaskOnCardDealExists(taskName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c075b575-1b60-4aeb-b00c-de7cbe476845", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c075b575-1b60-4aeb-b00c-de7cbe476845)")
    @DisplayName("Удалить созданную Воронку продаж")
    public void deleteFunnelDealTest() {
        String funnelDealName = "deleteFunnelDealTest" + RandomString.get(4);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.addNewFunnel(funnelDealName);
        crmSectionPage.checkFunnelDealExists(funnelDealName);
        sectionPage.clickPencilButton();
        crmSectionPage.clickDeleteFunnelDeal(funnelDealName);
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Воронка успешно удалена");
        filePage.clickButtonSystemClose();
        crmSectionPage.refreshPage();
        crmSectionPage.checkFunnelDealExists("Воронка продаж");
        crmSectionPage.clickExpandFunnelButton();
        crmSectionPage.checkFunnelDealNotExists(funnelDealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0f9a3df7-97e2-418d-abc9-9f90050c5c78", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0f9a3df7-97e2-418d-abc9-9f90050c5c78)")
    @DisplayName("Редактировать название Воронки продаж")
    public void editFunnelDealNameTest() {
        String funnelDealName = "editFunnelDealNameTest" + RandomString.get(4);
        String newFunnelDealName = "newFunnelDealNameTest" + RandomString.get(4);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.addNewFunnel(funnelDealName);
        crmSectionPage.checkPageContainsNewFunnel(funnelDealName);
        sectionPage.clickPencilButton();
        crmSectionPage.changeFunnelName(funnelDealName, newFunnelDealName);
        interfaceDesignerPage.checkAlertWithTextFragmentExists("Воронка успешно переименована");
        filePage.clickButtonSystemClose();
        crmSectionPage.checkFunnelDealExists(newFunnelDealName);
        crmSectionPage.checkFunnelDealNotExists(funnelDealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "88c7aabc-3cc0-4b7b-904c-60a3314f8c42", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/88c7aabc-3cc0-4b7b-904c-60a3314f8c42)")
    @DisplayName("Проверить корректность отображения страницы Воронка продаж")
    public void checkColumnNameTableDealsTest() {
        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.checkColumnNameTableDeals("Новые");
        crmSectionPage.checkColumnNameTableDeals("Первичный контакт");
        crmSectionPage.checkColumnNameTableDeals("В работе");
        crmSectionPage.checkColumnNameTableDeals("Обсуждение условий");
        crmSectionPage.checkColumnNameTableDeals("Заключение договора");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7e068853-e575-4550-82e9-b2859bca82b8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7e068853-e575-4550-82e9-b2859bca82b8)")
    @DisplayName("Проверить корректность отображения страницы Новые")
    public void checkCorrectViewPageNewTest() {
        String dealName = "checkCorrectViewPageNewTest" + RandomString.get(4);

        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.clickColumnNameTableDeals("Новые");
        crmSectionPage.checkCellTextTableContactExists(dealName, "Воронка продаж");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "4bb63703-d10f-4ffa-aebe-44d4595835da", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4bb63703-d10f-4ffa-aebe-44d4595835da)")
    @DisplayName("Создать сделку с заполнением всех полей")
    public void fillAllFieldsDealTest() {
        String dealName = "fillAllFieldsDealTest" + RandomString.get(4);
        String address = "address" + RandomString.get(4);
        String budget = "555,55";

        String contactName = "contactName" + RandomString.get(4);
        backendCrm.createContact(contactName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.appHeaderToolbar().clickActionButton("+ Сделка");
        settingsBlockModal.setTextInputByFormRowName("Название", dealName);
        settingsBlockModal.setTextInputByFormRowName("Бюджет", budget);
        settingsBlockModal.setTextInputByFormRowName("Адрес", address);
        settingsBlockModal.clickButtonZoomAllWithRowName("Контакты");
        mainPage.clickSelectName(contactName);
        settingsBlockModal.clickModalFooterButton("Сохранить");
        crmSectionPage.checkCardVisible(dealName, 1);
        crmSectionPage.openCard(dealName);
        crmSectionPage.checkTextForRowValue("Контакты", contactName);
        crmSectionPage.checkTextForRowValue("Адрес", address);
        crmSectionPage.checkTextForRowValue("Бюджет", budget);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "95f5ac3f-79c5-4a48-9a28-7bc6c4d8286b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/95f5ac3f-79c5-4a48-9a28-7bc6c4d8286b)")
    @DisplayName("Создать сделку с заменой ответственного")
    public void changeResponsibleForDealTest() {
        String dealName = "changeResponsibleForDealTest" + RandomString.get(4);

        backendCrm.createDeal(dealName);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.clickColumnNameTableDeals("Новые");
        crmSectionPage.checkCellTextTableContactExists(dealName, "Воронка продаж");
        crmSectionPage.setCheckBoxOnItemInDealsTable(dealName, true);
        crmSectionPage.clickPageHeaderButtons("Назначить");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(userLogin);
        settingsBlockModal.clickButtonOnModalWindowByName("Назначить");
        sectionPage.checkAlertWithTextFragmentExists("Успешно назначено");
        contractPage.clickSettingTableContractButton("Настройка таблицы");
        contractPage.addPropertyForTable("Ответственный");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        crmSectionPage.checkCellTextTableContactExists(dealName, backendCrm.getUserSurnameAndNameByEmail(userLogin));
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c0f98851-4239-4c15-90bd-eef35819e3ae", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c0f98851-4239-4c15-90bd-eef35819e3ae)")
    @DisplayName("Сменить ответственного")
    public void updateResponsibleTest() {
        String dealName = "updateResponsibleTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);
        backendCrm.updateDeal(dealId, dealName, backendCrm.getUserIdByEmail(userLogin), 60000, LocalDate.now() + "T00:00:00.000Z");
        crmSectionPage.open("_clients/_income");
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(adminLogin);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactNotExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName);
        settingsBlockModal.clickButtonZoomAllWithRowName("Ответственный");
        mainPage.clickSelectUser(userLogin);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7e981908-f6db-478a-a550-e4f368950cfd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7e981908-f6db-478a-a550-e4f368950cfd)")
    @DisplayName("Проверить изменение периода")
    public void checkChangePeriodTest() {
        String dealName1 = "checkChangePeriodTest" + RandomString.get(4);
        String dealName2 = "checkChangePeriodTest" + RandomString.get(4);


        String dealId1 = backendCrm.createDeal(dealName1);
        backendCrm.updateDeal(dealId1, dealName1, backendCrm.getUserIdByEmail(userLogin), 50000, LocalDate.now().plusDays(1) + "T00:00:00.000Z");
        String dealId2 = backendCrm.createDeal(dealName2);
        backendCrm.updateDeal(dealId2, dealName2, backendCrm.getUserIdByEmail(userLogin), 50000, LocalDate.now().plusDays(2) + "T00:00:00.000Z");
        crmSectionPage.open("_clients/_income");
        crmSectionPage.setPeriodWithLabelRow("Период", LocalDate.now().plusDays(1).format(FORMATTER_DD_MM_YYYY), LocalDate.now().plusDays(2).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName1);
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName2);
        crmSectionPage.setPeriodWithLabelRow("Период", LocalDate.now().plusDays(2).format(FORMATTER_DD_MM_YYYY), LocalDate.now().plusDays(2).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName2);
        crmSectionPage.checkCellTextTableContactNotExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName1);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5740e764-4fa9-4331-8958-0dab3a18d45f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5740e764-4fa9-4331-8958-0dab3a18d45f)")
    @DisplayName("Проверить корректное отображение информации по поступлениям")
    public void checkCorrectViewInfoTest() {
        String dealName = "checkCorrectViewInfoTest" + RandomString.get(4);

        String dealId = backendCrm.createDeal(dealName);
        backendCrm.updateDeal(dealId, dealName, backendCrm.getUserIdByEmail(userLogin), 50000, LocalDate.now().plusDays(10) + "T00:00:00.000Z");
        crmSectionPage.open("_clients/_income");
        crmSectionPage.setPeriodWithLabelRow("Период", LocalDate.now().format(FORMATTER_DD_MM_YYYY), LocalDate.now().format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactNotExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName);
        crmSectionPage.setPeriodWithLabelRow("Период", LocalDate.now().plusDays(10).format(FORMATTER_DD_MM_YYYY), LocalDate.now().plusDays(10).format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e11ba525-86cc-40f2-bb41-a88ebaff5564", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e11ba525-86cc-40f2-bb41-a88ebaff5564)")
    @DisplayName("Проверить изменение воронки продаж")
    public void checkChangeFunnelDealsIncomeTest() {
        String dealName1 = "checkChangeFunnelDealsIncomeTest" + RandomString.get(4);
        String dealName2 = "checkChangeFunnelDealsIncomeTest" + RandomString.get(4);
        String funnelName1 = "funnelName" + RandomString.get(4);
        String funnelName2 = "funnelName" + RandomString.get(4);

        crmSectionPage.open("_clients/_leads/_funnels/00000000-0000-0000-0000-000000000000");
        crmSectionPage.addNewFunnel(funnelName1);
        crmSectionPage.addNewFunnel(funnelName2);

        String funnelId1 = backendCrm.getFunnelId(funnelName1);
        String dealId1 = backendCrm.createDeal(dealName1, funnelId1);
        backendCrm.updateDeal(dealId1, dealName1, backendCrm.getUserIdByEmail(userLogin), 50000, LocalDate.now() + "T00:00:00.000Z");
        String funnelId2 = backendCrm.getFunnelId(funnelName2);
        String dealId2 = backendCrm.createDeal(dealName2, funnelId2);
        backendCrm.updateDeal(dealId2, dealName2, backendCrm.getUserIdByEmail(userLogin), 50000, LocalDate.now() + "T00:00:00.000Z");

        crmSectionPage.open("_clients/_income");
        crmSectionPage.setPeriodWithLabelRow("Период", LocalDate.now().format(FORMATTER_DD_MM_YYYY), LocalDate.now().format(FORMATTER_DD_MM_YYYY));
        crmSectionPage.clickAndSelectDropDownItemWithLabelRow("Воронка", "", funnelName1);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName1);
        crmSectionPage.checkCellTextTableContactNotExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName2);
        crmSectionPage.clickAndSelectDropDownItemWithLabelRow("Воронка", "", funnelName2);
        crmSectionPage.clickButtonBuilding();
        crmSectionPage.checkCellTextTableContactExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName2);
        crmSectionPage.checkCellTextTableContactNotExists(backendCrm.getUserSurnameAndNameByEmail(userLogin), dealName1);
    }
}