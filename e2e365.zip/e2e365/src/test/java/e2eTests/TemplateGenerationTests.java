package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.io.File;
import java.nio.file.Paths;
import java.util.Locale;

import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.PATH_TO_DEFAULT_DIR;

@MicronautTest
@Tags({@Tag("express"), @Tag("template_generation")})
public class TemplateGenerationTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected DocumentTemplatesPage documentTemplatesPage;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected NomenclaturePage nomenclaturePage;
    @Inject
    protected FilePage filePage;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "4d13d6f8-d3ea-4841-8335-445fbc7eb994", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4d13d6f8-d3ea-4841-8335-445fbc7eb994)")
    @DisplayName("Проверить возможность задать соответствие полей шаблона с полями переменных бизнес-процесса")
    public void checkSetBindingBetweenFieldsTempAndPBTest() {
        String processName = "checkSetBindingBetweenFieldsTempAndPB" + RandomString.get(4);
        String sectionName = "checkSetBindingBetweenFieldsTempAndPBSectionName" + RandomString.get(4);
        String variableStringName = "String" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithTemplateGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableStringName, ContextType.STRING, false))
                        .addContextOnDefaultStartForm(variableStringName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        documentTemplatesPage.open("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");
        documentTemplateCreatingModal.fillName(variableStringName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "шаблон со строкой.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Генерация пошаблону 1");
        settingsBlockModal.clickButtonOnModalWindowByName("выберите шаблон");
        documentTemplateCreatingModal.chooseDocumentTemplateOnList(variableStringName, "Шаблоны компании");

        settingsBlockModal.chooseTab("Значения полей");
        changeElementBlockModal.setFieldContextBPBinding(variableStringName);
        changeElementBlockModal.checkChooseFieldBinding("str");
        changeElementBlockModal.checkChooseFieldBinding(variableStringName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "67f8034f-60ce-447e-a7fc-28b779cfec51", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/67f8034f-60ce-447e-a7fc-28b779cfec51)")
    @DisplayName("Проверить возможность удалить указанный файл шаблона")
    public void checkDeleteTempDocInPBTest() {
        String processName = "checkDeleteTempDocInPB" + RandomString.get(4);
        String sectionName = "checkDeleteTempDocInPBSectionName" + RandomString.get(4);
        String variableStringName = "String" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithTemplateGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableStringName, ContextType.STRING, false))
                        .addContextOnDefaultStartForm(variableStringName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        documentTemplatesPage.open("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");
        documentTemplateCreatingModal.fillName(variableStringName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "шаблон со строкой.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Генерация пошаблону 1");
        settingsBlockModal.clickButtonOnModalWindowByName("выберите шаблон");
        documentTemplateCreatingModal.chooseDocumentTemplateOnList(variableStringName, "Шаблоны компании");
        settingsBlockModal.checkChooseFieldLinkedWithElement("Шаблон документа", "app_trash");
        settingsBlockModal.clickDeleteButtonAndConfirm();
        settingsBlockModal.checkChooseFieldLinkedWithElement("Шаблон документа", "выберите шаблон");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c3787bc8-85cb-4c78-a604-15a4d85bb4dc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c3787bc8-85cb-4c78-a604-15a4d85bb4dc)")
    @DisplayName("Проверить генерацию по указанному шаблону с конвертацией в PDF")
    public void checkGenerationPDFFromTempDocInPBTest() {
        String processName = "checkGenerationPDFFromTempDocInPB" + RandomString.get(4);
        String sectionName = "checkGenerationPDFFromTempDocInPBSectionName" + RandomString.get(4);
        String variableStringName = "variableString" + RandomString.get(4);
        String variableFileName = "variableFile" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithTemplateGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableStringName, ContextType.STRING, false))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableFileName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableStringName, "", false, false, false)
                        .addContextOnDefaultStartForm(variableFileName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        documentTemplatesPage.open("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");
        documentTemplateCreatingModal.fillName(variableStringName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "шаблон со строкой.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableFileName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(variableFileName, false);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Генерация пошаблону 1");
        settingsBlockModal.clickButtonOnModalWindowByName("выберите шаблон");
        documentTemplateCreatingModal.chooseDocumentTemplateOnList(variableStringName, "Шаблоны компании");

        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Генерация по шаблону 1", " ", variableFileName);
        nomenclatureModal.setCheckboxConditionByFormRowAndLabel("Конвертировать в PDF", "", true);
        documentTemplateCreatingModal.checkGenerationFileName("Имя выходного файла", variableStringName + ".pdf");

        settingsBlockModal.chooseTab("Значения полей");
        changeElementBlockModal.setFieldContextBPBinding(variableStringName);
        changeElementBlockModal.checkChooseFieldBinding("str");
        changeElementBlockModal.checkChooseFieldBinding(variableStringName);
        changeElementBlockModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);

        documentTemplateCreatingModal.setTextInputByFormRowName(variableStringName, "TEST");
        sectionPage.clickNextStageOrExit();

        filePage.clickLinkDocument(variableStringName + ".pdf");
        File file = filePage.downloadGenerationFile();
        Assertions.assertEquals("TEST", filePage.getTextFromPdfPage(file, 1), "Текст в документе отличается от указанного");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c9fa648c-0833-41fa-955d-4d2f0f2029b3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c9fa648c-0833-41fa-955d-4d2f0f2029b3)")
    @DisplayName("Проверить генерацию по указанному шаблону согласно связи переменных процесса и шаблона")
    public void checkGenerationBindingVariablesTempDocAndPBTest() {
        String processName = "checkGenerationBindingVariables" + RandomString.get(4);
        String sectionName = "checkGenerationBindingVariablesSectionName" + RandomString.get(4);
        String variableStringName = "variableString" + RandomString.get(4);
        String variableFileName = "variableFile" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithTemplateGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableStringName, ContextType.STRING, false))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableFileName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableStringName, "", false, false, false)
                        .addContextOnDefaultStartForm(variableFileName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        documentTemplatesPage.open("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");
        documentTemplateCreatingModal.fillName(variableStringName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "шаблон со строкой.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Генерация пошаблону 1");
        settingsBlockModal.clickButtonOnModalWindowByName("выберите шаблон");
        documentTemplateCreatingModal.chooseDocumentTemplateOnList(variableStringName, "Шаблоны компании");

        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Генерация по шаблону 1", " ", variableFileName);
        settingsBlockModal.chooseTab("Значения полей");
        changeElementBlockModal.setFieldContextBPBinding(variableStringName);
        changeElementBlockModal.checkChooseFieldBinding("str");
        changeElementBlockModal.checkChooseFieldBinding(variableStringName);

        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableFileName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.setConditionReadOnlyField(variableFileName, false);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        createContextModal.setTextInputByFormRowName(variableStringName, "TEST");
        sectionPage.clickNextStageOrExit();
        filePage.clickLinkDocument(variableStringName + ".docx");
        File file = filePage.downloadGenerationFile();
        Assertions.assertEquals("TEST", filePage.getParagraphFromDocxFileByNum(file, 0), "Текст в документе отличается от указанного");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "de1e1613-9f4e-431a-88d7-2584e66e57cd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/de1e1613-9f4e-431a-88d7-2584e66e57cd)")
    @DisplayName("Проверить генерацию по указанному шаблону с изменением имени выходного файла с использованием переменных процесса")
    public void checkEditNameFileTempDocAndPBTest() {
        String processName = "checkEditNameFile" + RandomString.get(4);
        String variableStringName = "variableString" + RandomString.get(4);
        String variableFileName = "variableFile" + RandomString.get(4);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithTemplateGeneration.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableStringName, ContextType.STRING, false))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableFileName, ContextType.FILE))
                        .addContextOnDefaultStartForm(variableStringName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        documentTemplatesPage.open("admin", "doctemplates");
        documentTemplatesPage.appHeaderToolbar().clickActionButton("+ шаблон");
        documentTemplateCreatingModal.fillName(variableStringName);
        String filePath = Paths.get(PATH_TO_DEFAULT_DIR, "testData", "шаблон со строкой.docx").toString();
        documentTemplateCreatingModal.uploadFile(filePath);
        documentTemplateCreatingModal.templateFillVariables();
        documentTemplateCreatingModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Генерация пошаблону 1");
        settingsBlockModal.clickButtonOnModalWindowByName("выберите шаблон");
        documentTemplateCreatingModal.chooseDocumentTemplateOnList(variableStringName, "Шаблоны компании");

        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Генерация по шаблону 1", " ", variableFileName);
        nomenclatureModal.setTextInputByFormRowName("Имя выходного файла", "{$" + variableStringName.toLowerCase(Locale.ROOT) + "}.docx");
        settingsBlockModal.chooseTab("Значения полей");
        changeElementBlockModal.setFieldContextBPBinding(variableStringName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(variableFileName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        createContextModal.setTextInputByFormRowName(variableStringName, "TEST");
        sectionPage.clickNextStageOrExit();

        interfaceDesignerPage.checkAppElementExistsOnForm("TEST.docx");
    }
}
