package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.SelectAppModal;
import pages.elmaModals.SelectWidgetsModal;
import pages.elmaModals.WidgetSettingsModal;
import pages.elmaPages.PageConstructorPage;
import pages.elmaPages.SectionPage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("app")})
public class AppTypePageTests {
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected SelectWidgetsModal selectWidgetsModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected SelectAppModal selectAppModal;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Link(value = "040c1064-1d6e-4f63-b7c8-9b4c5504c2a5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/040c1064-1d6e-4f63-b7c8-9b4c5504c2a5)")
    @DisplayName("Опубликовать шаблон для проверки (системный)")
    public void createPageFromTemplateTest() {
        String sectionName = "createPageFromTemplateTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkPageTemplatePublished(pageName);
    }

    @Test
    @Link(value = "ca4d4c4f-4b15-45c2-8f56-0172bff47279", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/ca4d4c4f-4b15-45c2-8f56-0172bff47279)")
    @DisplayName("Добавить виджет на странице (Выбрать из списка)")
    public void addDefaultWidgetOnPageTest() {
        String sectionName = "addDefaultWidgetOnPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        selectWidgetsModal.selectWidget("С чего начать");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        sectionPage.checkDefaultPageWidgetPublished();
    }

    @Test
    @Link(value = "0becc319-1711-48f3-970f-e3e65c9e11f7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/0becc319-1711-48f3-970f-e3e65c9e11f7)")
    @DisplayName("Добавить виджет \"Вкладки\"")
    public void addTabWidgetPageTest() {
        String sectionName = "addTabWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Вкладки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkTabWidgetAddedOnAppTypePage();
    }

    @Test
    @Link(value = "b717eddd-4112-4cf6-98e0-75cd5176b90d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b717eddd-4112-4cf6-98e0-75cd5176b90d)")
    @DisplayName("Добавить виджет \"Колонки\"")
    public void addColumnWidgetPageTest() {
        String sectionName = "addColumnWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Колонки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkColumnWidgetAddedOnAppTypePage();
    }

    @Test
    @Link(value = "3c36e0c7-a17a-48ac-85b1-fd65d3d4844f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3c36e0c7-a17a-48ac-85b1-fd65d3d4844f)")
    @DisplayName("Добавить виджет \"Панель с заголовком\"")
    public void addPanelWithTitleWidgetPageTest() {
        String sectionName = "addPanelWithTitleWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        String panelName = RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Панель с заголовком");
        widgetSettingsModal.fillPanelWithHeaderName(panelName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkTextPanelWithHeaderWidgetOnAppTypePage(panelName);
    }

    @Test
    @Link(value = "8740c2c4-415f-4c4d-b2ee-f797d3a02158", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8740c2c4-415f-4c4d-b2ee-f797d3a02158)")
    @DisplayName("Добавить виджет \"Код\"")
    public void addCodeWidgetPageTest() {
        String sectionName = "addCodeWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Код");
        widgetSettingsModal.fillCodeInCodeEditor("<div>Hello world!</div>");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        new SectionPage().checkTextCodeWidgetOnAppTypePage("Hello world!" + "\n" + pageName);
    }

    @Test
    @Link(value = "6addb16e-84ef-474c-a288-93e8431de14e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/6addb16e-84ef-474c-a288-93e8431de14e)")
    @DisplayName("Добавить виджет \"Текст\"")
    public void addTextWidgetPageTest() {
        String sectionName = "addTextWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        String randomText = RandomString.get(32);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Текст");
        widgetSettingsModal.fillTextInTextWidget(randomText);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkTextFromTextWidgetOnAppTypePage(randomText);
    }

    @Test
    @Link(value = "075b3920-32a4-42cd-806e-d3f32d6533c4", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/075b3920-32a4-42cd-806e-d3f32d6533c4)")
    @DisplayName("Добавить виджет \"Надпись\"")
    public void addInscriptionWidgetPageTest() {
        String sectionName = "addInscriptionWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        String inscription = RandomString.get(32);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Надпись");
        widgetSettingsModal.fillInscriptionWidget(inscription);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkTextFromInscriptionWidgetOnAppTypePage(inscription);
    }

    @Test
    @Link(value = "33d81df1-1795-41b9-95d4-c074a960e026", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/33d81df1-1795-41b9-95d4-c074a960e026)")
    @DisplayName("Добавить виджет \"Заголовок страницы\"")
    public void addPageHeaderWidgetPageTest() {
        String sectionName = "addPageHeaderWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Заголовок страницы");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkPageHeaderWidgetAddedOnAppTypePage();
    }

    @Test
    @Link(value = "33d81df1-1795-41b9-95d4-c074a960e026", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/33d81df1-1795-41b9-95d4-c074a960e026)")
    @DisplayName("Добавить виджет \"Содержимое страницы\"")
    public void addPageContentWidgetPageTest() {
        String sectionName = "addPageContentWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.dragWidgetAndDropArea("Содержимое страницы");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkPageContentWidgetAddedOnApTypePage();
    }

    @Test
    @Link(value = "3ed286c6-0f4d-48d7-9da1-2ad7dd283d18", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3ed286c6-0f4d-48d7-9da1-2ad7dd283d18)")
    @DisplayName("Добавить виджет на странице (Создать)")
    public void addWidgetOnPageCreateTest() {
        String sectionName = "addWidgetOnPageCreateTest" + RandomString.get(32);
        String widgetName = "WidgetName" + RandomString.get(8);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.clickCreateNewWidget();
        selectWidgetsModal.clickCreateNewWidget();
        selectWidgetsModal.fillWidgetName(widgetName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.dragWidgetAndDropArea("Вкладки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();
        pageConstructorPage.refreshPage();

        sectionPage.checkTabWidgetAddedOnAppTypePage();
    }

    @Test
    @Link(value = "3b7e4f8a-eafa-4eae-861f-f94c3b37a72e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/3b7e4f8a-eafa-4eae-861f-f94c3b37a72e)")
    @DisplayName("Контекст. Добавить простые свойства")
    public void addSimplePropertyWidgetPageTest() {
        String sectionName = "addSimplePropertyWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        String contextName = RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.fillContextName(contextName);
        createContextModal.dialogWindowPressButton("Создать");
        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickProperties();
        pageConstructorPage.dragContextAndDropArea(contextName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkNameContextWidgetOnAppTypePage(contextName);
    }

    @Test
    @Link(value = "685f180c-79c3-4e8c-b241-4d2284b4eb15", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/685f180c-79c3-4e8c-b241-4d2284b4eb15)")
    @DisplayName("Контекст. Добавить свойства типа Приложение")
    public void addTypeAppPropertyWidgetPageTest() {
        String sectionName = "addTypeAppPropertyWidgetPageTest" + RandomString.get(32);
        String pageName = "Page" + RandomString.get(10);
        String appName = "Компания";
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.appToolbar().selectSettingsPage("Конструктор");
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextApp();
        createContextModal.clickLinkSelectApp();
        selectAppModal.clickSectionInModal("CRM");
        selectAppModal.clickAppInModal("Компании");
        createContextModal.dialogWindowPressButton("Создать");
        pageConstructorPage.selectMainTab("Шаблон");
        pageConstructorPage.clickProperties();
        pageConstructorPage.dragContextAndDropArea(appName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();
        pageConstructorPage.clickBack();

        sectionPage.checkNameContextWidgetOnAppTypePage(appName);
    }

    @Test
    @Link(value = "68a83169-0bef-4f2d-a7d0-990ca6f0e4ac", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/68a83169-0bef-4f2d-a7d0-990ca6f0e4ac)")
    @DisplayName("Опубликовать созданный виджет")
    public void publishCreatedWidgetTest() {
        String sectionName = "addWidgetOnPageCreateTest" + RandomString.get(32);
        String widgetName = "WidgetName" + RandomString.get(8);
        String pageName = "Page" + RandomString.get(10);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.clickCreateNewWidget();
        selectWidgetsModal.clickCreateNewWidget();
        selectWidgetsModal.fillWidgetName(widgetName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.dragWidgetAndDropArea("Вкладки");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();

        pageConstructorPage.clickPublishAndCheckPublish();
    }

    @Test
    @Link(value = "e319dda4-7953-4165-894c-fe6f6f1a8e08", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e319dda4-7953-4165-894c-fe6f6f1a8e08)")
    @DisplayName("Удалить виджет со страницы")
    public void deleteWidgetTest() {
        String sectionName = "deleteWidgetTest" + RandomString.get(8);
        String pageName = "deleteWidgetPage" + RandomString.get(8);
        String widgetName = "titleBarText" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.clickCreateNewWidget();
        selectWidgetsModal.pressCreateTitleBarWidget();
        selectWidgetsModal.createTitleBarWidget(widgetName);
        selectWidgetsModal.deleteTitleBarWidget(widgetName);
        sectionPage.refreshPage();

        selectWidgetsModal.checkTitleBarWidgetDeleted();
    }

    @Test
    @Link(value = "e56d0ded-6c74-4e7b-ac85-05e36c940d7c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e56d0ded-6c74-4e7b-ac85-05e36c940d7c)")
    @DisplayName("Открыть настройки виджета")
    public void openWidgetSettingsTest() {
        String sectionName = "openWidgetSettingsTest" + RandomString.get(8);
        String pageName = "openWidgetSettingsPage" + RandomString.get(8);
        String widgetName = "titleBarText" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createPage(sectionName, pageName);

        sectionPage.open(sectionName, pageName);
        sectionPage.clickCreateNewWidget();
        selectWidgetsModal.pressCreateTitleBarWidget();
        selectWidgetsModal.createTitleBarWidget(widgetName);
        selectWidgetsModal.openSettingsTitleBarWidget(widgetName);

        selectWidgetsModal.checkTitleBarWidgetSettingsOpened();
    }
}
