package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendOrgStructure;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.elmaBackend.jsonTools.JsonOrgStructure;
import infrastructure.helpers.RandomString;
import infrastructure.helpers.configs.E2eTestConfig;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("zone_responsibility")})
public class ZoneResponsibilityTest {
    private final E2eTestConfig config = E2eTestConfig.getInstance();
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected FilePage filePage;
    @Inject
    protected ParameterSettingsModal parameterSettingsModal;
    @Inject
    protected BackendOrgStructure backendOrgStructure;
    @Inject
    protected AddCreateEventModal addCreateEventModal;
    @Inject
    protected TaskModal taskModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected SelectAppModal selectAppModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d540d28f-9b4c-4925-9a72-6bba9229d212", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d540d28f-9b4c-4925-9a72-6bba9229d212)")
    @DisplayName("Добавить динамическую зону ответственности плюсом")
    public void addDynamicZoneButtonPlusTest() {
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.addZoneResponsibilityButtonPlus();
        businessProcessPage.setDynamicZone();
        businessProcessPage.setVariableDynamicZone("Инициатор");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkAddTwoDynamicZone("Инициатор");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "09c08983-b9ed-4dd8-893a-2c85a677fd94", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/09c08983-b9ed-4dd8-893a-2c85a677fd94)")
    @DisplayName("Указать переменную для хранения исполнителя зоны ответственности")
    public void addDynamicZoneWithNewVariableTest() {
        String variableName = "UserZone" + RandomString.get(4);
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.addZoneResponsibilityButtonPlus();
        businessProcessPage.setDynamicZone();
        businessProcessPage.clickCreateNewVariableFromZone();
        createContextModal.fillContextName(variableName);
        createContextModal.dialogWindowPressButton("Создать");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(variableName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "15a45bae-b4ca-4c9a-97ce-ef79ea96c5ce", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/15a45bae-b4ca-4c9a-97ce-ef79ea96c5ce)")
    @DisplayName("Вынести динамическую зону на схему бизнес-процесса")
    public void addDynamicZoneOnSchemeTest() {
        String variableName = "UserZone" + RandomString.get(4);
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.dragAndDropZoneOnScheme("Вертикальная");
        businessProcessPage.setDynamicZone();
        businessProcessPage.clickCreateNewVariableFromZone();
        createContextModal.fillContextName(variableName);
        createContextModal.dialogWindowPressButton("Создать");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(variableName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "231399ff-a6c6-4f1b-af50-d5ec75056322", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/231399ff-a6c6-4f1b-af50-d5ec75056322)")
    @DisplayName("Проверить работу кнопки указать исполнителя позже для динамической зоны ответственности")
    public void addDynamicZoneWithoutVariableOnSchemeTest() {
        String variableName = "Исполнитель 1";
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.dragAndDropZoneOnScheme("Вертикальная");
        businessProcessPage.setStaticZone();
        createContextModal.dialogWindowPressButton("Выбрать исполнителя позже");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(variableName);
        businessProcessPage.openSettingZone(variableName);

        businessProcessPage.checkEmptyFieldVariableZone();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "fe3ef40f-2ce7-4229-bc52-519e8423a28c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/fe3ef40f-2ce7-4229-bc52-519e8423a28c)")
    @DisplayName("Проверить автоматическую выдачу прав на элементы приложений и файлы для динамической зоны")
    public void autoAccessForFileAndAppOnDynamicZoneTest() {
        String processName = "TestingProcessZone" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithTwoZoneAndContentVariable.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        mainPage.open();
        mainPage.sectionToolbar().selectSectionByCode("files");
        filePage.clickButtonMyFile();
        if (filePage.isFileNotExists("cats.png")) {
            filePage.uploadingPhotos("/testData/images/cats.png");
        }

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcess(processName);

        parameterSettingsModal.clickButtonOnField("МоиФайлы");
        parameterSettingsModal.clickItemContextMenu("Выбрать из Раздела \"Файлы\"");
        filePage.clickButtonMyFile();
        filePage.selectFile("cats.png");
        parameterSettingsModal.clickButtonOnField("Пользак");
        mainPage.clickSelectUser(userLogin);

        sectionPage.processStartConfirmation();
        //проверка под другим пользователем
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.refreshPage();

        businessProcessPage.open("/tasks/income");
        sectionPage.clickTask(processName, "Задача 1");
        parameterSettingsModal.checkExistWidgetOnBodyModal("cats.png");
        parameterSettingsModal.checkWidgetNotExistsOnBodyModal("app_trash");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "15914d46-9423-42ec-809b-cb63c9665d92", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/15914d46-9423-42ec-809b-cb63c9665d92)")
    @DisplayName("Добавить статическую зону ответственности плюсом")
    public void addStaticZoneButtonPlusTest() {
        String groupName = "UserZone" + RandomString.get(4);
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "TestingStaticZone" + RandomString.get(16);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createRoleInSection(groupName, sectionName);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.addZoneResponsibilityButtonPlus();
        businessProcessPage.setStaticZone();
        settingsBlockModal.selectFunction(groupName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(groupName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5ae55eaf-b4b5-4639-b234-6767fafe830d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5ae55eaf-b4b5-4639-b234-6767fafe830d)")
    @DisplayName("Создать переменную для хранения исполнителя статической зоны")
    public void addStaticZoneWithNewVariableTest() {
        String groupName = "UserZone" + RandomString.get(4);
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "TestingStaticZone" + RandomString.get(16);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createGroupInSection(groupName, sectionName);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.dragAndDropZoneOnScheme("Вертикальная");
        businessProcessPage.setStaticZone();
        settingsBlockModal.selectFunction(groupName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.checkElementByName(groupName);
        businessProcessPage.openSettingZone(groupName);

        businessProcessPage.clickCreateNewVariableFromZone();
        createContextModal.fillContextName(groupName);
        createContextModal.dialogWindowPressButton("Создать");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(groupName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e25852ca-fe98-41a6-9c46-665ce6a660ff", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e25852ca-fe98-41a6-9c46-665ce6a660ff)")
    @DisplayName("Проверить работу кнопки указать исполнителя позже для статической зоны ответственности")
    public void addStaticZoneWithoutVariableOnSchemeTest() {
        String variableName = "Исполнитель 1";
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "TestingProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.dragAndDropZoneOnScheme("Вертикальная");
        businessProcessPage.setStaticZone();
        createContextModal.dialogWindowPressButton("Выбрать исполнителя позже");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(variableName);
        businessProcessPage.openSettingZone(variableName);

        businessProcessPage.checkEmptyFieldVariableZone();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f28c9289-5a33-4cff-bede-b6133b0537cc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f28c9289-5a33-4cff-bede-b6133b0537cc)")
    @DisplayName("Указать исполнителя статической зоны ответственности - роль после добавления зоны")
    public void setRoleToStaticZoneTest() {
        String groupName = "UserZone" + RandomString.get(4);
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "TestingStaticZone" + RandomString.get(16);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createRoleInSection(groupName, sectionName);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.addZoneResponsibilityButtonPlus();
        businessProcessPage.setStaticZone();
        settingsBlockModal.selectFunction(groupName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(groupName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2902d404-571a-4349-99e2-d0dd97c4e203", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2902d404-571a-4349-99e2-d0dd97c4e203)")
    @DisplayName("Указать исполнителя статической зоны ответственности - группу после добавления зоны")
    public void setGroupToStaticZoneTest() {
        String groupName = "UserZone" + RandomString.get(4);
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "TestingStaticZone" + RandomString.get(16);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createGroupInSection(groupName, sectionName);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.addZoneResponsibilityButtonPlus();
        businessProcessPage.setStaticZone();
        settingsBlockModal.selectFunction(groupName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(groupName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "8dc563ba-93f9-44e0-9455-85535259e2d5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8dc563ba-93f9-44e0-9455-85535259e2d5)")
    @DisplayName("Указать исполнителя статической зоны ответственности - элемент орг структуры после добавления")
    public void setOrgStructureToStaticZoneTest() {
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "TestingStaticZone" + RandomString.get(16);

        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        String positionName = "StructureZone" + RandomString.get(4);
        String positionId = RandomString.getUUID();
        String jsonOrgStructure = new JsonOrgStructure.Builder()
                .addNewPositionInJson(new JsonOrgStructure.Builder()
                        .setJsonFile("testData/OrgStructure/PositionCreation.json")
                        .createDefault())
                .setJsonFile("testData/OrgStructure/PositionCreation.json")
                .setName(positionName)
                .setId(positionId)
                .setType("POSITION")
                .setParentId("242c7e76-ff4f-5523-815d-b219626acb54")
                .addStructureInJsonArray()
                .buildAndGetAsString();
        backendOrgStructure.createOrgStructure(jsonOrgStructure);
        elmaBackend.setUserOnPositionByUserId(elmaBackend.getUserIdByEmail(config.userLogin), positionId);

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.addZoneResponsibilityButtonPlus();
        businessProcessPage.setStaticZone();
        settingsBlockModal.clickButtonSettingZone("Элемент оргструктуры");
        settingsBlockModal.selectOrgStructure(positionName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        businessProcessPage.checkElementByName(positionName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d406d10c-c006-4605-9153-70864e06413d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d406d10c-c006-4605-9153-70864e06413d)")
    @DisplayName("Проверить автоматическую выдачу прав на элементы приложений для статической зоны")
    public void autoRightsByStaticZoneWithTest() {
        String groupName = "UserZone" + RandomString.get(4);
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "autoRightsByStaticZone" + RandomString.get(16);
        String appName = "appForZone" + RandomString.get(3);
        String taskAppName = "taskAppName" + RandomString.get(3);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createRoleInSection(groupName, sectionName + "." + appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStaticZone.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextApp();
        createContextModal.clickLinkSelectApp();
        selectAppModal.clickAppInModal(appName);
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSettingsZoneResponsibility("Исполнитель 1");
        parameterSettingsModal.clickAndSelectDropDownItem("Выберите группу", groupName);
        settingsBlockModal.chooseTab("Права доступа");
        createContextModal.setCheckboxConditionByLabel("Автоматически выдавать права на элементы Приложений и файлы используемые в задачах", true);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");

        settingsBlockModal.clickRadioButton("Ограничить доступ к данным");
        settingsBlockModal.clickRadioButton("На уровне элементов Приложения");
        mainPage.switchOffRightsForUserGroup("Все пользователи");
        mainPage.clickButtonOnAppContent("Сохранить");
        sectionPage.open(sectionName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        addCreateEventModal.fillName(taskAppName);
        createContextModal.clickModalFooterButton("Сохранить");
        taskModal.confirmInfoStartTask(processName);
        //проверка под другим пользователем
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.refreshPage();

        businessProcessPage.open("/tasks/income");
        sectionPage.clickTask(processName, "Задача 1");
        interfaceDesignerPage.checkAppElementExistsOnForm(taskAppName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "2969ea73-b6b5-4197-a78f-554dd6e4b4bf", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/2969ea73-b6b5-4197-a78f-554dd6e4b4bf)")
    @DisplayName("Проверить отключение автоматической выдачи прав на элементы приложений для статической зоны")
    public void notAutoRightsByStaticZoneWithTest() {
        String groupName = "UserZone" + RandomString.get(4);
        String sectionName = "Zone" + RandomString.get(4);
        String processName = "autoRightsByStaticZone" + RandomString.get(16);
        String appName = "appForZone" + RandomString.get(3);
        String taskAppName = "taskAppName" + RandomString.get(3);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createRoleInSection(groupName, sectionName + "." + appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName + "." + appName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStaticZone.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);

        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextApp();
        createContextModal.clickLinkSelectApp();
        selectAppModal.clickAppInModal(appName);
        createContextModal.dialogWindowPressButton("Создать");

        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(appName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsZoneResponsibility("Исполнитель 1");
        parameterSettingsModal.clickAndSelectDropDownItem("Выберите группу", groupName);
        settingsBlockModal.chooseTab("Права доступа");
        createContextModal.setCheckboxConditionByLabel("Автоматически выдавать права на элементы Приложений и файлы используемые в задачах", false);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open(sectionName);
        sectionPage.appToolbar().selectSettingsApp("Настройка доступа");

        settingsBlockModal.clickRadioButton("Ограничить доступ к данным");
        settingsBlockModal.clickRadioButton("На уровне Приложения");
        mainPage.switchOffRightsForUserGroup("Все пользователи");
        mainPage.clickButtonOnAppContent("Сохранить");
        sectionPage.open(sectionName);
        mainPage.clickButtonOnAppContent("+ " + appName);
        addCreateEventModal.fillName(taskAppName);
        createContextModal.clickModalFooterButton("Сохранить");
        taskModal.confirmInfoStartTask(processName);
        //проверка под другим пользователем
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.refreshPage();

        businessProcessPage.open("/tasks/income");
        sectionPage.clickTask(processName, "Задача 1");
        interfaceDesignerPage.checkAppElementNotExistsOnForm(taskAppName);
        sectionPage.clickNextStageOrExit();
    }
}
