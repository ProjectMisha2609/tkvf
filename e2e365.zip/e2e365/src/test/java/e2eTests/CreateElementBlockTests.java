package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.ChangeElementBlockModal;
import pages.elmaModals.CreateContextModal;
import pages.elmaModals.NomenclatureModal;
import pages.elmaModals.SettingsBlockModal;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.SectionPage;

import java.util.Locale;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("create_element_block")})
public class CreateElementBlockTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f811ded4-97ae-4043-9e78-83be0e3c9667", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f811ded4-97ae-4043-9e78-83be0e3c9667)")
    @DisplayName("Проверить создание элемента автоматически")
    public void checkAutoCreateElementPBTest() {
        String processName = "checkAutoCreateElementPB" + RandomString.get(4);
        String sectionName = "checkAutoCreateElementPBSectionName" + RandomString.get(4);
        String appName = "createApp" + RandomString.get(4);
        String randomString = "randomString" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithCreateElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Созданиеэлемента 1");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Создание элемента 1", " ", appName);
        changeElementBlockModal.clickRadioButton("Автоматически");

        settingsBlockModal.chooseTab("Значения полей");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Добавить");

        changeElementBlockModal.setFieldContextBPBinding("Название");
        changeElementBlockModal.setFieldContextBPBinding("<Ввести значение>");
        changeElementBlockModal.setManualTextInput(randomString);

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        backendBusinessProcess.run(processId, EMPTY_JSON);

        sectionPage.open(sectionName, appName);
        sectionPage.checkAppElementExist(randomString);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "9a095cb7-a719-4a0b-b51d-f3eb91bc23e6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9a095cb7-a719-4a0b-b51d-f3eb91bc23e6)")
    @DisplayName("Проверить создание элемента вручную")
    public void checkManualCreateElementPBTest() {
        String processName = "checkManualCreateElementPB" + RandomString.get(4);
        String sectionName = "checkManualCreateElementPBSectionName" + RandomString.get(4);
        String appName = "createApp" + RandomString.get(4);
        String randomString = "randomString" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithCreateElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Созданиеэлемента 1");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Создание элемента 1", " ", appName);
        changeElementBlockModal.clickRadioButton("Вручную");

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);
        sectionPage.clickNextStageOrExit();
        changeElementBlockModal.setTextInputByFormRowName("Название", randomString);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("успешно создан");

        sectionPage.open(sectionName, appName);
        sectionPage.checkAppElementExist(randomString);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "a7440a39-56e4-4dfe-af02-2d292139532b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a7440a39-56e4-4dfe-af02-2d292139532b)")
    @DisplayName("Проверить возможность привязки полей на вкладке Значения полей")
    public void checkBindingFieldsPBTest() {
        String processName = "checkBindingFieldsPB" + RandomString.get(4);
        String sectionName = "checkBindingFieldsPBSectionName" + RandomString.get(4);
        String appName = "createApp" + RandomString.get(4);
        String variableName = "string" + RandomString.get(4);
        String randomString = "randomString" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcessWithCreateElement.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(appName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING, false))
                        .addContextOnDefaultStartForm(appName, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Созданиеэлемента 1");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Создание элемента 1", " ", appName);
        changeElementBlockModal.clickRadioButton("Автоматически");

        settingsBlockModal.chooseTab("Значения полей");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Добавить");

        changeElementBlockModal.setFieldContextBPBinding("Название");
        changeElementBlockModal.setFieldContextBPBinding(variableName);

        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startSectionProcessWithName(sectionName, processName);

        changeElementBlockModal.setTextInputByFormRowName(variableName, randomString);
        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open(sectionName, appName);
        sectionPage.checkAppElementExist(randomString);
    }
}