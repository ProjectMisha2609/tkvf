package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("contracts")})
public class ContractsTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected ProcessMonitorPage processMonitorPage;
    @Inject
    protected ContractPage contractPage;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected SelectAppModal selectAppModal;
    @Inject
    protected CrmSectionPage crmSectionPage;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected ChangeElementBlockModal changeElementBlockModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected NomenclaturePage nomenclaturePage;
    @Inject
    protected CreateAppModal createAppModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "c2361baf-45a1-4456-9991-a15545f1a3d1", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c2361baf-45a1-4456-9991-a15545f1a3d1)")
    @DisplayName("Проверить создание контракта")
    public void checkCreateContractTest() {
        String sectionName = "checkCreateContractSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);

        sectionPage.open(sectionName);
        sectionPage.clickAddAppOrPageButton();
        settingsBlockModal.clickButtonOnModalWindowByName("Приложение");
        settingsBlockModal.clickButtonSettingZone("Контракт");
        nomenclatureModal.setTextInputByFormRowName("Название Контракта", contractName);
        nomenclatureModal.dialogWindowPressButton("Создать");
        contractPage.clickSaveSettingButton();
        processMonitorPage.checkProcessNameInTitle(contractName);
        processMonitorPage.checkProcessNameInTitle("Контракты");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5f7f658f-1bb0-4942-824d-acae3c6cb376", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5f7f658f-1bb0-4942-824d-acae3c6cb376)")
    @DisplayName("Проверить добавление полей контракта")
    public void checkAddFieldsContractTest() {
        String sectionName = "checkAddFieldsContractSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "addAppName" + RandomString.get(8);
        String fieldName = "fieldName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);

        sectionPage.open(sectionName, contractName);
        sectionPage.appToolbar().selectSettingsContract("Поля контракта");
        contractPage.clickHeaderButton("Добавить");
        createContextModal.fillContextName(fieldName);
        createContextModal.dialogWindowPressButton("Создать");
        contractPage.clickFooterButton("Сохранить");
        crmSectionPage.checkAlertWithTextFragmentExists("Поля сохранены успешно");
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.clickSourceSelectorButton();
        contractPage.selectSourceApp(sectionName, appName);

        contractPage.checkAppBindingOnListExists(fieldName);
        createContextModal.dialogWindowPressButton("Выбрать приложение");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0be128eb-cb0c-4e12-8cba-f8d3429f5cf8", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0be128eb-cb0c-4e12-8cba-f8d3429f5cf8)")
    @DisplayName("Проверить настройку таблицы отображения для контрактов")
    public void checkTableViewContractTest() {
        String sectionName = "checkTableViewContractSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "addAppName" + RandomString.get(8);
        String elementName1 = "FirstElementName" + RandomString.get(8);
        String elementName2 = "SecondElementName" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName1, sectionName, appName);
        elmaBackend.createElement(elementName2, sectionName, appName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        elmaBackend.setAppSourceContract(sectionName, appName, contractName);

        sectionPage.open(sectionName, contractName);
        contractPage.setViewStreamOnList();
        contractPage.clickSettingTableContractButton("Настройка таблицы");
        contractPage.addPropertyForTable("Идентификатор");
        createContextModal.dialogWindowPressButton("Сохранить");
        contractPage.checkColumnTableExists("Идентификатор");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "ecccad45-8284-4502-b038-29fc8166fc48", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/ecccad45-8284-4502-b038-29fc8166fc48)")
    @DisplayName("Проверить изменение контракта в процессе")
    public void checkEditContractInProcessTest() {
        String processName = "checkEditContractInProcess" + RandomString.get(16);
        String sectionName = "checkEditContractInProcessSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "addAppName" + RandomString.get(8);
        String variableName = "variableString" + RandomString.get(4);
        String fieldVariableName = "fieldVariable" + RandomString.get(4);
        String elementName = "elementName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        elmaBackend.setAppSourceContract(sectionName, appName, contractName);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithChangeElement.json")
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(contractName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), contractName.toLowerCase()))
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.STRING, false))
                        .addContextOnDefaultStartForm(contractName, "", false, false, false)
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, contractName);
        sectionPage.appToolbar().selectSettingsContract("Поля контракта");
        contractPage.clickHeaderButton("Добавить");
        createContextModal.fillContextName(variableName);
        createContextModal.dialogWindowPressButton("Создать");
        contractPage.clickFooterButton("Сохранить");
        crmSectionPage.checkAlertWithTextFragmentExists("Поля сохранены успешно");

        businessProcessPage.open("admin/process/" + processId);

        businessProcessPage.clickSettingsBlock("Изменение");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Изменение элемента 1", " ", contractName);
        contractPage.chooseParameterRadioButton("Способ создания", "Автоматически");
        settingsBlockModal.chooseTab("Значения полей");
        settingsBlockModal.clickButtonOnModalWindowByName("+ Добавить");
        changeElementBlockModal.setAppBinding(variableName, variableName);
        createContextModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);

        settingsBlockModal.clickZoomAll();
        settingsBlockModal.chooseRowTable(elementName);
        contractPage.setParameterSingleInput(variableName, fieldVariableName);
        sectionPage.clickNextStageOrExit();
        crmSectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open(sectionName, contractName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.checkAppElementExistsOnForm(fieldVariableName);
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "44642a01-3bfa-4bf5-b6b2-65e91e049466", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/44642a01-3bfa-4bf5-b6b2-65e91e049466)")
    @DisplayName("Проверить согласование контракта в процессе")
    public void checkApprovalContractInProcessTest() {
        String processName = "checkApprovalContractInProcess" + RandomString.get(16);
        String sectionName = "checkApprovalContractInProcessSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "addAppName" + RandomString.get(8);
        String comment = "commentString" + RandomString.get(4);
        String elementName = "elementName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        elmaBackend.setAppSourceContract(sectionName, appName, contractName);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleAgreementProcess.json")
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(contractName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), contractName.toLowerCase()))
                        .addContextOnDefaultStartForm(contractName, "", false, false, false)
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Согласование");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Согласование 1", " ", contractName);
        settingsBlockModal.chooseTab("Переходы");
        nomenclaturePage.chooseRowRadioButton(" ");
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);

        settingsBlockModal.clickZoomAll();
        settingsBlockModal.chooseRowTable(elementName);
        sectionPage.clickNextStageOrExit();
        crmSectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        settingsBlockModal.clickModalFooterButton("Согласовать");
        settingsBlockModal.fillCommentConfirmDialog(comment);
        settingsBlockModal.clickConfirmDialogButton("Согласовать");

        sectionPage.open(sectionName, contractName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.checkExistsWidgetOnToolBar("СОГЛАСОВАНО");
        interfaceDesignerPage.checkExistsWidgetOnToolBar(comment);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5b4a142b-2732-49a6-a004-5b676d9891cc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5b4a142b-2732-49a6-a004-5b676d9891cc)")
    @DisplayName("Проверить ознакомление с контрактом в процессе")
    public void checkFamiliarizationContractInProcessTest() {
        String processName = "checkFamiliarizationContract" + RandomString.get(8);
        String sectionName = "checkFamiliarizationContractSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(8);
        String comment = "commentString" + RandomString.get(4);
        String elementName = "elementName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        elmaBackend.setAppSourceContract(sectionName, appName, contractName);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleFamiliarizeProcess.json")
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(contractName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(), contractName.toLowerCase()))
                        .addContextOnDefaultStartForm(contractName, "", false, false, false)
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);


        businessProcessPage.clickSettingsBlock("Ознакомление");
        nomenclatureModal.clickAndSelectDropDownItemWithNameForm("Ознакомление 1", " ", contractName);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);

        settingsBlockModal.clickZoomAll();
        settingsBlockModal.chooseRowTable(elementName);
        sectionPage.clickNextStageOrExit();
        crmSectionPage.checkAlertWithTextFragmentExists("Запущен процесс");
        settingsBlockModal.clickModalFooterButton("Ознакомиться");
        settingsBlockModal.fillCommentConfirmDialog(comment);
        settingsBlockModal.clickConfirmDialogButton("Ознакомиться");

        sectionPage.open(sectionName, contractName);
        sectionPage.openAppElement(sectionName, appName, elementName);
        interfaceDesignerPage.checkExistsWidgetOnToolBar("ОЗНАКОМИЛИСЬ");
        interfaceDesignerPage.checkExistsWidgetOnToolBar(comment);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "92c3ca49-c358-47e3-b8f2-56f65bb3903c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/92c3ca49-c358-47e3-b8f2-56f65bb3903c)")
    @DisplayName("Добавить новое приложение типа стандартное в настройках источников контракта")
    public void addStandardAppInSettingSourceContractTest() {
        String sectionName = "addStandardAppSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        sectionPage.open(sectionName, contractName);
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.clickHeaderButton("Новое приложение");
        contractPage.setTextInputByFormRowName("Название Приложения", appName);
        settingsBlockModal.dialogWindowPressButton("Создать");
        contractPage.checkAlertWithTextFragmentExists("Источник добавлен успешно");
        sectionPage.open(sectionName, contractName);// TODO форма создания на автомате не закрывается. на s-стенде закрывается автоматически
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.checkSourceAppExists(sectionName, appName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "27e5374e-0aef-456d-9943-6dba9f9255fc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/27e5374e-0aef-456d-9943-6dba9f9255fc)")
    @DisplayName("Проверить, что новое приложение типа документ не добавляется в источники контракта, если в контракте отсутствует поле с кодом file типа Файл")
    public void impossibilityAddDocumentAppInSettingSourceContractTest() {
        String sectionName = "impossibilityAddAppSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        sectionPage.open(sectionName, contractName);
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.clickHeaderButton("Новое приложение");
        contractPage.setTextInputByFormRowName("Название Приложения", appName);
        createAppModal.chooseTypeOfApp("Документ");
        settingsBlockModal.dialogWindowPressButton("Создать");
        contractPage.checkAlertWithTextFragmentExists("invalid argument");
        sectionPage.open(sectionName, contractName);// TODO форма создания на автомате не закрывается. на s-стенде закрывается автоматически
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.checkTextAboutNotAppSource();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d60c1ae0-0922-4847-ade5-c7b5d4caff96", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d60c1ae0-0922-4847-ade5-c7b5d4caff96)")
    @DisplayName("Добавить новое приложение типа документ в настройках источников контракта")
    public void addDocumentAppInSettingSourceContractTest() {
        String sectionName = "addDocumentAppSectionName" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(4);
        String variableName = "file"; // необходимо только такое название переменной

        elmaBackend.createSection(sectionName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        sectionPage.open(sectionName, contractName);

        sectionPage.appToolbar().selectSettingsContract("Поля контракта");
        contractPage.clickHeaderButton("Добавить");
        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextFiles();
        createContextModal.dialogWindowPressButton("Создать");
        contractPage.clickFooterButton("Сохранить");
        crmSectionPage.checkAlertWithTextFragmentExists("Поля сохранены успешно");

        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.clickHeaderButton("Новое приложение");
        contractPage.setTextInputByFormRowName("Название Приложения", appName);
        createAppModal.chooseTypeOfApp("Документ");
        settingsBlockModal.dialogWindowPressButton("Создать");
        contractPage.checkAlertWithTextFragmentExists("Источник добавлен успешно");
        sectionPage.open(sectionName, contractName);// TODO форма создания на автомате не закрывается. на s-стенде закрывается автоматически
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.checkSourceAppExists(sectionName, appName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "bc001dfa-cdac-459c-8c55-7c3d78435d7f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/bc001dfa-cdac-459c-8c55-7c3d78435d7f)")
    @DisplayName("Проверить удаление источника контракта")
    public void checkDeleteSourceContractTest() {
        String sectionName = "checkDeleteSource" + RandomString.get(4);
        String contractName = "contractName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createContract(sectionName, contractName);
        elmaBackend.setDefaultSettingContract(sectionName, contractName);
        elmaBackend.setAppSourceContract(sectionName, appName, contractName);

        sectionPage.open(sectionName, contractName);
        sectionPage.appToolbar().selectSettingsContract("Настройки источников");
        contractPage.selectSourceApp(sectionName, appName);
        settingsBlockModal.dialogWindowPressButton("Удалить");
        settingsBlockModal.dialogWindowPressButton("ОК");
        contractPage.clickFooterButton("Сохранить");
        contractPage.checkAlertWithTextFragmentExists("Источники сохранены успешно");
        contractPage.refreshPage(); // TODO надпись "Нет источников для контракта" появится только после перезагрузки страницы
        contractPage.checkTextAboutNotAppSource();
    }
}