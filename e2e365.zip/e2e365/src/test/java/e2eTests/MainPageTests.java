package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaModals.*;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.UserStatus.INVITED;

@MicronautTest
@Tags({@Tag("express"), @Tag("main_page")})
public class MainPageTests {
    @Inject
    protected MainPage mainPage;
    @Inject
    protected SectionSettingsModal settingsModal;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected CreateAppElementModal createApplicationElementModal;
    @Inject
    protected CreateTaskModal createTaskModal;
    @Inject
    protected SettingsPageModal settingsPageModal;
    @Inject
    protected SelectProcessModal selectProcessModal;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Link(value = "8d5c7c21-a8e2-47f2-b20b-4560af2d25ad", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/8d5c7c21-a8e2-47f2-b20b-4560af2d25ad)")
    @DisplayName("Создать задачу по кнопке из верхнего меню")
    public void createTaskTest() {
        mainPage.open();
        mainPage.selectFromCreateMenu("Задача");
        createTaskModal.fillSubject("TestTask" + RandomString.get(8));
        createTaskModal.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickModalFooterButton("Создать задачу");

        mainPage.checkToastAppeared();
    }

    @Test
    @Link(value = "98ff7a00-86da-4bfa-834f-7098e204080e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/98ff7a00-86da-4bfa-834f-7098e204080e)")
    @DisplayName("Запустить бизнес-процесс по кнопке из верхнего меню")
    public void createBusinessProcessTest() {
        mainPage.open();
        mainPage.selectFromCreateMenu("Запустить бизнес-процесс");
        selectProcessModal.selectFromSystemProcesses("Задача");
        createTaskModal.fillSubject("TestTask" + RandomString.get(8));
        createTaskModal.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickModalFooterButton("Создать задачу");

        mainPage.checkToastAppeared();
    }

    @Test
    @Link(value = "415db3ef-f5ce-4cfc-9e1e-0dbf26f7a169", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/415db3ef-f5ce-4cfc-9e1e-0dbf26f7a169)")
    @DisplayName("Создать элемент приложения по кнопке из верхнего меню")
    public void createApplicationElementFromMainPageTest() {
        mainPage.open();
        mainPage.clickCreate();
        mainPage.moveCursorOnSections("Системные справочники");
        mainPage.clickApp("Юридическое лицо");
        String appElementName = "SystemDirectoryApp" + RandomString.get(8);
        createApplicationElementModal.fillName(appElementName);
        createApplicationElementModal.clickModalFooterButton("Сохранить");
        sectionPage.open("_system_catalogs", "_my_companies");

        sectionPage.checkHeaderTitleCard(appElementName);
    }

    @Test
    @Link(value = "15eb84c0-60fd-4efd-8af6-1ef615e1eb24", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/15eb84c0-60fd-4efd-8af6-1ef615e1eb24)")
    @DisplayName("Настроить страницу в две колонки")
    public void customizePageTwoColumnsTest() {
        mainPage.open();
        mainPage.selectPageSettings("Настройки страницы");
        settingsPageModal.selectTwoColumns();
        settingsPageModal.dialogWindowPressButton("Сохранить");
        // todo: иногда не нажимается клавиша сохранить
        mainPage.checkPageSetToTwoColumn();
    }

    @Test
    @Link(value = "7f891876-fbeb-4696-a0d5-44722f211540", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/7f891876-fbeb-4696-a0d5-44722f211540)")
    @DisplayName("Настроить страницу в одну колонку")
    public void customizePageOneColumnsTest() {
        mainPage.open();
        mainPage.selectPageSettings("Настройки страницы");
        settingsPageModal.selectOneColumns();
        settingsPageModal.dialogWindowPressButton("Сохранить");

        mainPage.checkPageSetToOneColumn();
    }

    @Test
    @Link(value = "59283b77-d130-4663-a19e-041523630cba", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/59283b77-d130-4663-a19e-041523630cba)")
    @DisplayName("Добавить раздел с главной страницы")
    public void addSectionTestFromMainPage() {
        String sectionName = "addSectionTest" + RandomString.get(16);
        mainPage.open();
        mainPage.clickCreateSection();
        settingsModal.fillNewSectionName(sectionName);
        settingsModal.dialogWindowPressButton("Создать");

        mainPage.appToolbar().checkSectionName(sectionName);
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "3b8dc92d-9032-4500-a54e-7e9b76f0391f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3b8dc92d-9032-4500-a54e-7e9b76f0391f)")
    @DisplayName("Добавить пользователя с главной страницы")
    public void addUserTestFromMainPage() {
        String emailString = RandomString.get(10) + "@mail.com";

        mainPage.open();
        mainPage.clickAddNewUser();
        createApplicationElementModal.fillEmail(emailString);
        createApplicationElementModal.clickModalFooterButton("Выслать приглашение");
        mainPage.isUserAdded();
        Assertions.assertTrue(elmaBackend.isUserWithStatusExists(emailString, INVITED),
                "Пользователь с запрошенным логином и статусом не найден");
    }
}
