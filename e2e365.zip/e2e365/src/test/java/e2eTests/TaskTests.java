package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.BusinessProcessPage;
import pages.elmaPages.InterfaceDesignerPage;
import pages.elmaPages.MessagePage;
import pages.elmaPages.SectionPage;

import java.time.LocalDate;

import static infrastructure.elmaBackend.BackendUser.adminLogin;
import static infrastructure.elmaBackend.BackendUser.userLogin;
import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;

@MicronautTest
@Tags({@Tag("express"), @Tag("task")})
public class TaskTests {
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected CreateTaskModal createTaskModal;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SelectAppModal selectAppModal;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected PropertyContextTypeTableModal propertyContextTypeTableModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected MessagePage messagePage;

    @Test
    @Link(value = "b218679f-3b32-450d-b647-c15e637756ce", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/b218679f-3b32-450d-b647-c15e637756ce)")
    @DisplayName("Проверить работу кнопки \"Сделано\"")
    public void taskDoneButtonTest() {
        String taskName = "taskDoneButton" + RandomString.get(8);

        sectionPage.open("tasks", "income");
        sectionPage.appHeaderToolbar().clickActionButton("Задача");

        createTaskModal.fillSubject(taskName);
        createTaskModal.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickControlChoice();
        createTaskModal.chooseControlType("Не требуется");
        createTaskModal.clickModalFooterButton("Создать задачу");
        createTaskModal.clickModalFooterButton("Сделано");
        createTaskModal.clickConfirmDone();
        sectionPage.clickAllTasks();
        sectionPage.clickTask(taskName);

        createTaskModal.checkStatusTaskIsDone();
    }

    @Test
    @Link(value = "93e8d5fa-acc1-4edb-b5bd-b1d622c298e3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/93e8d5fa-acc1-4edb-b5bd-b1d622c298e3)")
    @DisplayName("Список действий. Переназначить")
    public void taskReassignTest() {
        String taskName = "taskReassign" + RandomString.get(8);

        sectionPage.open("tasks", "income");
        sectionPage.appHeaderToolbar().clickActionButton("Задача");

        createTaskModal.fillSubject(taskName);
        createTaskModal.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickModalFooterButton("Создать задачу");
        //TODO костыль с ожиданием
        CustomDriver.waitMills(2000);
        sectionPage.open("tasks", "income");

        sectionPage.clickTask(taskName);
        createTaskModal.clickThreePointsOption("Переназначить");
        createTaskModal.clickExtendSearch();
        createTaskModal.fillReassignExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickSubmitReassign();
        sectionPage.clickTaskType("Исходящие");
        sectionPage.clickTask(taskName);

        createTaskModal.checkReassignedExecutorEmailCorrect();
    }

    @Test
    @Link(value = "c08decea-e942-4da3-bc79-4f60baeedba9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/c08decea-e942-4da3-bc79-4f60baeedba9)")
    @DisplayName("Проверить поиск по полю \"Автор\"")
    public void checkTaskSearchByAuthorTest() {
        String sectionName = "tasks";
        String appName = "income";
        String taskName = RandomString.get(16);

        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickActionButton("Задача");

        createTaskModal.fillSubject(taskName);
        createTaskModal.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickModalFooterButton("Создать задачу");
        //TODO с ожиданием это костыль!
        CustomDriver.waitMills(2000);//Ждем если вдруг задача упадет на нас
        sectionPage.open(sectionName, appName);
        sectionPage.clickSearchInParametersTasks();
        sectionPage.clickSystemFields("Системные поля");
        sectionPage.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        sectionPage.clickSearchByParameters();

        sectionPage.checkTaskWithNameAppearFromProcess(taskName, "Задача");
    }

    @Test
    @Link(value = "e0947005-73bf-4454-9947-9fd4efcb527f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/e0947005-73bf-4454-9947-9fd4efcb527f)")
    @DisplayName("Проверить поиск по Названию")
    public void checkTaskSearchByNameTest() {
        String sectionName = "tasks";
        String appName = "income";
        String taskName = RandomString.get(16);
        sectionPage.open(sectionName, appName);
        sectionPage.appHeaderToolbar().clickActionButton("Задача");

        createTaskModal.fillSubject(taskName);
        createTaskModal.clickExtendSearch();
        createTaskModal.fillEmailExecutor();
        createTaskModal.clickFoundedExecutor();
        createTaskModal.clickModalFooterButton("Создать задачу");
        //TODO костыль с ожиданием
        CustomDriver.waitMills(2000);
        sectionPage.open(sectionName, appName);
        sectionPage.fillNameTaskBySearch(taskName);
        sectionPage.clickSearchInTasks();

        sectionPage.checkTaskWithNameAppearFromProcess(taskName, "Задача");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "1bbe3654-b9f5-4f61-873d-1909bc33eab3", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1bbe3654-b9f5-4f61-873d-1909bc33eab3)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи с типом - точное время")
    public void checkTimeLimitOfTaskWithTypeExactTimeTest() {
        int differenceOfDays = 5;
        String businessProcessName = "checkTimeLimitOfTaskWithTypeExactTimeProcessName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.inputDateLimitDeadline(differenceOfDays);
        settingsBlockModal.removeCheckMarkFromTakeIntoAccountWorkCalendar();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("tasks/income");

        sectionPage.checkDifferentDateStartAndFinishDate(businessProcessName, differenceOfDays);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "321605c6-8bcb-428f-ace7-74d14503850b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/321605c6-8bcb-428f-ace7-74d14503850b)")
    @DisplayName("Изменить название операции Задача, используя шаблон")
    public void changeNameOfTaskOperationUseTemplateTest() {
        String businessProcessName = "changeNameOfTaskOperationUseTemplateProcessName" + RandomString.get(8);
        String pattern = RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.checkBoxFormNameOfTaskAccordToTemplate();
        settingsBlockModal.inputPattern("{$__createdBy.__name}" + pattern);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("/tasks/income");

        sectionPage.checkNameTaskPattern(elmaBackend.getUserFIOByEmail(adminLogin) + pattern);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4ed5fdf4-c3ef-4929-9ab3-9fe60aec9d8c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4ed5fdf4-c3ef-4929-9ab3-9fe60aec9d8c)")
    @DisplayName("Запланировать задачу в календаре")
    public void scheduleTaskInCalendarTest() {
        String processName = "scheduleTaskInCalendarProcessName" + RandomString.get(8);
        String taskName = "scheduleTaskInCalendarTaskName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessWithStartAndFinishWorkCalendar.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        businessProcessPage.open("admin/process", processId);
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.fillNameBlock(taskName);
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.chooseTab("Планирование в календаре");
        settingsBlockModal.checkboxScheduleTaskInCalendar();
        settingsBlockModal.selectDateStartAndFinish();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        businessProcessPage.open("schedule");

        sectionPage.checkVisibleTaskInCalendar(taskName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "584ed49b-ad6a-476d-87dd-f735d91ce073", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/584ed49b-ad6a-476d-87dd-f735d91ce073)")
    @DisplayName("Добавить на форму задачи контекст типа приложение")
    public void addApplicationTypeContextToTaskFormTest() {
        String sectionName = "addApplicationTypeContextToTaskFormSectionName" + RandomString.get(8);
        String appName = "addApplicationTypeContextToTaskFormAppName" + RandomString.get(8);
        String columnName = "Column" + RandomString.get(4);
        String businessProcessName = "addApplicationTypeContextToTaskFormProcessName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        propertyContextTypeTableModal.fillNameColumn(columnName);
        propertyContextTypeTableModal.selectTypeApp();
        propertyContextTypeTableModal.clickLinkSelectApp();
        selectAppModal.clickSectionInModal(sectionName);
        selectAppModal.clickAppInModal(appName);
        createContextModal.dialogWindowPressButton("Создать");
        settingsBlockModal.noteContextVariable(columnName);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(columnName);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "5da40055-23ed-4b37-918f-9f8e20017657", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5da40055-23ed-4b37-918f-9f8e20017657)")
    @DisplayName("Настроить новую форму отображения")
    public void setUpNewDisplayFormTest() {
        String businessProcessName = "setUpNewDisplayFormName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        interfaceDesignerPage.checkTabVisible("Вкладка");
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "85e001f6-18e3-4850-bab3-f6d2b69898a5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/85e001f6-18e3-4850-bab3-f6d2b69898a5)")
    @DisplayName("Добавить на форму задачи контекст простого типа")
    public void addSimpleTypeContextToTaskFormTest() {
        String nameStringType = "nameStringType" + RandomString.get(4);
        String nameNumberType = "nameNumberType" + RandomString.get(4);
        String nameDateTimeType = "nameDateTimeType" + RandomString.get(4);
        String nameYesNotType = "nameYesNotType" + RandomString.get(4);
        String nameMoneyType = "nameMoneyType" + RandomString.get(4);
        String nameNumberPhoneType = "nameNumberPhoneType" + RandomString.get(4);
        String nameEmailType = "nameEmailType" + RandomString.get(4);

        String businessProcessName = "addSimpleTypeContextToTaskFormProcessName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameStringType);
        createContextModal.selectContextType("Строка");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameNumberType);
        createContextModal.selectContextType("Число");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameYesNotType);
        createContextModal.selectContextType("Выбор «да/нет»");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameDateTimeType);
        createContextModal.selectContextType("Дата/время");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameMoneyType);
        createContextModal.selectContextType("Деньги");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameNumberPhoneType);
        createContextModal.selectContextType("Номер телефона");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameEmailType);
        createContextModal.selectContextType("Электронная почта");
        createContextModal.dialogWindowPressButton("Создать");
        interfaceDesignerPage.clickBack();
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable(nameStringType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.noteContextVariable(nameNumberType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.noteContextVariable(nameDateTimeType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.noteContextVariable(nameYesNotType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.noteContextVariable(nameMoneyType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.noteContextVariable(nameNumberPhoneType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        settingsBlockModal.noteContextVariable(nameEmailType);
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(nameStringType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameNumberType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameDateTimeType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameYesNotType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameMoneyType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameNumberPhoneType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameEmailType);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "92cdecd7-e779-4988-ad8e-7435d9644ea9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/92cdecd7-e779-4988-ad8e-7435d9644ea9)")
    @DisplayName("Проверить настройку ограничения срока выполнения задачи с типом - контекстная переменная без корректировки времени")
    public void checkLimitTaskWithContextVariableTest() {
        String nameDateTimeType = "nameDateTimeType" + RandomString.get(4);
        LocalDate dateNow = LocalDate.now();
        String businessProcessName = "checkLimitTaskWithContextVariableProcessName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameDateTimeType);
        createContextModal.selectContextType("Дата/время");
        createContextModal.dialogWindowPressButton("Создать");

        interfaceDesignerPage.clickBack();

        businessProcessPage.chooseSidebarActivity("Системные элементы");
        businessProcessPage.simpleDragAndDrop("Присваивание", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Присваивание");
        settingsBlockModal.chooseTab("Таблица соответствия");
        settingsBlockModal.clickButtonOnModalWindowByName("Добавить");
        settingsBlockModal.clickButtonOnModalWindowByName("Выберите поле");
        settingsBlockModal.clickItemContextMenu(nameDateTimeType);
        settingsBlockModal.clickButtonOnModalWindowByName("Выберите поле");
        settingsBlockModal.clickItemContextMenu("<Ввести значение>");
        settingsBlockModal.inputDateInColumnVariable(nameDateTimeType, dateNow);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.chooseSidebarActivity("Стандартные элементы");
        businessProcessPage.simpleDragAndDropBelowBlock("Задача", "Присваивание");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.clickRadioButtonVariable();
        settingsBlockModal.expandDueDateMenuAndSelect(nameDateTimeType);
        createContextModal.dialogWindowPressButton("Сохранить");

        businessProcessPage.moveArrow("", "Присваивание");
        businessProcessPage.moveArrow("Присваивание", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        sectionPage.open("tasks/income");
        sectionPage.checkDateFinishTask(businessProcessName, dateNow);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "de457fea-0cc3-43ac-b27e-f27e21681222", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/de457fea-0cc3-43ac-b27e-f27e21681222)")
    @DisplayName("Использовать форму по умолчанию")
    public void useDefaultFormTest() {
        String nameStringType = "nameStringType" + RandomString.get(4);
        String nameNumberType = "nameNumberType" + RandomString.get(4);
        String nameDateTimeType = "nameDateTimeType" + RandomString.get(4);
        String nameYesNotType = "nameYesNotType" + RandomString.get(4);
        String nameMoneyType = "nameMoneyType" + RandomString.get(4);
        String nameNumberPhoneType = "nameNumberPhoneType" + RandomString.get(4);
        String nameEmailType = "nameEmailType" + RandomString.get(4);

        String businessProcessName = "useDefaultFormProcessName" + RandomString.get(8);
        String processId = backendBusinessProcess.createBusinessProcess("global", businessProcessName);
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.selectTab("Контекст");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameStringType);
        createContextModal.selectContextType("Строка");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameNumberType);
        createContextModal.selectContextType("Число");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameYesNotType);
        createContextModal.selectContextType("Выбор «да/нет»");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameDateTimeType);
        createContextModal.selectContextType("Дата/время");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameMoneyType);
        createContextModal.selectContextType("Деньги");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameNumberPhoneType);
        createContextModal.selectContextType("Номер телефона");
        createContextModal.dialogWindowPressButton("Создать");
        businessProcessPage.clickAddButton();
        createContextModal.fillContextName(nameEmailType);
        createContextModal.selectContextType("Электронная почта");
        createContextModal.dialogWindowPressButton("Создать");
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.waitGreySpinnerDisappear();
        businessProcessPage.simpleDragAndDrop("Задача", "#content>:nth-child(1)");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.setContextVariable(nameStringType);
        settingsBlockModal.setContextVariable(nameNumberType);
        settingsBlockModal.setContextVariable(nameDateTimeType);
        settingsBlockModal.setContextVariable(nameYesNotType);
        settingsBlockModal.setContextVariable(nameMoneyType);
        settingsBlockModal.setContextVariable(nameNumberPhoneType);
        settingsBlockModal.setContextVariable(nameEmailType);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.moveArrow("", "Задача 1");
        businessProcessPage.moveArrowFinish("Задача 1");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        backendBusinessProcess.run(processId, EMPTY_JSON);
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkModalWindowHeader("Задача 1");
        widgetSettingsModal.checkModalWindowHeader(businessProcessName);
        widgetSettingsModal.checkExistHeaderControlOnModal();
        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Напоминания");
        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Задачи");
        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Лента");
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameStringType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameNumberType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameDateTimeType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameYesNotType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameMoneyType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameNumberPhoneType);
        widgetSettingsModal.checkExistWidgetOnBodyModal(nameEmailType);
        //Проверяет кнопку выхода и нажимает для завершения задачи
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "0517e912-2883-4bab-be5d-7723cc52b04f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0517e912-2883-4bab-be5d-7723cc52b04f)")
    @DisplayName("Проверить множественное исполнение задачи - Последовательное")
    public void checkMultipleTaskExecutionSequentialTest() {
        String operatorsGroupName = "users_group" + RandomString.get(8);
        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);
        String sectionName = "checkMultipleTaskExecutionSequentialSectionName" + RandomString.get(4);
        String businessProcessName = "checkMultipleTaskExecutionSequentialProcessName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessMultipleTaskExecutionSequential.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .setGroupCode(groupId)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        sectionPage.clickTaskByName("-> Задача 2");
        if (sectionPage.isTaskBindToCurrentUser("-> Оповещение 2")) {
            // сценарий прохождения, если задача упала на админа.
            sectionPage.clickTaskByName("-> Оповещение 2");
            sectionPage.checkAlertWithTextFragmentExists("Оповещение 2");
            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();
        } else {
            // сценарий прохождения, если задача упала не на админа.
            CustomDriver.clearStoredData();
            CustomDriver.setCookieUser();
            sectionPage.open("tasks/income");
            sectionPage.clickTask("Задача 2", businessProcessName);
            sectionPage.clickTaskByName("-> Оповещение 2");
            sectionPage.checkAlertWithTextFragmentExists("Оповещение 2");
            CustomDriver.clearStoredData();
            CustomDriver.setCookieAdmin();
        }
        sectionPage.open("tasks/income");
        sectionPage.clickTask("Задача 2", businessProcessName);
        sectionPage.clickTaskByName("-> Оповещение 2");
        sectionPage.checkAlertWithTextFragmentExists("Оповещение 2");
        messagePage.open("messages/feed");
        messagePage.checkMessageHeaderAndTextEqual("Переход по условию", "Переход по условию");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "7890fc1a-ace7-498a-8e10-cf633d8e4c99", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7890fc1a-ace7-498a-8e10-cf633d8e4c99)")
    @DisplayName("Проверить множественное исполнение задачи - Параллельное")
    public void checkMultipleTaskExecutionParallelTest() {
        String operatorsGroupName = "users_group" + RandomString.get(8);
        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);
        String sectionName = "checkMultipleTaskExecutionParallelSectionName" + RandomString.get(4);
        String businessProcessName = "checkMultipleTaskExecutionParallelProcessName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessMultipleTaskExecutionParallel.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .setGroupCode(groupId)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        sectionPage.clickTaskByName("-> Задача 2");
        sectionPage.clickTaskByName("-> Оповещение 2");
        sectionPage.checkAlertWithTextFragmentExists("Оповещение 2");
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("tasks/income");
        sectionPage.clickTask("Задача 2", businessProcessName);
        sectionPage.clickTaskByName("-> Оповещение 2");
        messagePage.open("messages/feed");
        messagePage.checkMessageHeaderAndTextEqual("Переход по условию", "Переход по условию");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e8587f47-c701-4797-801e-3386b912e063", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e8587f47-c701-4797-801e-3386b912e063)")
    @DisplayName("Проверить множественное исполнение задачи - Кто первый")
    public void checkMultipleTaskExecutionFirstTest() {
        String operatorsGroupName = "users_group" + RandomString.get(8);
        elmaBackend.createCompanyGroup(operatorsGroupName, elmaBackend.getUserIdByEmail(adminLogin), elmaBackend.getUserIdByEmail(userLogin));
        String groupId = elmaBackend.getCompanyGroupCode(operatorsGroupName);
        String sectionName = "checkMultipleTaskExecutionParallelSectionName" + RandomString.get(4);
        String businessProcessName = "checkMultipleTaskExecutionParallelProcessName" + RandomString.get(8);
        elmaBackend.createSection(sectionName);
        String processId = backendBusinessProcess.createBusinessProcess(sectionName, businessProcessName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/ProcessMultipleTaskExecutionFirst.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .setGroupCode(groupId)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        sectionPage.clickTaskByName("-> Задача 2");
        sectionPage.checkAlertWithTextFragmentExists("Задача 2");
        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("tasks/income");
        sectionPage.checkTaskWithNameAppearFromProcess("Задача 2", businessProcessName);
        CustomDriver.clearStoredData();
        CustomDriver.setCookieAdmin();
        sectionPage.open("tasks/income");
        sectionPage.clickTask("Задача 2", businessProcessName);
        sectionPage.clickTaskByName("В работе");
        sectionPage.checkAlertWithTextFragmentExists("В работе");

        CustomDriver.clearStoredData();
        CustomDriver.setCookieUser();
        sectionPage.open("tasks/income");

        sectionPage.checkTaskNameNotExists(businessProcessName);
    }
}
