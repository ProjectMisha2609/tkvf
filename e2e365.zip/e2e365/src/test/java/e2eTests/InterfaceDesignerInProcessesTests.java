package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.BackendTasks;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static infrastructure.elmaBackend.jsonTools.JsonBodies.EMPTY_JSON;
import static infrastructure.utils.Constants.ELMA_TMS;
import static infrastructure.utils.Constants.TimeWait.SECONDS_5;
import static org.junit.jupiter.api.Assertions.assertTrue;

@MicronautTest
@Tags({@Tag("express"), @Tag("interface_designer")})
public class InterfaceDesignerInProcessesTests {
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BackendTasks backendTasks;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;
    @Inject
    protected SelectWidgetsModal selectWidgetsModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected PageConstructorPage pageConstructorPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected CreateContextModal createContextModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected UserWidgetPage userWidgetPage;
    @Inject
    protected NomenclaturePage nomenclaturePage;

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "cfb703e6-9175-4af5-b607-3a6c0a7eaa3d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cfb703e6-9175-4af5-b607-3a6c0a7eaa3d)")
    @DisplayName("Добавить на форму элемент Вкладки с включенной настройкой  \\Скрывать вкладки с одной страницей\\")
    public void addTabWhenHidingIsEnabledTest() {
        String tabName1 = "addTabWhenHidingIsEnabledTabNameFirst" + RandomString.get(8);
        String tabName2 = "addTabWhenHidingIsEnabledTabNameSecond" + RandomString.get(8);
        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.tabWidgetSettingsModal().changeHideSinglePageCheckboxValue();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.openDefaultTabSettings();
        widgetSettingsModal.clearPanelHeaderName();
        widgetSettingsModal.fillPanelWithHeaderName(tabName1);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        interfaceDesignerPage.checkTabNotExists(tabName1);

        sectionPage.clickNextStageOrExit();
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.openExistingForm();
        interfaceDesignerPage.addTabByPlusButton();
        widgetSettingsModal.fillPanelWithHeaderName(tabName2);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        interfaceDesignerPage.checkTabVisible(tabName1);
        interfaceDesignerPage.checkTabVisible(tabName2);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Krasilnikov")
    @Link(value = "b4f8f923-f64e-44ca-938d-08c1ce521d0c", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b4f8f923-f64e-44ca-938d-08c1ce521d0c)")
    @DisplayName("Добавить на форму элемент Вкладки с выключенной настройкой  \\Скрывать вкладки с одной страницей\\")
    public void addTabWhenHidingIsDisabledTest() {
        String tabName1 = "addTabWhenHidingIsDisabledTabNameFirst" + RandomString.get(8);
        String tabName2 = "addTabWhenHidingIsDisabledTabNameSecond" + RandomString.get(8);
        String processName = "addTabWhenHidingIsDisabledProcess" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");

        settingsBlockModal.createDefaultForm();
        interfaceDesignerPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.openDefaultTabSettings();
        widgetSettingsModal.clearPanelHeaderName();
        widgetSettingsModal.fillPanelWithHeaderName(tabName1);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();
        interfaceDesignerPage.checkTabVisible(tabName1);
        sectionPage.clickNextStageOrExit();
        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.openExistingForm();
        interfaceDesignerPage.addTabByPlusButton();
        widgetSettingsModal.fillPanelWithHeaderName(tabName2);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.processStartConfirmation();

        interfaceDesignerPage.checkTabVisible(tabName1);
        interfaceDesignerPage.checkTabVisible(tabName2);
        sectionPage.clickNextStageOrExit();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "6c877988-b99b-4565-88b8-d25695e252c7", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/6c877988-b99b-4565-88b8-d25695e252c7)")
    @DisplayName("Добавить на форму элемент Счетчик с указанием заголовка по связанному полю")
    public void addCounterOnFormWithJoinField() {
        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Счетчик");
        pageConstructorPage.fillCardOfCounterWithRelation();
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal("TestStart");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "d0477acf-b697-49fe-ad18-5aacf96416f6", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/d0477acf-b697-49fe-ad18-5aacf96416f6)")
    @DisplayName("Добавить на форму элемент Счетчик с вводом заголовка вручную")
    public void addCounterWithHandNameOnForm() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Счетчик");
        pageConstructorPage.fillCardOfCounter(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b1a9acc0-aba4-4336-a3bd-b935c78013c9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b1a9acc0-aba4-4336-a3bd-b935c78013c9)")
    @DisplayName("Добавить виджет в счетчик")
    public void addWidgetIntoCounterWithHandNameOnForm() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Счетчик");
        pageConstructorPage.fillCardOfCounter(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToCounter(widgetCodeName);
        selectWidgetsModal.pressCreateWidget("Вкладки");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
        selectWidgetsModal.checkExistWidgetOnBodyModal("Вкладка");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "a49711fa-cdfc-4126-b0d0-e1da37394b57", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/a49711fa-cdfc-4126-b0d0-e1da37394b57)")
    @DisplayName("Добавить на форму элемент Текст")
    public void addHtmlTextOnForm() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);


        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Текст");
        widgetSettingsModal.fillTextInTextWidget(widgetCodeName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(widgetCodeName);
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "67436539-fd73-4669-b87e-6f644ff2303b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/67436539-fd73-4669-b87e-6f644ff2303b)")
    @DisplayName("Добавить на форму элемент Код")
    public void addHtmlCodeOnForm() {
        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Код");
        widgetSettingsModal.fillCodeInCodeEditor("<div>Hello world!</div>");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal("Hello world!");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "88ddb920-e6a4-454b-82ff-25abe9993270", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/88ddb920-e6a4-454b-82ff-25abe9993270)")
    @DisplayName("Добавить элемент График с фильтрацией по полю")
    public void addGraphWithFilterFieldOnForm() {
        String processName = "TestingProcessGraph" + RandomString.get(16);
        String sectionName = "addForGraphSectionName" + RandomString.get(8);
        String appForGraphName = "appForGraph" + RandomString.get(3);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appForGraphName);
        elmaBackend.createElement(appForGraphName, sectionName, appForGraphName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("График");
        widgetSettingsModal.fillGraphWithFilterField(sectionName, appForGraphName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(appForGraphName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e155cfe1-1561-4010-a6a3-1fe1ca848221", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e155cfe1-1561-4010-a6a3-1fe1ca848221)")
    @DisplayName("Добавить элемент График тип круговой")
    public void addGraphRoundOnForm() {
        String processName = "TestingProcessGraph" + RandomString.get(16);
        String sectionName = "addForGraphSectionName" + RandomString.get(8);
        String appForGraphName = "appForGraph" + RandomString.get(3);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appForGraphName);
        elmaBackend.createElement(appForGraphName, sectionName, appForGraphName);


        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("График");
        widgetSettingsModal.fillGraphType("Круговой", sectionName, appForGraphName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(appForGraphName);
        widgetSettingsModal.checkTypePieGraphExists();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "27f63b50-9fc6-4420-a0dc-235743d50da5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/27f63b50-9fc6-4420-a0dc-235743d50da5)")
    @DisplayName("Добавить элемент График тип линейный")
    public void addGraphLinearOnForm() {
        String processName = "TestingProcessGraph" + RandomString.get(16);
        String sectionName = "addForGraphSectionName" + RandomString.get(8);
        String appForGraphName = "appForGraph" + RandomString.get(3);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appForGraphName);
        elmaBackend.createElement(appForGraphName, sectionName, appForGraphName);


        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("График");
        widgetSettingsModal.fillGraphType("Линейный", sectionName, appForGraphName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(appForGraphName);
        widgetSettingsModal.checkTypeLineGraphExists();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "0e7c8feb-ae75-4960-adca-abfdeb9d6470", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/0e7c8feb-ae75-4960-adca-abfdeb9d6470)")
    @DisplayName("Добавить элемент График тип столбчатый")
    public void addGraphPillarOnForm() {
        String processName = "TestingProcessGraph" + RandomString.get(16);
        String sectionName = "addForGraphSectionName" + RandomString.get(8);
        String appForGraphName = "appForGraph" + RandomString.get(3);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appForGraphName);
        elmaBackend.createElement(appForGraphName, sectionName, appForGraphName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("График");
        widgetSettingsModal.fillGraphType("Столбчатый", sectionName, appForGraphName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal(appForGraphName);
        widgetSettingsModal.checkTypeBarGraphExists();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "3d2ddfbd-0459-4d98-bbde-0a27b0ece984", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3d2ddfbd-0459-4d98-bbde-0a27b0ece984)")
    @DisplayName("Добавить виджет в строку")
    public void addWidgetIntoLineOnForm() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);


        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Строка");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToLine();
        selectWidgetsModal.pressCreateWidget("Кнопка");
        pageConstructorPage.fillCardOfButton(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "3f5e7293-2d28-4532-b1a5-f824146346f5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3f5e7293-2d28-4532-b1a5-f824146346f5)")
    @DisplayName("Добавить элемент Строка с выравниванием элементов по центру")
    public void addLineWithCenterAlignmentOnFormTest() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Строка");
        widgetSettingsModal.setAlignmentLine("По центру");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToLine();
        selectWidgetsModal.pressCreateWidget("Кнопка");
        pageConstructorPage.fillCardOfButton(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
        interfaceDesignerPage.checkAlignmentLine("По центру");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "83cf176a-1f6f-4111-af06-9fde5cca4c67", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/83cf176a-1f6f-4111-af06-9fde5cca4c67)")
    @DisplayName("Добавить элемент Строка с выравниванием элементов по ширине")
    public void addLineWithAlignmentByWidthOnFormTest() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Строка");
        widgetSettingsModal.setAlignmentLine("По ширине");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToLine();
        selectWidgetsModal.pressCreateWidget("Кнопка");
        pageConstructorPage.fillCardOfButton(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
        interfaceDesignerPage.checkAlignmentLine("По ширине");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "b0d07edc-9e6e-40d5-9901-292f2ac33211", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b0d07edc-9e6e-40d5-9901-292f2ac33211)")
    @DisplayName("Добавить элемент Строка с выравниванием элементов - Распределить")
    public void addLineWithDistributeAlignmentOnFormTest() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Строка");
        widgetSettingsModal.setAlignmentLine("Распределить");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToLine();
        selectWidgetsModal.pressCreateWidget("Кнопка");
        pageConstructorPage.fillCardOfButton(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
        interfaceDesignerPage.checkAlignmentLine("Распределить");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "8dbdcfea-1066-4e02-9bf8-e2c04f287364", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/8dbdcfea-1066-4e02-9bf8-e2c04f287364)")
    @DisplayName("Добавить элемент Строка с выравниванием элементов по левому краю")
    public void addLineWithAlignmentByLeftOnFormTest() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Строка");
        widgetSettingsModal.setAlignmentLine("По левому краю");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToLine();
        selectWidgetsModal.pressCreateWidget("Кнопка");
        pageConstructorPage.fillCardOfButton(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
        interfaceDesignerPage.checkAlignmentLine("По левому краю");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "df3779c4-e430-4f67-84b5-1b6bbd6ca7fd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/df3779c4-e430-4f67-84b5-1b6bbd6ca7fd)")
    @DisplayName("Добавить элемент Строка с выравниванием элементов по правому краю")
    public void addLineWithAlignmentByRightOnFormTest() {
        String widgetCodeName = "addWidgetTest" + RandomString.get(8);

        String processName = "TestingProcessCounter" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Строка");
        widgetSettingsModal.setAlignmentLine("По правому краю");
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.addWidgetToLine();
        selectWidgetsModal.pressCreateWidget("Кнопка");
        pageConstructorPage.fillCardOfButton(widgetCodeName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        selectWidgetsModal.checkExistWidgetOnBodyModal(widgetCodeName);
        interfaceDesignerPage.checkAlignmentLine("По правому краю");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "7b57d6af-7760-4e0b-8c54-802bef5a8efa", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/7b57d6af-7760-4e0b-8c54-802bef5a8efa)")
    @DisplayName("Добавить виджет Дата запуска процесса на форму процессной задачи")
    public void addDateStartProcessOnFormTest() {
        String processName = "TestingProcessDate" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        interfaceDesignerPage.dragWidgetAndDropSidePanelToJoinTaskWidget("Дата запуска процесса");
        widgetSettingsModal.fillCardOfDateStartProcess();
        selectWidgetsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        LocalDateTime localDateTime = LocalDateTime.now();
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        String dateStart = interfaceDesignerPage.getDateStart();
        long diffMin = Duration.between(LocalDateTime.parse(dateStart, DateTimeFormatter.ofPattern("d.MM.yyyy H:mm")), localDateTime).toMinutes();
        assertTrue(diffMin <= 10, "Слишком большое отличие даты и времени запуска процесса");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f59f06d4-fec7-4017-9f16-6e2e19d2848f", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f59f06d4-fec7-4017-9f16-6e2e19d2848f)")
    @DisplayName("Добавить на форму Надпись с указанием надписи по связанному полю")
    public void addInscriptionWithJoinOnFormTest() {
        String processName = "TestingInscription" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Надпись");
        widgetSettingsModal.fillInscriptionWithJoin();
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        // в json-файле название с грамматической ошибкой.
        settingsBlockModal.checkExistWidgetOnBodyModal("TestStartSubProces");
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "56a9dbb9-73cb-43aa-8aed-872eab93b4ff", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/56a9dbb9-73cb-43aa-8aed-872eab93b4ff)")
    @DisplayName("Добавить на форму Надпись с вводом надписи вручную")
    public void addInscriptionOnFormTest() {
        String processName = "TestingInscription" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Надпись");
        widgetSettingsModal.fillInscriptionWidget(processName);
        selectWidgetsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();
        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);
        settingsBlockModal.checkExistWidgetOnBodyModal(processName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "96812537-3897-4806-a3db-3fa517b6f278", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/96812537-3897-4806-a3db-3fa517b6f278)")
    @DisplayName("Добавить элемент Загрузка файла с предпросмотром с указанием контекстной переменной файл")
    public void addUploaderFileWidgetOnFormTest() {
        String processName = "TestUploaderFile" + RandomString.get(16);
        String variableName = "ButtonFile" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();

        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextFiles();
        createContextModal.dialogWindowPressButton("Создать");

        interfaceDesignerPage.clickSaveToolbarButton();
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickSettingsBlock("Задача 1");

        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Загрузка файла с предпросмотром");
        widgetSettingsModal.fillUploaderFileViewWidget(variableName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");

        settingsBlockModal.checkExistWidgetOnBodyModal("cats.png");
        interfaceDesignerPage.checkUploadPNGOnForm();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "e14cbff6-7cf9-4ddc-aab8-cc6f5e220fe9", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e14cbff6-7cf9-4ddc-aab8-cc6f5e220fe9)")
    @DisplayName("Проверить добавление пользовательского виджета в задачу процесса")
    public void addUserWidgetOnFormTaskTest() {
        String processName = "TestingInscription" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        String widgetName = "userWidget" + RandomString.get(4);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);
        elmaBackend.createEmptyUserWidget(widgetName);

        userWidgetPage.open(widgetName);
        userWidgetPage.addTabByDragAndDrop();
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.openDefaultTabSettings();
        widgetSettingsModal.clearPanelHeaderName();
        widgetSettingsModal.fillPanelWithHeaderName(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        pageConstructorPage.clickSaveInToolbar();
        pageConstructorPage.clickPublishAndCheckPublish();

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");

        settingsBlockModal.createDefaultForm();
        interfaceDesignerPage.addUserWidgetByDragAndDrop(widgetName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        settingsBlockModal.checkExistWidgetOnBodyModal(widgetName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "5ed73dfc-6464-4ba1-8678-c0c46f85eb55", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/5ed73dfc-6464-4ba1-8678-c0c46f85eb55)")
    @DisplayName("Удалить график")
    public void deleteGraphOnFormTest() {
        String processName = "TestingProcessGraph" + RandomString.get(16);
        String sectionName = "addForGraphSectionName" + RandomString.get(8);
        String appForGraphName = "appForGraph" + RandomString.get(3);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appForGraphName);
        elmaBackend.createElement(appForGraphName, sectionName, appForGraphName);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("График");

        widgetSettingsModal.fillGraphType("Круговой", sectionName, appForGraphName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId1 = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId1);

        widgetSettingsModal.checkExistWidgetOnBodyModal(appForGraphName);
        widgetSettingsModal.checkTypePieGraphExists();

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Формы");
        businessProcessPage.clickForm("Задача 1");
        pageConstructorPage.findAndDeleteGraph();
        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId2 = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId2 = backendTasks.getTaskByInstanceId(instanceId2, SECONDS_5);
        sectionPage.openTask(taskId2);

        widgetSettingsModal.checkWidgetNotExistsOnBodyModal(appForGraphName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "58b6a748-bc30-4143-8098-283b1c83b12b", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/58b6a748-bc30-4143-8098-283b1c83b12b)")
    @DisplayName("Добавить элемент Просмотр файла с указанием контекстной переменной файл")
    public void addViewFileWidgetOnFormTest() {
        String processName = "TestViewFile" + RandomString.get(16);
        String variableName = "ButtonFile" + RandomString.get(4);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        pageConstructorPage.selectMainTab("Контекст");
        pageConstructorPage.clickContextAdd();

        createContextModal.fillContextName(variableName);
        createContextModal.clickFieldSelectType();
        createContextModal.clickTypeContextFiles();
        createContextModal.dialogWindowPressButton("Создать");

        interfaceDesignerPage.clickSaveToolbarButton();
        pageConstructorPage.selectMainTab("Схема");
        businessProcessPage.clickStartBlock();

        settingsBlockModal.setContextVariable(variableName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Просмотр файла");
        widgetSettingsModal.fillUploaderFileViewWidget(variableName);
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("/tasks/income");
        sectionPage.startCompanyProcessWithNameAndSetFile(processName, variableName);
        sectionPage.processStartConfirmation();

        documentTemplateCreatingModal.checkExistWidgetOnBodyModal(variableName);
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.processStartConfirmation();

        interfaceDesignerPage.checkUploadPNGOnForm();
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "f58fe551-24ce-49e2-a849-28cb70ef79c5", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f58fe551-24ce-49e2-a849-28cb70ef79c5)")
    @DisplayName("Добавить виджет Стандартная форма элемента с указанием элемента и отображаемых полей")
    public void addStandardFormElementWidgetOnFormTest() {
        String processName = "TestViewFile" + RandomString.get(16);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("admin/process/" + processId);
        businessProcessPage.clickSettingsBlock("Задача 1");
        settingsBlockModal.chooseTab("Форма");
        settingsBlockModal.noteContextVariable("Инициатор");
        settingsBlockModal.clickButtonOnModalWindowByName("Перенести");

        settingsBlockModal.createDefaultForm();
        pageConstructorPage.dragWidgetAndDropForm("Стандартная форма элемента");
        widgetSettingsModal.dialogWindowPressButton("Сохранить");

        interfaceDesignerPage.clickSaveToolbarButton();
        interfaceDesignerPage.clickBack();
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        String instanceId = backendBusinessProcess.run(processId, EMPTY_JSON);
        String taskId = backendTasks.getTaskByInstanceId(instanceId, SECONDS_5);
        sectionPage.openTask(taskId);

        widgetSettingsModal.checkExistWidgetOnBodyModal("Инициатор");
        widgetSettingsModal.checkCountStandardFormElement();
    }
}
