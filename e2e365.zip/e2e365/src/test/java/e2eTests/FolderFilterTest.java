package e2eTests;

import infrastructure.drivers.CustomDriver;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.Keys;
import pages.elmaModals.SettingFolderFilterModal;
import pages.elmaPages.MainPage;
import pages.elmaPages.SectionPage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("folder_filter")})
public class FolderFilterTest {
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected SettingFolderFilterModal settingFolderFilterModal;

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "21ce4ffd-6eed-4826-b0a9-0a094bc76148", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/21ce4ffd-6eed-4826-b0a9-0a094bc76148)")
    @DisplayName("Сохранить фильтр")
    public void saveOwnFilterTest() {
        String sectionName = "saveOwnFilterSectionName" + RandomString.get(8);
        String appName = "filterTestAppName" + RandomString.get(8);
        String filterName = "filter" + RandomString.get(3);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        settingFolderFilterModal.clickButtonMainSettingFilter();

        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр");
        settingFolderFilterModal.setNameNewFilter(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        settingFolderFilterModal.checkFilterExistsOnList(filterName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "3306f351-9307-436f-aac1-9112e67e776e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/3306f351-9307-436f-aac1-9112e67e776e)")
    @DisplayName("Сохранить фильтр директории в папке Все записи")
    public void saveFilterInRootDirectoryTest() {
        String sectionName = "saveFilterInRootDirectorySectionName" + RandomString.get(8);
        String appName = "filterTestAppName" + RandomString.get(8);
        String filterName = "filter" + RandomString.get(3);
        String firstElement = "firstElement";
        String secondElement = "secondElement";

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(firstElement, sectionName, appName);
        elmaBackend.createElement(secondElement, sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Иерархический справочник");
        sectionPage.clickCheckBox("Включить иерархический справочник");
        mainPage.clickButtonOnAppContent("Сохранить");
        sectionPage.checkAppElementExist(firstElement); //TODO Для задержки

        sectionPage.selectItemFromRootDirectory("Все записи");

        settingFolderFilterModal.clickButtonMainSettingFilter();
        settingFolderFilterModal.setParameterSingleInput("Название", firstElement);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр директории");
        settingFolderFilterModal.setNameNewFilter(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        settingFolderFilterModal.closeSettingPageWithKeyESCAPE();

        sectionPage.checkItemFromRootDirectoryExists(filterName);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "1497ee0f-8be6-4d1e-b277-874dacbdf4cb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1497ee0f-8be6-4d1e-b277-874dacbdf4cb)")
    @DisplayName("Проверить отображение элементов в фильтре директории в конкретной папке")
    public void saveFilterInCurrentFolderTest() {
        String sectionName = "saveFilterInCurrentFolderSectionName" + RandomString.get(8);
        String appName = "filterApp" + RandomString.get(8);
        String filterName = "filter" + RandomString.get(3);
        String directoryName = "directory" + RandomString.get(3);
        String uuidDirectory = RandomString.getUUID();
        String firstElement = "firstElement";
        String secondElement = "secondElement";

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Иерархический справочник");
        sectionPage.clickCheckBox("Включить иерархический справочник");
        mainPage.clickButtonOnAppContent("Сохранить");

        elmaBackend.createDirectoryApp(sectionName, appName, uuidDirectory, directoryName);
        elmaBackend.createElementWithDirectory(firstElement, sectionName, appName, uuidDirectory);
        elmaBackend.createElementWithDirectory(secondElement, sectionName, appName, uuidDirectory);

        sectionPage.refreshPage();
        sectionPage.selectItemFromRootDirectory(directoryName);

        settingFolderFilterModal.clickButtonMainSettingFilter();
        settingFolderFilterModal.setParameterSingleInput("Название", firstElement);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр директории");
        settingFolderFilterModal.setNameNewFilter(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        settingFolderFilterModal.closeSettingPageWithKeyESCAPE();

        sectionPage.checkItemFromCurrentFolderExists(directoryName, filterName);

        sectionPage.selectItemFromRootDirectory(filterName);

        sectionPage.checkAppElementExist(firstElement);
        sectionPage.checkAppElementNotExist(secondElement);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "028ad030-ff7e-45e4-a073-5efbdaccd662", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_cases(p:item/test_management_system/test_cases/028ad030-ff7e-45e4-a073-5efbdaccd662)")
    @DisplayName("Проверить отображение элементов в фильтре директории в корне")
    public void checkFilterInRootDirectoryTest() {
        String sectionName = "checkFilterInRootDirectorySectionName" + RandomString.get(8);
        String appName = "filterTestApp" + RandomString.get(8);
        String filterName = "filter" + RandomString.get(3);
        String firstElement = "firstElement";
        String secondElement = "secondElement";

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);
        elmaBackend.createElement(firstElement, sectionName, appName);
        elmaBackend.createElement(secondElement, sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Иерархический справочник");
        sectionPage.clickCheckBox("Включить иерархический справочник");
        mainPage.clickButtonOnAppContent("Сохранить");
        sectionPage.selectItemFromRootDirectory("Все записи");

        settingFolderFilterModal.clickButtonMainSettingFilter();
        settingFolderFilterModal.setParameterSingleInput("Название", firstElement);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр директории");
        settingFolderFilterModal.setNameNewFilter(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        settingFolderFilterModal.closeSettingPageWithKeyESCAPE();
        sectionPage.selectItemFromRootDirectory(filterName);

        sectionPage.checkAppElementExist(firstElement);
        sectionPage.checkAppElementNotExist(secondElement);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "1497ee0f-8be6-4d1e-b277-874dacbdf4cb", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/1497ee0f-8be6-4d1e-b277-874dacbdf4cb)")
    @DisplayName("Проверить отображение элементов в фильтре директории в конкретной папке")
    public void checkFilterInCurrentFolderTest() {
        String sectionName = "checkFilterInCurrentFolderSectionName" + RandomString.get(8);
        String appName = "filterApp" + RandomString.get(8);
        String filterName = "filter" + RandomString.get(3);
        String directoryName = "directory" + RandomString.get(3);
        String uuidDirectory = RandomString.getUUID();
        String firstElement = "firstElement";
        String secondElement = "secondElement";

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Иерархический справочник");
        sectionPage.clickCheckBox("Включить иерархический справочник");
        mainPage.clickButtonOnAppContent("Сохранить");

        elmaBackend.createDirectoryApp(sectionName, appName, uuidDirectory, directoryName);
        elmaBackend.createElementWithDirectory(firstElement, sectionName, appName, uuidDirectory);
        elmaBackend.createElementWithDirectory(secondElement, sectionName, appName, uuidDirectory);

        sectionPage.refreshPage();
        sectionPage.selectItemFromRootDirectory(directoryName);

        settingFolderFilterModal.clickButtonMainSettingFilter();
        settingFolderFilterModal.setParameterSingleInput("Название", firstElement);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр директории");
        settingFolderFilterModal.setNameNewFilter(filterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        settingFolderFilterModal.closeSettingPageWithKeyESCAPE();
        sectionPage.selectItemFromRootDirectory(filterName);

        sectionPage.checkAppElementExist(firstElement);
        sectionPage.checkAppElementNotExist(secondElement);
    }

    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "15f2a65b-2c9b-4209-97ef-f9e73d3722db", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/15f2a65b-2c9b-4209-97ef-f9e73d3722db)")
    @DisplayName("Проверить одновременную фильтрацию по собственному фильтру и по фильтру директории")
    public void checkOwnAndRootDirectoryFiltersTest() {
        String sectionName = "checkOwnAndRootDirectoryFiltersSectionName" + RandomString.get(8);
        String appName = "filterApp" + RandomString.get(8);
        String firstFilterName = "filter" + RandomString.get(3);
        String secondFilterName = "filter" + RandomString.get(3);
        String directoryName = "directory" + RandomString.get(3);
        String uuidDirectory = RandomString.getUUID();
        String firstElement = "123";
        String secondElement = "456";
        String thirdElement = "123456";

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplication(sectionName, appName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Иерархический справочник");
        sectionPage.clickCheckBox("Включить иерархический справочник");
        mainPage.clickButtonOnAppContent("Сохранить");

        elmaBackend.createDirectoryApp(sectionName, appName, uuidDirectory, directoryName);
        elmaBackend.createElementWithDirectory(firstElement, sectionName, appName, uuidDirectory);
        elmaBackend.createElementWithDirectory(secondElement, sectionName, appName, uuidDirectory);
        elmaBackend.createElementWithDirectory(thirdElement, sectionName, appName, uuidDirectory);

        //фильтр директории
        sectionPage.refreshPage();
        sectionPage.selectItemFromRootDirectory(directoryName);
        settingFolderFilterModal.clickButtonMainSettingFilter();
        settingFolderFilterModal.setParameterSingleInput("Название", firstElement);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр директории");
        settingFolderFilterModal.setNameNewFilter(firstFilterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        CustomDriver.getAction().sendKeys(Keys.ESCAPE).perform();
        sectionPage.selectItemFromRootDirectory(firstFilterName);

        sectionPage.checkAppElementExist(firstElement);
        sectionPage.checkAppElementNotExist(secondElement);
        sectionPage.checkAppElementExist(thirdElement);

        //свой фильтр
        settingFolderFilterModal.clickButtonMainSettingFilter();
        settingFolderFilterModal.setParameterSingleInput("Название", secondElement);
        settingFolderFilterModal.clickFooterButton("Сохранить как фильтр");
        settingFolderFilterModal.setNameNewFilter(secondFilterName);
        settingFolderFilterModal.clickFooterButton("Сохранить");
        settingFolderFilterModal.chooseSearchFilterFromList(secondFilterName);
        settingFolderFilterModal.closeSettingPageWithKeyESCAPE();

        sectionPage.checkAppElementNotExist(firstElement);
        sectionPage.checkAppElementNotExist(secondElement);
        sectionPage.checkAppElementExist(thirdElement);
    }
}
