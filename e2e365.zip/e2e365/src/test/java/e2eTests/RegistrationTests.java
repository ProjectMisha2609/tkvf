package e2eTests;

import infrastructure.elmaBackend.BackendBusinessProcess;
import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.elmaBackend.jsonTools.ContextType;
import infrastructure.elmaBackend.jsonTools.JsonBusinessProcess;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaModals.*;
import pages.elmaPages.*;

import java.time.LocalDate;
import java.util.Locale;

import static infrastructure.utils.Constants.DateAndTimeFormatters.FORMATTER_DD_MM_YYYY;
import static infrastructure.utils.Constants.ELMA_TMS;
import static java.time.LocalDate.now;

@MicronautTest
@Tags({@Tag("express"), @Tag("registration")})
public class RegistrationTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected BackendBusinessProcess backendBusinessProcess;
    @Inject
    protected BusinessProcessPage businessProcessPage;
    @Inject
    protected SectionPage sectionPage;
    @Inject
    protected SettingsBlockModal settingsBlockModal;
    @Inject
    protected DocumentTemplateCreatingModal documentTemplateCreatingModal;
    @Inject
    protected WidgetSettingsModal widgetSettingsModal;
    @Inject
    protected InterfaceDesignerPage interfaceDesignerPage;
    @Inject
    protected NomenclaturePage nomenclaturePage;
    @Inject
    protected NomenclatureModal nomenclatureModal;
    @Inject
    protected SettingsPageModal settingsPageModal;
    @Inject
    protected MainPage mainPage;
    @Inject
    protected AppFormSettingsModal appFormSettingsModal;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "27a1b12c-f681-4150-be6d-3973f18b7f9e", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/27a1b12c-f681-4150-be6d-3973f18b7f9e)")
    @DisplayName("Проверить регистрацию элемента приложения со способом регистрации - вручную")
    public void checkRegistrationOfAppElementWithRegistrationMethodManuallyTest() {
        String sectionName = "checkRegistrationManuallySectionName" + RandomString.get(8);
        String appName = "checkRegistrationManuallyAppName" + RandomString.get(8);
        String elementName = "checkRegistrationManuallyElementName" + RandomString.get(8);
        String processName = "checkRegistrationManuallyProcess" + RandomString.get(8);
        String placeRegName = "checkRegistrationManuallyPlaceReg" + RandomString.get(4);
        String dossierName = "checkRegistrationManuallyDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);
        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.clickRadiobuttonManually();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();
        sectionPage.clickNextStageOrExit();
        sectionPage.clickRegistrationButtonRightSideOfWindow();
        sectionPage.expandMenuOfSelected(placeRegName);
        sectionPage.clickRegistrationDocButtonRightSideOfWindow();

        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Регистрация");
        nomenclaturePage.checkNumerationRegDocument("1");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "58dba098-4007-4893-9c8e-762fca1c8850", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/58dba098-4007-4893-9c8e-762fca1c8850)")
    @DisplayName("Проверить регистрацию вручную с возможностью выбирать дело в поставленной задаче")
    public void checkRegistrationManuallyWithAbilityToChooseCaseInTaskTest() {
        String sectionName = "checkRegistrationManuallyChooseCaseInTaskSectionName" + RandomString.get(8);
        String appName = "checkRegistrationManuallyChooseCaseInTaskAppName" + RandomString.get(8);
        String elementName = "checkRegistrationManuallyChooseCaseInTaskElementName" + RandomString.get(8);
        String processName = "checkRegistrationManuallyChooseCaseInTaskProcess" + RandomString.get(8);
        String placeRegName = "checkRegistrationManuallyChooseCaseInTaskPlaceReg" + RandomString.get(4);
        String dossierName = "checkRegistrationManuallyChooseCaseInTaskDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.clickRadiobuttonManually();
        settingsBlockModal.checkBoxAllowSelectCaseInAssignedTask();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();
        sectionPage.clickNextStageOrExit();
        sectionPage.clickRegistrationButtonBottomOfWindow();
        sectionPage.expandMenuAndRegister(placeRegName + "/" + dossierName);

        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp("cats.png");
        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Регистрация");
        nomenclaturePage.checkNumerationRegDocument("1");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "74bc58a2-6a0b-45ca-8eab-ae5b1ee750da", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/74bc58a2-6a0b-45ca-8eab-ae5b1ee750da)")
    @DisplayName("Проверить ограничение времени выполнения регистрации - по переменной")
    public void checkRegistrationExecutionTimeLimitByVariableTest() {
        LocalDate date = now().plusDays(5);

        String sectionName = "checkRegistrationExecutionTimeLimitByVariableSectionName" + RandomString.get(8);
        String appName = "checkRegistrationExecutionTimeLimitByVariableAppName" + RandomString.get(8);
        String elementName = "checkRegistrationExecutionTimeLimitByVariableElementName" + RandomString.get(8);
        String processName = "checkRegistrationExecutionTimeLimitByVariableProcess" + RandomString.get(8);
        String placeRegName = "checkRegistrationExecutionTimeLimitByVariablePlaceReg" + RandomString.get(4);
        String dossierName = "checkRegistrationExecutionTimeLimitByVariableDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(4);
        String variableTimerName = "timer" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.clickRadiobuttonManually();
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.clickRadioButtonVariable();
        settingsBlockModal.expandDueDateMenuAndSelect(variableTimerName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "00:00");

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkDateFinishTask(processName, date);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "9d7d87ce-99b1-49fb-8402-2c44d506fb88", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/9d7d87ce-99b1-49fb-8402-2c44d506fb88)")
    @DisplayName("Проверить ограничение времени выполнения регистрации - точное время")
    public void checkTimeLimitOfRegistrationExecutionExactTimeTest() {
        int differenceOfDays = 4;
        String sectionName = "checkTimeLimitOfRegistrationExecutionExactTimeSectionName" + RandomString.get(8);
        String appName = "checkTimeLimitOfRegistrationExecutionExactTimeAppName" + RandomString.get(8);
        String elementName = "checkTimeLimitOfRegistrationExecutionExactTimeElementName" + RandomString.get(8);
        String processName = "checkTimeLimitOfRegistrationExecutionExactTimeProcess" + RandomString.get(8);
        String placeRegName = "checkTimeLimitOfRegistrationExecutionExactTimePlaceReg" + RandomString.get(4);
        String dossierName = "checkTimeLimitOfRegistrationExecutionExactTimeDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.clickRadiobuttonManually();
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.inputDateLimitDeadline(differenceOfDays);
        settingsBlockModal.removeCheckMarkFromTakeIntoAccountWorkCalendar();
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open("tasks/income");

        sectionPage.checkDifferentDateStartAndFinishDate(processName, differenceOfDays);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "c75facfa-120c-4cf1-a4e9-00dd1e361240", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c75facfa-120c-4cf1-a4e9-00dd1e361240)")
    @DisplayName("Проверить регистрацию элемента приложения со способом регистрации - автоматически")
    public void checkRegistrationOfAppElementWithRegistrationMethodAutomaticallyTest() {
        String sectionName = "checkRegistrationAutomaticallySectionName" + RandomString.get(8);
        String appName = "checkRegistrationAutomaticallyAppName" + RandomString.get(8);
        String elementName = "checkRegistrationAutomaticallyElementName" + RandomString.get(8);
        String processName = "checkRegistrationAutomaticallyProcess" + RandomString.get(8);
        String placeRegName = "checkRegistrationAutomaticallyPlaceReg" + RandomString.get(4);
        String dossierName = "checkRegistrationAutomaticallyDossier" + RandomString.get(4);
        String namePhoto = "cats.png";
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(8);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/" + namePhoto);
        sectionPage.clickSaveButton();

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(namePhoto);

        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Регистрация");
        nomenclaturePage.checkNumerationRegDocument("1");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "e7a341a8-46e8-463e-b59b-b7c7b1b88954", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/e7a341a8-46e8-463e-b59b-b7c7b1b88954)")
    @DisplayName("Проверить переход к следующему шагу при просрочке")
    public void checkTransitionToNextStepInCaseOfDelayTest() {
        LocalDate date = now().minusDays(5);
        String sectionName = "checkTransitionToNextStepInCaseOfDelaySectionName" + RandomString.get(8);
        String appName = "checkTransitionToNextStepInCaseOfDelayAppName" + RandomString.get(8);
        String elementName = "checkTransitionToNextStepInCaseOfDelayElementName" + RandomString.get(8);
        String processName = "checkTransitionToNextStepInCaseOfDelayProcess" + RandomString.get(8);
        String placeRegName = "checkTransitionToNextStepInCaseOfDelayPlaceReg" + RandomString.get(4);
        String dossierName = "checkTransitionToNextStepInCaseOfDelayDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(4);
        String variableTimerName = "timer" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createElement(elementName, sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationWithTaskProcess.json")
                        .setDraft(JsonBusinessProcess.PUBLISH_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableTimerName, ContextType.DATETIME, false)
                                .setViewField(false, "datetime", "startOfDay", true))
                        .addContextOnDefaultStartForm(variableTimerName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.clickRadiobuttonManually();
        settingsBlockModal.chooseTab("Время выполнения");
        settingsBlockModal.clickCheckBoxLimitDeadline();
        settingsBlockModal.clickRadioButtonVariable();
        settingsBlockModal.expandDueDateMenuAndSelect(variableTimerName);
        settingsBlockModal.clickCheckboxAbortAndSelectNextStep();
        settingsBlockModal.chooseTab("Переходы");
        settingsBlockModal.clickRadioButtonByName("-> Выход");
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcess(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/cats.png");
        sectionPage.clickSaveButton();
        sectionPage.inputDateInModalWindow(date.format(FORMATTER_DD_MM_YYYY), "00:00");

        sectionPage.clickNextStageOrExit();
        sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        interfaceDesignerPage.checkTaskNameVisible("Задача 1");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "cedaf402-cde9-4c57-b8df-ee09875e14be", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/cedaf402-cde9-4c57-b8df-ee09875e14be)")
    @DisplayName("Проверить настройку Включить резервирование при создании элементов приложения")
    public void checkEnableRedundancySettingWhenCreatingAppElementsTest() {
        String sectionName = "checkEnableRedundancySettingWhenCreatingSectionName" + RandomString.get(8);
        String appName = "checkEnableRedundancySettingWhenCreatingAppName" + RandomString.get(8);
        String placeRegName = "checkEnableRedundancySettingWhenCreatingPlaceReg" + RandomString.get(4);
        String dossierName = "checkEnableRedundancySettingWhenCreatingDossier" + RandomString.get(4);
        String serialId = RandomString.getUUID();

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.setParameterCheckBox("Нумерация", "Разрешить резервировать регистрационный номер до регистрации");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegName);
        nomenclaturePage.checkArrowRightExists(placeRegName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        nomenclaturePage.createAppPressButton();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/starfish.png");
        documentTemplateCreatingModal.checkFileZoomBarExists();
        settingsPageModal.clickModalFooterButton("Сохранить");
        sectionPage.checkAppElementExist("starfish.png");
        sectionPage.openAppElement(sectionName, appName, "starfish.png");
        nomenclaturePage.runRegDocumentWithReserveNumber(dossierName);
        nomenclaturePage.checkReserveNumerationRegDocument("1");
        nomenclaturePage.clickButton("Регистрировать");

        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Регистрация");
        nomenclaturePage.checkNumerationRegDocument("1");
    }


    @Test
    @Tag("Author=Lenkevich")
    @Link(value = "73dbc4ff-9d7e-48d5-8807-6c9cfeb6bf1d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/73dbc4ff-9d7e-48d5-8807-6c9cfeb6bf1d)")
    @DisplayName("Проверить настройку \"Разрешить выбирать дату регистрации в поставленной задаче\"")
    public void checkSettingOfDateRegTaskTest() {
        String sectionName = "checkSettingOfDateRegTaskSectionName" + RandomString.get(4);
        String appName = "appName" + RandomString.get(4);
        String processName = "checkSettingOfDateRegTaskProcess" + RandomString.get(4);
        String placeRegName = "placeRegName" + RandomString.get(4);
        String dossierName = "dossierName" + RandomString.get(4);
        String namePhoto = "cats.png";
        String serialId = RandomString.getUUID();
        String variableName = "document" + RandomString.get(4);
        String taskName = "taskName" + RandomString.get(4);

        elmaBackend.createSection(sectionName);
        elmaBackend.createApplicationDocumentType(sectionName, appName);
        elmaBackend.createPlaceOfRegistration(placeRegName);
        elmaBackend.createSerialNumForNomenclature(serialId, dossierName);
        String placeRegId = elmaBackend.getPlaceRegistrationIdByName(placeRegName);
        elmaBackend.createDossierNomenclature(dossierName, placeRegId, serialId);

        String processId = backendBusinessProcess.createBusinessProcess("global", processName);
        String lockHash = backendBusinessProcess.lock(processId);
        backendBusinessProcess.saveChanges(processId, lockHash,
                new JsonBusinessProcess.Builder()
                        .setJsonFile("testData/JsonProcess/SimpleRegistrationProcess.json")
                        .setDraft(JsonBusinessProcess.SAVE_PROCESS)
                        .addContextVariable(new JsonBusinessProcess.Builder.ContextProcess(variableName, ContextType.SYS_COLLECTION)
                                .setDataField(sectionName.toLowerCase(Locale.ROOT), appName.toLowerCase(Locale.ROOT)))
                        .addContextOnDefaultStartForm(variableName, "", false, false, false)
                        .buildAndGetAsString());
        backendBusinessProcess.unlock(processId, lockHash);

        businessProcessPage.open("_designer/nom");
        nomenclaturePage.clickItemOnAdministrationList(placeRegName);
        nomenclaturePage.clickItemOnAdministrationList(dossierName);
        nomenclatureModal.chooseParameterRadioButton("Нумерация", "Вручную");
        settingsPageModal.clickButtonOnModalWindowByName("Сохранить");
        nomenclaturePage.checkItemOnAdministrationListExists(placeRegName);
        nomenclaturePage.checkArrowRightExists(placeRegName);

        sectionPage.open(sectionName, appName);
        sectionPage.appToolbar().selectSettingsApp("Регистрация");
        nomenclaturePage.checkButtonSaveExists();
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", false); // TODO Как-то нехорошо отрабатывает, если сразу ставить чекбокс
        nomenclaturePage.setConditionCheckBox("Включить регистрацию", true);
        sectionPage.clickMultiSelectLabel("Выберите дело для нумерации");
        sectionPage.clickMultiSelectItem(placeRegName + "/" + dossierName);
        nomenclaturePage.clickControlButton("Сохранить");
        nomenclaturePage.checkCreateElementButtonAndAppListExists();

        businessProcessPage.open("admin/process", processId);
        businessProcessPage.clickSettingsBlock("Регистрация");
        settingsBlockModal.setTextInputByFormRowName("Название задачи", taskName);
        settingsBlockModal.chooseRadioButtonByFormRowNameAndLabel("Способ регистрации", "Вручную");
        settingsBlockModal.setCheckboxConditionByLabel("Разрешить выбирать дело в поставленной задаче", true);
        settingsBlockModal.setCheckboxConditionByLabel("Разрешить выбирать дату регистрации в поставленной задаче", true);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Документ", variableName);
        settingsBlockModal.expandMenuOfSelectedFieldAndSelectType("Дело", placeRegName + "/" + dossierName);
        settingsBlockModal.dialogWindowPressButton("Сохранить");
        businessProcessPage.clickSave();
        businessProcessPage.clickPublish();

        sectionPage.open("tasks/income");
        sectionPage.startCompanyProcessWithName(processName);
        sectionPage.clickButtonPlusCreate();
        documentTemplateCreatingModal.uploadFileWidget("testData/images/" + namePhoto);
        sectionPage.clickSaveButton();

        sectionPage.clickNextStageOrExit();
        //sectionPage.checkAlertWithTextFragmentExists("Запущен процесс");

        sectionPage.clickTask(processName, taskName);
        sectionPage.clickRegistrationButtonBottomOfWindow();
        settingsBlockModal.checkInputFormRowValue("Дата регистрации",LocalDate.now().format(FORMATTER_DD_MM_YYYY));
        settingsBlockModal.setTextInputByFormRowName("Номер регистрации", "123");
        settingsBlockModal.setTextInputByFormRowName("Дата регистрации", LocalDate.now().plusDays(1).format(FORMATTER_DD_MM_YYYY));
        appFormSettingsModal.clickPopoverFooterButton("Зарегистрировать");

        sectionPage.open(sectionName, appName);
        sectionPage.clickOnCardApp(namePhoto);

        widgetSettingsModal.checkExistTitleComplexPopupInfoOnModal("Регистрация");
        nomenclaturePage.checkNumerationRegDocument("123");
        nomenclaturePage.clickButtonExpandRegDocument();
        nomenclaturePage.checkDateRegDocument(LocalDate.now().plusDays(1));
    }
}