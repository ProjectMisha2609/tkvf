package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.*;
import pages.elmaPages.SectionPage;
import pages.elmaPages.WorkCalendarPage;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static infrastructure.elmaBackend.BackendUser.UnixTimeConverter.getDayMonthYearFromUnix;
import static infrastructure.elmaBackend.BackendUser.UnixTimeConverter.getHoursAndMinutesFromUnix;
import static infrastructure.utils.Constants.ELMA_TMS;
import static java.time.LocalDate.now;
import static java.time.format.DateTimeFormatter.ofPattern;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

@MicronautTest
@Tags({@Tag("express"), @Tag("work_calendar")})
public class WorkCalendarTests {
    @Inject
    protected ElmaBackend elmaBackend;
    @Inject
    protected WorkCalendarPage workCalendarPage;
    @Inject
    protected SectionPage sectionPage;

    @BeforeEach
    public void resetToDefault() {
        elmaBackend.deleteExclusionWorkCalendar();
        elmaBackend.defaultWorkCalendar();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "22c679bb-9b70-4d52-ae6f-74f6e04674bd", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/22c679bb-9b70-4d52-ae6f-74f6e04674bd)")
    @DisplayName("Удалить дни исключения")
    public void deleteExclusionDaysTest() {
        LocalDate exclusionDate = now().plusDays(20);
        elmaBackend.createExclusionWorkCalendar(exclusionDate);
        workCalendarPage.open("admin/worktimer");
        workCalendarPage.clickButtonDelete();
        workCalendarPage.clickButtonSave();

        assertEquals("null", elmaBackend.getExclusionWorkCalendar(),
                "День-исключения не равен null");
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "234dbde2-f41c-487f-aa09-783982e6e732", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/234dbde2-f41c-487f-aa09-783982e6e732)")
    @DisplayName("Изменить выходные дни недели")
    public void changeDaysOffWeekTest() {
        workCalendarPage.open("admin/worktimer");
        workCalendarPage.clickInputFriday();
        workCalendarPage.clickButtonSave();

        assertEquals("true", elmaBackend.getWeekendsWorkCalendar("friday"),
                "Выходные дни недели  не соответствуют ожидаемым");
        elmaBackend.defaultWorkCalendar();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "49d12cf1-0754-4a25-a8e7-ae60b2b72c5d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/49d12cf1-0754-4a25-a8e7-ae60b2b72c5d)")
    @DisplayName("Изменить продолжительность рабочего дня")
    public void changeLengthOfWorkDayTest() {
        String timeFrom = "11:00";
        String timeTo = "17:00";
        workCalendarPage.open("admin/worktimer");
        workCalendarPage.inputBeginOfWorkDay(timeFrom);
        workCalendarPage.inputFinishOfWorkDay(timeTo);
        workCalendarPage.clickButtonSave();

        assertAll(
                () -> assertEquals(timeFrom,
                        getHoursAndMinutesFromUnix(elmaBackend.getDayScheduleCalendarWorkTime("workingTime", "from"))),
                () -> assertEquals(timeTo,
                        getHoursAndMinutesFromUnix(elmaBackend.getDayScheduleCalendarWorkTime("workingTime", "to"))));
        elmaBackend.defaultWorkCalendar();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "c1c30220-1865-4fbc-a0d8-f78213f3bd87", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/c1c30220-1865-4fbc-a0d8-f78213f3bd87)")
    @DisplayName("Изменить время перерыва на обед")
    public void changeLunchBreakTimeTest() {
        String timeFrom = "11:00";
        String timeTo = "14:00";
        workCalendarPage.open("admin/worktimer");
        workCalendarPage.inputBeginOfLunchBreakTime(timeFrom);
        workCalendarPage.inputFinishOfLunchBreakTime(timeTo);
        workCalendarPage.clickButtonSave();

        assertAll(
                () -> assertEquals(timeFrom,
                        getHoursAndMinutesFromUnix(elmaBackend.getDayScheduleCalendarWorkTime("lunchTime", "from"))),
                () -> assertEquals(timeTo,
                        getHoursAndMinutesFromUnix(elmaBackend.getDayScheduleCalendarWorkTime("lunchTime", "to"))));
        elmaBackend.defaultWorkCalendar();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "b43ebbdf-b4db-4a61-89ba-89f1404cf3cc", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/b43ebbdf-b4db-4a61-89ba-89f1404cf3cc)")
    @DisplayName("Установить дни исключения - добавить выходной день")
    public void setExclusionDaysAddDayOffTest() {
        DateTimeFormatter format = ofPattern("dd.MM.yyyy");
        LocalDate date = now().plusDays(5);
        workCalendarPage.open("admin/worktimer");
        workCalendarPage.clickButtonException();
        workCalendarPage.clickCheckBoxWeekend();
        workCalendarPage.inputDateException(date.format(format));
        workCalendarPage.clickButtonSave();

        assertEquals("true", elmaBackend.getSpecialDaysData("holiday"), "Выходной день не был добавлен");
        elmaBackend.deleteExclusionWorkCalendar();
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "dbc5c685-46c9-4ba3-a287-1bfbd51c4571", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/dbc5c685-46c9-4ba3-a287-1bfbd51c4571)")
    @DisplayName("Установить дни исключения - добавить укороченный день")
    public void setExclusionDaysAddDayTest() {
        DateTimeFormatter format = ofPattern("dd.MM.yyyy");
        LocalDate date = now().plusDays(5);
        String timeFrom = "11:00";
        String timeTo = "13:00";
        workCalendarPage.open("admin/worktimer");
        workCalendarPage.clickButtonException();
        workCalendarPage.inputDateException(date.format(format));
        workCalendarPage.inputTimeFromException(timeFrom);
        workCalendarPage.inputTimeToException(timeTo);
        workCalendarPage.clickButtonSave();

        assertAll(
                () -> assertEquals(date.format(format), getDayMonthYearFromUnix(elmaBackend.getSpecialDaysData("date"))),
                () -> assertEquals(timeFrom, getHoursAndMinutesFromUnix(elmaBackend.getSpecialDaysData("from"))),
                () -> assertEquals(timeTo, getHoursAndMinutesFromUnix(elmaBackend.getSpecialDaysData("to"))));
        elmaBackend.deleteExclusionWorkCalendar();
    }
}