package e2eTests;

import infrastructure.elmaBackend.ElmaBackend;
import infrastructure.helpers.RandomString;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import io.qameta.allure.Link;
import io.qameta.allure.TmsLink;
import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Tags;
import org.junit.jupiter.api.Test;
import pages.elmaPages.TokensPage;

import static infrastructure.utils.Constants.ELMA_TMS;

@MicronautTest
@Tags({@Tag("express"), @Tag("token")})
public class TokenTests {
    @Inject
    protected TokensPage tokensPage;
    @Inject
    protected ElmaBackend elmaBackend;

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "4079e158-8fbb-47c1-bb32-ba2f7a9d5825", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/4079e158-8fbb-47c1-bb32-ba2f7a9d5825)")
    @DisplayName("Проверить создание нового токена")
    public void createNewTokenTest() {
        String tokenName = "Test" + RandomString.get(16);

        tokensPage.open("/admin/token");
        tokensPage.clickButtonToken();
        tokensPage.clickButtonAdvancedSearch();
        tokensPage.clickSelectUser();
        tokensPage.inputName(tokenName);
        tokensPage.clickButtonCreate();

        tokensPage.isTokenNameExists(tokenName);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "37e6fea6-9021-4618-aa01-3e5e1964f45d", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/37e6fea6-9021-4618-aa01-3e5e1964f45d)")
    @DisplayName("Проверить удаление токена")
    public void deleteTokenTest() {
        String tokenName = "Test" + RandomString.get(16);
        elmaBackend.createPublicApiTokenForAdmin(tokenName);

        tokensPage.open("/admin/token");
        int tokenListSize = tokensPage.getTokensCount();
        tokensPage.clickButtonDeleteToken();
        tokensPage.clickButtonOk();

        tokensPage.isTokenNamesListHaveSameSize(tokenListSize - 1);
    }

    @Test
    @Tag("Author=Hushvahtov")
    @Link(value = "f389134d-7e2c-4219-b626-e7f7903e2e52", type = ELMA_TMS)
    @TmsLink("https://cicbfrvw3tfjq.elma365.ru/test_management_system/test_plans(p:item/test_management_system/test_cases/f389134d-7e2c-4219-b626-e7f7903e2e52)")
    @DisplayName("Просмотр списка всех добавленных токенов")
    public void checkListsTokenTest() {
        String tokenName = "Test" + RandomString.get(16);
        elmaBackend.createPublicApiTokenForAdmin(tokenName);
        tokenName = "Test" + RandomString.get(16);
        elmaBackend.createPublicApiTokenForAdmin(tokenName);

        tokensPage.open("/admin/token");

        tokensPage.isTokenNamesListHaveSizeGreaterThan(1);
    }
}