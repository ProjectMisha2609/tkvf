**Ночной запуск нагрузки**  

Перед запуском Pipeline необходимо подготовить и настроит машину на которой будет запускаться нагрузка, а так же сделать предварительные действия на машине со стендом elma365.  

**Настроки машины с JMeter (на которой будем запускать нагрузку)**  

1. Скачтаь и распаковать на нее JMeter
2. Сделать файл /apache-jmeter/bin/jmeter - испольняемым  
Пример: `sudo chmod 777 /path/for/you/apache-jmeter/bin/jmeter`
3. Сделать ссылку на JMeter чтобы вызвать его можно было из любого места, а не только из папки bin  
Пример: `sudo ln -s /path/for/you/apache-jmeter/bin/jmeter /usr/local/bin/`  
4. Скачать на машину файл со скриптом run.sh и так же сделать его исполняемым
5. Подготовить сценарии нагрузки
По умолчанию названия сценариев в скрипте прописаны как Scen1.jmx Scen2.jmx Scen3.jmx
6. Создать папку load_scen и положить в нее сценарии
Как это сделать? - находясь в директории откуда будет запускаться скрипт пишем  
- `mkdir load_scen` - создали папку
- `mv Scen1.jmx Scen2.jmx Scen3.jmx load_scen/` - перенесли сценарии в папку
7. Во время запуска, сценарий сам создаст папки reports/ и report/download/

**Поднимаем nginx в докере на машине с JMeter**  

Кладем в папку пользователя конфиг для nginx - default.conf с этим конфигом nginx разрешит видеть папки и открывать и скачивать файлы из расшаренной папки.    
Команда для запуск - `docker run --name my_nginx --restart always -e TZ=Europe/Samara -v /path/for/your/default.conf:/etc/nginx/conf.d/default.conf -v /path/for/your/dir/reports/:/usr/share/nginx/html:ro -dp 80:80 nginx`  
1. `docker run --name my_nginx` - запускаем контейнер из образа `nginx:latest` и присвоим ему имя my_nginx
2. `--restart always` - перезапускает всегда в случае ошибки  
3. `-v /path/for/your/default.conf:/etc/nginx/conf.d/default.conf` - пробразываем volume (папку с файлом /path/for/your/default.conf в папку внутри контейнера /etc/nginx/conf.d/default.conf)
4. `-v /path/for/your/dir/reports/:/usr/share/nginx/html:ro` - пробрасываем папку (/path/for/your/dir/reports/ - в ней лежат наши отчеты, пробрасываем в папку внутри контейнера /usr/share/nginx/html - это и будет расшаривать nginx) :ro - говорит что только для чтения
5. `-dp 80:80` - пробрасываем порт из контейнера на хост машину 80:80
6. `-e TZ=Europe/Samara` - устанавливаем часовой пояс внутри контейнера

**Настрйока машины со стендом elma365**  

1. Установить elma365 enterprise нужной версии - указав внешние БД и сделать необходимые настройки во время установки
2. Активировать версию на 3000 пользователей
3. Создать 3000 пользователей (как это делать написано в архиве elma365_load_test_10k_users)
4. В дальнейшем версию нужно будет только обновлять (папйплан сам будет это делать)