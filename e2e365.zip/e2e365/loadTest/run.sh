#!/bin/sh

CURRENT_PATH=$(pwd)
CURRENT_DATE=$(date +"%d%m%Y_%H%M%S")
SCEN_ONE='Scen1'
SCEN_TWO='Scen2'
SCEN_THR='Scen3'
USER_CSV='login1.txt'
# Проверям что существует директоря отчетов, если ее нет то создаем ее
if ! [ -d $CURRENT_PATH/reports/ ];then
    echo "GO TO CREATE DIR reports"
    mkdir $CURRENT_PATH/reports/
fi
PATH_REPORTS=$CURRENT_PATH/reports
# Проверяем что существет директория с отчетами для загрузки, если ее нет то создаем 
if ! [ -d $CURRENT_PATH/reports/downloads ];then
    echo "GO TO CREATE DIR downloads"
    mkdir $CURRENT_PATH/reports/downloads/
fi
PATH_DOWNLOADS_REPORT=$PATH_REPORTS/downloads
# Проверяем что существует файл с пользоавтелями
if ! [ -f $CURRENT_PATH/$USER_CSV ];then
    echo -e "\033[1;31mNOT FOUND CSV USERS FILE login1.txt\033[0m"
    exit 1
fi
# Функция для проверки существования папки со сценариями
checScenDir () {
    if ! [ -d $CURRENT_PATH/load_scen/ ];then
        echo -e "\033[1;31mNOT FOUND LOAD TEST SCENS DIR load_scen\033[0m"
        exit 1
    fi
}
# Функция для проверки существования сценария в качестве аргумента передаем название сценария
checkScen () {
    if ! [ -f $CURRENT_PATH/load_scen/$1.jmx ];then
        echo -e "\033[1;31mNOT FOUND LOAD TEST SCEN $1 IN DIR load_scen\033[0m"
        exit 1
    fi
}
# Проверям что нагрузочный тест прошел успешно и если все ок то создаем архив для загрузки, если нет то говори что все плохо
# В качестве аргумента принимает название сценария
checkExitStatus () {
    if [ $? -ne 0 ];then
        echo -e "\033[1;31mFAILED $1 RUN!\033[0m"
    else
        echo -e "\033[1;32mSUCCESS $1 RUN!\033[0m"
        echo -e "\033[1;32mGOING CREATE REPORT ARCHIVE $1\033[0m"
        tar -czvf $PATH_DOWNLOADS_REPORT/download_$1_$CURRENT_DATE.tar.gz $PATH_REPORTS/$1-$CURRENT_DATE/ $PATH_REPORTS/$1-$CURRENT_DATE.jtl
        if [ $? -ne 0 ];then
            echo -e "\033[1;31mFAILED CREATE ARCHIVE $1\033[0m"
        else
            echo -e "\033[1;32mARCHIVE CREATED$1\033[0m"
        fi
    fi
}
# Удаляем не нужные файлы после прохождения теста
cleanAfterTest () {
    echo "go to Clean after Load Test"
    if [ -f $CURRENT_PATH/jmeter.log ];then
        echo "delete jmeter.log"
        rm $CURRENT_PATH/jmeter.log
    fi

    if [ -f $PATH_REPORTS/$1-$CURRENT_DATE.jtl ];then
        echo "delete *.jtl files"
        rm $PATH_REPORTS/$1-$CURRENT_DATE.jtl
    fi
}
# Запуск нагрузочных тестов
checScenDir                 # Эту проверку надо вызывать только 1 раз перед тестами
checkScen $SCEN_ONE         # Эту проверку надо вызвать перед каждым тестом
echo "LOAD TEST RUN"        # Это вызывается 1 раз перед первым тестом
# Запускаем первый сценарий
jmeter -n -t $CURRENT_PATH/load_scen/$SCEN_ONE.jmx -l $PATH_REPORTS/$SCEN_ONE-$CURRENT_DATE.jtl -e -o $PATH_REPORTS/$SCEN_ONE-$CURRENT_DATE/
checkExitStatus $SCEN_ONE   # Вызывать эту функцию после каждого теста
cleanAfterTest $SCEN_ONE    # Вызывать эту функцию после каждого теста
# Запускаем второй сценарий
checkScen $SCEN_TWO
jmeter -n -t $CURRENT_PATH/load_scen/$SCEN_TWO.jmx -l $PATH_REPORTS/$SCEN_TWO-$CURRENT_DATE.jtl -e -o $PATH_REPORTS/$SCEN_TWO-$CURRENT_DATE/
checkExitStatus $SCEN_TWO
cleanAfterTest $SCEN_TWO
# Запускаем третий сценарий
checkScen $SCEN_THR
jmeter -n -t $CURRENT_PATH/load_scen/$SCEN_THR.jmx -l $PATH_REPORTS/$SCEN_THR-$CURRENT_DATE.jtl -e -o $PATH_REPORTS/$SCEN_THR-$CURRENT_DATE/
checkExitStatus $SCEN_THR
cleanAfterTest $SCEN_THR