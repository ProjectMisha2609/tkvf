///usr/local/go/bin/go run $0 $@; exit $?
package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
	"time"
)

var robotToken = ""
var jobToken = ""

//на вход получает action (pipeline|wait|file)
//и если action pipeline то еще сервисы и ветки вида serviceName=branchName,serviceName=branchName
func main() {
	pipelineHandlerArgs := parseArgs()
	log.Println(pipelineHandlerArgs)
	robotToken = pipelineHandlerArgs.robotToken
	jobToken = pipelineHandlerArgs.jobToken
	if pipelineHandlerArgs.action == "pipeline" {
		runPipelines(pipelineHandlerArgs.servicesAndBranches,
			pipelineHandlerArgs.issueNumber,
			pipelineHandlerArgs.ciJobId,
			pipelineHandlerArgs.ciProjectId)
	}
	if pipelineHandlerArgs.action == "wait" {
		waitForTestsIsDone(pipelineHandlerArgs.testRunPipelineId)
	}
	if pipelineHandlerArgs.action == "deploy" {
		deploy(pipelineHandlerArgs.parentJobId, pipelineHandlerArgs.parentProjectId)
	}
}

type PipelineHandlerArgs struct {
	action              string
	robotToken          string
	jobToken            string
	parentProjectId     string
	parentJobId         string
	testRunPipelineId   string
	servicesAndBranches string
	ciJobId             string
	ciProjectId         string
	issueNumber         string
}

func parseArgs() PipelineHandlerArgs {
	action := flag.String("action", "none", "pipeline or wait or file")
	robotToken := flag.String("robotToken", "none", "pass token here")
	jobToken := flag.String("jobToken", "none", "pass token here")
	parentProjectId := flag.String("parentProjectId", "none", "parent project id")
	parentJobId := flag.String("parentJobId", "none", "parent job id")
	testRunPipelineId := flag.String("testRunPipelineId", "none", "pipeline id that is executing e2e e2eTests")
	ciJobId := flag.String("ciJobId", "none", "current job id")
	ciProjectId := flag.String("ciProjectId", "none", "current pipeline project id")
	servicesAndBranches := flag.String("servicesAndBranches", "none", "pipeline handler will deploy elma365 using these services and branches if these ones are presented")
	issueNumber := flag.String("issueNumber", "none", "pipeline handler will deploy elma365 using services and branches from an issue if this one is presented")
	flag.Parse()

	return PipelineHandlerArgs{
		action:              *action,
		robotToken:          *robotToken,
		jobToken:            *jobToken,
		parentProjectId:     *parentProjectId,
		parentJobId:         *parentJobId,
		testRunPipelineId:   *testRunPipelineId,
		ciJobId:             *ciJobId,
		ciProjectId:         *ciProjectId,
		servicesAndBranches: *servicesAndBranches,
		issueNumber:         *issueNumber,
	}
}

func validate(serviceBranchPairs map[string]string) {
	if len(serviceBranchPairs) == 0 {
		log.Fatalf("specify issue number(key=issue,value=XXXX where X is digit) or services and branches")
	}
	for serviceName, branchName := range serviceBranchPairs {
		if branchName == "develop" {
			log.Fatal("cannot run pipeline on develop branch because of automerge")
		}
		if _, ok := allServicesMap[serviceName]; !ok {
			log.Fatal(fmt.Sprintf("do we really have service \"%s\"? maybe you should put it to allServicesMap", serviceName))
		}
	}
}

func mapFrom(servicesAndBranches string) map[string]string {
	var serviceBranchPairs = make(map[string]string)
	serviceBranchStringPairs := getServiceBranchPairs(servicesAndBranches)
	for _, serviceBranchPair := range serviceBranchStringPairs {
		serviceName := toProjectName(getServiceName(serviceBranchPair))
		branchName := getBranchName(serviceBranchPair)
		serviceBranchPairs[serviceName] = branchName
	}

	return serviceBranchPairs
}

//deploy ждет появления докер образов в приватном реджистри, формирует values файл
//с помощью которого будет произведена подмена образов для тестируемых сервисов
// формирует опции для квака и запускает деплой через него же
func deploy(parentJobId string, parentProjectId string) {
	pipelines := getPipelines(parentJobId, parentProjectId)
	buildJobs := getBuildJobs(pipelines)
	waitForImagesIsBuilt(buildJobs)
	imageNamesByProjectIds := getImageNamesByProjectIds(buildJobs)
	substitutionFileText := ""
	branches := "--branches="
	for _, pipeline := range pipelines {
		serviceName := toServiceName(pipeline.Project.Name)
		branches += fmt.Sprintf("%s=%s,", serviceName, pipeline.Ref)
		substitutionFileText += fmt.Sprintf("\n%s:\n  images:", serviceName)
		for projectId, imageNames := range imageNamesByProjectIds {
			if projectId == pipeline.Project.ID {
				for _, imageName := range imageNames {
					substitutionFileText += fmt.Sprintf("\n    %s", imageName)
				}
			}
		}
	}
	substitutionFileText = substitutionFileText[1:]
	log.Println(substitutionFileText)
	branches = branches[:len(branches)-1]
	valuesFileName := "imageSubstitutionFile"
	writeFile(valuesFileName, substitutionFileText)
	cmd := exec.Command("quack", "elma365", "deploy", "--retry=5", branches, "--values-path="+valuesFileName)
	log.Println(cmd.Args)
	var outBuffer, errBuffer bytes.Buffer
	cmd.Stdout = &outBuffer
	cmd.Stderr = &errBuffer
	deployStartTime := time.Now()
	err := cmd.Run()
	log.Println(errBuffer.String())
	log.Println("deploy took ", time.Since(deployStartTime))
	if err != nil {
		log.Fatal(err)
	}
}

func getBuildJobs(pipelines []Pipeline) map[int]int {
	jobsByProject := make(map[int]int)
	for _, pipeline := range pipelines {
		projectId := pipeline.Project.ID
		getJobsResponseBody := sendGetToGitlab(fmt.Sprintf("projects/%d/pipelines/%d/jobs", projectId, pipeline.ID))
		var jobs Jobs
		json.Unmarshal(getJobsResponseBody, &jobs)
		for _, job := range jobs {
			if job.Stage == "build" {
				jobsByProject[job.ID] = projectId
			}
		}
	}

	return jobsByProject
}

func waitForImagesIsBuilt(buildJobs map[int]int) {
	builds := make(map[int]int)
	for jobId, projectId := range buildJobs {
		builds[jobId] = projectId
	}
	waitFor(20, func() bool {
		log.Println("------------------------------------")
		log.Println(builds)
		log.Println("------------------------------------")
		for jobId, projectId := range builds {
			getSingleJobResponseBody := sendGetToGitlab(fmt.Sprintf("projects/%d/jobs/%d", projectId, jobId))
			var job Job
			json.Unmarshal(getSingleJobResponseBody, &job)
			jobStatus := job.Status
			jobWebUrl := job.WebURL
			if jobStatus == Failed {
				log.Fatal(fmt.Sprintf("docker build job is failed %s", jobWebUrl))
			}
			if jobStatus == Skipped {
				log.Fatal(fmt.Sprintf("docker build job is skipped, it means one or more previous jobs has failed %s", jobWebUrl))
			}
			if jobStatus == Success {
				log.Println("deleted entry for project: ", projectId, "and job id: ", jobId)
				delete(builds, jobId)
				log.Println("docker image build job succeeded ", jobWebUrl)
			}
		}
		if len(builds) == 0 {
			return true
		}
		return false
	})
}

func getImageNamesByProjectIds(buildJobs map[int]int) map[int][]string {
	imageNamesByProjectId := make(map[int][]string)
	for jobId, projectId := range buildJobs {
		imageName := getImageName(projectId, jobId)
		if _, ok := imageNamesByProjectId[projectId]; !ok {
			imageNamesByProjectId[projectId] = []string{}
		}
		imageNamesByProjectId[projectId] = append(imageNamesByProjectId[projectId], imageName)
	}

	return imageNamesByProjectId
}

func getImageName(projectId int, jobId int) string {
	branchImagePath := string(sendGetToGitlab(fmt.Sprintf("projects/%d/jobs/%d/artifacts/branchImage", projectId, jobId)))
	log.Println("branchImagePath = " + branchImagePath)
	imageName := getFirstGroup("\\/(\\w+):", branchImagePath)
	imageTag := getFirstGroup(":(branch-.*)", branchImagePath)

	return imageName + ": " + imageTag
}

func getPipelines(parentJobId string, parentProjectId string) []Pipeline {
	log.Println("parentJobId = " + parentJobId)
	log.Println("parentProjectId = " + parentProjectId)
	pipelinesIdsBytes := sendGetToGitlab(fmt.Sprintf("projects/%s/jobs/%s/artifacts/childPipelinesData", parentProjectId, parentJobId))
	log.Println("pipelines data that extracted from parent pipeline artifacts(runPipelines action)------------\n ", string(pipelinesIdsBytes))
	var pipelines []Pipeline
	json.Unmarshal(pipelinesIdsBytes, &pipelines)

	return pipelines
}

//waitForTestsIsDone ожидает окончания пайплайна в проекте с тестами
//и возвращает ошибку если тесты завершились неуспешно
func waitForTestsIsDone(pipelineId string) {
	e2e365ProjectId := 604
	pipelineStatus := waitForPipelineIsDone(e2e365ProjectId, pipelineId)
	if pipelineStatus != Success {
		os.Exit(1)
	}
}

// runPipelines запускает пайплайны проекта с тестами и проектов указанных при старте тестов в переменную sb
func runPipelines(servicesAndBranches, issueNumber, ciJobId, ciProjectId string) {
	mergeRequests := getMergeRequests(servicesAndBranches, issueNumber)
	e2e365ProjectId := 604
	variables := map[string]string{
		"PARENT_JOB_ID":     ciJobId,
		"PARENT_PROJECT_ID": ciProjectId}
	testsPipeline := triggerProjectPipeline("master", e2e365ProjectId, variables)
	log.Println("e2eTests pipeline was triggered with variables", "\n", variables)
	var childPipelines []Pipeline
	for _, mergeRequest := range mergeRequests {
		variables = make(map[string]string)
		variables["TESTS_PIPELINE_ID"] = strconv.Itoa(testsPipeline.ID)
		if mergeRequest.HeadPipeline.Status == Success {
			variables["SMOKE_ONLY"] = "true"
		}
		projectId := mergeRequest.ProjectID
		sourceBranch := mergeRequest.SourceBranch
		childPipeline := triggerProjectPipeline(sourceBranch, projectId, variables)
		projectName := getProjectNameById(projectId)
		log.Println(projectName, " pipeline was triggered with variables", "\n", variables)
		childPipeline.Ref = sourceBranch
		childPipeline.Project = Project{
			ID:   projectId,
			Name: projectName,
		}
		childPipelines = append(childPipelines, childPipeline)
	}
	childPipelinesJsonBytes, _ := json.Marshal(childPipelines)
	writeFile("childPipelinesData", string(childPipelinesJsonBytes))
	log.Println("pipeline ended with artifact", "\n", string(childPipelinesJsonBytes))
}

func getMergeRequests(servicesAndBranches string, issueNumber string) []MergeRequest {
	var mergeRequests []MergeRequest
	if issueNumber != "" {
		return findMergeRequestsByIssueNumber(issueNumber)
	}
	log.Println("sb = " + servicesAndBranches)
	serviceBranchPairs := mapFrom(servicesAndBranches)
	validate(serviceBranchPairs)
	for serviceName, branchName := range serviceBranchPairs {
		mergeRequest := MergeRequest{
			ProjectID:    getProjectIdByProjectName(toProjectName(serviceName)),
			SourceBranch: branchName,
			HeadPipeline: HeadPipeline{
				Status: "failed",
			},
		}

		mergeRequests = append(mergeRequests, mergeRequest)
	}

	return mergeRequests
}

func findMergeRequestsByIssueNumber(issueNumber string) []MergeRequest {
	var elma365IssueInfo Elma365IssueInfo
	waitFor(6, func() bool {
		releaseDashboardGetIssueInfoRequestUrl := "https://rd-365.elewise.com/api/issues?index=" + issueNumber
		getElma365IssueInfoResponseBytes := sendGet(releaseDashboardGetIssueInfoRequestUrl)
		json.Unmarshal(getElma365IssueInfoResponseBytes, &elma365IssueInfo)
		if len(elma365IssueInfo) == 0 {
			return false
		}
		return true
	})

	var mergeRequests []MergeRequest
	log.Println("filtered MRs with status is opened and are elma365 service")
	for _, mergeRequestFromReleaseDashboard := range elma365IssueInfo[0].MergeRequests {
		getSingleMergeRequestResponseBytes := sendGetToGitlab(fmt.Sprintf("projects/%d/merge_requests/%d", mergeRequestFromReleaseDashboard.ProjectID, mergeRequestFromReleaseDashboard.Iid))
		var mergeRequest MergeRequest
		json.Unmarshal(getSingleMergeRequestResponseBytes, &mergeRequest)
		isServiceOfElma365App := false
		for _, projectName := range allServicesMap {
			if projectName == getProjectNameById(mergeRequest.ProjectID) {
				isServiceOfElma365App = true
				break
			}
		}
		if mergeRequest.State == "opened" && isServiceOfElma365App {
			mergeRequests = append(mergeRequests, mergeRequest)
			log.Println(mergeRequest.WebUrl)
		}
	}

	return mergeRequests
}

func writeFile(fileName string, data string) {
	file, _ := os.OpenFile(fileName, os.O_RDWR|os.O_CREATE|os.O_TRUNC, 400)
	file.Write([]byte(data))
	file.Close()
}

func waitForPipelineIsDone(projectId int, pipelineId string) string {
	var pipeline Pipeline
	pipelineStatus := pipeline.Status

	waitFor(15, func() bool {
		getSinglePipelineBody := sendGetToGitlab(fmt.Sprintf("projects/%d/pipelines/%s", projectId, pipelineId))
		json.Unmarshal(getSinglePipelineBody, &pipeline)
		pipelineStatus = pipeline.Status
		if pipelineStatus == Success || pipelineStatus == Failed || pipelineStatus == Canceled || pipelineStatus == Skipped {
			return true
		}
		return false
	})

	return pipelineStatus

}

func waitFor(minutes time.Duration, function func() bool) {
	totalWaitDuration := 60 * minutes * time.Second
	defaultWaitTime := 10
	defaultIterationWaitDuration := time.Duration(defaultWaitTime) * time.Second
	iterationsCount := int(totalWaitDuration / defaultIterationWaitDuration)
	for i := 0; i < iterationsCount; i++ {
		time.Sleep(defaultIterationWaitDuration)
		log.Printf("waiting time = %d seconds\n", i*defaultWaitTime)
		if function() == true {
			return
		}
	}
	log.Fatal("could not wait for the condition")
}

func getServiceBranchPairs(servicesAndBranches string) []string {
	regexForServiceBranchPairs, _ := regexp.Compile("((?:\\w|=|/|-+)+),?")
	serviceBranchPairsSubmatch := regexForServiceBranchPairs.FindAllStringSubmatch(servicesAndBranches, -1)
	var serviceBranchPairs []string
	for _, serviceBranchPairSubmatch := range serviceBranchPairsSubmatch {
		serviceBranchPairs = append(serviceBranchPairs, serviceBranchPairSubmatch[1])
	}

	return serviceBranchPairs
}

func getBranchName(serviceBranchPair string) string {
	return getFirstGroup("=(.*)", serviceBranchPair)
}

func getServiceName(serviceBranchPair string) string {
	return getFirstGroup("(.*)=", serviceBranchPair)
}

func getFirstGroup(regexString string, source string) string {
	regex, _ := regexp.Compile(regexString)
	return regex.FindStringSubmatch(source)[1]
}

func triggerProjectPipeline(branchName string, projectId int, variables map[string]string) Pipeline {
	formData := url.Values{}
	formData.Set("token", jobToken)
	formData.Set("ref", branchName)
	for key, value := range variables {
		formData.Set(fmt.Sprintf("variables[%s]", key), value)
	}
	triggerPipelineResponseBody := sendPostToGitlab(fmt.Sprintf("projects/%d/trigger/pipeline", projectId), formData)
	var pipeline Pipeline
	json.Unmarshal(triggerPipelineResponseBody, &pipeline)

	return pipeline
}

func getProjectNameById(id int) string {
	getProjectResponseBody := sendGetToGitlab(fmt.Sprintf("projects/%d", id))
	var project Project
	json.Unmarshal(getProjectResponseBody, &project)

	return project.Name
}

func getProjectIdByProjectName(projectName string) int {
	searchProjectsResponseBody := sendGetToGitlab(fmt.Sprintf("groups/11/search?scope=projects&search=%s", projectName))
	var projects Projects
	json.Unmarshal(searchProjectsResponseBody, &projects)
	for _, project := range projects {
		if project.Name == projectName {
			return project.ID
		}
	}
	log.Fatalf("could not find id for project %s", projectName)
	return 0
}

func toServiceName(projectName string) string {
	for serviceName, storedProjectName := range allServicesMap {
		if serviceName != storedProjectName && projectName == storedProjectName {
			projectName = serviceName
			log.Printf("going to use service name(%s) instead of project name(%s)\n", serviceName, storedProjectName)
		}
	}
	return projectName
}

func toProjectName(serviceName string) string {
	if projectName, ok := allServicesMap[serviceName]; ok {
		if serviceName != projectName {
			serviceName = projectName
			log.Printf("going to use project name(%s) instead of service name(%s)\n", projectName, serviceName)
		}
	}
	return serviceName
}

func sendGet(requestUrl string) []byte {
	request := createRequest(requestUrl, "GET", nil)
	return sendRequest(request)
}

var gitlabAddr = "https://git.elewise.com/api/v4/"

func sendGetToGitlab(requestPath string) []byte {
	requestUrl := gitlabAddr + requestPath
	request := createRequest(requestUrl, "GET", nil)
	request.Header.Set("PRIVATE-TOKEN", robotToken)
	return sendRequest(request)
}

func sendPostToGitlab(requestPath string, bodyJson url.Values) []byte {
	requestUrl := gitlabAddr + requestPath
	request := createRequest(requestUrl, "POST", bodyJson)
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	return sendRequest(request)
}

func createRequest(requestPath string, method string, body url.Values) *http.Request {
	request, _ := http.NewRequest(method, requestPath, strings.NewReader(body.Encode()))
	return request
}

func sendRequest(request *http.Request) []byte {
	response, _ := (&http.Client{}).Do(request)
	defer response.Body.Close()
	body, _ := ioutil.ReadAll(response.Body)
	log.Println(string(body))
	return body
}

type Pipeline struct {
	ID      int     `json:"id"`
	Status  string  `json:"status"`
	Ref     string  `json:"ref"`
	Project Project `json:"project"`
}

type Projects []Project

type Project struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}

type Jobs []Job

type Job struct {
	ID     int    `json:"id"`
	Status string `json:"status"`
	Stage  string `json:"stage"`
	WebURL string `json:"web_url"`
}

type Elma365IssueInfo []struct {
	WebURL         string      `json:"webUrl"`
	ID             int         `json:"id"`
	ExternalID     string      `json:"externalId"`
	Name           string      `json:"name"`
	Description    interface{} `json:"description"`
	Index          int         `json:"index"`
	Status         int         `json:"status"`
	Type           int         `json:"type"`
	BoardPriority  int         `json:"boardPriority"`
	ProductOwnerID string      `json:"productOwnerId"`
	ReleaseID      interface{} `json:"releaseId"`
	PlanReleaseID  string      `json:"planReleaseId"`
	TeamID         string      `json:"teamId"`
	MergeRequests  []struct {
		ID                 int         `json:"id"`
		ExternalID         int         `json:"externalId"`
		Iid                int         `json:"iid"`
		ProjectID          int         `json:"projectId"`
		Title              string      `json:"title"`
		Description        string      `json:"description"`
		State              int         `json:"state"`
		WebURL             string      `json:"webUrl"`
		SourceBranch       string      `json:"sourceBranch"`
		TargetBranch       string      `json:"targetBranch"`
		RelativeReferences string      `json:"relativeReferences"`
		Sha                string      `json:"sha"`
		MergeCommitSha     string      `json:"mergeCommitSha"`
		SquashCommitSha    interface{} `json:"squashCommitSha"`
		AuthorID           string      `json:"authorId"`
		AuthorUserName     string      `json:"authorUserName"`
		AssigneeID         string      `json:"assigneeId"`
		AssigneeUserName   string      `json:"assigneeUserName"`
		Reviewers          string      `json:"reviewers"`
	} `json:"mergeRequests"`
}

type MergeRequest struct {
	ID           int          `json:"id"`
	Iid          int          `json:"iid"`
	ProjectID    int          `json:"project_id"`
	State        string       `json:"state"`
	SourceBranch string       `json:"source_branch"`
	HeadPipeline HeadPipeline `json:"head_pipeline"`
	WebUrl       string       `json:"web_url"`
}

type HeadPipeline struct {
	Status string `json:"status"`
}

var allServicesMap = map[string]string{
	"auth":              "serv_auth",
	"balancer":          "balancer",
	"billing":           "billing",
	"calculator":        "calculator",
	"chat":              "chat",
	"collector":         "collector",
	"convertik":         "convertik",
	"deploy":            "deploy",
	"diskjockey":        "diskjockey",
	"docflow":           "docflow",
	"feeder":            "feeder",
	"front":             "front",
	"integrations":      "integrations",
	"mailer":            "mailer",
	"main":              "main",
	"notifier":          "notifier",
	"processor":         "processor",
	"scheduler":         "scheduler",
	"settings":          "settings",
	"templater":         "templater",
	"web-forms":         "web-forms",
	"widget":            "widget",
	"worker":            "serv_worker",
	"vahter":            "vahter",
	"picasso":           "picasso",
	"exchange":          "exchange",
	"messengers":        "messengers",
	"event-bus":         "event_bus",
	"dup-detector":      "dup-detector",
	"support-messenger": "support-messenger",
	"elmabot-proxy":     "elmabot-proxy",
	"contractor":        "contractor",
}

const (
	Success  = "success"
	Failed   = "failed"
	Canceled = "canceled"
	Skipped  = "skipped"
)
